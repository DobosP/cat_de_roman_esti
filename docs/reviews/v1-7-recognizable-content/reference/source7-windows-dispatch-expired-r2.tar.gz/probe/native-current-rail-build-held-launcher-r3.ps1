param([Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$SourceBoundarySha)
$ErrorActionPreference='Stop'
$taskScratch='C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7'
$taskPython='C:/Users/Paul Work/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe'
$publisher=Join-Path $taskScratch 'probe/native-current-rail-build-per-lane-late-admission-r3.py'
$boundary=Join-Path $taskScratch 'current-rail-build-per-lane-source-boundary-r3.json'
if ((Get-FileHash -LiteralPath $publisher -Algorithm SHA256).Hash.ToLowerInvariant() -ne '095b40b14911635fc295b18554a0e855f687c0a5cf72693ff758b7d69ee4b0b9') { throw 'publisher drift' }
if ((Get-FileHash -LiteralPath $boundary -Algorithm SHA256).Hash.ToLowerInvariant() -ne $SourceBoundarySha) { throw 'source boundary drift' }
& $taskPython -X utf8 -B $publisher "$PID" $SourceBoundarySha
if ($LASTEXITCODE -ne 0) { throw 'publisher refused' }
$specPath=Join-Path $taskScratch 'probe/native-current-rail-build-spec-r3.json'
$admissionPath=Join-Path $taskScratch 'native-current-rail-build-actual-admission-r3.json'
$specHash=(Get-FileHash -LiteralPath $specPath -Algorithm SHA256).Hash.ToLowerInvariant()
$admissionHash=(Get-FileHash -LiteralPath $admissionPath -Algorithm SHA256).Hash.ToLowerInvariant()
$actualSpec=Get-Content -LiteralPath $specPath -Raw | ConvertFrom-Json
$dispatchMarker=Join-Path $taskScratch 'probe/native-current-rail-build-dispatch-approval-r3.json'
$holdUntil=$actualSpec.deadline_epoch-195
Write-Output ('HELD actual launcher PID='+$PID+' spec='+$specHash+' admission='+$admissionHash)
while (-not (Test-Path -LiteralPath $dispatchMarker)) {
 $now=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000
 if ($now -ge $holdUntil -or $now -ge $actualSpec.deadline_epoch-195) { throw 'actual dispatch review hold expired' }
 Start-Sleep -Milliseconds 250
}
$approval=Get-Content -LiteralPath $dispatchMarker -Raw | ConvertFrom-Json
if ($approval.spec_sha256 -ne $specHash -or $approval.admission_sha256 -ne $admissionHash -or $approval.reviewer -ne '/root/continuation_audit' -or $approval.verdict -ne 'ACCEPT_ACTUAL_CURRENT_RAIL_BUILD_DISPATCH_ONLY' -or $approval.reviewed_held_launcher_pid -ne $PID) { throw 'actual review marker refused' }
if ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000 -ge $holdUntil) { throw 'immutable launch cutoff expired before compiler release' }
& $taskPython -X utf8 -B (Join-Path $taskScratch 'probe/native-current-rail-build-windows-r1.py') $specPath $specHash
if ($LASTEXITCODE -ne 0) { throw 'owned current rail build failed' }
