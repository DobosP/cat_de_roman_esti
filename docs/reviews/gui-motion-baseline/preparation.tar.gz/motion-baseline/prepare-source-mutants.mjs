// Build-free sensitivity scaffolds. Never overlays or changes the frozen tree.
import {readFileSync,writeFileSync,mkdirSync} from "node:fs";
import {createHash} from "node:crypto";
import assert from "node:assert/strict";
const rows=[];
for(const name of ["Intrusul","Perechi"]){
 const path="frontend/src/screens/"+name+".tsx";
 const original=readFileSync(new URL("./frozen/"+path,import.meta.url),"utf8");
 for(const mode of ["presence-always-true","actions-lock-only-disabled","cancel-at-exit-disabled"]){
  const from=mode==="presence-always-true"?"const isPresent = useIsPresent();":mode==="actions-lock-only-disabled"?"const actionsLocked = !isPresent ||":"if (!isPresent) {";
  const to=mode==="presence-always-true"?"const isPresent = useIsPresent() || true;":mode==="actions-lock-only-disabled"?"const actionsLocked =":"if (false) { // scratch cancellation mutant";
  assert.equal(original.split(from).length-1,1,"exact mutation site required");
  const out=original.replace(from,to);const dest=new URL("./mutants/"+name+"-"+mode+".tsx",import.meta.url);
  writeFileSync(dest,out);
  rows.push({source:path,mode,file:dest.pathname,from,to,sha256:createHash("sha256").update(out).digest("hex"),compiled:false,browser_executed:false,combined_mutant:mode==="presence-always-true"});
 }
}
writeFileSync(new URL("./mutants/manifest.json",import.meta.url),JSON.stringify({provisional:true,source_mutants_unexecuted:true,reason:"No source-build dependency set available; frozen bundle browser controls are separate.",variants:rows},null,2)+"\n");
console.log("6 screen-only source mutant scaffolds; uncompiled/unexecuted; asyncControl/scores/API unchanged");
