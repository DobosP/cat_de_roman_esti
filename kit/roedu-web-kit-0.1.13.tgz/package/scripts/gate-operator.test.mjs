// Synthetic owner-identity contracts for the wrapper's OPERATOR_FUNCTIONS block (PROGRAM E8, ADR-0024); never a gate pass.
import assert from 'node:assert/strict';
import { test } from 'node:test';
import * as fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const template = fs.readFileSync(path.resolve(here, '../templates/gate.sh'));
assert(template.equals(fs.readFileSync(path.resolve(here, '../../scripts/gate.sh'))), 'wrapper and template must stay byte-identical');
const wrapper = template.toString('utf8');
const begin = '# OPERATOR_FUNCTIONS_BEGIN\n', end = '# OPERATOR_FUNCTIONS_END';
assert.equal(wrapper.split(begin).length, 2); assert.equal(wrapper.split(end).length, 2);
const functions = wrapper.slice(wrapper.indexOf(begin) + begin.length, wrapper.indexOf(end));
function block(label) {
  const start = wrapper.indexOf(`<<'${label}'\n`), stop = wrapper.indexOf(`\n${label}\n`, start);
  assert(start >= 0 && stop > start, `missing trusted inline ${label}`);
  return wrapper.slice(start + label.length + 5, stop);
}
// Values travel as positional arguments, never interpolated into the script: quoting is part of what is under test.
function shell(body, args = [], env = {}) {
  const output = spawnSync('bash', ['--noprofile', '--norc', '-s', '--', ...args], { input: `set -euo pipefail\n${functions}\n${body}\n`, encoding: 'utf8', env: { PATH: process.env.PATH, ...env } });
  assert(!output.error, output.error?.message);
  return output;
}
// Non-ASCII letters and digits (ADR-0024 review N1): under a UTF-8 locale whose collation orders them inside a-z/0-9 (glibc
// en_US/ro_RO; not C.UTF-8, which collates by code point) bash's [a-z0-9] accepts them unless the match runs under LC_ALL=C.
const nonAscii = ['agent:aéc', 'agent:a²c', 'agent:ａｂｃ', 'agent:é', 'agent:codéx-1', 'agent:ｐaul'];
const accepted = ['paul', 'agent:codex', 'agent:claude-code', 'agent:a1', `agent:${'a'.repeat(40)}`];
const refused = ['', 'agent:Bad', 'agent:', 'other', 'Paul', 'root', 'agent:a', 'agent:-codex', 'agent:co_dex', 'agent:codex ', ' paul', 'paul\n', 'agent:codex\n', `agent:${'a'.repeat(41)}`, 'agent:codex/x', 'agent:claude code', ...nonAscii];

test('owner identity accepts paul and agent:<name> only', () => {
  for (const op of accepted) assert.equal(shell('owner_operator "$1"', [op]).status, 0, JSON.stringify(op));
  for (const op of refused) assert.notEqual(shell('owner_operator "$1"', [op]).status, 0, JSON.stringify(op));
});
// `shell` runs bash with only PATH, so every case above is a C-locale case. The UTF-8 cases below use each UTF-8 locale the
// host actually has (`locale -a`), with a control that proves the locale took effect; a locale that silently fell back to C
// would make the case vacuous, as would an image without any UTF-8 locale.
const installed = spawnSync('locale', ['-a'], { encoding: 'utf8' });
const utf8Locales = (installed.stdout ?? '').split('\n').map(line => line.trim()).filter(line => /\.utf-?8$/i.test(line));
test('owner identity is ASCII-only under every installed UTF-8 locale, and the C scope ends with the function', () => {
  assert.equal(installed.status, 0, installed.stderr);
  assert(utf8Locales.length > 0, `no UTF-8 locale installed; locale -a: ${JSON.stringify(installed.stdout)}`);
  for (const locale of utf8Locales) for (const env of [{ LC_ALL: locale, LANG: locale }, { LANG: locale }]) {
    const label = `${locale} ${JSON.stringify(env)}`;
    const control = shell('printf %s "${#1}"', ['é'], env);
    assert.equal(control.status, 0, `${label}: ${control.stderr}`); assert.equal(control.stdout, '1', `${label}: locale not in effect (é is one character under UTF-8, two bytes under C): ${control.stderr}`);
    for (const op of nonAscii) assert.notEqual(shell('owner_operator "$1"', [op], env).status, 0, `${label} ${JSON.stringify(op)}`);
    for (const op of accepted) assert.equal(shell('owner_operator "$1"', [op], env).status, 0, `${label} ${JSON.stringify(op)}`);
    for (const op of refused) assert.notEqual(shell('owner_operator "$1"', [op], env).status, 0, `${label} ${JSON.stringify(op)}`);
    const after = shell('owner_operator "$1" || :; owner_operator paul; printf %s "${#1}"', ['é'], env);
    assert.equal(after.status, 0, `${label}: ${after.stderr}`); assert.equal(after.stdout, '1', `${label}: the caller's locale must be intact after owner_operator`);
  }
  console.log(`gate-operator: UTF-8 locales exercised: ${utf8Locales.join(', ')}`);
});
test('the owner identity match is scoped to the C locale in the wrapper text', () => {
  assert(functions.includes('owner_operator() { local LC_ALL=C; [ "$1" = paul ] || [[ $1 =~ ^agent:[a-z0-9][a-z0-9-]{1,39}$ ]]; }'), 'LC_ALL=C is local to owner_operator');
});
test('wrapper refuses any other GATE_OPERATOR before the target switch and keeps owner targets and --keep behind it', () => {
  assert(wrapper.includes(`[ -z "$op" ] || owner_operator "$op" || die "GATE_OPERATOR '$op' is neither paul nor agent:<name>`));
  assert(wrapper.includes(`qualify|shell|toolchain|trust) [ -n "$op" ] || die "'$target' is owner-only (GATE_OPERATOR=paul or GATE_OPERATOR=agent:<name>)"`));
  assert(wrapper.includes(`[ "$keep" = 0 ] || [ -n "$op" ] || die "--keep is owner-only`));
  assert(!wrapper.includes('[ "$op" = paul ]'), 'no remaining paul-literal owner comparison');
  assert.equal(wrapper.indexOf('owner_operator "$op"') < wrapper.indexOf('case "$target" in unit|full|gen|deps'), true, 'identity is validated before any target work');
});
test('trust pin line carries op= and the pin store is still only an existence check', () => {
  const sha = 'c'.repeat(40);
  for (const op of ['paul', 'agent:codex']) {
    const line = shell('trust_pin_line "$1" "$2" "$3" "$4"', ['roedu-ui', 'feat__fixture', sha, op]);
    assert.equal(line.status, 0, line.stderr);
    assert.match(line.stdout, new RegExp(`^roedu-ui/feat__fixture sha=${sha} \\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z op=${op}\\n$`));
  }
  assert(wrapper.includes('trust_pin_line "$repo" "$slug" "$sha" "$op" >> "$TP/$TRUST"; exit 0; fi'));
  assert(wrapper.includes('[ -f "$TP/$TRUST" ] || die "no trust pin for gate files'), 'older pin files without op= stay valid: the reader never parses lines');
  assert(!/\$TP\/\$TRUST"[^\n]*(grep|read |awk|cut)/.test(wrapper));
});
test('current invocation descriptor records the operator and keeps schema 1 with a null worker operator', () => {
  const parent = path.resolve('.gate/wrapper-config-fixtures'); fs.mkdirSync(parent, { recursive: true });
  const dir = fs.mkdtempSync(path.join(parent, 'operator-'));
  try {
    const capture = { schema: 1, target: 'unit', sha: 'a'.repeat(40), tree_sha256: 'b'.repeat(64), toolchain_digest: `sha256:${'c'.repeat(64)}`, config: { role: 'core' }, config_sha256: 'd'.repeat(64) };
    const source = path.join(dir, 'capture.json'); fs.writeFileSync(source, JSON.stringify(capture) + '\n');
    const keys = ['schema', 'invocation', 'target', 'sha', 'tree_sha256', 'toolchain_digest', 'config_sha256', 'config_path', 'config_file_sha256', 'operator'];
    for (const [name, args, expected] of [['agent', ['agent:claude-code'], 'agent:claude-code'], ['paul', ['paul'], 'paul'], ['empty', [''], null], ['legacy-argv', [], null]]) {
      const destination = path.join(dir, `current-${name}.json`);
      const run = spawnSync('python3', ['-I', '-', source, destination, ...args], { input: block('PY_CURRENT_CONTEXT'), encoding: 'utf8' });
      assert.equal(run.status, 0, run.stderr);
      const record = JSON.parse(fs.readFileSync(destination, 'utf8'));
      assert.deepEqual(Object.keys(record), keys, name);
      assert.equal(record.schema, 1); assert.equal(record.operator, expected, name);
      assert.equal(record.config_path, '.gate/unit/wrapper-kit-config.json');
    }
    assert(wrapper.includes(`"$control/config-before.json" "$control/current-wrapper.json" "$op" <<'PY_CURRENT_CONTEXT'`));
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
