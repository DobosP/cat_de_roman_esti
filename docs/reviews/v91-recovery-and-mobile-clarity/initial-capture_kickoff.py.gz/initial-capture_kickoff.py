import hashlib,json,os,subprocess
from pathlib import Path
os.environ.update(DJANGO_SETTINGS_MODULE='cat_de_roman_esti.web.settings',CAT_ACCOUNTS_ENABLED='0',CAT_DEBUG='0',ROEDU_API_URL='',ROEDU_API_KEY='')
import django
django.setup()
from django.test import Client
from cat_de_roman_esti.wordgames import intrusul as I,perechi as P
from cat_de_roman_esti.wordgames.service import get_service
root=Path.cwd();out=root/'docs/reviews/v91-recovery-and-mobile-clarity';client=Client();evidence=[]
for key,mod in [('intrusul',I),('perechi',P)]:
 response=client.post(f'/api/wordgames/{key}/games',{'seed':38,'difficulty':'usor'},content_type='application/json');assert response.status_code==200,response.content;gid=response.json()['game_id'];path=f'/api/wordgames/{key}/games/{gid}'
 try:
  session=mod.store.get(gid);assert session
  if key=='intrusul':
   r=client.post(path+'/guess',{'id':session.members[0]},content_type='application/json');assert r.status_code==200
  else:
   for i in (0,1):
    r=client.post(path+'/match',{'ids':[session.pairs[0].members[i],session.pairs[1].members[i]]},content_type='application/json');assert r.status_code==200
  before=client.get(path).json();paid=client.post(path+'/hint',{},content_type='application/json');assert paid.status_code==200,paid.content;body=paid.json();resumed=client.get(path).json();field='clue' if key=='intrusul' else 'hint';assert body[field]==resumed[field] and body['hints_used']==resumed['hints_used']==1
  repeated=client.post(path+'/hint',{},content_type='application/json');assert repeated.status_code==400;after=client.get(path).json();assert after['hints_used']==1 and after[field]==body[field]
  evidence.append({'game':key,'before_hint_available':before['hint_available'],'earned_field':field,'earned_payload':body[field],'post_get_same_earned_payload':True,'hints_used_after_get':resumed['hints_used'],'repeat_hint_http':repeated.status_code,'hints_used_after_rejected_repeat':after['hints_used'],'source_id':session.source_id})
 finally:mod.store.delete(gid)
svc=get_service();pack=json.loads((root/'cat_de_roman_esti/fixtures/games_pack.json').read_text());sport=next(r for r in pack['alchimie'] if r['id']=='al_sport_083');thin=[]
for item_id in ['ct_geografie_030','ct_geografie_031','ct_istorie_309','ct_muzica_070']:
 row=next(r for r in pack['contexto'] if r['id']==item_id);thin.append({'id':item_id,'target':row['target'],'label':svc.label(row['target']),'incoming_count':len(set(svc.predecessor_ids(row['target']))-{row['target']}),'status':row['status']})
files=['frontend/src/screens/Intrusul.tsx','frontend/src/screens/Perechi.tsx','frontend/src/components/Hud.tsx','frontend/src/styles/arcade.css','frontend/src/App.tsx','frontend/src/gameActionRecovery.mjs','frontend/src/useSavedGameResume.mjs','cat_de_roman_esti/wordgames/intrusul.py','cat_de_roman_esti/wordgames/perechi.py','cat_de_roman_esti/fixtures/games_pack.json','cat_de_roman_esti/fixtures/kg_sample.json','cat_de_roman_esti/fixtures/derived_catalog_v38.json']
result={'phase':'V91 measured baseline; complete this version only, no V92','baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'date':'2026-09-08','source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files},'actual_paid_hint_resume_probes':evidence,'sport_record':sport,'sport_seed_labels':[svc.label(x) for x in sport['seeds']],'approved_thin_targets':thin,'limits':['This is BFF clue-persistence/cap evidence, not a browser loss or ownership reproduction.','Existing clues already survive GET; no second hint charge or missing backend cue is claimed.','Sport recognition/discovery and C3 findings are review questions, not approved revisions.','No V91 source/data changes or promotions are delivered by kickoff.']}
(out/'kickoff-baseline.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(out/'capture-kickoff.py.txt').write_bytes(Path(__file__).read_bytes());print(json.dumps({'hint_contracts':evidence,'sport_id':sport['id'],'thin_targets':thin},ensure_ascii=False,indent=2))
