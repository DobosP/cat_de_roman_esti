import pathlib,json,hashlib,os,stat,sys,datetime
R=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-7-qualification')
S=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification')
T=S/'source7-stage';O=S/'authority-pins-r1'
H=lambda b:hashlib.sha256(b).hexdigest()
EXPECTED_PROPOSAL='1b2886d697c19c43320d59f639084bb0d376b19a08aba765fbedacaa00889c11'
target=T/'go-backend/internal/contentbuild/build.go'
tmp=target.parent/'build.go.authority-pins-r1.tmp'
receipt=O/'applied-stage-go-receipt-r1.json'
failure=O/'apply-stage-go-failure-r1.json'
def put(p,x):
    with p.open('xb') as f:
        f.write((json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode());f.flush();os.fsync(f.fileno())
def snapshot():
    out=[];todo=[T]
    while todo:
        for e in os.scandir(todo.pop()):
            st=e.stat(follow_symlinks=False)
            if stat.S_ISLNK(st.st_mode) or getattr(st,'st_file_attributes',0)&1024:raise RuntimeError('reparse/symlink '+e.path)
            if stat.S_ISDIR(st.st_mode):todo.append(e.path)
            elif stat.S_ISREG(st.st_mode):
                p=pathlib.Path(e.path);out.append({'path':p.relative_to(T).as_posix(),'bytes':st.st_size,'sha256':H(p.read_bytes())})
            else:raise RuntimeError('nonregular '+e.path)
    return sorted(out,key=lambda x:x['path'])
def guard_protected(p):
    for row in p['protected_unchanged']:
        b=pathlib.Path(row['path']).read_bytes()
        assert len(b)==row['bytes'] and H(b)==row['sha256'],row['path']
    for row in p['proposed_files'][1:]:
        b=pathlib.Path(row['live_path']).read_bytes()
        assert H(b)==row['before_sha256'],row['live_path']
try:
    assert len(sys.argv)==4,'expected script SHA, actual factual SHA, actual quality SHA'
    assert H(pathlib.Path(__file__).read_bytes())==sys.argv[1],'apply method source drift'
    assert not receipt.exists() and not failure.exists() and not tmp.exists(),'owned output already exists'
    raw=(O/'proposal.json').read_bytes();assert H(raw)==EXPECTED_PROPOSAL
    p=json.loads(raw)
    admission=json.loads((S/'authority-pins-source-admission-r1.json').read_bytes())
    now=datetime.datetime.now(datetime.timezone.utc)
    assert now<datetime.datetime.fromisoformat(admission['cutoff_utc']),'source cutoff'
    reviews=[]
    for filename,expected,identity in [('factual-pin-review-r1.json',sys.argv[2],'/root/qualification_ledger'),('quality-pin-review-r1.json',sys.argv[3],'/root/continuation_audit')]:
        b=(O/filename).read_bytes();assert H(b)==expected
        j=json.loads(b);assert j['reviewer']==identity and j['decision']=='ACCEPT_SOURCE_PINS_ONLY'
        assert j['proposal_sha256']==EXPECTED_PROPOSAL
        reviews.append({'filename':filename,'sha256':expected,'reviewer':identity})
    row=p['proposed_files'][0];assert pathlib.Path(row['live_path'])==target
    before=pathlib.Path(row['before_path']).read_bytes();after=pathlib.Path(row['after_path']).read_bytes()
    assert H(before)==row['before_sha256'] and H(after)==row['after_sha256']
    reconstructed=before
    for change in row['replacements']:
        a=change['old'].encode();b=change['new'].encode();assert reconstructed.count(a)==1
        reconstructed=reconstructed.replace(a,b)
    assert reconstructed==after,'non-pin mutation'
    assert snapshot()==p['stage_namespace_before'],'stage pre-readset drift'
    guard_protected(p)
    assert target.read_bytes()==before,'live target predecessor drift'
    with tmp.open('xb') as f:f.write(after);f.flush();os.fsync(f.fileno())
    assert tmp.read_bytes()==after
    # The temporary has a declared namespace entry until atomic replacement.
    current=snapshot();rel=tmp.relative_to(T).as_posix()
    assert [x for x in current if x['path']!=rel]==p['stage_namespace_before']
    assert sum(x['path']==rel for x in current)==1
    guard_protected(p);assert target.read_bytes()==before
    assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(admission['cutoff_utc'])
    os.replace(tmp,target)
    expected=[dict(x) for x in p['stage_namespace_before']]
    target_rel=target.relative_to(T).as_posix()
    for x in expected:
        if x['path']==target_rel:x.update(bytes=len(after),sha256=H(after))
    assert snapshot()==expected,'stage post-readset drift'
    guard_protected(p)
    assert target.read_bytes()==after and not tmp.exists()
    out={'kind':'staged-go-authority-pin-apply-receipt-v1','publisher':'/root','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'proposal_sha256':EXPECTED_PROPOSAL,'method_sha256':sys.argv[1],'reviews':reviews,'target':str(target),'before_sha256':H(before),'after_sha256':H(after),'stage_regular_files':416,'unchanged_other_stage_files':415,'complete_namespace_exact':True,'protected_source_history_and_live_python_exact':True,'live_R_P_Source6':True,'Python_changes':'prospective only; not installed','native_executed':False,'version_qualified':False,'source_rss':'unmeasured'}
    put(receipt,out);print(json.dumps(out))
except BaseException as e:
    try:put(failure,{'kind':'source-pin-apply-failure-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':type(e).__name__+': '+str(e),'target_sha256':H(target.read_bytes()) if target.is_file() else None,'temporary_exists':tmp.exists(),'receipt_exists':receipt.exists(),'native_executed':False,'instruction':'Preserve actual target/temp/receipt and this original failure. Do not rerun unchanged; independently inspect and repair specific cause. No rollback is assumed.'})
    except BaseException:pass
    raise

