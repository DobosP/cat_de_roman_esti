
import ast,json,hashlib,pathlib,os,stat as filemode,tempfile
S=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7');P=S/'probe'
helpers={}
for flavor,h in [('windows','b9bf7b958f054e526897396f4a14757099586b4e67fcd4158e0eb2b427e615f5'),('linux','9a79edc6cdda6882d17e6bb00f4b84abd34cfd16e45388e548552f69508e73bc')]:
 b=(P/('native-current-rail-build-'+flavor+'-r1.py')).read_bytes();assert hashlib.sha256(b).hexdigest()==h
 tree=ast.parse(b);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['success_stderr','build_cache_proof']];assert len(nodes)==2
 helpers[flavor]=nodes
assert [ast.dump(n,include_attributes=False) for n in helpers['windows']]==[ast.dump(n,include_attributes=False) for n in helpers['linux']]
T=json.loads((P/'native-current-rail-build-template-r2.json').read_bytes())
ns={'json':json,'hashlib':hashlib,'pathlib':pathlib,'os':os,'filemode':filemode,'spec':T.copy()}
exec(compile(ast.Module(body=helpers['windows'],type_ignores=[]),'exact-accepted-build-source-helpers','exec'),ns)
results=[]
def check(name,action,valid):
 try:action()
 except (AssertionError,RuntimeError,ValueError,KeyError,FileExistsError):
  assert not valid,('unexpected reject',name);results.append([name,'PASS_expected_refusal']);return
 assert valid,('unexpected acceptance',name);results.append([name,'PASS'])
lines=[('go: downloading '+p+' '+v+'\n').encode() for p,v in T['allowed_build_modules']]
assert sum(map(len,lines))==793 and hashlib.sha256(b''.join(lines)).hexdigest()=='43188082cb3b4df43d04f7c01c31544efff8a241860685a1af8c6c731ab76ce8'
for name,raw,valid in [('empty',b'',True),('all',b''.join(lines),True),('reverse',b''.join(reversed(lines)),True),('subset',b''.join(lines[:7]),True),('duplicate',lines[0]*2,False),('CRLF',lines[0].replace(b'\n',b'\r\n'),False),('missingLF',lines[0][:-1],False),('blank',b'\n',False),('blankAfter',lines[0]+b'\n',False),('unknown',b'go: downloading example.invalid/new v1.0.0\n',False),('warning',b'warning: hidden issue\n',False),('overcap',b'x'*794,False)]:
 check('stderr_'+name,lambda raw=raw:ns['success_stderr'](raw),valid)
parent=P/'build-control-fixtures';parent.mkdir(exist_ok=True)
assert str(parent.resolve(strict=True))==str(parent) and parent.is_relative_to(P.resolve(strict=True))
# Synthetic file/namespace controls only: no real Go, archive/ZIP authentication, compiler or gameplay.
for name,change,valid in [('valid',None,True),('changed_payload','payload',False),('unexpected_file','file',False),('unexpected_dir','dir',False),('missing_hash','missing',False),('nonempty_source_lock',None,True),('manifest_collision','manifest',False)]:
 with tempfile.TemporaryDirectory(prefix='owned-build-',dir=parent) as tmp:
  root=pathlib.Path(tmp);assert root.resolve().is_relative_to(parent.resolve())
  cache=root/'cache';run=root/'run';cache.mkdir();run.mkdir()
  q=cache/'example.invalid/a@v1.0.0';q.mkdir(parents=True)
  payload=q/'payload.fixture.lock';payload.write_bytes(b'synthetic nonempty source lock')
  rel=payload.relative_to(cache).as_posix();dirs={'.','example.invalid','example.invalid/a@v1.0.0'}
  ns['spec']=dict(T,windows_build_cache=str(cache),allowed_cache_files={rel:hashlib.sha256(payload.read_bytes()).hexdigest()},allowed_cache_dirs=sorted(dirs));ns['run']=run
  if change=='payload':payload.write_bytes(b'corrupt')
  if change=='file':(q/'unexpected').write_bytes(b'x')
  if change=='dir':(q/'unexpected').mkdir()
  if change=='missing':ns['spec']['allowed_cache_files']={}
  if change=='manifest':(run/'build-cache-manifest-windows.json').write_bytes(b'old')
  check('cache_'+name,lambda:ns['build_cache_proof']('windows'),valid)
  # Verify cleanup boundary before TemporaryDirectory removes only this owned synthetic fixture.
  assert root.resolve().is_relative_to(parent.resolve()) and root.parent.resolve()==parent.resolve()
print(json.dumps({'schema':'build-source-controlled-fixtures-v1','scope':'synthetic namespace/hash/schema/log controls only; no native/ZIP/build qualification','helpers_AST_equal':True,'cases':len(results),'results':results}))
