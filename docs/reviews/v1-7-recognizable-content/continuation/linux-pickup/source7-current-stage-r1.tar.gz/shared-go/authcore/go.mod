module github.com/DobosP/cat_de_roman_esti/shared-go/authcore

go 1.27.1

require (
	github.com/coreos/go-oidc/v3 v3.21.0
	golang.org/x/crypto v0.57.0
	golang.org/x/oauth2 v0.37.0
)

require (
	github.com/go-jose/go-jose/v4 v4.1.4 // indirect
	golang.org/x/sys v0.48.0 // indirect
)
