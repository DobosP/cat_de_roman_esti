# RO-EDU core monorepo

Last verified: 2026-10-08 — core-v1.5 forward bundler candidate source reviewed; actual qualification pending.

Candidate @roedu/ui 1.0.5 / @roedu/web-kit 0.1.5 align Rolldown1.2.13; published core-v1.4 stays immutable.
[ADR-0015](docs/adr/0015-approved-parser-alias.md) records the boundary; earlier releases remain immutable.
The [ADR ledger](docs/adr/README.md) records architecture and policy.

## Current state

Core-v1.4 is qualified and atomically published at immutable source `12cbefb7e9d5e7fe2090ade94d83af26b303185c`, tree
`eab619954c2be1fbaa9b8f416a4e1dd3f73fe60ae8218c4119c0fc1531c0aa42`.
Annotated tag object: `dd2006c0c24ca44e2960ad878922ef727a110511`.
Clean unit passed 28 plus only pg-live/no-dsn; fresh full passed 41 with zero skips/retries,
16 HTTP Chromium cases once, six exact PNGs and zero CSP/axe violations.
Fresh A/B and owning-tag builds passed 5 each; all seven outputs were byte-identical.
All 20 new alias regression cases passed. Owning Git Go A/B matched 41 full-mode files/55,213 bytes.
The five-file bundle passed 12 actual parser/sync/npm/Go commands, vet/race 11 packages/66 tests
and repeat no drift; 37 byte/mode artifact rows were independently verified in source/mirror.
[Release evidence](docs/reviews/gui-core-v14/README.md) binds archives and physical keepers.
Scope is Linux/local desktop Chromium and disposable PG, not Cat/device/production qualification.

Core-v1.3 remains immutable at 95aec253/tag 68d8d0b9: unit 28 + PG skip/full 41/16 cases/six PNGs/CSP+axe zero,
builds 5/seven equal outputs and canonical 41-file/55,206-byte Go/11-package/66-test proof.
[V1.3 evidence](docs/reviews/gui-core-v13/README.md) retains exact hashes and scopes; ADR-0014's classifier correction remains enforced.

Core-v1.2 remains immutable at `9e0a88e33d44ba7ce9e84ead890c897b36d41dd4`, tag object
`b5e1c817608e79411595da7f46618475e92acc13`: unit 28 + PG skip, worker/parent full 41,
16 cases/six PNGs/CSP+axe zero, builds 5/seven equal outputs/ten actual consumer packs.
Its canonical 41-file/55,202-byte Go archive and 11-package/66-test proof retain scope
in [v1.2 evidence](docs/reviews/gui-core-v12/README.md); later releases overwrite none of them.

Earlier core-v1.0/v1.1 remain immutable; v1.1 source 9acd440 passed unit 27 + PG skip,
full/parent full 40 checks, 16 cases, six PNGs, zero CSP/axe/skips/retries. Lab 432 ms LCP/40 ms INP
and the compiler-cache correction retain their scope in [WORKLOG](WORKLOG.md) and [ADR-0008](docs/adr/0008-release-artifacts-exclude-compiler-state.md).

Paul directly resumed Linux implementation on 2026-10-08; the [living handoff](docs/GUI_MIGRATION_HANDOFF.md)
supersedes the historical pause/source-only Windows transfer. Five verified layers are applied:
38 Cat source paths (including 15 accepted style files), 2 eager accounting paths, 9 Cat/2 core docs and 6 Node alignment paths.
Original 16 fixtures/78 assertions, the exact 30-file legacy freeze and sealed packets retain their earlier scope.
The CORE_REQ3 correction in [ADR-0010](docs/adr/0010-configured-consumer-version-resolution.md) is released;
adoption requires the clean idle owner sequence; d0e6c7c unit 28 + PG skip/full 41, six screenshots/185/231 bindings retain that historical scope.

The sealed Windows81 core-v1.2 source remains applied; [ADR-0012](docs/adr/0012-go-archive-budget-closure.md)
records Go closure and [ADR-0013](docs/adr/0013-confined-declaration-preparation.md) records confined declaration regeneration.
Private bundle/Go parity and refusal checks passed actual qualification with public exports/failure order preserved.
The [integration ExecPlan](docs/execplans/core-integration.md) retains provenance, checks and evidence.
At core-v1.2, final clean unit verified 292 artifact hashes/21 declaration safety cases;
each full verified 337 artifact hashes. Its actual owning Git Go exports A/B
reproduced 41 files/55,202-byte TGZ, SHA256
`f499198a0b229b6b04488344724f5ba8873c6e1bd8da64096b76cc371f228bb4`.
Cat's original 114,086-byte gzip entry still exceeds 40,960; M0/M1 remain unqualified.
Its physical Samsung Chrome/Internet checkpoint remains UNMET. Active UI adoption,
production and S0b templ migration remain pending.
[ADR-0011](docs/adr/0011-original-runtime-budget-qualification-order.md) corrects
preliminary acceptance ordering while keeping the budget red, the real device
checkpoint and the green M2 requirement before S0b unchanged.

Paul's accepted startup calculation includes entry/static JS/CSS plus immediately mounted AccountBar,
counted once; decision: `cat_de_roman_esti/docs/adr/0185-accepted-eager-startup-bundle-accounting.md`.
Cat branch `fix/gui-cat-prerequisites-linux`, source fixes 9a2b84ca remain unrun; actual deps 91aec3c passed 4 checks.
Latest same-SYNC unit 781e5854 failed at source 0be684b/tree eda114ac; 415/444 frontend tests do not qualify conversion.
Last fresh startup 125,166 remains 2,286 over 122,880; reported 121,968 came from stale dist after a pre-Vite failure.
Earlier bundle 11/native TypeScript 7/API consumer 2/selection-key 3 passes keep their source-bound scopes.
Parent is integrating container source eaa54724 and observed Linux image pins; no image/compatibility/deployment proof follows.
Normalized 900/canonical unit/full/image/CSP/device remain pending. No KIT_BUMP, active UI/M2 or production approval is earned.
Frontend 120KiB JS/CSS and canonical 40,960/30,720-byte JS remain distinct, unchanged and unqualified here.

The Cat-only sealed staged-UI contract and confined same-repo Go audits from
[ADR-0009](docs/adr/0009-corrective-release-and-staged-sdk.md) remain enforced.
Staged UI is pending; M2 requires actual active installation proof. Bootstrap
uses the bound current descriptor and host-private result checks. The
[core ExecPlan](docs/execplans/core-v1.md) preserves S0a history; the
[consumer resolver ExecPlan](docs/execplans/consumer-resolution.md) records the
current fix. [PROGRAM](docs/PROGRAM.md) retains the release and consumer gates.

## Source and interfaces

| Area | Path | Surface |
| --- | --- | --- |
| Tokens | src/tokens/ | DTCG input, generated CSS/app themes, TS and Go constants |
| Layered CSS | src/css/ | reset, tokens, base, components, utilities, app |
| Components | src/preact/ | CSP-safe and keyboard accessible Preact components |
| Behaviors | src/behaviors/ | light-DOM elements, invoker and island protocol |
| Motion | src/motion/ | Presence, springs, Confetti and mini playback controls |
| Network/storage | src/net/, src/storage/ | same-origin CSRF and registered keys |
| Go delivery | web-kit/ | assets, static, csp, island, health, golden, routes, engine |
| Sample | web-kit/sample/ | three stress modules, Pongo2 and compiled templ pages |
| Gate | scripts/gate.sh | pinned Linux execution and bound evidence |
| Templates | web-kit/templates/ | shared gate files, repo hooks and CI reference |

## Consumption

Consumers select only committed kit/CORE_TAG and adopt through the owner
staging/sync/trust sequence. The [consumer notes](CONSUMER_NOTES.md) list every
breaking API/style change and the exact kit protocol. Import components from
@roedu/ui/preact, CSS from @roedu/ui/styles.css and one generated theme.
Reading comfort requires a self-paced surface and rejects timed/psychometric use.
Preact island adapters render into a stable owned child, then dispose it on abort.

## Verification and documentation

Published UI1.0.4/web-kit0.1.4/Go identities bind immutable 12cbefb; earlier releases retain their own sources.
This later documentation HEAD is not a qualified archive source. README is packaged:
repacking changed metadata would change archive bytes; a subsequent product release
must bump affected package versions rather than replace these published archives.
Core-v1.4's qualification retains scope; the [ADR-0016](docs/adr/0016-rolldown-forward-pin.md) successor is authored, NOT RUN.
Parent owns actual deps/qualification and new release versions; no published archive is repacked here.
Cat/device/production, parent-owned captures and earlier receipts retain their scopes.

Every product build/test runs through the pinned native wrapper. Full adds real
PostgreSQL, an image-built app, all registered-page nonce checks, axe/vitals,
journeys and exact committed screenshot comparisons. Full permits no skips.
The [testing guide](docs/agent-testing.md) describes commands and evidence.
Requests and resolutions are append-only in [GATE_REQUESTS.md](GATE_REQUESTS.md).
Source maps: [agent map](docs/agent-map.md), [architecture](docs/architecture.md),
[theming](docs/theming.md), [tokens](docs/design-tokens.md),
[consumer guide](docs/consuming-web-react.md) and [LLM guides](docs/llm/README.md).
The original React 0.3.1 verification remains historical in [WORKLOG.md](WORKLOG.md).
