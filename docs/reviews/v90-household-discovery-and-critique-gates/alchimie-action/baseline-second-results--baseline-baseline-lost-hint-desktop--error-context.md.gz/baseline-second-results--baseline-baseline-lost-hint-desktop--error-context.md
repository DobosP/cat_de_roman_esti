# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: baseline.spec.mjs >> baseline lost hint
- Location: ../../../_temp/feat__v90-household-discovery-and-critique-gates/alchimie/baseline.spec.mjs:5:54

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 200
Received: 500
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - generic [ref=e7]:
    - button "Ieși la lista de jocuri" [ref=e10] [cursor=pointer]:
      - generic [aria-hidden] [ref=e11]: ←
      - text: Ieși
    - generic [ref=e12]:
      - generic [aria-hidden] [ref=e13]: ⚗️
      - generic [ref=e14]:
        - heading "Alchimie" [level=2] [ref=e15]
        - generic [ref=e16]: Combină și descoperă
      - paragraph [ref=e18]: Combină două concepte și ajungi la ținta afișată.
      - list "Cum joci" [ref=e19]:
        - listitem [ref=e20]:
          - generic [aria-hidden] [ref=e21]: "1"
          - generic [aria-hidden] [ref=e22]: 👆
          - strong [ref=e23]: Alege două
        - listitem [ref=e24]:
          - generic [aria-hidden] [ref=e25]: "2"
          - generic [aria-hidden] [ref=e26]: ⚗️
          - strong [ref=e27]: Combină
        - listitem [ref=e28]:
          - generic [aria-hidden] [ref=e29]: "3"
          - generic [aria-hidden] [ref=e30]: ✨
          - strong [ref=e31]: Descoperă
      - generic [ref=e33]:
        - generic [ref=e34]: DIFICULTATE
        - group "DIFICULTATE" [ref=e35]:
          - button "Ușor recomandat" [pressed] [ref=e36] [cursor=pointer]:
            - generic [ref=e37]: Ușor
            - generic [ref=e38]: recomandat
          - button "Normal echilibrat" [ref=e39] [cursor=pointer]:
            - generic [ref=e40]: Normal
            - generic [ref=e41]: echilibrat
          - button "Greu țintă îndepărtată" [ref=e42] [cursor=pointer]:
            - generic [ref=e43]: Greu
            - generic [ref=e44]: țintă îndepărtată
      - alert [ref=e45]: Nu am putut porni jocul. Am păstrat opțiunile alese. Poți încerca din nou.
      - generic [ref=e46]:
        - button "Joacă →" [ref=e47] [cursor=pointer]
        - button "Provocarea zilei" [ref=e48] [cursor=pointer]:
          - generic [aria-hidden] [ref=e49]: 📅
          - text: Provocarea zilei
  - status
```

# Test source

```ts
  1   | import { execFileSync } from "node:child_process";
  2   | import { fileURLToPath } from "node:url";
  3   | import { readFileSync } from "node:fs";
  4   | import { expect } from "@playwright/test";
  5   | 
  6   | export const games = [
  7   |   { key: "alchimie", path: "/alchimie", board: ".alchemy-inventory-grid" },
  8   |   { key: "intrusul", path: "/intrusul", board: ".intrusul-grid", derived: true },
  9   |   { key: "perechi", path: "/perechi", board: ".perechi-grid", derived: true },
  10  |   { key: "conexiuni", path: "/conexiuni", board: ".connections-grid" },
  11  |   { key: "contexto", path: "/cald-rece", board: '[aria-label="Concept de ghicit"]' },
  12  |   { key: "lant", path: "/lant", board: '[aria-label="Următorul concept"]' },
  13  | ];
  14  | const fixtures = new Map();
  15  | export const seededStarts = JSON.parse(readFileSync(new URL("./seeded-starts.json", import.meta.url), "utf8"));
  16  | const root = fileURLToPath(new URL("../../", import.meta.url));
  17  | const script = fileURLToPath(new URL("./solutions.py", import.meta.url));
  18  | const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  19  | 
  20  | export function solution(game) {
  21  |   if (!fixtures.has(game.key)) {
  22  |     fixtures.set(game.key, JSON.parse(execFileSync("python3", [script, game.key], {
  23  |       cwd: root, env: { ...process.env, PYTHONPATH: root }, encoding: "utf8",
  24  |     })));
  25  |   }
  26  |   return fixtures.get(game.key);
  27  | }
  28  | 
  29  | export const activeKey = (game) => `cat_active_game_v1_${game.key}`;
  30  | export const gameURL = (game, id) => `/api/wordgames/${game.key}/games/${id}`;
  31  | 
  32  | export async function deterministicStarts(page, game) {
  33  |   await page.route(`**/api/wordgames/${game.key}/games?*`, async (route) => {
  34  |     const url = new URL(route.request().url());
  35  |     url.searchParams.set("seed", "38");
  36  |     await route.continue({ url: url.toString() });
  37  |   });
  38  | }
  39  | 
  40  | export async function tabTo(page, target) {
  41  |   await expect(target).toBeVisible();
  42  |   await expect(target).toBeEnabled();
  43  |   for (let steps = 0; steps < 80; steps += 1) {
  44  |     if (await target.evaluate((element) => element === globalThis.document.activeElement)) return;
  45  |     await page.keyboard.press("Tab");
  46  |   }
  47  |   await expect(target, "essential control must be reachable with Tab").toBeFocused();
  48  | }
  49  | 
  50  | async function activate(page, target, keyboard) {
  51  |   if (!keyboard) return target.click();
  52  |   await tabTo(page, target);
  53  |   await page.keyboard.press("Space");
  54  | }
  55  | 
  56  | export async function start(page, game, { keyboard = false } = {}) {
  57  |   await page.goto(game.path);
  58  |   const response = page.waitForResponse((r) =>
  59  |     r.request().method() === "POST" &&
  60  |     new URL(r.url()).pathname === `/api/wordgames/${game.key}/games`);
  61  |   await activate(page, page.getByRole("button", { name: /^Joacă(?: →)?$/ }), keyboard);
  62  |   const created = await response;
> 63  |   expect(created.status()).toBe(200);
      |                            ^ Error: expect(received).toBe(expected) // Object.is equality
  64  |   const state = await created.json();
  65  |   await expect(page.locator(game.board)).toBeVisible();
  66  |   return state;
  67  | }
  68  | 
  69  | export async function act(page, game, step, { keyboard = false } = {}) {
  70  |   const response = page.waitForResponse((r) =>
  71  |     r.request().method() === "POST" && new URL(r.url()).pathname.endsWith(`/${step.action}`));
  72  |   if (game.key === "contexto" || game.key === "lant") {
  73  |     const input = page.getByRole("textbox", {
  74  |       name: game.key === "contexto" ? "Concept de ghicit" : "Următorul concept",
  75  |     });
  76  |     if (keyboard) await tabTo(page, input);
  77  |     await input.fill(step.payload.text);
  78  |     await input.press("Enter");
  79  |   } else {
  80  |     if (game.key === "alchimie") {
  81  |       for (const slot of await page.getByRole("button", { name: /^Scoate .* din alambic$/ }).all()) {
  82  |         await activate(page, slot, keyboard);
  83  |       }
  84  |       await activate(page, page.getByRole("button", { name: /^Toate / }), keyboard);
  85  |     }
  86  |     for (const label of step.labels) {
  87  |       await activate(page, page.locator(game.board).getByRole("button", {
  88  |         name: new RegExp(`^${escapeRegex(label)}(?:,|$)`),
  89  |       }), keyboard);
  90  |     }
  91  |     if (game.key === "alchimie") {
  92  |       await activate(page, page.getByRole("button", { name: "Combină cele două concepte selectate" }), keyboard);
  93  |     } else if (game.key === "conexiuni") {
  94  |       await activate(page, page.getByRole("button", { name: "Verifică", exact: true }), keyboard);
  95  |     }
  96  |   }
  97  |   return response;
  98  | }
  99  | 
  100 | export async function solve(page, game, steps, options = {}) {
  101 |   let result;
  102 |   for (const step of steps) {
  103 |     const response = await act(page, game, step, options);
  104 |     expect(response.status()).toBe(200);
  105 |     result = await response.json();
  106 |     if (game.key === "conexiuni") {
  107 |       await expect(page.locator(`${game.board} button`)).toHaveCount(16 - result.solved_count * 4);
  108 |     }
  109 |     if (game.key === "perechi" && options.keyboard) {
  110 |       if (result.won) {
  111 |         await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeFocused();
  112 |       } else {
  113 |         const split = result.tiles.findIndex((tile) => tile.id === step.payload.ids[1]) + 1;
  114 |         const next = [...result.tiles.slice(split), ...result.tiles.slice(0, split)]
  115 |           .find((tile) => !tile.solved);
  116 |         await expect(page.locator(game.board).getByRole("button", { name: next.label, exact: true }))
  117 |           .toBeFocused();
  118 |       }
  119 |     }
  120 |   }
  121 |   expect(result.won).toBe(true);
  122 |   await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeVisible();
  123 |   await expect(page.getByRole("button", { name: /^Încă (?:unul|un lanț) →$/ })).toBeEnabled();
  124 |   return result;
  125 | }
  126 | 
```