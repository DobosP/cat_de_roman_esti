import pathlib,json,hashlib,os,sys,time,stat,shutil,subprocess,psutil
spec_path=pathlib.Path(sys.argv[1]);expected=sys.argv[2]
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(spec_path)==expected
spec=json.loads(spec_path.read_text(encoding="utf-8"))
G=1024**3;start=time.time();mono_deadline=time.monotonic()+spec["deadline_epoch"]-start
assert spec["deadline_epoch"]-spec["started_epoch"]==1200 and start<spec["deadline_epoch"]-195
root=pathlib.Path(spec["root"]);run=pathlib.Path(spec["run"]);assert run.is_dir()
child=None;seen={};samples=[];peak=0;out=run/"stdout.json";err=run/"stderr.log"
assert not out.exists() and not err.exists()
controller=psutil.Process(os.getpid());launcher=controller.parent();assert launcher is not None
identities={p.pid:p.create_time() for p in [controller,launcher]}
def pins():
 assert sha(spec_path)==expected
 for name,digest in spec["protected"].items():assert sha(name)==digest,name
def count(p):
 total=0;todo=[pathlib.Path(p)]
 while todo:
  d=todo.pop()
  with os.scandir(d) as it:
   for e in it:
    st=e.stat(follow_symlinks=False)
    assert not stat.S_ISLNK(st.st_mode) and not getattr(st,"st_file_attributes",0)&0x400,"reparse accounting input"
    if stat.S_ISDIR(st.st_mode):todo.append(pathlib.Path(e.path))
    else:assert stat.S_ISREG(st.st_mode);total+=st.st_size
 return total
def resources(diskfloor=16*G):
 assert time.time()<spec["deadline_epoch"]-180 and time.monotonic()<mono_deadline-180,"original reserve"
 total=sum(count(p) for p in spec["accounting_roots"])
 assert total-spec["anchor"]+65536<=G,"wholeowned growth reserve"
 assert shutil.disk_usage(root).free-65536>=diskfloor and psutil.virtual_memory().available>=16*G,"disk/memory reserve"
 return total
def process_sample():
 global peak
 rows={}
 for pid,created in identities.items():
  p=psutil.Process(pid);assert p.create_time()==created,"parent identity drift";rows[pid]=p.memory_info().rss
 if child is not None:
  try:
   p=psutil.Process(child.pid)
   for q in [p]+p.children(recursive=True):
    try:
     created=q.create_time()
     assert q.pid not in seen or seen[q.pid]==created,"owned PID reuse"
     seen[q.pid]=created;rows[q.pid]=q.memory_info().rss
    except psutil.NoSuchProcess:pass
  except psutil.NoSuchProcess:pass
 total=sum(rows.values());peak=max(peak,total);assert total<=2*G,"parent-inclusive sampled RSS"
 samples.append({"epoch":time.time(),"rss":total,"pid_rss":rows});return total
def cleanup():
 if child is not None and child.poll() is None:
  try:
   p=psutil.Process(child.pid)
   for q in p.children(recursive=True):q.kill()
   p.kill()
  except psutil.NoSuchProcess:pass
  child.wait(timeout=10)
 absent=[]
 for pid,created in seen.items():
  try:
   p=psutil.Process(pid)
   if p.create_time()==created:absent.append(pid)
  except psutil.NoSuchProcess:pass
 assert not absent,("owned descendants remain",absent)
try:
 resources(17*G);pins();before=resources(17*G)
 env={"SystemRoot":spec["system_root"],"WINDIR":spec["system_root"],"PATH":spec["git_dir"],"HOME":str(run/"tmp"),"TMP":str(run/"tmp"),"TEMP":str(run/"tmp"),"GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_SYSTEM":"NUL","GIT_CONFIG_GLOBAL":"NUL","GIT_TERMINAL_PROMPT":"0","GOMAXPROCS":"2","GOMEMLIMIT":"1536MiB"}
 process_sample()
 with out.open("xb") as stdout,err.open("xb") as stderr:
  child=subprocess.Popen([spec["tool"],"--root",str(root)],cwd=root,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
  while True:
   process_sample();resources()
   assert out.stat().st_size<=1024**2 and err.stat().st_size<=1024**2,"stream cap"
   if child.poll() is not None:break
   assert time.time()-start<120,"fixed native timeout"
   time.sleep(.1)
  assert child.wait()==0,"native exit"
 cleanup();pins();after=resources();process_sample()
 report=json.loads(out.read_bytes());assert report=={"files":59,"dead_links":[],"stale_terms":[],"retired_verbs":[],"orphans":[],"budgets":[]},"exact docs report"
 assert err.read_bytes()==b"","native stderr"
 result={"kind":"PASS","scope":"ONE existing source-exact Windows documentation checker only","started_epoch":spec["started_epoch"],"deadline_epoch":spec["deadline_epoch"],"finished_epoch":time.time(),"before_bytes":before,"after_bytes":after,"anchor":spec["anchor"],"growth":after-spec["anchor"],"parent_inclusive_sampled_peak":peak,"rss_scope":"controller + actual PowerShell parent + observed native checker/Git descendants; short-lived processes may fall between samples; source Codex workers excluded","observed_owned_pids":seen,"all_observed_owned_processes_absent":True,"report":report,"tool_sha256":sha(spec["tool"]),"spec_sha256":expected,"stdout_sha256":sha(out),"samples":samples,"trusted_boundary":"existing Windows/Python/psutil/Git runtime DLLs and OS; no whole-OS hermetic claim"}
 p=run/"result.json";assert not p.exists();p.write_bytes((json.dumps(result,indent=2)+"\n").encode());resources();pins()
 print(json.dumps({k:result[k] for k in ["kind","parent_inclusive_sampled_peak","growth","finished_epoch"]}))
except BaseException as exc:
 try:cleanup()
 except BaseException as secondary:cleanup_error=repr(secondary)
 else:cleanup_error=None
 failure={"kind":"FAILED","error":repr(exc),"cleanup_error":cleanup_error,"finished_epoch":time.time(),"peak":peak,"samples":samples}
 (run/"failure.json").write_bytes((json.dumps(failure,indent=2)+"\n").encode());print(json.dumps(failure));raise
