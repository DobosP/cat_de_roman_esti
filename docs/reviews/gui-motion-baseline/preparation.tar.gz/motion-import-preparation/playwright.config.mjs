import {defineConfig} from "./runner-api.mjs";
import {binding,descriptor} from "./descriptor.mjs";
import {fileURLToPath} from "node:url";
import {resolve} from "node:path";
const root=fileURLToPath(new URL("./",import.meta.url));
const diagnostic=binding.profile==="baseline-diagnostic";
const testDir=diagnostic?resolve(root,"../motion-baseline/tests"):resolve(root,"target/tests");
const files=project=>[...new Set(binding.inventory.filter(c=>c.project===project).map(c=>"**/"+c.file.split("/").at(-1)))];
export default defineConfig({
 testDir,outputDir:resolve(descriptor.out_dir,"artifacts"),forbidOnly:true,workers:1,retries:0,repeatEach:1,
 fullyParallel:false,maxFailures:0,updateSnapshots:"none",timeout:20000,expect:{timeout:4000},
 reporter:[["json",{outputFile:resolve(descriptor.out_dir,"playwright.json")}]],
 use:{baseURL:binding.app.base_url,locale:"ro-RO",timezoneId:"Europe/Bucharest",viewport:{width:1280,height:900},
  trace:"retain-on-failure",screenshot:"only-on-failure",serviceWorkers:"block",
  launchOptions:{executablePath:binding.browser.executable}},
 projects:[
  {name:"motion-on",testMatch:files("motion-on"),use:{reducedMotion:"no-preference"}},
  {name:"reduce",testMatch:files("reduce"),use:{reducedMotion:"reduce"}}
 ],
 // This launcher never starts a frozen preview on behalf of target acceptance.
 // Every profile must use an independently supplied isolated app URL whose served bytes are witnessed.
 webServer:undefined
});
