# RO-EDU core monorepo

Last verified: 2026-10-12 — core-v1.9 candidate on feat/core-presence-frame (REQ-8 Presence finalized-exit frame ADR-0025, ADR-0024 N1 locale fix): UI1.0.9/WK0.1.9 sanctioned deps passed at b77008b (three own-version lock fields, operator-pinned trust set a8ad8f62…); unit/full/build pending. Core-v1.8 (55ec460, tagged) and earlier remain immutable.

Released @roedu/ui 1.0.8 / @roedu/web-kit 0.1.8 (core-v1.8, [ADR-0024](docs/adr/0024-agent-operator-identity.md)) retain the qualified toolchain and dependency pins; the corrective successor targets UI 1.0.9 / web-kit 0.1.9 ([ADR-0025](docs/adr/0025-presence-finalized-exit-frame.md)).
[ADR-0017](docs/adr/0017-trusted-full-browser-loopback.md) records real app-loopback full routing; [ADR-0016](docs/adr/0016-rolldown-forward-pin.md) remains the unchanged forward pin.
The [ADR ledger](docs/adr/README.md) records architecture and policy.

## Current state

Core-v1.9 candidate (`feat/core-presence-frame`, UI1.0.9/WK0.1.9) makes `Presence` keep an exiting child mounted (`data-state="exiting"`, `useIsPresent()` false) through one animation frame after the exit commit, so a finalized reduced-motion exit is observable by the next frame callback (Cat REQ-8, [ADR-0025](docs/adr/0025-presence-finalized-exit-frame.md)); default/variant timing and the two-frame data-motion-off bound are unchanged. The wrapper's owner-identity match runs under a scoped `LC_ALL=C` (ADR-0024 review N1), with UTF-8-locale cases in `gate-operator.test.mjs`.
Gate state: source authored, trust pin and deps/unit/full/build pending; evidence will live in docs/reviews/gui-core-v19.
Core-v1.8 `55ec4606819f8b6f2cc9e3591b9abaf379248285` (tree `ddd32bf7…`, tag `core-v1.8`, UI1.0.8/WK0.1.8, [ADR-0024](docs/adr/0024-agent-operator-identity.md) agent operator identity) is qualified: unit 28 + sole pg-live skip, full 41/zero skips, six exact PNGs, fresh A/B seven equal outputs (UI fd3df161…, WK 0ac3da0e…), Go archive A=B ecd232c3…; [evidence](docs/reviews/gui-core-v18/README.md) retains three refusals and the independent review.
Core-v1.7 `1c51337780803bff5d03f4594a7fd9a106791e25` (tree `dd5195fc…`, tag `core-v1.7`) is qualified: unit 28 + sole pg-live skip, full 41/zero skips, six exact PNGs, fresh A/B seven equal outputs (UI 25a1281f…, WK e01054e3…); [evidence](docs/reviews/gui-core-v17/README.md).

Core-v1.6 is qualified and atomically published at source `b0ad658086a2745d1b3aea02659e6b644c89c680`, tree
`446613f7591685c234d2c7a3235022558b7354038381322dd069f7a4d2852f55`; tag object `ec3f79a009d13f593f3bb350052d0d53876a5786`.
Actual clean unit passed28 plus only pg-live/no-dsn; fresh full41 passed with zero skips/retries, 16 HTTP Chromium cases once, six exact PNGs, zero axe/CSP findings and real PG.
All13 trusted-origin contracts pass; A/B/tag builds passed5 each with seven equal outputs; owning Git Go A/B match41 files/55,202 bytes; the canonical five-file kit passed12 real commands, 11 Go packages/66 tests, vet/race and repeat sync without drift; permanent keepers preserve72,341 rows,236 links and six FIFOs.
[Release evidence](docs/reviews/gui-core-v16/README.md) binds source/image/archives and preserves the first fixture refusal; scope is Linux core/sample/report-only/native delivery, not Cat/enforced CSP/device/production qualification.

Core-v1.5/source5a66f701/tagd1a6c60 remains immutable with unit28/full41/A-B-tag/canonical qualification. [Its evidence](docs/reviews/gui-core-v15/README.md) retains the 41-file/55,203-byte Go proof and all old records.

Core-v1.4 remains immutable at12cbefb/tagdd2006c0: unit 28 + PG skip/full 41/16 cases/six PNGs/CSP+axe zero,
builds 5/seven equal outputs and canonical 41-file/55,213-byte Go/11-package/66-test proof.
[V1.4 evidence](docs/reviews/gui-core-v14/README.md) retains hashes/scopes; all 20 alias regression cases passed there.

Core-v1.3 remains immutable at 95aec253/tag 68d8d0b9: unit 28 + PG skip/full 41/16 cases/six PNGs/CSP+axe zero,
builds 5/seven equal outputs and canonical 41-file/55,206-byte Go/11-package/66-test proof.
[V1.3 evidence](docs/reviews/gui-core-v13/README.md) retains exact hashes and scopes; ADR-0014's classifier correction remains enforced.

Core-v1.2 stays immutable at9e0a88e/tagb5e1c817: unit 28 + PG skip, worker/parent full 41,
16 cases/six PNGs/CSP+axe zero, builds 5/seven equal outputs/ten actual consumer packs.
Its 41-file/55,202-byte Go/11-package/66-test scope and full identities stay in [v1.2 evidence](docs/reviews/gui-core-v12/README.md).

Earlier core-v1.0/v1.1 remain immutable; v1.1 source 9acd440 passed unit 27 + PG skip,
full/parent full 40 checks, 16 cases, six PNGs, zero CSP/axe/skips/retries. Lab 432 ms LCP/40 ms INP
and the compiler-cache correction retain their scope in [WORKLOG](WORKLOG.md) and [ADR-0008](docs/adr/0008-release-artifacts-exclude-compiler-state.md).

Paul directly resumed Linux implementation on 2026-10-08; the [living handoff](docs/GUI_MIGRATION_HANDOFF.md)
supersedes the historical pause/source-only Windows transfer. Five verified layers are applied:
38 Cat source paths (including 15 accepted style files), 2 eager accounting paths, 9 Cat/2 core docs and 6 Node alignment paths.
Original 16 fixtures/78 assertions, the exact 30-file legacy freeze and sealed packets retain their earlier scope.
The CORE_REQ3 correction in [ADR-0010](docs/adr/0010-configured-consumer-version-resolution.md) is released;
adoption requires the clean idle owner sequence; d0e6c7c unit 28 + PG skip/full 41, six screenshots/185/231 bindings retain that historical scope.

The sealed Windows81 core-v1.2 source remains applied; [ADR-0012](docs/adr/0012-go-archive-budget-closure.md)
records Go closure and [ADR-0013](docs/adr/0013-confined-declaration-preparation.md) records confined declaration regeneration.
Private bundle/Go parity and refusal checks passed actual qualification with public exports/failure order preserved.
The [integration ExecPlan](docs/execplans/core-integration.md) retains provenance, checks and evidence.
At core-v1.2, unit verified 292 artifact hashes/21 declaration cases; each full verified 337.
Its owning Git Go A/B hash remains `f499198a0b229b6b04488344724f5ba8873c6e1bd8da64096b76cc371f228bb4`.
Cat's current Home JS115181/frozen117271 remains red at40960; combined122743/122880 is a working-target observation. M0/M1/KIT_BUMP remain unqualified.
Its physical Samsung Chrome/Internet checkpoint remains UNMET. Active UI adoption,
production and S0b templ migration remain pending.
[ADR-0011](docs/adr/0011-original-runtime-budget-qualification-order.md) corrects
preliminary acceptance ordering while keeping the budget red, the real device
checkpoint and the green M2 requirement before S0b unchanged.

Paul's accepted startup calculation includes entry/static JS/CSS plus immediately mounted AccountBar,
counted once; decision: `cat_de_roman_esti/docs/adr/0185-accepted-eager-startup-bundle-accounting.md`.
Cat owning86a162d handover records actual FULL2db FAIL201: frontend319/backend1302/HTTP1207 pass;
browser894/900, six failures; native WebLocks absent at HTTP alias, two score losses are fallback-consistent inference.
GEN156bf7d1/eace4880's27/29, startup124,714/122,880 and unreached900 remain historical, not the latest result.
Actual startup122,743/122,880 is not phone proof; all20 route JS rows RED at40,960; Home115,181/117,271.
Browser failure prevented receipt/image-asset witnesses/CSP/9PNG/axe/vitals; image IID alone is not qualification.
Installed WK0.1.5/React19/UI0.3 remain; successor/full/CSP/device/formalKIT_BUMP/activeUI1-M2 are pending.
Frontend120KiB JS/CSS and canonical40,960/30,720 JS stay distinct/unchanged; no E3 non-budget-failure waiver.

The Cat-only sealed staged-UI contract and confined same-repo Go audits from
[ADR-0009](docs/adr/0009-corrective-release-and-staged-sdk.md) remain enforced.
Staged UI is pending; M2 requires actual active installation proof. Bootstrap
uses the bound current descriptor and host-private result checks. The
[core ExecPlan](docs/execplans/core-v1.md) preserves S0a history; the
[consumer resolver ExecPlan](docs/execplans/consumer-resolution.md) records the
current fix. [PROGRAM](docs/PROGRAM.md) retains the release and consumer gates.

## Source and interfaces

| Area | Path | Surface |
| --- | --- | --- |
| Tokens | src/tokens/ | DTCG input, generated CSS/app themes, TS and Go constants |
| Layered CSS | src/css/ | reset, tokens, base, components, utilities, app |
| Components | src/preact/ | CSP-safe and keyboard accessible Preact components |
| Behaviors | src/behaviors/ | light-DOM elements, invoker and island protocol |
| Motion | src/motion/ | Presence, springs, Confetti and mini playback controls |
| Network/storage | src/net/, src/storage/ | same-origin CSRF and registered keys |
| Go delivery | web-kit/ | assets, static, csp, island, health, golden, routes, engine |
| Sample | web-kit/sample/ | three stress modules, Pongo2 and compiled templ pages |
| Gate | scripts/gate.sh | pinned Linux execution and bound evidence |
| Templates | web-kit/templates/ | shared gate files, repo hooks and CI reference |

## Consumption

Consumers select only committed kit/CORE_TAG and adopt through the owner
staging/sync/trust sequence. The [consumer notes](CONSUMER_NOTES.md) list every
breaking API/style change and the exact kit protocol. Import components from
@roedu/ui/preact, CSS from @roedu/ui/styles.css and one generated theme.
Reading comfort requires a self-paced surface and rejects timed/psychometric use.
Preact island adapters render into a stable owned child, then dispose it on abort.

## Verification and documentation

Published UI1.0.6/web-kit0.1.6/Go identities bind immutableb0ad658; earlier releases retain their own sources.
This later documentation HEAD is not a qualified archive source. README is packaged:
repacking changed metadata would change archive bytes; a subsequent product release
must bump affected package versions rather than replace these published archives.
Core-v1.6's actual qualification supersedes its source-only state; this later update runs documentation checks only.
Parent owns consumer staging and later release operations; no published archive is repacked here.
Cat/device/production, parent-owned captures and earlier receipts retain their scopes.

Every product build/test runs through the pinned native wrapper. Full adds real
PostgreSQL, an image-built app, all registered-page nonce checks, axe/vitals,
journeys and exact committed screenshot comparisons. Full permits no skips.
The [testing guide](docs/agent-testing.md) describes commands and evidence.
Requests and resolutions are append-only in [GATE_REQUESTS.md](GATE_REQUESTS.md).
Source maps: [agent map](docs/agent-map.md), [architecture](docs/architecture.md),
[theming](docs/theming.md), [tokens](docs/design-tokens.md),
[consumer guide](docs/consuming-web-react.md) and [LLM guides](docs/llm/README.md).
The original React 0.3.1 verification remains historical in [WORKLOG.md](WORKLOG.md).
