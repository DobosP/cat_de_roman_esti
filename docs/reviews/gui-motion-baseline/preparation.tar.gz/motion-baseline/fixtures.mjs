import assert from "node:assert/strict";
export const GAMES=["intrusul","perechi","conexiuni"];
export const boardFor=g=>g==="conexiuni"?".connections-grid":"."+g+"-grid";
export const activeKey=g=>"cat_active_game_v1_"+g;
const labels=["Măr","Pară","Prună","Caisă","Pix","Creion","Radieră","Rig­lă","Masă","Scaun","Dulap","Pat","Câine","Pisică","Cal","Iepure"];
export function liveState(game,id,nearWin=false){
 const tiles=labels.slice(0,game==="intrusul"?4:game==="perechi"?8:16).map((label,i)=>({id:"fixture-"+i,label:label.replace("\u00ad","")}));
 const common={game_id:id,won:false,lost:false,difficulty:"usor",mistakes:0};
 if(game==="intrusul")return{...common,tiles,wrong_ids:[],attempts:0,remaining_mistakes:3,hints_used:0,hint_available:true};
 if(game==="perechi"){
  const pairs=Array.from({length:4},(_,i)=>({label:"Pereche sintetică "+i,tiles:tiles.slice(i*2,i*2+2)}));
  return{...common,tiles:tiles.map((t,i)=>({...t,solved:nearWin&&i<6})),solved_pairs:nearWin?pairs.slice(0,3):[],solved_count:nearWin?3:0,remaining_pairs:nearWin?1:4,remaining_mistakes:6,actions:nearWin?3:0,hints_used:0,hint_available:true};
 }
 const groups=Array.from({length:4},(_,i)=>({key:"group-"+i,label:"Grup sintetic "+i,tiles:tiles.slice(i*4,i*4+4)}));
 return{...common,tiles,solved:nearWin?groups.slice(0,3):[],solved_count:nearWin?3:0,remaining_groups:nearWin?1:4,lives:4,clues_used:0,clue_available:true,clues:[]};
}
export function terminalState(game,state){
 const s={...structuredClone(state),won:true,lost:false,score:1000,share:"Rezultat exclusiv sintetic",ok:true,correct:true};
 if(game==="intrusul")return{...s,attempts:s.attempts+1,already_tried:false,message:"Corect sintetic.",solution:{intruder:s.tiles[0],group:{label:"Grup sintetic",tiles:s.tiles.slice(1)}}};
 if(game==="perechi"){
  const pairs=Array.from({length:4},(_,i)=>({label:"Pereche sintetică "+i,tiles:s.tiles.slice(i*2,i*2+2).map(({id,label})=>({id,label}))}));
  return{...s,tiles:s.tiles.map(t=>({...t,solved:true})),solved_pairs:pairs,solved_count:4,remaining_pairs:0,actions:s.actions+1,pair:pairs[3],solution:pairs};
 }
 const groups=Array.from({length:4},(_,i)=>({key:"group-"+i,label:"Grup sintetic "+i,tiles:s.tiles.slice(i*4,i*4+4)}));
 return{...s,solved:groups,solved_count:4,remaining_groups:0,category:{key:groups[3].key,label:groups[3].label},solution:groups};
}
export async function installSynthetic(context,game,{nearWin=false,anonymous=false}={}){
 const id="00000000-0000-4000-8000-"+String(GAMES.indexOf(game)+1).padStart(12,"0");
 let state=liveState(game,id,nearWin),hold=null;
 const ledger=[];const unexpected=[];const requestRows=new WeakMap();
 context.on("response",async response=>{const row=requestRows.get(response.request());if(row){row.delivery=(await response.finished())?"failed":"finished";}});
 context.on("requestfailed",request=>{const row=requestRows.get(request);if(row)row.delivery="failed";});
 await context.addInitScript(({game,id})=>{
  if(!sessionStorage.getItem("motion-fixture-seeded")){
   localStorage.clear();localStorage.setItem("cat_active_game_v1_"+game,id);
   sessionStorage.setItem("motion-fixture-seeded","1");
  }
  localStorage.setItem("cat_sound_enabled_v1","0");
  window.__motionWrites=[];const nativeSet=Storage.prototype.setItem;
  Storage.prototype.setItem=function(key,value){
   const outcome=nativeSet.call(this,key,value);
   if(this===localStorage&&key==="cat_wordgame_scores_v1")try{
    const raw=JSON.parse(value);window.__motionWrites.push({time:performance.now(),played:raw[game]?.played||0,
     recent:raw[game]?.recent?.length||0,receiptIds:(raw._completionReceipts?.games?.[game]||[]).map(r=>r.id),
     retainedScreenMounted:window.__motionRetainedScreen?.isConnected===true});
    if(window.__motionWrites.length>32)throw Error("fixture score observation exceeded bound");
   }catch(error){window.__motionObserverError=String(error);}
   return outcome;
  };
 },{game,id});
 await context.route("**/*",async route=>{
  const req=route.request(),url=new URL(req.url());
  if(!["127.0.0.1","localhost","app"].includes(url.hostname)){unexpected.push(req.url());await route.abort("blockedbyclient");return;}
  const path=url.pathname,method=req.method();
  if(!path.startsWith("/api/")){await route.continue();return;}
  const entry={path,method,body:req.postDataJSON()};ledger.push(entry);requestRows.set(req,entry);
  const respond=body=>route.fulfill({status:200,json:body});
  if(path==="/api/me"&&method==="GET")return respond({accounts_enabled:true,authenticated:!anonymous,user:anonymous?null:{
   id:1,email:"motion-fixture@example.invalid",name:"Fixture",avatar:"",ranking_name:"Fixture",display_name:"Fixture",
   show_on_ranking:false,consent_completed:true,can_save_progress:true,is_minor:false,parental_consent_required:false}});
  if(path==="/api/categories")return respond({categories:[]});
  if(path==="/api/ranking")return respond({game:null,entries:[],me:null});
  if(path==="/api/me/scores"&&method==="POST"){
   const rows=entry.body?.entries;
   const valid=Array.isArray(rows)&&rows.length>0&&rows.every(e=>e.game===game&&Number.isFinite(e.score)&&typeof e.detail==="string"&&Number.isFinite(e.at)&&["puzzle_key","daily","difficulty","category"].every(k=>typeof e[k]==="string"));
   if(!valid){unexpected.push("invalid synthetic score upload");return route.fulfill({status:400,json:{detail:"invalid upload"}});}
   return respond({ok:true});
  }
  const base="/api/wordgames/"+game+"/games";
  if(path===base&&method==="POST")return respond(state);
  if(path===base+"/"+id&&method==="GET")return respond(state);
  if(path.startsWith(base+"/"+id+"/")&&method==="POST"){
   const action=path.split("/").at(-1);
   if(!({intrusul:["guess","hint"],perechi:["match","hint"],conexiuni:["guess","clue"]}[game]).includes(action)){unexpected.push(path);await route.fulfill({status:501,json:{detail:"unexpected action"}});return;}
   const known=new Set(state.tiles.filter(t=>!t.solved).map(t=>t.id));
   const ids=entry.body?.ids;
   const valid=action==="guess"&&game==="intrusul"?known.has(entry.body?.id):
    ["guess","match"].includes(action)?Array.isArray(ids)&&ids.length===(game==="perechi"?2:4)&&new Set(ids).size===ids.length&&ids.every(id=>known.has(id)):
    action==="hint"?state.hint_available:state.clue_available;
   if(!valid){unexpected.push("invalid "+game+" "+action+" payload");return route.fulfill({status:400,json:{detail:"invalid mutation"}});}
   const mode=hold?.mode||(["hint","clue"].includes(action)?"hint":"terminal");
   let response;
   if(mode==="hint"){
    state={...state,hints_used:1,hint_available:false,ok:true};
    if(game==="intrusul")state.clue={label:"Indiciu sintetic",message:"Indiciu sintetic primit"};
    else state.hint={label:"Indiciu sintetic",tiles:state.tiles.filter(t=>!t.solved).slice(-2)};
    response=state;
   }else if(mode==="503"){response={};}
   else{state=terminalState(game,state);response=state;}
   if(hold){const h=hold;hold=null;h.enter({action,response});await h.barrier;}
   if(mode==="503")return route.fulfill({status:503,json:{}});
   return respond(response);
  }
  unexpected.push(method+" "+path);return route.fulfill({status:501,json:{detail:"unexpected synthetic route"}});
 });
 return{
  game,id,ledger,unexpected,get state(){return structuredClone(state);},
  hold(mode="terminal"){
   assert.equal(hold,null,"one held response at a time");let release,enter;
   const requested=new Promise(r=>{enter=r;}),barrier=new Promise(r=>{release=r;});hold={mode,release,enter,barrier};
   return{requested,release};
  },
  counts(){return{mutations:ledger.filter(r=>r.method==="POST"&&r.path.includes("/games/")).length,
   creates:ledger.filter(r=>r.method==="POST"&&r.path.endsWith("/games")).length,
   reads:ledger.filter(r=>r.method==="GET"&&r.path.includes("/games/")).length,
   uploads:ledger.filter(r=>r.method==="POST"&&r.path==="/api/me/scores").length};}
 };
}
