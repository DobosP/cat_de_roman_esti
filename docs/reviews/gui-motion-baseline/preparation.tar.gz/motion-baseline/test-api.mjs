// Preview injects a cached Playwright module; reviewed M0 defaults to its pinned dependency.
const api=await import(process.env.MOTION_PLAYWRIGHT_TEST_MODULE||"@playwright/test");
export const {test,expect,defineConfig}=api;
