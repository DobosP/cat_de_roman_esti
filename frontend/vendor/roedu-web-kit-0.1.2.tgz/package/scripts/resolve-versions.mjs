import {readFileSync,realpathSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import {readKitConfig} from './locate-kit.mjs';
import {planner,json} from './resolver-files.mjs';
import {resolveEntry,stable} from './resolver-policy.mjs';
import {planConsumer} from './resolver-consumer.mjs';
export {selectStable} from './resolver-policy.mjs';

export async function resolveVersions(args=process.argv.slice(2)) {
  assert.ok(args.length===0||args.length===2&&args[0]==='--fixture'&&args[1],'Usage: resolve-versions.mjs [--fixture metadata.json]');
  assert.equal(process.env.GATE_VERSIONS_RESOLVE,'1','Only native gen --resolve-versions may resolve versions');
  const root=realpathSync(process.cwd()),config=readKitConfig(root,true,'gen'),plan=planner(root);
  const recorded=args.length?JSON.parse(readFileSync(args[1])):null;
  const get=async url=>{if(recorded){assert.ok(Object.hasOwn(recorded,url),`Missing fixture ${url}`);return recorded[url];}const response=await fetch(url);assert.ok(response.ok,`${url}: ${response.status}`);return response.json();};
  const lock=JSON.parse(plan.read('versions.lock.json'));assert.ok(lock.schema===2&&Array.isArray(lock.tools)&&lock.tools.length,'Actual schema2 version lock required');
  assert.equal(new Set(lock.tools.map(e=>e.tool)).size,lock.tools.length,'Duplicate version entries');
  const date=new Date().toISOString().slice(0,10),native=[];let report;
  if(config.role==='consumer')report=await planConsumer({root,config,lock,plan,get,date,native});
  else {
    const next=structuredClone(lock),changes=[];
    for(const entry of next.tools.filter(e=>e.scope==='core'&&e.version&&e.status!=='banned')){const resolved=await resolveEntry(entry,get,date);Object.assign(entry,resolved);changes.push({tool:entry.tool,from:lock.tools.find(e=>e.tool===entry.tool).version,to:entry.version,source:entry.source,date});}
    for(const file of ['package.json',path.posix.join(config.npm_dir,'package.json')]){
      const manifest=JSON.parse(plan.read(file));
      for(const group of ['dependencies','devDependencies','optionalDependencies','peerDependencies'])for(const name of Object.keys(manifest[group]??{})){const entry=next.tools.find(e=>e.tool===name);if(entry&&entry.status!=='banned'&&entry.status!=='transitive-only'&&stable(entry.version)&&!manifest[group][name].startsWith('file:'))manifest[group][name]=entry.version;}
      plan.put(file,json(manifest));
    }
    next.resolved=date;plan.put('versions.lock.json',json(next));report={changes,native_commands:native};
  }
  const changed=plan.commit();return {schema:1,check:'versions-resolve',status:'pass',role:config.role,app:config.app,...report,changed};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  try{process.stdout.write(JSON.stringify(await resolveVersions(),null,2)+'\n');}catch(error){process.stderr.write(error.message+'\n');process.exitCode=1;}
}
