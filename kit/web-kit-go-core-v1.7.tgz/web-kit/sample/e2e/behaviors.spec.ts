import './diagnostics';
import { test, expect } from '../../playwright/index.mjs';
const appURL = process.env.GATE_APP_URL;
if (!appURL) throw Error('GATE_APP_URL is required: behavior qualification needs the live sample app image');

test('pw-islands Go-emitted islands mount with each frozen load mode and bubbling identity', async ({ page }) => {
  await page.addInitScript(() => {
    const events: { type: string; key: string; error: string | null }[] = [];
    Object.assign(window, { __islandEvents: events });
    for (const type of ['island:mounted', 'island:failed']) document.addEventListener(type, event => {
      const detail = (event as CustomEvent).detail;
      events.push({ type, key: detail.key, error: detail.error?.message ?? null });
    });
  });
  await page.goto(appURL!);
  await expect.poll(() => page.evaluate(() => (window as Window & { __islandEvents: { type: string; key: string }[] }).__islandEvents.filter(event => event.type === 'island:mounted').map(event => event.key))).toEqual(expect.arrayContaining(['stress-counter', 'stress-presence', 'stress-events']));
  const interaction = page.locator('[data-island="stress-counter"][data-load="interaction"]');
  await expect(interaction).toHaveText('Server skeleton');
  await interaction.dispatchEvent('pointerdown');
  await expect(interaction).not.toHaveText('Server skeleton');
  expect(await page.evaluate(() => (window as Window & { __islandEvents: { type: string }[] }).__islandEvents.filter(event => event.type === 'island:failed'))).toEqual([]);
  await expect.poll(() => page.evaluate(() => (window as Window & { __islandEvents: { type: string; key: string }[] }).__islandEvents.filter(event => event.type === 'island:mounted' && event.key === 'stress-counter').length)).toBe(2);
});

test('pw-islands real loader retains the server skeleton and executes only its nonced legacy fallback', async ({ page }) => {
  await page.route('**/legacy-fixture.js', route => route.fulfill({ contentType: 'text/javascript', body: 'window.__legacyLoaded=(window.__legacyLoaded||0)+1;' }));
  await page.goto(appURL!);
  await expect.poll(() => page.evaluate(() => !!(window as Window & { roeduSample?: unknown }).roeduSample)).toBe(true);
  await page.evaluate(() => {
    type FixtureModule = { mount(root: Element, props: unknown, ctx: { signal: AbortSignal; nonce: string }): () => void };
    const sample = (window as Window & { roeduSample: { loadIslands(registry: Record<string, () => Promise<FixtureModule>>, scope: ParentNode, nonce: string): () => void } }).roeduSample;
    const sourceJSON = document.querySelector<HTMLScriptElement>('script[type="application/json"]')!;
    const nonce = sourceJSON.nonce;
    const section = document.createElement('section'); section.id = 'failure-fixture';
    const host = document.createElement('div'); host.dataset.island = 'failed-fixture'; host.dataset.props = sourceJSON.id; host.dataset.load = 'eager'; host.dataset.legacy = '/legacy-fixture.js';
    const skeleton = document.createElement('p'); skeleton.textContent = 'Server fixture stays'; host.append(skeleton);
    // Keep parser-created server JSON in place; reconnecting a clone is a TT sink.
    section.append(host); document.querySelector('main')!.append(section);
    section.addEventListener('island:failed', event => {
      const detail = (event as CustomEvent).detail;
      section.dataset.failedKey = detail.key; section.dataset.failedError = detail.error.message;
    });
    sample.loadIslands({ 'failed-fixture': async () => { throw Error('fixture chunk failed'); } }, section, nonce);
  });
  await expect(page.locator('#failure-fixture')).toHaveAttribute('data-failed-key', 'failed-fixture');
  await expect(page.locator('#failure-fixture')).toHaveAttribute('data-failed-error', 'fixture chunk failed');
  await expect(page.locator('#failure-fixture [data-island]')).toHaveText('Server fixture stays');
  await expect.poll(() => page.evaluate(() => (window as Window & { __legacyLoaded?: number }).__legacyLoaded)).toBe(1);
  const sourceNonce=await page.locator('#failure-fixture [data-island]').evaluate(element=>{const script=document.getElementById((element as HTMLElement).dataset.props!);if(!(script instanceof HTMLScriptElement)||script.type!=='application/json')throw Error('Go JSON props linkage missing');return script.nonce;});
  expect(await page.locator('script[src$="/legacy-fixture.js"]').evaluate((element: HTMLScriptElement) => element.nonce)).toBe(sourceNonce);
});

test('pw-behaviors sample light-DOM controls preserve keyboard, ARIA and reading comfort', async ({ page }) => {
  await page.goto(appURL!);
  await expect(page.getByRole('meter', { name: 'Sample progress' })).toHaveAttribute('aria-valuenow', '45');
  const panels = page.locator('roedu-wizard [data-wizard-panel]');
  await expect(panels.nth(0)).toBeVisible(); await page.locator('roedu-wizard [data-wizard-next]').click(); await expect(panels.nth(1)).toBeVisible();
  await page.locator('roedu-wizard [data-wizard-back]').click(); await expect(panels.nth(0)).toBeVisible();
  const size = page.locator('roedu-comfort [data-comfort="size"]'); await size.focus(); await page.keyboard.press('Enter');
  await expect(size).toHaveAttribute('aria-pressed', 'true'); await expect(page.locator('html')).toHaveClass(/roedu-rc-size-1/);
  await page.locator('roedu-comfort [data-comfort="reset"]').click(); await expect(page.locator('html')).not.toHaveClass(/roedu-rc-size-1/);
  expect(await page.locator('roedu-comfort').evaluate(element => element.shadowRoot)).toBeNull();
});

test('pw-behaviors hovercard uses server HTML and keeps the original veto cache with enforced Trusted Types', async ({ page }) => {
  let requests = 0; page.on('request', request => { if (request.url().endsWith('/api/veto')) requests++; });
  const navigation=await page.goto(new URL('/behaviors?__gate_tt=enforced',appURL!).href);
  expect(navigation?.headers()['content-security-policy']).toContain("require-trusted-types-for 'script'");
  await page.getByRole('button', { name: 'Sample person', exact: true }).focus();
  await expect(page.getByRole('dialog', { name: 'Sample person card' })).toContainText('Sample person');
  await page.keyboard.press('Escape'); await expect(page.locator('roedu-hovercard')).toBeHidden();
  await page.locator('roedu-hovercard').evaluate(element => element.setAttribute('data-url', '/api/veto'));
  const trigger = page.getByRole('button', { name: 'Sample person', exact: true });
  await trigger.evaluate(element => (element as HTMLElement).blur()); await trigger.focus(); await expect.poll(() => requests).toBe(1);
  await trigger.evaluate(element => (element as HTMLElement).blur()); await trigger.focus();
  await page.waitForTimeout(350); expect(requests).toBe(1); await expect(page.locator('roedu-hovercard')).toBeHidden();
});

test('pw-behaviors speak delegates only after a user action and aborts listeners after removal', async ({ page }) => {
  await page.addInitScript(() => {
    Object.assign(window, { __spoken: [] as string[], roSpeak: (text: string, done: () => void) => { (window as Window & { __spoken: string[] }).__spoken.push(text); done(); } });
  });
  await page.goto(appURL!); expect(await page.evaluate(() => (window as Window & { __spoken: string[] }).__spoken)).toEqual([]);
  await page.getByRole('button', { name: 'Speak sample' }).click(); expect(await page.evaluate(() => (window as Window & { __spoken: string[] }).__spoken)).toEqual(['Bun venit']);
  await page.locator('roedu-speak').evaluate(element => { element.remove(); element.querySelector<HTMLButtonElement>('button')!.click(); });
  expect(await page.evaluate(() => (window as Window & { __spoken: string[] }).__spoken)).toEqual(['Bun venit']);
});

test('pw-behaviors behaviors remain calm under actual prefers-reduced-motion', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' }); await page.goto(appURL!);
  for (const selector of ['roedu-wizard', 'roedu-meter', 'roedu-speak', 'roedu-comfort']) {
    expect(await page.locator(selector).evaluate(element => ({ animation: getComputedStyle(element).animationName, transition: getComputedStyle(element).transitionDuration }))).toEqual({ animation: 'none', transition: '0s' });
  }
});
