import json,os,pathlib,signal,subprocess,sys,time,hashlib,threading,stat as filemode
spec_bytes=pathlib.Path(sys.argv[1]).read_bytes()
expected_spec=sys.argv[2]
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"): raise RuntimeError("optimized Python refused")
if hashlib.sha256(spec_bytes).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")
spec=json.loads(spec_bytes.decode("utf-8"))
REQUIRED_SPEC_KEYS = ['candidate_sha256', 'contract_required_spec_keys', 'contract_required_step_keys', 'deadline_epoch', 'full_R_S_baseline', 'go_sha256', 'growth_cap', 'host_launcher_pid', 'linux_build_root', 'linux_gocache', 'linux_gomodcache', 'linux_gopath', 'linux_goroot', 'linux_guard', 'linux_protected', 'linux_run', 'linux_spec', 'linux_stage', 'linux_target', 'memory_floor', 'module_source_dirs', 'module_source_files', 'python_sha256', 'review_hashes', 'reviewer_ids', 'rss_cap', 'sdk_dirs', 'sdk_files', 'stage_files', 'started_epoch', 'steps', 'target_after_sha256', 'target_before_sha256', 'windows_R', 'windows_S', 'windows_build_root', 'windows_gomodcache', 'windows_goroot', 'windows_protected', 'windows_run', 'windows_spec', 'windows_stage', 'windows_target']
REQUIRED_STEP_KEYS = ['argv', 'linux_output', 'name', 'windows_output']
LATE_ADMISSION_KEYS = ['deadline_epoch', 'full_R_S_baseline', 'host_launcher_pid', 'started_epoch']
def translated_windows_path(value):
 if not isinstance(value,str):raise RuntimeError("Windows path type")
 q=value.replace(chr(92),"/")
 if len(q)<3 or q[1:3]!=":/" or not q[0].isalpha() or "/../" in q or q.endswith("/.."):raise RuntimeError("Windows absolute path contract")
 return "/mnt/"+q[0].lower()+q[2:]
def validate_contract(v,clock=True):
 if not isinstance(v,dict):raise RuntimeError("spec object required")
 wanted=set(REQUIRED_SPEC_KEYS)-(set() if clock else set(LATE_ADMISSION_KEYS))
 missing=sorted(wanted-set(v))
 if missing:raise RuntimeError("required spec fields missing: "+repr(missing))
 if v["contract_required_spec_keys"]!=REQUIRED_SPEC_KEYS or v["contract_required_step_keys"]!=REQUIRED_STEP_KEYS:raise RuntimeError("required-key contract drift")
 for win,lin in [("windows_spec","linux_spec"),("windows_run","linux_run"),("windows_stage","linux_stage"),("windows_build_root","linux_build_root"),("windows_goroot","linux_goroot"),("windows_gomodcache","linux_gomodcache"),("windows_target","linux_target")]:
  if translated_windows_path(v[win])!=v[lin]:raise RuntimeError("exact Windows/Linux path binding: "+win)
 steps=v["steps"]
 if not isinstance(steps,list) or len(steps)!=1 or [x.get("name") for x in steps]!=["authcore-imported-metadata"]:raise RuntimeError("one exact metadata producer contract")
 for x in steps:
  if not isinstance(x,dict) or set(REQUIRED_STEP_KEYS)-set(x):raise RuntimeError("required step fields missing")
  if translated_windows_path(x["windows_output"])!=x["linux_output"]:raise RuntimeError("exact step output path binding")
  if x["argv"]!=[v["linux_goroot"]+"/bin/go","-C",v["linux_stage"]+"/shared-go/authcore","list","-deps","-test","-json","./..."]:raise RuntimeError("fixed metadata argv contract")

validate_contract(spec)
if str(pathlib.Path(sys.argv[1]))!=spec["linux_spec"]:raise RuntimeError("exact Linux actual-spec path mismatch")
index=int(sys.argv[3]); step=spec["steps"][index]; run=pathlib.Path(spec["linux_run"])
mono_deadline=time.monotonic()+spec["deadline_epoch"]-time.time()
if spec["deadline_epoch"]-spec["started_epoch"]!=1200: raise RuntimeError("campaign duration drift")
cancel=run/"cancel"; pgid=None; child=None; initial=None; peak=0; error=None; cleanup_attempted=False; cleanup_confirmed=False
emit_lock=threading.Lock()
def emit(v):
 with emit_lock:print(json.dumps(v,separators=(",",":")),flush=True)
def stat(pid):
 try:
  t=pathlib.Path("/proc",str(pid),"stat").read_text(); f=t[t.rfind(")")+2:].split()
  return int(f[2]),int(f[19]),int(f[21])*os.sysconf("SC_PAGE_SIZE"),f[0]
 except (FileNotFoundError,ProcessLookupError): return None
def group():
 rows=[]
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdigit(): continue
  v=stat(p.name)
  if v and (int(p.name)==os.getpid() or v[0]==pgid): rows.append((int(p.name),*v))
 return rows
def memory():
 return int(next(x.split()[1] for x in pathlib.Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))*1024
stopping=False
def interrupted(signum,frame):
 global stopping
 stopping=True
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
def spec_pin():
 if hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")
def cleanup():
 global child,pgid,initial,cleanup_attempted,cleanup_confirmed
 if cleanup_attempted:
  if cleanup_confirmed:return
  raise RuntimeError("prior cleanup uncertain; refusing repeated process-group action")
 cleanup_attempted=True
 if child is None:
  cleanup_confirmed=True
  return
 leader=stat(child.pid)
 if leader is not None and initial is not None and leader[1]!=initial[1]: raise RuntimeError("owned leader generation changed")
 if any(x[1]==pgid and x[4]!="Z" for x in group()):
  try: os.killpg(pgid,signal.SIGTERM)
  except ProcessLookupError: pass
  end=time.monotonic()+2
  while time.monotonic()<end and any(x[1]==pgid and x[4]!="Z" for x in group()): time.sleep(.05)
  if any(x[1]==pgid and x[4]!="Z" for x in group()):
   try: os.killpg(pgid,signal.SIGKILL)
   except ProcessLookupError: pass
 child.wait(timeout=5)
 if any(x[1]==pgid for x in group()): raise RuntimeError("owned group still present")
 cleanup_confirmed=True;child=None;pgid=None;initial=None

NAMESPACE_FIELDS=[("linux_goroot","sdk_files","sdk_dirs"),("linux_gomodcache","module_source_files","module_source_dirs")]
def immutable_namespaces():
 for root_key,files_key,dirs_key in NAMESPACE_FIELDS:
  base=pathlib.Path(spec[root_key]);base_info=base.lstat()
  if filemode.S_ISLNK(base_info.st_mode) or getattr(base_info,"st_file_attributes",0)&0x400 or not filemode.S_ISDIR(base_info.st_mode):raise RuntimeError("immutable source root reparse/type refused")
  files=set();dirs={"."};pending=[base]
  while pending:
   assert not stopping and not cancel.exists(),"cancel during namespace scan"
   with os.scandir(pending.pop()) as entries:
    for entry in entries:
     info=entry.stat(follow_symlinks=False);p=pathlib.Path(entry.path);rel=p.relative_to(base).as_posix()
     if filemode.S_ISLNK(info.st_mode) or getattr(info,"st_file_attributes",0)&0x400:raise RuntimeError("immutable source reparse/symlink refused: "+entry.path)
     if filemode.S_ISDIR(info.st_mode):dirs.add(rel);pending.append(p)
     elif filemode.S_ISREG(info.st_mode):files.add(rel)
     else:raise RuntimeError("immutable source nonregular refused: "+entry.path)
  assert files==set(spec[files_key]) and dirs==set(spec[dirs_key]),"complete immutable source namespace drift: "+root_key

def target_and_namespace(after=False):
 root=pathlib.Path(spec["linux_stage"]);names=set();pending=[root]
 while pending:
  assert not stopping and not cancel.exists(),"cancel during namespace scan"
  with os.scandir(pending.pop()) as entries:
   for entry in entries:
    info=entry.stat(follow_symlinks=False)
    if filemode.S_ISLNK(info.st_mode):raise RuntimeError("stage symlink refused: "+entry.path)
    if filemode.S_ISDIR(info.st_mode):pending.append(pathlib.Path(entry.path))
    elif filemode.S_ISREG(info.st_mode):names.add(str(pathlib.Path(entry.path).relative_to(root)))
    else:raise RuntimeError("stage nonregular refused: "+entry.path)
 assert names==set(spec["stage_files"]),"full stage namespace drift"
 immutable_namespaces()
 assert not (root/".cat-content-ops.lock").exists(),"operator lock present"
 target=pathlib.Path(spec["linux_target"])
 assert target==root/"cat_de_roman_esti/fixtures/quick_games_v92.json"
 expected=spec["target_after_sha256"] if after else spec["target_before_sha256"]
 assert hashlib.sha256(target.read_bytes()).hexdigest()==expected,"Quick target pin drift"

def sample_supervisor():
 global stopping
 try:
  while True:
   rows=group();rss=sum(x[3] for x in rows)
   emit({"kind":"sample","rss":rss,"phase":"supervisor-and-owned-session"})
   if stopping or cancel.exists() or rss>spec["rss_cap"] or memory()<spec["memory_floor"] or time.time()>=spec["deadline_epoch"]-180:stopping=True
   time.sleep(.25)
 except BaseException as exc:
  stopping=True;emit({"kind":"failed","error":"supervisor sampler: "+repr(exc),"group_absent":False})
threading.Thread(target=sample_supervisor,daemon=True).start()
try:
 spec_pin()
 assert not stopping and not cancel.exists(),"pre-admission cooperative cancel"
 target_and_namespace()
 assert hashlib.sha256(pathlib.Path("/usr/bin/python3.14").read_bytes()).hexdigest()==spec["python_sha256"]
 assert memory()>=spec["memory_floor"]
 assert time.time()<spec["deadline_epoch"]-195
 for path,digest in spec["linux_protected"].items():
  assert not stopping and not cancel.exists(),"cancel during pre-readset"
  assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
 executable=pathlib.Path(step["argv"][0]); assert os.access(executable,os.X_OK),"preserved operator execute access absent"
 assert hashlib.sha256(executable.read_bytes()).hexdigest()==spec["go_sha256"]
 env={}
 env.update({"GOMAXPROCS":"2","GOTOOLCHAIN":"local","GOPROXY":"off","GOSUMDB":"off","GOPRIVATE":"","GONOPROXY":"none","GONOSUMDB":"none","TEST_TELEMETRY_DIR":str(pathlib.Path(spec["linux_build_root"])/"telemetry"),"GOENV":"off","GOWORK":"off","CGO_ENABLED":"0","GOOS":"linux","GOARCH":"amd64","GOAMD64":"v1","GOEXPERIMENT":"","GOFLAGS":"-mod=readonly -p=2 -buildvcs=false","GOMEMLIMIT":"1536MiB","HOME":str(run/"tmp"),"PATH":str(pathlib.Path(spec["linux_build_root"])/"native-path"),"GOROOT":spec["linux_goroot"],"GOCACHE":spec["linux_gocache"],"GOMODCACHE":spec["linux_gomodcache"],"GOPATH":spec["linux_gopath"],"GOTMPDIR":str(run/"tmp"),"TMPDIR":str(run/"tmp")})
 for key in ("linux_gocache","linux_gomodcache","linux_gopath"):
  owned=pathlib.Path(spec[key]);base=pathlib.Path(spec["linux_build_root"]);assert owned.is_dir(),key
  if key=="linux_gopath":assert owned==base/"gopath"
  else:assert str(owned)=="/mnt/c/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/toolbuild-r1/"+("gocache" if key=="linux_gocache" else "gomodcache")
 assert spec["target_before_sha256"]==spec["target_after_sha256"],"build cannot alter current Quick target"
 assert (pathlib.Path(spec["linux_build_root"])/"telemetry/mode").read_bytes()==b"off 2026-10-09\n","owned Go telemetry off mode drift"
 assert executable==pathlib.Path(spec["linux_goroot"])/"bin/go","only preserved qualified Go executable"
 assert step["argv"]==[str(executable),"-C",str(pathlib.Path(spec["linux_stage"])/"shared-go/authcore"),"list","-deps","-test","-json","./..."]
 assert step["name"]=="authcore-imported-metadata"
 assert pathlib.Path(step["linux_output"]).parent==base/"tools" and not pathlib.Path(step["linux_output"]).exists(),"fresh owned build output"
 with pathlib.Path(step["linux_output"]).open("xb") as out,(run/(step["name"]+".stderr.log")).open("wb") as err:
  spec_pin();assert not stopping and not cancel.exists(),"cooperative signal/cancel before launch"
  assert memory()>=spec["memory_floor"]
  assert time.monotonic()<mono_deadline-195 and time.time()<spec["deadline_epoch"]-195
  assert not stopping and not cancel.exists(),"immediate pre-Popen cancel"
  child=subprocess.Popen(step["argv"],cwd=spec["linux_stage"],env=env,stdout=out,stderr=err,start_new_session=True)
  pgid=child.pid; initial=stat(pgid); assert initial is not None
  while True:
   rows=group(); rss=sum(x[3] for x in rows); peak=max(peak,rss)
   emit({"kind":"sample","rss":rss,"peak":peak,"pid":child.pid,"start_ticks":initial[1]})
   if stopping or rss>spec["rss_cap"] or memory()<spec["memory_floor"] or cancel.exists() or (time.time()>=spec["deadline_epoch"]-180 or time.monotonic()>=mono_deadline-180): raise RuntimeError("native RSS/memory/cancel/reserve guard")
   done=os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
   if done is not None: break
   time.sleep(.25)
  assert done.si_code==os.CLD_EXITED and done.si_status==0,("command exited",done.si_code,done.si_status)
 cleanup();spec_pin();target_and_namespace(after=True)
 output=pathlib.Path(step["linux_output"]);assert output.is_file() and 0<output.stat().st_size<=16*1024**2,"bounded metadata output"
 emit({"kind":"build-output","step":step["name"],"output_sha256":hashlib.sha256(output.read_bytes()).hexdigest(),"output_bytes":output.stat().st_size})
 for path,digest in spec["linux_protected"].items():
  assert not stopping and not cancel.exists(),"cancel during post-readset"
  assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
 assert hashlib.sha256(pathlib.Path("/usr/bin/python3.14").read_bytes()).hexdigest()==spec["python_sha256"]
 assert not stopping,"cooperative signal before completion"
 emit({"kind":"complete","step":step["name"],"returncode":0,"native_peak":peak,"group_absent":True})
except BaseException as exc:
 error=repr(exc);absent=False
 try: cleanup();absent=True
 except BaseException as cleanup_error: error+=";cleanup="+repr(cleanup_error)
 emit({"kind":"failed","step":step["name"],"error":error,"native_peak":peak,"group_absent":absent})
 sys.exit(1)


