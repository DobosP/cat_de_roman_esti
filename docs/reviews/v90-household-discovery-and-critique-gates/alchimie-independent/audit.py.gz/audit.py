import ast
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates')
SCRATCH = Path('/home/dobo/work/_temp/feat__v90-household-discovery-and-critique-gates/alchimie-review')
RAW = SCRATCH.parent / 'alchimie'
LANE = ROOT / 'docs/reviews/v90-household-discovery-and-critique-gates/alchimie-action'
V = json.loads((LANE / 'verification.json').read_text())
B = json.loads((LANE / 'baseline-proof.json').read_text())
P = json.loads((LANE / 'preserved-behavior.json').read_text())
issues = []
def digest(data):
    return hashlib.sha256(data).hexdigest()
def check(condition, name):
    if not condition:
        issues.append(name)
def baseline(path):
    return subprocess.check_output(['git', 'show', V['baseline'] + ':' + path], cwd=ROOT)

for path, sha in V['sources'].items():
    check(digest((ROOT / path).read_bytes()) == sha, 'candidate source ' + path)
development_matches = {path: digest((ROOT / path).read_bytes()) == sha for path, sha in V['development_gate_bindings'].items()}
for path, sha in B['source_bindings'].items():
    check(digest(baseline(path)) == sha, 'baseline source ' + path)
for row in P['files']:
    old, current = baseline(row['path']), (ROOT / row['path']).read_bytes()
    check(old == current and digest(old) == row['baseline_sha256'] == row['candidate_sha256'], 'preserved source ' + row['path'])
for row in V['archives']:
    archive = (LANE / row['archive']).read_bytes()
    raw = gzip.decompress(archive)
    check(digest(archive) == row['archive_sha256'], 'archive SHA ' + row['archive'])
    check(digest(raw) == row['decoded_sha256'] and len(raw) == row['decoded_bytes'], 'decoded SHA/length ' + row['archive'])
    check(archive[4:8] == bytes(4), 'gzip mtime ' + row['archive'])
    check(raw == (RAW / row['source']).read_bytes(), 'raw equality ' + row['archive'])
for row in V['images']:
    data = (LANE / row['path']).read_bytes()
    check(digest(data) == row['sha256'] and len(data) == row['bytes'], 'image SHA/length ' + row['path'])
    check(data == (RAW / row['source']).read_bytes(), 'image raw equality ' + row['path'])
for case in B['cases']:
    kind = case['kind']
    raw_case = json.loads(gzip.decompress((LANE / f'baseline-results--baseline-baseline-lost-{kind}-desktop--baseline-{kind}.json.gz').read_bytes()))
    check(case == raw_case, 'baseline case raw equality ' + kind)
    check(case['counts'] == {'reads': 0, 'mutations': 1}, 'baseline request counts ' + kind)
    check(case['after']['game_id'] == case['committed']['game_id'] == case['before']['game_id'], 'baseline identities ' + kind)
    for key in ('inventory', 'moves', 'hints_used', 'won'):
        check(case['after'][key] == case['committed'][key], 'baseline committed GET equality ' + kind + ':' + key)
hint = next(case for case in B['cases'] if case['kind'] == 'hint')
check(hint['after']['hints_used'] == 1 and not {'hint', 'hint_output', 'earned_hint'} & hint['after'].keys(), 'baseline paid cue absent from GET')

receipts = {}
for filename, regex in {
    'backend-focused.log.gz': r'74 passed in 130\.63s',
    'backend-focused-initial.log.gz': r'24 passed in 1\.14s',
    'native.log.gz': r'pass 193\n.*fail 0',
    'browser.log.gz': r'32 passed \(2\.4m\)',
    'baseline-browser.log.gz': r'4 passed \(15\.4s\)',
    'build.log.gz': r'118\.88 KiB  total',
    'native-initial.log.gz': r'fail 5',
    'browser-initial.log.gz': r'4 failed[\s\S]*28 passed',
}.items():
    text = gzip.decompress((LANE / filename).read_bytes()).decode()
    receipts[filename] = bool(re.search(regex, text))
    check(receipts[filename], 'receipt text ' + filename)

backend_path = 'cat_de_roman_esti/wordgames/alchimie.py'
old_ast = ast.parse(baseline(backend_path))
new_ast = ast.parse((ROOT / backend_path).read_bytes())
def named_nodes(tree):
    return {node.name: node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))}
old_nodes, new_nodes = named_nodes(old_ast), named_nodes(new_ast)
changed = [name for name in old_nodes.keys() | new_nodes.keys() if name not in old_nodes or name not in new_nodes or ast.dump(old_nodes[name]) != ast.dump(new_nodes[name])]
check(set(changed) == {'AlchimieSession', '_state_payload', 'CombineView', 'HintGameView', 'ResetGameView'}, 'backend AST changed definitions')
old_methods = {node.name: ast.dump(node) for node in old_nodes['AlchimieSession'].body if isinstance(node, ast.FunctionDef)}
new_methods = {node.name: ast.dump(node) for node in new_nodes['AlchimieSession'].body if isinstance(node, ast.FunctionDef)}
check(old_methods == new_methods, 'session methods including score unchanged')
nondefinitions = lambda tree: [ast.dump(node) for node in tree.body if not isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))]
check(nondefinitions(old_ast) == nondefinitions(new_ast), 'backend imports/constants/routes unchanged')

result = {
    'baseline': V['baseline'], 'branch_head_at_review': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(),
    'sources': V['sources'], 'development_gate_bindings': V['development_gate_bindings'],
    'development_current_matches': development_matches,
    'candidate_sources_verified': len(V['sources']), 'baseline_sources_verified': len(B['source_bindings']),
    'unchanged_sources_verified': len(P['files']), 'raw_and_archive_pairs_verified': len(V['archives']),
    'raw_image_pairs_verified': len(V['images']), 'baseline_cases_verified': len(B['cases']),
    'receipt_checks': receipts, 'backend_changed_definitions': sorted(changed),
    'backend_session_methods_unchanged': sorted(old_methods),
    'lane_record_bindings': {name:digest((LANE/name).read_bytes()) for name in ['verification.json','baseline-proof.json','preserved-behavior.json','README.md']},
    'issues': issues,
}
(SCRATCH / 'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['sources','development_gate_bindings','lane_record_bindings']},ensure_ascii=False,indent=2))
raise SystemExit(bool(issues))
