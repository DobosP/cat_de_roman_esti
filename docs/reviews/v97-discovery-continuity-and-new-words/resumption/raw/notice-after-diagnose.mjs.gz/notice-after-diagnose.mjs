import { chromium, devices, expect } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v97-discovery-continuity-and-new-words/frontend/node_modules/@playwright/test/index.mjs';
import { games, deterministicStarts, start, solve, solution, openGameOptions } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v97-discovery-continuity-and-new-words/frontend/e2e/games.mjs';
import { writeFileSync } from 'node:fs';
const output = new URL('./', import.meta.url).pathname;
const browser = await chromium.launch({ headless:true });
const rows=[];
const game=games.find(g=>g.key==='lant');
try {
for (const mode of ['clock-immediate','real-clock','clock-settled']) {
 const context=await browser.newContext({...devices['Pixel 7'], baseURL:'http://127.0.0.1:8188',locale:'ro-RO',timezoneId:'Europe/Bucharest',reducedMotion:'reduce'});
 const page=await context.newPage();
 await page.setViewportSize({width:412,height:560});
 if(mode!=='real-clock') await page.clock.install();
 const capture=async phase=>{
  const geometry=await page.evaluate(()=>{
   const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom}};
   const notice=document.querySelector('.start-failure-notice');
   const replay=[...document.querySelectorAll('button')].find(b=>/Încă un lanț|Se pregătește/.test(b.textContent));
   const card=notice.closest('[role=status]');
   return {notice:rect(notice),replay:rect(replay),card:rect(card),cardStyle:card.getAttribute('style'),scrollTop:document.querySelector('.screen-pad').scrollTop,appNotices:rect(document.querySelector('.app-notices')),focused:document.activeElement?.textContent};
  });
  rows.push({mode,phase,...geometry});
  await page.screenshot({path:`${output}${mode}-${phase}.png`});
 };
 await deterministicStarts(page,game);
 await start(page,game);
 await openGameOptions(page,game);
 await page.getByText('Reguli și ajutor',{exact:true}).click();
 await solve(page,game,solution(game).steps);
 await expect.poll(()=>page.evaluate(()=>JSON.parse(localStorage.getItem('cat_wordgame_scores_v1')).lant.played)).toBe(1);
 if(mode==='clock-settled') await page.clock.runFor(1000);
 await capture('before-scroll');
 const replay=page.getByRole('button',{name:'Încă un lanț →'});
 await replay.scrollIntoViewIfNeeded();
 await capture('after-scroll');
 await page.route('**/api/wordgames/lant/games?*',route=>route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({detail:'diagnostic controlled create failure'})}),{times:1});
 const response=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname==='/api/wordgames/lant/games');
 await replay.click();
 await response;
 await expect(page.getByRole('alert')).toBeVisible();
 await capture('failure');
 if(mode==='real-clock') await page.waitForTimeout(4000); else await page.clock.fastForward(4000);
 await capture('after-four-seconds');
 if(mode!=='real-clock') await page.clock.runFor(1000);
 await capture('settled');
 await context.close();
}
} finally { await browser.close();writeFileSync(`${output}geometry.json`,JSON.stringify(rows,null,2)); }
