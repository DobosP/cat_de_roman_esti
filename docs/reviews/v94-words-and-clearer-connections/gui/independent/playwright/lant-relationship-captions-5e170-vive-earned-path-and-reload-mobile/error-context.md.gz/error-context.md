# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: lant-relationship-captions.spec.mjs >> lt_literatura_240 route 2: meaningful choices survive earned path and reload
- Location: e2e/lant-relationship-captions.spec.mjs:73:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: 'Copiază rezultatul' })
Expected: visible
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('button', { name: 'Copiază rezultatul' }) with timeout 10000ms
  - waiting for getByRole('button', { name: 'Copiază rezultatul' })
  - Test ended.

```

```yaml
- status
- button "Ieși la lista de jocuri": Ieși
- heading "Lanțul Cuvintelor" [level=2]
- text: Leagă conceptele
- paragraph: Ajungi la țintă prin concepte legate direct.
- button "Cum funcționează"
- list "Cum joci":
  - listitem:
    - strong: Alege o legătură
  - listitem:
    - strong: Fă un salt
  - listitem:
    - strong: Ajungi la țintă
- group: + Personalizează jocul
- button "Joacă →"
- button "Provocarea zilei"
- paragraph:
  - text: "Recordul tău:"
  - strong: "1000"
  - text: · 2/2 mutări
```

# Test source

```ts
  13  | ].map((item) => ({
  14  |   ...item,
  15  |   journey: JSON.parse(execFileSync("python3", [helper, item.id], {
  16  |     cwd: root, env: { ...process.env, PYTHONPATH: root }, encoding: "utf8",
  17  |   })),
  18  | }));
  19  | 
  20  | const responseFor = (page, id, action) => page.waitForResponse((response) =>
  21  |   response.request().method() === "POST" &&
  22  |   new URL(response.url()).pathname === `${gameURL(game, id)}/${action}`);
  23  | 
  24  | async function begin(page, item) {
  25  |   if (test.info().project.name === "mobile") {
  26  |     await page.setViewportSize({ width: 320, height: 900 });
  27  |     await page.addInitScript(() => {
  28  |       globalThis.document.addEventListener("DOMContentLoaded", () => {
  29  |         globalThis.document.documentElement.style.fontSize = "200%";
  30  |       });
  31  |     });
  32  |   }
  33  |   await page.route("**/api/wordgames/lant/games?*", async (route) => {
  34  |     const url = new URL(route.request().url());
  35  |     for (const [name, value] of Object.entries(item.journey.query)) {
  36  |       url.searchParams.set(name, String(value));
  37  |     }
  38  |     await route.continue({ url: url.toString() });
  39  |   });
  40  |   const state = await start(page, game, { keyboard: true });
  41  |   expect(state.start.id).toBe(item.journey.start.id);
  42  |   expect(state.target.id).toBe(item.journey.target.id);
  43  |   return state;
  44  | }
  45  | 
  46  | function meaningful(caption, nouns) {
  47  |   expect(caption).toMatch(nouns);
  48  |   expect(caption).not.toMatch(/^legătură(?: directă)?$/i);
  49  | }
  50  | 
  51  | async function fits(page) {
  52  |   const layout = await page.locator(".lant-choice-grid button, .lant-hint-panel, .breadcrumb-trail, .lant-trail-step, .lant-trail-relation, .lant-trail-step .chip")
  53  |     .evaluateAll((elements) => ({
  54  |       width: globalThis.document.documentElement.clientWidth,
  55  |       scroll: globalThis.document.documentElement.scrollWidth,
  56  |       visible: elements.filter((element) => element.getClientRects().length).map((element) => ({
  57  |         left: element.getBoundingClientRect().left,
  58  |         right: element.getBoundingClientRect().right,
  59  |         width: element.clientWidth,
  60  |         scroll: element.scrollWidth,
  61  |       })),
  62  |     }));
  63  |   expect(layout.scroll).toBeLessThanOrEqual(layout.width + 1);
  64  |   for (const element of layout.visible) {
  65  |     expect(element.left).toBeGreaterThanOrEqual(-1);
  66  |     expect(element.right).toBeLessThanOrEqual(layout.width + 1);
  67  |     expect(element.scroll).toBeLessThanOrEqual(element.width + 1);
  68  |   }
  69  | }
  70  | 
  71  | for (const item of cases) {
  72  |   for (const [index, route] of item.journey.routes.entries()) {
  73  |     test(`${item.id} route ${index + 1}: meaningful choices survive earned path and reload`, async ({ page, request }) => {
  74  |       let state = await begin(page, item);
  75  |       const id = state.game_id;
  76  |       const firstHops = new Set(item.journey.routes.map((path) => path[1].label));
  77  |       const usefulChoices = state.choices.filter((choice) => firstHops.has(choice.label));
  78  |       expect(usefulChoices.length).toBeGreaterThanOrEqual(2);
  79  |       for (const choice of usefulChoices) {
  80  |         meaningful(choice.relation, item.nouns);
  81  |         await expect(page.getByRole("button", { name: `Salt la ${choice.label}: ${choice.relation}`, exact: true }))
  82  |           .toContainText(choice.relation);
  83  |       }
  84  |       await fits(page);
  85  |       if (index === 0) await page.screenshot({ path: test.info().outputPath("choices.png"), fullPage: true });
  86  |       for (const next of route.slice(1)) {
  87  |         const response = responseFor(page, id, "move");
  88  |         const choice = page.locator(".lant-choice-grid button").filter({
  89  |           has: page.locator("strong", { hasText: new RegExp(`^${next.label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`) }),
  90  |         });
  91  |         if (await choice.count()) {
  92  |           await tabTo(page, choice);
  93  |           await page.keyboard.press("Space");
  94  |         } else {
  95  |           const input = page.getByRole("textbox", { name: "Următorul concept" });
  96  |           await tabTo(page, input);
  97  |           await input.fill(next.label);
  98  |           await input.press("Enter");
  99  |         }
  100 |         state = await (await response).json();
  101 |         expect(state.ok).toBe(true);
  102 |         expect(state.current.id).toBe(next.id);
  103 |         meaningful(state.path.at(-1).relation, item.nouns);
  104 |       }
  105 |       expect(state.won).toBe(true);
  106 |       let mutations = 0;
  107 |       page.on("request", (request) => {
  108 |         if (request.method() === "POST" && new URL(request.url()).pathname.startsWith(`${gameURL(game, id)}/`)) mutations += 1;
  109 |       });
  110 |       const saved = await (await request.get(gameURL(game, id))).json();
  111 |       expect(saved.path).toEqual(state.path);
  112 |       await page.reload();
> 113 |       await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeVisible();
      |                                                                              ^ Error: expect(locator).toBeVisible() failed
  114 |       const options = page.locator(".game-options > summary");
  115 |       await tabTo(page, options);
  116 |       await page.keyboard.press("Space");
  117 |       const path = page.getByRole("group", { name: "Traseul parcurs" });
  118 |       for (const step of saved.path.slice(1)) await expect(path).toContainText(step.relation);
  119 |       expect(mutations).toBe(0);
  120 |       await fits(page);
  121 |       if (index === 0) await page.screenshot({ path: test.info().outputPath("earned-path.png"), fullPage: true });
  122 |       await test.info().attach("earned-captions", {
  123 |         body: JSON.stringify({ seed: item.journey.query, path: saved.path }, null, 2), contentType: "application/json",
  124 |       });
  125 |     });
  126 |   }
  127 | 
  128 |   test(`${item.id}: noun-bearing hints persist without taking a hop`, async ({ page, request }) => {
  129 |     const initial = await begin(page, item);
  130 |     const id = initial.game_id;
  131 |     async function ask() {
  132 |       const response = responseFor(page, id, "hint");
  133 |       const button = page.getByRole("button", { name: /💡 (?:Indiciu|Mai clar)/ });
  134 |       await tabTo(page, button);
  135 |       await page.keyboard.press("Space");
  136 |       return (await response).json();
  137 |     }
  138 |     const direction = await ask();
  139 |     expect(direction.stage).toBe("direction");
  140 |     meaningful(direction.relation, item.nouns);
  141 |     await expect(page.locator(".lant-hint-panel")).toContainText(direction.relation);
  142 |     await page.reload();
  143 |     await expect(page.locator(".lant-hint-panel")).toContainText(direction.relation);
  144 |     const saved = await (await request.get(gameURL(game, id))).json();
  145 |     expect(saved.moves).toBe(0);
  146 |     expect(saved.earned_hint).toEqual(direction);
  147 |     const alternatives = await ask();
  148 |     expect(alternatives.stage).toBe("alternatives");
  149 |     for (const choice of alternatives.alternatives_choices) {
  150 |       meaningful(choice.relation, item.nouns);
  151 |       await expect(page.locator(".lant-hint-panel").getByRole("button", {
  152 |         name: `Salt la ${choice.label}: ${choice.relation}`, exact: true,
  153 |       })).toBeVisible();
  154 |     }
  155 |     const exact = await ask();
  156 |     expect(exact.stage).toBe("hop");
  157 |     meaningful(exact.relation, item.nouns);
  158 |     await expect(page.locator(".lant-hint-panel")).toContainText(exact.relation);
  159 |     await fits(page);
  160 |     await page.screenshot({ path: test.info().outputPath("exact-hint.png"), fullPage: true });
  161 |     const move = responseFor(page, id, "move");
  162 |     await tabTo(page, page.locator(".hint-fill-button"));
  163 |     await page.keyboard.press("Space");
  164 |     const moved = await (await move).json();
  165 |     expect(moved.moves).toBe(1);
  166 |     expect(moved.current.id).toBe(exact.hint.id);
  167 |     expect(moved.path.at(-1).relation).toBe(exact.relation);
  168 |     await expect(page.locator(".lant-hint-panel")).toHaveCount(0);
  169 |     await expect(page.locator(".lant-choice-grid button").first()).toBeFocused();
  170 |   });
  171 | }
  172 | 
```