import { test,expect,auditAxe,observeVitals,committedBudgets,writeBrowserMeasurement } from '../../playwright/index.mjs';
test('axe actual locked axeSource scans every sample page',async({page})=>{
  if(!process.env.GATE_APP_URL)throw Error('Live app required');
  const pages=[];
  for(const route of ['/','/pongo2','/islands','/behaviors','/motion','/templ']){
    const response=await page.goto(route);expect(response?.status()).toBe(200);
    await expect(page.locator('[data-island="stress-counter"][data-load="eager"]')).toContainText('Increment counter');
    const {results,fingerprint,axe_source_sha256}=await auditAxe(page);
    pages.push({route,fingerprint,axe_source_sha256,violations:results.violations,passes:results.passes.length,incomplete:results.incomplete.length});
  }
  writeBrowserMeasurement('axe',{pages});for(const page of pages)expect(page.violations).toEqual([]);
});
test('vitals actual web-vitals6 LCP and interacted INP under committed throttle',async({page})=>{
  if(!process.env.GATE_APP_URL)throw Error('Live app required');
  const limits=committedBudgets().vitals,observed=await observeVitals(page);
  const response=await page.goto('/islands');expect(response?.status()).toBe(200);
  const counter=page.locator('[data-island="stress-counter"][data-load="eager"]');await expect(counter).toContainText('Increment counter');
  for(let i=0;i<5;i++)await counter.getByRole('button',{name:'Increment counter'}).click();
  await expect(counter).toContainText('Count: 5');
  // Real navigation finalizes metrics; no synthetic performance entries or visibility properties.
  await page.goto('about:blank');
  await expect.poll(()=>observed.metrics.some(m=>m.name==='LCP')&&observed.metrics.some(m=>m.name==='INP')).toBe(true);
  const lcp=observed.metrics.filter(m=>m.name==='LCP').at(-1)!,inp=observed.metrics.filter(m=>m.name==='INP').at(-1)!;
  writeBrowserMeasurement('vitals',{route:'/islands',source_sha256:observed.source_sha256,throttle:limits.throttle,interactions:5,metrics:observed.metrics,actual:{lcp_ms:lcp.value,inp_ms:inp.value},limits:{lcp_ms:limits.lcp_ms,inp_ms:limits.inp_ms}});
  expect(lcp.value).toBeGreaterThan(0);expect(inp.value).toBeGreaterThanOrEqual(0);expect(lcp.value).toBeLessThan(limits.lcp_ms);expect(inp.value).toBeLessThan(limits.inp_ms);
});
