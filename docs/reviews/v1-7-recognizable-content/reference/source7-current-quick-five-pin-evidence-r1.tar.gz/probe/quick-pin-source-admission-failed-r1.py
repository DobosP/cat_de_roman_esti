
import pathlib,os,stat,json,time,datetime,hashlib,ctypes,shutil,subprocess
S=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7")
R=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-7")
OLD=S.parent/"codex__content-v1-7-qualification"
start=time.time(); G=1<<30
roots=[R,S,OLD/"toolbuild-r1/gocache",OLD/"toolbuild-r1/gomodcache"]
def count(root):
 total=files=dirs=0; pending=[root]
 while pending:
  p=pending.pop();a=p.lstat();assert stat.S_ISDIR(a.st_mode) and not stat.S_ISLNK(a.st_mode) and not getattr(a,"st_file_attributes",0)&0x400
  dirs+=1
  with os.scandir(p) as es:
   for e in es:
    q=e.stat(follow_symlinks=False);assert not stat.S_ISLNK(q.st_mode) and not getattr(q,"st_file_attributes",0)&0x400
    if stat.S_ISDIR(q.st_mode):pending.append(pathlib.Path(e.path))
    else:assert stat.S_ISREG(q.st_mode) and q.st_nlink==1;total+=q.st_size;files+=1
  z=p.lstat();assert (a.st_dev,a.st_ino)==(z.st_dev,z.st_ino)
 return dict(bytes=total,files=files,dirs=dirs)
counts={str(p):count(p) for p in roots};baseline=sum(x["bytes"] for x in counts.values())
class M(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","tp","ap","tv","av","extra"]]
m=M();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
r=subprocess.run(["wsl.exe","-e","/usr/bin/python3","-I","-B","-c","import json; print(json.dumps({'MemAvailable_kB':int(next(x.split()[1] for x in open('/proc/meminfo') if x.startswith('MemAvailable:')))}))"],capture_output=True,timeout=20)
assert r.returncode==0 and not r.stderr;linux=json.loads(r.stdout)["MemAvailable_kB"]*1024
free=shutil.disk_usage(S).free
assert free>=17*G and m.available>=16*G and linux>=16*G
j={"kind":"fresh-complete-source-and-checkpoint-admission-v1","purpose":"exact5 isolated Quickpin changes and durable isolatedtransition checkpoint, independent source/metadata reviews plus nativeWindowsdocs only; noGo/operator/gameplay inthis source phase","start_epoch":start,"cutoff_epoch":start+1020,"deadline_epoch":start+1200,"start_utc":datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),"accounting_roots":[str(p) for p in roots],"full_owned_counts":counts,"baseline_bytes":baseline,"increment_limit_bytes":G,"absolute_ceiling_bytes":baseline+G,"explicitly_higher_absolute_ceiling":True,"previous_native_transition_baseline_immutable":3190956343,"disk_free_bytes":free,"Windows_available_bytes":m.available,"Linux_available_bytes":linux,"source_metadata_RSS":"unmeasured","native_sampled_group_RSS_limit_bytes":2*G,"disk_remaining_floor_bytes":16*G,"metadata_reserve_seconds":180,"no_active_native_owner":True,"previous_transition_closed_utc":"2026-10-09T15:51:59.544236+00:00"}
p=S/"quick-pin-source-checkpoint-admission-r1.json"
with p.open("x",encoding="utf-8") as f:json.dump(j,f,indent=2);f.write("\n")
print(json.dumps(j))
