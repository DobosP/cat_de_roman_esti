import {readFileSync,writeFileSync,statSync,existsSync} from "node:fs";
import {join} from "node:path";
import {randomUUID} from "node:crypto";
import {spawnSync} from "node:child_process";
import {parseLaunch,rejectAmbient,digest,validateReceipt,assertChildSuccess} from "./policy.mjs";
import {ROOT,inspectBinding,reserveRun,materializeEvidence,shaFile} from "./io.mjs";
const started=Date.now();
let run=null;
try{
 const args=parseLaunch(process.argv.slice(2));rejectAmbient(process.env);
 const checked=inspectBinding(args.path,args.sha,args.profile);
 run=reserveRun();
 const unsigned={schema_version:1,run_id:run.runId,out_dir:run.out,started_at:Date.now(),binding:checked.binding,
  reviewed_binding_sha256:args.sha,state_sha256:checked.state_sha256,selection:"complete-inventory-no-filters",config_file:join(ROOT,"playwright.config.mjs"),argv:[process.execPath,join(checked.binding.browser.package_root,"cli.js"),"test","-c",join(ROOT,"playwright.config.mjs")]};
 const descriptor={...unsigned,descriptor_sha256:digest(unsigned)};
 const descriptorPath=join(run.out,"descriptor.json");writeFileSync(descriptorPath,JSON.stringify(descriptor,null,2)+"\n");
 const childEnv={PATH:process.env.PATH||"",LANG:"C.UTF-8",TZ:"Europe/Bucharest",TMPDIR:join(ROOT,"runtime-tmp"),
  IMPORT_DESCRIPTOR:descriptorPath,MOTION_PLAYWRIGHT_TEST_MODULE:"file://"+join(ROOT,"runner-api.mjs")};
 const child=spawnSync(process.execPath,[join(checked.binding.browser.package_root,"cli.js"),"test","-c",join(ROOT,"playwright.config.mjs")],
  {cwd:ROOT,env:childEnv,encoding:"utf8",maxBuffer:32*1024*1024});
 writeFileSync(join(run.out,"process.log"),(child.stdout||"")+(child.stderr||""));
 assertChildSuccess({status:child.status,signal:child.signal||null,error:child.error||null});
 if(!existsSync(run.report))throw Error("fresh Playwright receipt missing");
 const finish=Date.now();
 const after=inspectBinding(args.path,args.sha,args.profile);
 if(after.state_sha256!==checked.state_sha256)throw Error("source/build/browser/harness drift during execution");
 const report=materializeEvidence(JSON.parse(readFileSync(run.report)),run.out);
 const result=validateReceipt(report,descriptor,{child:{status:child.status,signal:child.signal||null,error:child.error||null},
  reportMtimeMs:statSync(run.report).mtimeMs,finishedAt:finish});
 writeFileSync(join(run.out,"verified-receipt.json"),JSON.stringify({...result,run_id:run.runId,descriptor_sha256:descriptor.descriptor_sha256,
  fresh_report_sha256:shaFile(run.report),binding_sha256:args.sha,source_build_browser_binding_verified:true},null,2)+"\n");
 console.log(JSON.stringify({status:"PASS",scope:result.scope,formal_gate:false,run_dir:run.out,case_count:result.case_count}));
}catch(error){
 if(run)writeFileSync(join(run.out,"launch-failure.json"),JSON.stringify({status:"FAIL",formal_gate:false,error:String(error),started_at:started},null,2)+"\n");
 console.error("FAIL CLOSED: "+String(error));process.exitCode=1;
}
