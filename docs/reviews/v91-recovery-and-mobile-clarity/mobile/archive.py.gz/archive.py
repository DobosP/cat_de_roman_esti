"""Archive the mobile lane's exact captures with deterministic gzip and file hashes."""
import gzip
import hashlib
import json
import shutil
from pathlib import Path

scratch = Path('/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/mobile')
repo = Path('/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity')
out = repo / 'docs/reviews/v91-recovery-and-mobile-clarity/mobile'
out.mkdir(parents=True, exist_ok=True)
records = []
old = json.loads((out / 'manifest.json').read_text())['files'] if (out / 'manifest.json').exists() else []


def keep(src, rel, compressed=False):
    raw = src.read_bytes()
    dest = out / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    stored = gzip.compress(raw, mtime=0) if compressed else raw
    dest.write_bytes(stored)
    records.append({'path': rel, 'sha256': hashlib.sha256(stored).hexdigest(),
                    'bytes': len(stored), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                    'raw_bytes': len(raw), 'gzip_mtime': 0 if compressed else None})

for phase in ['before', 'before-touch', 'after-dev', 'after-built', 'after-built-verified-notices', 'focused-built-attachments']:
    for path in sorted((scratch / phase).glob('*')):
        if phase == 'before' and '1280' not in path.name:
            continue
        if phase == 'after-dev' and path.suffix == '.png':
            continue
        if phase == 'focused-built-attachments' and path.suffix == '.png' and '-long-' not in path.name:
            continue
        keep(path, f'{phase}/{path.name}')
for path in sorted(scratch.glob('*.png')):
    keep(path, path.name)
for path in sorted(scratch.glob('*.json')):
    keep(path, path.name + '.gz' if path.stat().st_size > 100000 else path.name,
         compressed=path.stat().st_size > 100000)
for suffix in ['*.log', '*.mjs', '*.py']:
    for path in sorted(scratch.glob(suffix)):
        keep(path, path.name + '.gz', compressed=True)
for phase in ['focused-dev-results', 'focused-built-results', 'stress-corrected-dev-results']:
    for path in sorted((scratch / phase).rglob('*')):
        if path.is_file() and '.playwright-artifacts-' not in str(path) and path.name != '.last-run.json':
            name = str(path.relative_to(scratch))
            keep(path, name + '.gz' if path.suffix == '.md' else name, compressed=path.suffix == '.md')
api = repo / 'frontend/node_modules/@roedu/ui/dist/components/Toast/Toast.d.ts'
keep(api, 'installed-toast-api.d.ts.gz', compressed=True)
selected = {record['path'] for record in records}
for record in old:
    if record['path'] not in selected:
        stale = out / record['path']
        original = scratch / record['path']
        # Only remove our unchanged duplicate; the exact original stays in scratch.
        assert hashlib.sha256(stale.read_bytes()).hexdigest() == record['sha256']
        assert hashlib.sha256(original.read_bytes()).hexdigest() == record['raw_sha256']
        stale.unlink()
(out / 'manifest.json').write_text(json.dumps({'files': records}, indent=2) + '\n')
print(json.dumps({'files': len(records), 'bytes': sum(r['bytes'] for r in records)}))
