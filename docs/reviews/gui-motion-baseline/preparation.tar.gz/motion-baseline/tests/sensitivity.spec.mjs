import assert from "node:assert/strict";
import {test} from "../test-api.mjs";
import {installSynthetic,boardFor} from "../fixtures.mjs";
import {ready,snapshot,depart,assertLocked,assertCounts,assertNoRecord,evidence} from "../contracts.mjs";
test("sensitivity: same lock oracle rejects a real DOM-enabled leaving tile",async({page,context})=>{
 const f=await installSynthetic(context,"intrusul");await ready(page,f);const before=await depart(page,"intrusul");assertLocked(before);
 await page.evaluate(board=>{const b=document.querySelector(board+" button");if(!b)throw Error("detached");b.disabled=false;},boardFor("intrusul"));
 const mutated=await snapshot(page,"intrusul");
 assert.throws(()=>assertLocked(mutated),/all leaving tile controls/);
 await evidence(test,page,f,{mutation_kind:"browser DOM control, not source mutant",detected:true,before,mutated});
});
test("sensitivity: same counter oracle rejects an injected synthetic mutation and upload",async({page,context})=>{
 const f=await installSynthetic(context,"intrusul");await ready(page,f);const before=f.counts();
 await page.evaluate(async id=>{
  await fetch("/api/wordgames/intrusul/games/"+id+"/hint",{method:"POST"});
  await fetch("/api/me/scores",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({entries:[{game:"intrusul",score:1000,detail:"Injected synthetic control",at:Date.now(),puzzle_key:"fixture-control",daily:"",difficulty:"usor",category:""}]})});
 },f.id);
 assert.throws(()=>assertCounts(before,f.counts()),/unexpected API/);
 await evidence(test,page,f,{mutation_kind:"synthetic request control, not source mutant",detected:true,before});
});
test("sensitivity: same storage oracle rejects injected local completion metadata",async({page,context})=>{
 const f=await installSynthetic(context,"intrusul");await ready(page,f);const before=await snapshot(page,"intrusul");
 await page.evaluate(game=>localStorage.setItem("cat_wordgame_scores_v1",JSON.stringify({
  [game]:{played:1,recent:[{score:1}]},_completionReceipts:{[game]:{"fixture-extra":1}}
 })),"intrusul");
 const mutated=await snapshot(page,"intrusul");assert.throws(()=>assertNoRecord(before,mutated),/unexpected record/);
 await evidence(test,page,f,{mutation_kind:"synthetic storage control, not source mutant",detected:true,before,mutated});
});
