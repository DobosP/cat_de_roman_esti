# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: conexiuni-action-recovery.spec.mjs >> precommit failure preserves a valid selection and earned clue without replay
- Location: e2e/conexiuni-action-recovery.spec.mjs:221:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Joc sincronizat. Poți continua.', { exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Joc sincronizat. Poți continua.', { exact: true }) with timeout 10000ms
  - waiting for getByText('Joc sincronizat. Poți continua.', { exact: true })

```

```yaml
- button "Ieși la lista de jocuri": Ieși
- strong: Conexiuni
- group "Starea jocului": DIFICULTATE Ușor GREȘELI 2 rămase
- group: Reguli și ajutor
- status:
  - text: ACUM
  - strong: Grup gata
  - text: Apasă Verifică.
- text: 4/4
- img "2 greșeli disponibile"
- button "Verifică"
- status: Joc sincronizat. Poți continua.
- status: "Un grup ramas are eticheta: L_ Ș___ D_ L_ B___."
- button "Sârma de rufe"
- button "Cauciucurile de iarnă"
- button "Revelionul la televizor"
- button "Sărbători în familie"
- button "Masa în familie"
- button "Vitrina cu bibelouri"
- button "Borcanele de zacuscă"
- button "Rude"
- button "Asociația de proprietari" [pressed]
- button "Covor"
- button "Interfonul" [pressed]
- button "lift" [pressed]
- button "Întreținerea" [pressed]
- button "Mileurile croșetate"
- button "Carpeta de pe perete"
- button "Bicicleta Pegas"
- button "Indiciu · încă 1 greșeală" [disabled]
- button "Amestecă"
- button "Golește"
- text: Enter = verifică · Esc = golește
- status
```

# Test source

```ts
  130 |   expect(server.solved).toEqual([]);
  131 |   await expect(page.getByText(server.clues[0].message, { exact: false })).toHaveCount(1);
  132 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  133 |   await page.locator(".connections-feedback").scrollIntoViewIfNeeded();
  134 |   await expect(page.locator(".connections-feedback")).toHaveCSS("opacity", "1");
  135 |   await page.screenshot({ path: test.info().outputPath("recovered-clue.png") });
  136 |   await page.reload();
  137 |   await expect(clueButton(page)).toContainText("1 rămas");
  138 |   await expect(page.getByText(server.clues[0].message, { exact: false })).toHaveCount(1);
  139 |   for (const step of steps()) expect((await guess(page, initial.game_id, step)).status()).toBe(200);
  140 |   await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeVisible();
  141 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).score).toBe(150);
  142 |   await expect.poll(() => played(page)).toBe(1);
  143 |   expect(counts.mutations).toBe(5);
  144 | });
  145 | 
  146 | test("a lost solved group removes only its four earned tiles and leaves answers private", async ({ page, request }) => {
  147 |   const initial = await prepare(page, request);
  148 |   const counts = traffic(page, initial.game_id);
  149 |   const committed = await loseCommittedResponse(page, initial.game_id, "guess");
  150 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(503);
  151 |   await expect(page.locator(`${game.board} button`)).toHaveCount(12);
  152 |   await expect(page.locator(`${game.board} [aria-pressed=true]`)).toHaveCount(0);
  153 |   await expect(page.getByText(committed().category.label, { exact: true })).toBeVisible();
  154 |   const server = await (await request.get(gameURL(game, initial.game_id))).json();
  155 |   expect(server.solved_count).toBe(1);
  156 |   expect(server.solved).toEqual(committed().solved);
  157 |   expect(server.solution).toBeUndefined();
  158 |   expect(server.one_away).toBeUndefined();
  159 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  160 |   expect(await played(page)).toBe(0);
  161 | });
  162 | 
  163 | for (const lost of [false, true]) {
  164 |   test(`a lost committed ${lost ? "loss" : "win"} adopts the terminal score exactly once`, async ({ page, request }) => {
  165 |     const initial = await prepare(page, request, lost ? { mistakes: 3 } : { solved: 3 });
  166 |     const counts = traffic(page, initial.game_id);
  167 |     const committed = await loseCommittedResponse(page, initial.game_id, "guess");
  168 |     expect((await guess(page, initial.game_id, lost ? wrong(3) : steps()[3])).status()).toBe(503);
  169 |     await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeVisible();
  170 |     await expect(page.getByText(lost ? "Ai rămas fără vieți." : "Ai găsit toate grupurile!", { exact: true })).toBeVisible();
  171 |     await expect.poll(() => played(page)).toBe(1);
  172 |     await expect.poll(() => remembered(page)).toBeNull();
  173 |     const server = await (await request.get(gameURL(game, initial.game_id))).json();
  174 |     expect(server.won).toBe(!lost);
  175 |     expect(server.lost).toBe(lost);
  176 |     expect(server.score).toBe(lost ? 0 : 1000);
  177 |     expect(server.score).toBe(committed().score);
  178 |     expect(server.solution).toHaveLength(4);
  179 |     expect(counts).toEqual({ reads: 1, mutations: 1 });
  180 |     await expect(page.getByText(lost ? "Ai rămas fără vieți." : "Ai găsit toate grupurile!", { exact: true }).locator("../..")).toHaveCSS("opacity", "1");
  181 |     await page.screenshot({ path: test.info().outputPath(`recovered-${lost ? "loss" : "win"}.png`), fullPage: true });
  182 |     await page.reload();
  183 |     await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  184 |     expect(await played(page)).toBe(1);
  185 |   });
  186 | }
  187 | 
  188 | test("failed verification persists, locks every board action, and retries by GET only", async ({ page, request }) => {
  189 |   await page.clock.install();
  190 |   const initial = await prepare(page, request, { mistakes: 3 });
  191 |   const counts = traffic(page, initial.game_id);
  192 |   await loseCommittedResponse(page, initial.game_id, "clue");
  193 |   await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({
  194 |     status: 503, contentType: "application/json", body: "{}",
  195 |   }), { times: 1 });
  196 |   expect((await askClue(page, initial.game_id)).status()).toBe(503);
  197 |   await expect(verify(page)).toBeEnabled();
  198 |   for (const button of await page.locator(`${game.board} button`).all()) await expect(button).toBeDisabled();
  199 |   for (const name of ["Verifică", "Amestecă", "Golește"]) {
  200 |     await expect(page.getByRole("button", { name, exact: true })).toBeDisabled();
  201 |   }
  202 |   await expect(clueButton(page)).toBeDisabled();
  203 |   await page.keyboard.press("Enter");
  204 |   await page.clock.fastForward(4000);
  205 |   await expect(verify(page)).toBeVisible();
  206 |   await page.locator(".connections-sync-recovery").scrollIntoViewIfNeeded();
  207 |   await expect(page.locator(".connections-sync-recovery")).toBeInViewport();
  208 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  209 |   expect(await remembered(page)).toBe(initial.game_id);
  210 |   await page.screenshot({ path: test.info().outputPath("read-only-recovery.png") });
  211 |   const response = responseFor(page, initial.game_id, "", "GET");
  212 |   await verify(page).click();
  213 |   expect((await response).status()).toBe(200);
  214 |   await expect(verify(page)).toHaveCount(0);
  215 |   await expect(clueButton(page)).toBeEnabled();
  216 |   await expect(clueButton(page)).toContainText("1 rămas");
  217 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).clues_used).toBe(1);
  218 |   expect(counts).toEqual({ reads: 2, mutations: 1 });
  219 | });
  220 | 
  221 | test("precommit failure preserves a valid selection and earned clue without replay", async ({ page, request }) => {
  222 |   const initial = await prepare(page, request, { mistakes: 2 });
  223 |   expect((await askClue(page, initial.game_id)).status()).toBe(200);
  224 |   const before = await (await request.get(gameURL(game, initial.game_id))).json();
  225 |   const counts = traffic(page, initial.game_id);
  226 |   await page.route(`**${gameURL(game, initial.game_id)}/guess`, (route) => route.fulfill({
  227 |     status: 503, contentType: "application/json", body: "{}",
  228 |   }), { times: 1 });
  229 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(503);
> 230 |   await expect(page.getByText("Joc sincronizat. Poți continua.", { exact: true })).toBeVisible();
      |                                                                                    ^ Error: expect(locator).toBeVisible() failed
  231 |   await expect(page.getByRole("button", { name: "Verifică", exact: true })).toBeEnabled();
  232 |   await expect(page.locator(`${game.board} [aria-pressed=true]`)).toHaveCount(4);
  233 |   await expect(page.getByText(before.clues[0].message, { exact: false })).toHaveCount(1);
  234 |   expect(await (await request.get(gameURL(game, initial.game_id))).json()).toEqual(before);
  235 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  236 |   const response = responseFor(page, initial.game_id, "guess");
  237 |   await page.getByRole("button", { name: "Verifică", exact: true }).click();
  238 |   expect((await (await response).json()).solved_count).toBe(1);
  239 |   expect(counts.mutations).toBe(2);
  240 | });
  241 | 
  242 | for (const missing of [false, true]) {
  243 |   test(`a late ${missing ? "404" : "winning"} read cannot adopt or clear another tab's saved round`, async ({ page, context, request }) => {
  244 |     const initial = await prepare(page, request, { solved: 3 });
  245 |     const newer = await newerRound(request);
  246 |     await loseCommittedResponse(page, initial.game_id, "guess");
  247 |     const held = await holdRecovery(page, initial.game_id, missing);
  248 |     expect((await guess(page, initial.game_id, steps()[3])).status()).toBe(503);
  249 |     await held.requested;
  250 |     const other = await saveFromOtherTab(context, newer.game_id);
  251 |     held.release();
  252 |     await expect(currentGame(page)).toBeEnabled();
  253 |     await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toHaveCount(0);
  254 |     expect(await remembered(page)).toBe(newer.game_id);
  255 |     expect(await played(page)).toBe(0);
  256 |     const loaded = responseFor(page, newer.game_id, "", "GET");
  257 |     await currentGame(page).click();
  258 |     expect((await loaded).status()).toBe(200);
  259 |     await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  260 |     expect(await remembered(page)).toBe(newer.game_id);
  261 |     expect(await played(page)).toBe(0);
  262 |     await other.close();
  263 |   });
  264 | }
  265 | 
  266 | test("leaving during recovery preserves its pointer and stale completion cannot change a new screen", async ({ page, context, request }) => {
  267 |   const initial = await prepare(page, request, { solved: 3 });
  268 |   await loseCommittedResponse(page, initial.game_id, "guess");
  269 |   const held = await holdRecovery(page, initial.game_id);
  270 |   expect((await guess(page, initial.game_id, steps()[3])).status()).toBe(503);
  271 |   await held.requested;
  272 |   await page.getByRole("button", { name: "Ieși la lista de jocuri", exact: true }).click();
  273 |   await expect(page.getByRole("button", { name: /^Joacă Conexiuni —/ })).toBeVisible();
  274 |   expect(await remembered(page)).toBe(initial.game_id);
  275 |   const newer = await newerRound(request);
  276 |   const other = await saveFromOtherTab(context, newer.game_id);
  277 |   const loaded = responseFor(page, newer.game_id, "", "GET");
  278 |   await page.getByRole("button", { name: /^Joacă Conexiuni —/ }).click();
  279 |   expect((await loaded).status()).toBe(200);
  280 |   const oldCompleted = responseFor(page, initial.game_id, "", "GET");
  281 |   held.release();
  282 |   await oldCompleted;
  283 |   await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  284 |   await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toHaveCount(0);
  285 |   expect(await remembered(page)).toBe(newer.game_id);
  286 |   expect(await played(page)).toBe(0);
  287 |   await other.close();
  288 | });
  289 | 
  290 | test("an already different saved pointer pauses before any old-round mutation", async ({ page, context, request }) => {
  291 |   const initial = await prepare(page, request);
  292 |   const newer = await newerRound(request);
  293 |   const other = await saveFromOtherTab(context, newer.game_id);
  294 |   const counts = traffic(page, initial.game_id);
  295 |   await choose(page, steps()[0]);
  296 |   await page.getByRole("button", { name: "Verifică", exact: true }).click();
  297 |   await expect(currentGame(page)).toBeEnabled();
  298 |   expect(counts).toEqual({ reads: 0, mutations: 0 });
  299 |   expect(await (await request.get(gameURL(game, initial.game_id))).json()).toEqual(initial);
  300 |   expect(await remembered(page)).toBe(newer.game_id);
  301 |   await currentGame(page).click();
  302 |   await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  303 |   expect(await played(page)).toBe(0);
  304 |   await other.close();
  305 | });
  306 | 
  307 | test("a verified missing owned session returns to setup and conditionally clears its pointer", async ({ page, request }) => {
  308 |   const initial = await prepare(page, request);
  309 |   const counts = traffic(page, initial.game_id);
  310 |   for (const suffix of ["/guess", ""]) {
  311 |     await page.route(`**${gameURL(game, initial.game_id)}${suffix}`, (route) => route.fulfill({
  312 |       status: 404, contentType: "application/json", body: "{}",
  313 |     }), { times: 1 });
  314 |   }
  315 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(404);
  316 |   await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  317 |   expect(await remembered(page)).toBeNull();
  318 |   expect(await played(page)).toBe(0);
  319 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  320 | });
  321 | 
  322 | test("lost one-away feedback stays neutral and confirmed duplicate feedback still requires a change", async ({ page, request }) => {
  323 |   const initial = await prepare(page, request);
  324 |   const counts = traffic(page, initial.game_id);
  325 |   const committed = await loseCommittedResponse(page, initial.game_id, "guess");
  326 |   expect((await guess(page, initial.game_id, solution(game).practice)).status()).toBe(503);
  327 |   await expect(page.getByText("Joc sincronizat. Poți continua.", { exact: true })).toBeVisible();
  328 |   expect(committed().one_away).toBe(true);
  329 |   await expect(page.getByText("Aproape: 3 din 4. Schimbă o piesă.", { exact: true })).toHaveCount(0);
  330 |   const duplicate = responseFor(page, initial.game_id, "guess");
```