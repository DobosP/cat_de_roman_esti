import assert from "node:assert/strict";
import {test} from "../test-api.mjs";
import {installSynthetic} from "../fixtures.mjs";
import {ready,snapshot,trigger,poll,recordExactlyOnce,assertCounts,assertNoRecord,settledFrames,evidence} from "../contracts.mjs";
for(const game of ["intrusul","perechi"]){
 test(game+": leaving recorded result cannot create a replay or record/upload again",async({page,context})=>{
  await page.emulateMedia({reducedMotion:"no-preference"});
  const f=await installSynthetic(context,game,{nearWin:true});await ready(page,f);
  await trigger(page,game);await recordExactlyOnce(page,f);
  const replay=await page.getByRole("button",{name:/Încă unul/}).elementHandle();
  assert.ok(replay,"terminal replay button must exist before departure");
  const before=await snapshot(page,game),counts=f.counts();
  await page.evaluate(()=>document.querySelector('.account-bar a[href="/clasament"]').click());
  await page.waitForFunction(button=>button.isConnected&&location.pathname==="/clasament"&&Number(getComputedStyle(button.closest(".screen")).opacity)<1,replay,{timeout:250});
  const attached=await replay.evaluate(button=>{if(!button.isConnected)throw Error("replay detached");button.click();return button.isConnected;});
  assert.equal(attached,true);await settledFrames(page);
  assert.equal(await replay.evaluate(button=>button.isConnected),true,"activation and assertions must occur during mounted exit");
  assertNoRecord(before,await snapshot(page,game));assertCounts(counts,f.counts());
  assert.equal(counts.uploads,1,"positive upload control already happened");
  await evidence(test,page,f,{before,counts,retained_replay:true});
 });
}
