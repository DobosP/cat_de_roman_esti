import ast,pathlib,stat,sys,types,unittest,shlex,json
sys.dont_write_bytecode=True
S=pathlib.Path(sys.argv.pop(1))
L=S/'probe/native-authcore-race-compile-linux-r3.py';W=S/'probe/native-authcore-race-compile-windows-r2.py'
tree=ast.parse(L.read_text())
outer=next(n for n in tree.body if isinstance(n,ast.Try) and any(isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Name) and x.value.func.id=='spec_pin' for x in n.body))
start=next(i for i,n in enumerate(outer.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='info')
block=compile(ast.Module(body=outer.body[start:start+4],type_ignores=[]),str(L),'exec')
stderr_check=next(n for n in outer.body if isinstance(n,ast.Assert) and isinstance(n.msg,ast.Constant) and n.msg.value=='final retained Go stderr cap')
stderr_code=compile(ast.Module(body=[stderr_check],type_ignores=[]),str(L),'exec')
stdout_check=next(n for n in outer.body if isinstance(n,ast.Assert) and isinstance(n.msg,ast.Constant) and n.msg.value=='bounded compile stdout')
stdout_code=compile(ast.Module(body=[stdout_check],type_ignores=[]),str(L),'exec')
class File:
 def __init__(self,raw=None,size=64,nlink=1,mode=stat.S_IFREG):self.raw=raw;self.size=size;self.nlink=nlink;self.mode=mode
 def lstat(self):return types.SimpleNamespace(st_mode=self.mode,st_nlink=self.nlink,st_size=self.size)
 def stat(self):return self.lstat()
 def read_bytes(self):return self.raw
 def is_file(self):return self.mode==stat.S_IFREG
def header():
 b=bytearray(64);b[:6]=b'\x7fELF\x02\x01';b[16:18]=(2).to_bytes(2,'little');b[18:20]=(62).to_bytes(2,'little');return bytes(b)
class Controls(unittest.TestCase):
 def run_header(self,file,x=True):exec(block,{'artifact':file,'filemode':stat,'os':types.SimpleNamespace(access=lambda p,m:x,X_OK=1)})
 def test_valid_header(self):self.run_header(File(header()))
 def test_truncated_header_refused(self):
  with self.assertRaises(AssertionError):self.run_header(File(header()[:20]))
 def test_wrong_machine_refused(self):
  b=bytearray(header());b[18:20]=(3).to_bytes(2,'little')
  with self.assertRaises(AssertionError):self.run_header(File(bytes(b)))
 def test_nonexecutable_refused(self):
  with self.assertRaises(AssertionError):self.run_header(File(header()),False)
 def test_hardlink_refused(self):
  with self.assertRaises(AssertionError):self.run_header(File(header(),nlink=2))
 def test_artifact_size_caps(self):
  for n in (0,(128<<20)+1):
   with self.subTest(size=n),self.assertRaises(AssertionError):self.run_header(File(header(),size=n))
 def test_final_stderr_growth_refused(self):
  class Run:
   def __truediv__(self,name):return File(size=(1<<20)+1)
  with self.assertRaises(AssertionError):exec(stderr_code,{'run':Run(),'step':{'name':'x'}})
 def test_final_stderr_boundary_accepted(self):
  class Run:
   def __truediv__(self,name):return File(size=1<<20)
  exec(stderr_code,{'run':Run(),'step':{'name':'x'}})
 def test_empty_compile_stdout_accepted(self):exec(stdout_code,{'output':File(size=0)})
 def test_compile_stdout_oversize_refused(self):
  with self.assertRaises(AssertionError):exec(stdout_code,{'output':File(size=(1<<20)+1)})
 def test_windows_truncated_header_refused(self):
  wt=ast.parse(W.read_text());test=next(n for n in ast.walk(wt) if isinstance(n,ast.Assert) and isinstance(n.msg,ast.Constant) and n.msg.value=='Linux amd64 ELF')
  code=compile(ast.Module(body=[test],type_ignores=[]),str(W),'exec')
  with self.assertRaises(AssertionError):exec(code,{'header':header()[:20]})
 def test_fixed_compiler_prefix_quoting(self):
  node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compiler_command')
  spec=json.loads((S/'probe/native-authcore-race-compile-template-r2.json').read_text());env={'spec':spec,'pathlib':types.SimpleNamespace(Path=pathlib.PurePosixPath)}
  exec(compile(ast.Module(body=[node],type_ignores=[]),str(L),'exec'),env);command=env['compiler_command']()
  self.assertTrue(command.startswith("/usr/bin/gcc '-B"));self.assertTrue(command.endswith("/'"))
  self.assertEqual(shlex.split(command),['/usr/bin/gcc','-B'+spec['linux_build_root']+'/native-path/'])
if __name__=='__main__':unittest.main(verbosity=2)
