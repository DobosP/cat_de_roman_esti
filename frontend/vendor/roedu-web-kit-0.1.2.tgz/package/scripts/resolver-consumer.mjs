import assert from 'node:assert/strict';
import path from 'node:path';
import {isDeepStrictEqual} from 'node:util';
import {bannedName} from '../lint/lint-scope.mjs';
import {loadKit,inspectUiAdoption,validateUiAdoption} from './kit-sync.mjs';
import {stable,compare,resolveEntry,frozenTool} from './resolver-policy.mjs';
import {json} from './resolver-files.mjs';
import {discoverGo,validateGoBaseline,planGoWrites} from './resolver-go.mjs';
const groups=['dependencies','devDependencies','optionalDependencies','peerDependencies'];
const literalName=name=>/^(@[A-Za-z0-9_.-]+\/)?[A-Za-z0-9_.-]+$/.test(name);
const minDeclaration=value=>typeof value==='string'&&/^(?:\^|~|>=)?(\d+\.\d+\.\d+)$/.exec(value)?.[1];
function minimum(entry,version,label){assert.ok(stable(version),`${label}: actual stable baseline required`);if(!entry.version||compare(version,entry.version)>0)entry.version=version;}
export async function planConsumer({root,config,lock,plan,get,date,native}) {
  const kit=loadKit(root),floor=new Map(kit.coreLock.tools.filter(e=>['core','environment'].includes(e.scope)).map(e=>[e.tool,e]));
  const rows=new Map(lock.tools.map(e=>[e.tool,e]));assert.equal(rows.size,lock.tools.length,'Duplicate resolver tools');
  assert.ok(isDeepStrictEqual(lock.toolchain_image,kit.coreLock.toolchain_image)&&lock.core_tag===kit.tag,'Consumer changed core toolchain/tag floor');
  for(const [name,entry] of floor)assert.ok(isDeepStrictEqual(rows.get(name),entry),`Consumer changed core floor: ${name}`);
  for(const entry of rows.values())if(['core','environment'].includes(entry.scope))assert.ok(floor.has(entry.tool),`Consumer invented core floor: ${entry.tool}`);
  const owner=path.posix.join(path.posix.dirname(config.vendor_dir),'package.json');
  assert.ok(owner!==config.npm_dir+'/package.json'&&!owner.startsWith(config.npm_dir+'/')&&!owner.split('/').some(part=>part.startsWith('.')||['kit','legacy','third_party','node_modules','dist','vendor','embedfs','testdata','fixtures'].includes(part)),'Owning manifest overlaps tooling, immutable inputs or excluded source');
  const manifest=JSON.parse(plan.read(owner)),manifestNext=structuredClone(manifest);
  assert.ok(manifest&&typeof manifest==='object'&&!Array.isArray(manifest)&&!['@roedu/ui','@roedu/web-kit'].includes(manifest.name),'Application manifest must not be an SDK owner');
  for(const group of groups)assert.ok(manifest[group]===undefined||manifest[group]&&typeof manifest[group]==='object'&&!Array.isArray(manifest[group]),`Owning dependency object required: ${group}`);
  const ownerLock=path.posix.join(path.posix.dirname(config.vendor_dir),'package-lock.json'),baseline=JSON.parse(plan.read(ownerLock));
  assert.ok(baseline.lockfileVersion===3&&baseline.packages?.[''],'Actual npm owning v3 baseline required');
  for(const group of groups)assert.ok(isDeepStrictEqual(manifest[group]??{},baseline.packages[''][group]??{}),`Owning manifest/lock baseline differs: ${group}`);
  const sdk=groups.flatMap(group=>Object.hasOwn(manifest[group]??{},'@roedu/ui')?[manifest[group]['@roedu/ui']]:[]);
  assert.ok(sdk.length<=1,'Duplicate UI declaration');
  if(sdk[0]==='file:'+path.posix.basename(config.vendor_dir)+'/roedu-ui-0.3.0.tgz')assert.ok(validateUiAdoption(config),'Original UI0.3 requires parent-verified staged seal before resolution');
  const adoption=inspectUiAdoption(root,config,kit);
  const declared=new Map();
  for(const group of groups)for(const [name,value] of Object.entries(manifest[group]??{})) {
    assert.ok(literalName(name)&&typeof value==='string',`Nonliteral owning npm dependency: ${name}`);
    assert.ok(!/^(?:npm:|workspace:|https?:|git(?:\+|:))/.test(value),`Dependency alias/remote spec refused: ${name}`);
    if(['@roedu/ui','@roedu/web-kit'].includes(name)){
      const expected='file:'+path.posix.basename(config.vendor_dir)+'/'+(name==='@roedu/ui'?(adoption.pending?'roedu-ui-0.3.0.tgz':kit.ui.filename):kit.npm.filename);
      assert.equal(value,expected,`Owning SDK pointer differs: ${name}`);continue;
    }
    assert.ok(!value.startsWith('file:'),`Unowned local dependency refused: ${name}`);
    const entry=rows.get(name);
    if(bannedName(name)||entry?.status==='banned'||entry?.status==='transitive-only')continue;
    assert.ok(!declared.has(name)||declared.get(name)===value,`Conflicting owning declarations: ${name}`);declared.set(name,value);
  }
  const go=discoverGo(root,config,plan,native);
  const selected=new Map([...rows].map(([name,e])=>[name,structuredClone(e)]));
  function own(name,kind,version) {
    let entry=selected.get(name);
    if(!entry){entry={tool:name,kind,scope:'app',apps:[config.app],version};selected.set(name,entry);}
    assert.ok(entry.kind===kind,`Dependency kind differs: ${name}`);
    if(entry.scope==='app'){assert.ok(Array.isArray(entry.apps)&&entry.apps.includes(config.app),`Dependency belongs to another app: ${name}`);minimum(entry,version,name);}
    else assert.ok(entry.scope==='core',`Dependency is not an application/core pin: ${name}`);
  }
  for(const [name,value] of declared){const entry=rows.get(name),installed=baseline.packages['node_modules/'+name];
    if(installed)assert.ok(!installed.link&&(installed.name===undefined||installed.name===name),`Aliased/link npm baseline: ${name}`);
    const version=installed?.version??entry?.version??minDeclaration(value);assert.ok(stable(version),`Stable owning dependency baseline missing: ${name}`);
    const lower=minDeclaration(value);assert.ok(lower,`Unsupported owning dependency declaration: ${name}`);assert.ok(compare(version,lower)>=0,`Owning lock is below declaration: ${name}`);own(name,'npm',version);
    if(entry?.scope==='core')assert.ok(compare(entry.version,version)>=0,`CORE_KIT_BUMP_REQUIRED higher owning npm version: ${name}`);
  }
  for(const module of go.modules)for(const req of module.requirements)if(!module.local.has(req.Path)) {
    const entry=rows.get(req.Path);if(entry?.status==='banned')throw Error(`Banned Go requirement: ${req.Path}`);
    if(entry||!req.Indirect){assert.ok(stable(req.Version),`Nonstable direct/registered Go baseline: ${req.Path}`);own(req.Path,'gomod',req.Version);if(entry?.scope==='core')assert.ok(compare(entry.version,req.Version)>=0,`CORE_KIT_BUMP_REQUIRED higher owning Go version: ${req.Path}`);}
  }
  const goInputBaselines=validateGoBaseline(root,config,lock,go,selected,native);
  const changes=[];
  for(const [name,entry] of selected){
    if(entry.scope==='environment'||entry.scope==='app'&&(!Array.isArray(entry.apps)||!entry.apps.includes(config.app)))continue;
    if(frozenTool(entry))continue;
    let resolved;
    try{resolved=await resolveEntry(entry,get,date);}catch(error){if(entry.scope==='core'&&/TOOLCHAIN REBUILD/.test(error.message))throw Error(`CORE_KIT_BUMP_REQUIRED ${error.message}`);throw error;}
    if(entry.scope==='core'){assert.equal(resolved.version,entry.version,`CORE_KIT_BUMP_REQUIRED newer core pin: ${name}`);continue;}
    if(entry.scope==='app'){selected.set(name,resolved);changes.push({tool:name,from:rows.get(name)?.version??entry.version,to:resolved.version,source:resolved.source,date});}
  }
  for(const group of groups)for(const name of Object.keys(manifestNext[group]??{})){
    if(!declared.has(name))continue;const entry=selected.get(name);assert.ok(stable(entry.version)&&entry.kind==='npm','Resolved owning npm pin required');manifestNext[group][name]=entry.version;
  }
  // Do not install or write package-lock/go.sum here. Actual repo:deps follows.
  planGoWrites(root,config,go,selected,plan);
  plan.put(owner,json(manifestNext));
  const next={...structuredClone(lock),tools:[...selected.values()],resolved:date};
  for(const [name,entry] of floor)assert.ok(isDeepStrictEqual(selected.get(name),entry),`Resolution changed core/environment floor: ${name}`);
  plan.put('versions.lock.json',json(next));return {changes,native_commands:native,go_input_baselines:goInputBaselines};
}
