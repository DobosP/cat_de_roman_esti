# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: v96-input-and-focus.spec.mjs >> unsupported Cald sau Rece words are explicitly free and do not suggest unrelated spelling
- Location: e2e/v96-input-and-focus.spec.mjs:48:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/Nu ai pierdut nicio încercare/)
Expected: visible
Error: strict mode violation: getByText(/Nu ai pierdut nicio încercare/) resolved to 2 elements:
    1) <span role="status" aria-live="polite" aria-atomic="true" class="visually-hidden">Cuvântul nu este încă în vocabularul jocului. Nu …</span> aka getByText('Cuvântul nu este încă în vocabularul jocului. Nu ai pierdut nicio încercare.', { exact: true })
    2) <span>…</span> aka getByText('⚠Cuvântul nu este încă în')

Call log:
  - Expect "toBeVisible" getByText(/Nu ai pierdut nicio încercare/) with timeout 10000ms
  - waiting for getByText(/Nu ai pierdut nicio încercare/)

```

# Page snapshot

```yaml
- generic [ref=e4]:
  - generic:
    - status
  - generic [ref=e8]:
    - generic [ref=e9]:
      - generic [ref=e10]:
        - button "Ieși la lista de jocuri" [ref=e11] [cursor=pointer]:
          - generic [aria-hidden] [ref=e12]: ←
          - text: Ieși
        - strong [ref=e13]: Cald sau Rece
      - group "Starea jocului" [ref=e15]:
        - generic "Încercări" [ref=e16]: 0 încercări
    - generic [ref=e19]:
      - generic [ref=e20]:
        - textbox "Concept de ghicit" [active] [ref=e21]:
          - /placeholder: Încearcă un cuvânt…
          - text: fier
        - button "Ghicește" [ref=e22] [cursor=pointer]
      - paragraph [ref=e23]:
        - text: Un număr mai mic = mai aproape.
        - strong [ref=e24]: "#1 este ținta."
    - generic [ref=e25]:
      - generic "Acțiuni joc" [ref=e26]:
        - button "Indiciu în 3" [disabled] [ref=e27]
        - generic [ref=e28]: −120 puncte / indiciu
      - group [ref=e29]:
        - generic "⋯ Opțiuni de joc" [ref=e30] [cursor=pointer]
    - status [ref=e31]: Cuvântul nu este încă în vocabularul jocului. Nu ai pierdut nicio încercare.
    - generic [ref=e32]: ⚠Cuvântul nu este încă în vocabularul jocului. Nu ai pierdut nicio încercare.
    - heading "Cele mai apropiate cuvinte" [level=2] [ref=e35]
    - paragraph [ref=e37]: Sensul contează, nu literele. Începe cu orice idee!
```

# Test source

```ts
  1  | /* global document, innerWidth */
  2  | import { test, expect } from "@playwright/test";
  3  | import { readFileSync } from "node:fs";
  4  | 
  5  | const BASE = "/api/alchimie/explore";
  6  | const word = (p, label) => p.locator(".alchemy-inventory-grid").getByRole("button", { name: new RegExp(`^${label}(?:,|$)`) });
  7  | const response = (p, path, method = "POST") => p.waitForResponse(r => r.request().method() === method && new URL(r.url()).pathname === path);
  8  | async function begin(page) {
  9  |   await page.goto("/alchimie");
  10 |   const pending = response(page, BASE);
  11 |   await page.getByRole("button", { name: "Începe explorarea →" }).click();
  12 |   return (await pending).json();
  13 | }
  14 | for (const committed of [false, true]) for (const moved of [false, true]) {
  15 |   test(`recovery of ${committed ? "committed" : "uncommitted"} crafting ${moved ? "respects moved focus" : "restores activated word"}`, async ({ page }) => {
  16 |     await page.setViewportSize({ width: 320, height: 844 });
  17 |     await page.addInitScript(() => document.addEventListener("DOMContentLoaded", () => { document.documentElement.style.fontSize = "200%"; }));
  18 |     const state = await begin(page);
  19 |     let release;
  20 |     const gate = new Promise(resolve => { release = resolve; });
  21 |     await page.route(`**${BASE}/${state.game_id}/combine`, async route => {
  22 |       if (committed) await route.fetch();
  23 |       await gate;
  24 |       await route.abort("failed");
  25 |     }, { times: 1 });
  26 |     await word(page, "Făină").click();
  27 |     await word(page, "Apă").focus();
  28 |     const post = page.waitForRequest(r => r.url().endsWith("/combine"));
  29 |     await word(page, "Apă").press("Enter");
  30 |     await post;
  31 |     const library = page.getByRole("region", { name: "Colecția ta" });
  32 |     if (moved) await library.focus();
  33 |     const recovered = response(page, `${BASE}/${state.game_id}`, "GET");
  34 |     release();
  35 |     const fresh = await (await recovered).json();
  36 |     expect(fresh.inventory.some(i => i.label === "Aluat")).toBe(committed);
  37 |     await expect(page.getByText("Colecție sincronizată. Poți continua.")).toBeVisible();
  38 |     await expect(moved ? library : word(page, "Apă")).toBeFocused();
  39 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  40 |     if (!moved) {
  41 |       const box = await word(page, "Apă").boundingBox();
  42 |       expect(box.y).toBeGreaterThanOrEqual(0);
  43 |       expect(box.y + box.height).toBeLessThanOrEqual(844);
  44 |     }
  45 |   });
  46 | }
  47 | 
  48 | test("unsupported Cald sau Rece words are explicitly free and do not suggest unrelated spelling", async ({ page }) => {
  49 |   await page.goto("/cald-rece");
  50 |   const created = response(page, "/api/wordgames/contexto/games");
  51 |   await page.getByRole("button", { name: /^Joacă(?: →)?$/ }).click();
  52 |   const state = await (await created).json();
  53 |   const field = page.getByRole("textbox", { name: "Concept de ghicit" });
  54 |   for (const text of ["fier", "reparație", "scule", "rechizite"]) {
  55 |     await field.fill(text);
  56 |     const guessed = response(page, `/api/wordgames/contexto/games/${state.game_id}/guess`);
  57 |     await field.press("Enter");
  58 |     const result = await (await guessed).json();
  59 |     expect(result.ok).toBe(false);
  60 |     expect(result.attempts).toBe(0);
  61 |     expect(result.suggestions).not.toContain("fluier");
  62 |     expect(result.suggestions).not.toContain("pârâu");
> 63 |     await expect(page.getByText(/Nu ai pierdut nicio încercare/)).toBeVisible();
     |                                                                   ^ Error: expect(locator).toBeVisible() failed
  64 |     await expect(field).toHaveValue(text);
  65 |     await expect(field).toBeFocused();
  66 |   }
  67 | });
  68 | 
  69 | test("a lost final craft restores collection focus when both inputs are depleted", async ({ page }) => {
  70 |   const checkpoint = JSON.parse(readFileSync(new URL("./alchimie-221-checkpoint.json", import.meta.url), "utf8")).collection;
  71 |   checkpoint.revision = 85;
  72 |   checkpoint.goal_id = null;
  73 |   checkpoint.progress.discoveries = checkpoint.progress.discoveries.slice(0, 85);
  74 |   await page.goto("/alchimie");
  75 |   await page.evaluate(value => localStorage.setItem("cat_alchimie_exploration_v1", JSON.stringify(value)), checkpoint);
  76 |   const restored = response(page, BASE);
  77 |   await page.reload();
  78 |   const state = await (await restored).json();
  79 |   await page.route(`**${BASE}/${state.game_id}/combine`, async route => {
  80 |     await route.fetch();
  81 |     await route.abort("failed");
  82 |   }, { times: 1 });
  83 |   await word(page, "Lipie").click();
  84 |   await word(page, "Friptură").focus();
  85 |   const recovered = response(page, `${BASE}/${state.game_id}`, "GET");
  86 |   await word(page, "Friptură").press("Enter");
  87 |   const fresh = await (await recovered).json();
  88 |   expect(fresh.inventory.some(i => i.label === "Șaorma cu de toate")).toBe(true);
  89 |   await expect(page.getByRole("region", { name: "Colecția ta" })).toBeFocused();
  90 | });
  91 | 
```