import ctypes,hashlib,json,os,pathlib,shutil,stat,sys,time,datetime
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"):raise RuntimeError("optimized Python refused")
r=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-7-qualification");s=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification");probe=s/"probe";d=r/"docs/reviews/v1-7-recognizable-content/continuation/quick-transition"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
template=probe/"quick-transition-method-template-r3.json";assert sha(template)=="500affe9b96d1ccc0192b2c0dd5665cd169c473ec688428c403937d58616aa3d";v=json.loads(template.read_bytes())
method=d/"method-review-r3.json";expected_method=sys.argv[2];assert len(expected_method)==64 and sha(method)==expected_method
assert len(v["steps"])==1 and v["steps"][0]["argv"][-1]=="--write"
assert v["target_before_sha256"]=="0c79b9c5cb0f9602c2506ef384ac64d519731dd9add53acf602d2c4f51a3f345" and v["target_after_sha256"]=="26b7dc0e7a4db0cd665c2593d86e55b2d5edff98f478374e0a8f3917e320512a"
for p,want in v["windows_protected"].items():assert sha(pathlib.Path(p))==want,p
assert sha(pathlib.Path(v["windows_target"]))==v["target_before_sha256"]
def lp(p):
 q=p.as_posix();assert q[1:3]==":/";return "/mnt/"+q[0].lower()+q[2:]
extras=[template,method,pathlib.Path(__file__),s/"quick-transition-source-admission-r1.json",s/"quick-transition-source-stop-r1.json"]+list(d.glob("*.json"))
for p in extras:
 v["windows_protected"][str(p)]=sha(p);v["linux_protected"][lp(p)]=sha(p)
def count():
 total=0;pending=[r,s]
 while pending:
  with os.scandir(pending.pop()) as entries:
   for entry in entries:
    st=entry.stat(follow_symlinks=False)
    if getattr(st,"st_file_attributes",0)&0x400 or stat.S_ISLNK(st.st_mode):raise RuntimeError("owned reparse path")
    if stat.S_ISDIR(st.st_mode):pending.append(entry.path)
    elif stat.S_ISREG(st.st_mode):total+=st.st_size
    else:raise RuntimeError("owned nonregular path")
 return total
class M(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","totalPage","availablePage","totalVirtual","availableVirtual","extra"]]
m=M();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));disk=shutil.disk_usage(r).free;baseline=count()
assert disk>=17*1024**3 and m.available>=16*1024**3
now=time.time();v.update({"native_execution":"Fresh immutable single-target admission; dispatch only after exact independent spec check","started_epoch":now,"deadline_epoch":now+1200,"full_R_S_baseline":baseline,"host_launcher_pid":int(sys.argv[1]),"admission":{"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"disk_free_bytes":disk,"available_physical_bytes":m.available,"whole_R_S_baseline":baseline,"pre_dispatch_source_RSS":"unmeasured; native executor/controller group sampling begins at dispatch","method_sha256":expected_method}})
p=probe/"quick-transition-native-spec-r1.json";assert not p.exists();p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode("utf8"))
receipt=s/"quick-transition-native-admission-r1.json";assert not receipt.exists();receipt.write_bytes((json.dumps({"spec_sha256":sha(p),"spec":str(p),"admission":v["admission"],"started_epoch":now,"deadline_epoch":now+1200,"steps":v["steps"],"pending":"Independent exact spec/readset check; no operator dispatched"},ensure_ascii=False,indent=2)+"\n").encode("utf8"))
print(json.dumps({"spec_sha256":sha(p),"started_epoch":now,"deadline_epoch":now+1200,"protected_paths":len(v["windows_protected"]),"disk_free_bytes":disk,"available_physical_bytes":m.available,"full_R_S_baseline":baseline}))
