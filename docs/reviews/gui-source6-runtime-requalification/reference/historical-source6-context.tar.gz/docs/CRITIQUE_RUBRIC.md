# Content critique rubric (ADR-0023)

Hard-critique standard every curated pack item must pass **before** `status: approved`.
Two layers: deterministic lints (`scripts/critique_pack.py`) and an LLM judge fleet
(`.claude/workflows/critique-games.js`) applying this rubric with live web checks.
The playability validator (`scripts/validate_games_pack.py`) checks *solvability*;
this rubric checks whether the item is **fair, recognizable, and fun for a broad
Romanian audience**. ADR-0019's editorial boundary sits ABOVE this rubric: a judge
verdict never overrides it.

Gate artifacts use version-2 batch/binding/coverage metadata (section G4) and the final
vocabulary `promote|reject|keep` for pending items. Sweeps over `approved` items output
*proposals* (`keep|demote|revise`) for the owner — approved content is never auto-demoted.

## A. Universal kill criteria (all four games)

- **A1 Recognition floor.** The concepts a player must produce or recognize are things
  an average Romanian (non-specialist, cross-generational) has actually heard of.
  Operational test: would it be unremarkable in a prime-time TV quiz? Judges verify
  doubtful cases on the web (see F). One deliberate deep-cut per item is allowed on
  `greu` only, and only when the rest of the item carries it.
- **A2 Social relevance.** The item's theme is something Romanians actively think or
  talk about (school canon, national media, charts, living memory, current internet
  culture) — not a concept that merely *exists* and is technically Romanian.
  "It makes sense but nobody would ever think of it" = kill.
- **A3 Predicate honesty.** Labels and descriptions promise exactly what the content
  delivers. No word-salad labels enumerating unlike things ("Festival, mare, castel,
  sat"), no vibe-only themes.
- **A4 Factual verifiability.** Any claim embedded in the item (who wrote what, where
  something is) must be web-verifiable. Unverifiable → reject (same rule as the
  v18-v21 import rail).
- **A5 ADR-0019 boundary.** Adult framing, profanity, alcohol-dependent play value,
  insensitive historical humor, near-duplicate of a served board: in GATE mode →
  `keep` (stays pending) regardless of quality scores — the owner decides. In SWEEP
  mode every verdict is already only an owner proposal: return your honest quality
  verdict and flag the A5 trigger in the reasoning — never convert a quality kill
  into `keep` out of deference (that hides the signal the owner needs).
- **A6 Freshness.** Not a re-skin of an already-approved item (same mechanic + same
  concepts under a new label). For a pending Conexiuni board, an exact or three-of-four
  reused quad anywhere in full pack inventory (`duplicate_groups`) and an overlap of at
  least 8 of 16 concepts with one inventory/selected board (`board_reskin`) block
  promotion, as does pushing any member above the eight-board reuse ceiling
  (`member_overuse`). Approved-stock sweeps retain approved-only comparison scope and
  report the patterns as warnings so an owner can retire them without rewriting history.
  Smaller shared-member counts remain judge evidence.
- **A7 Distinctive association.** Any connection the gameplay leans on must be true of
  X *specifically*, not of the whole country or class. "Sarmale → Moldova" is
  true-but-generic (sarmale is pan-Romanian; the same claim works for every region) —
  it makes region guesses rank warm arbitrarily and groups read as fake-regional.
  Biographic/definitional links (Eminescu → Moldova, Ciorbă rădăuțeană → Bucovina)
  are distinctive and fine. Lints: `generic_region_link` (item),
  `nondistinctive_region_link` (KG inventory); judges settle flagged cases with the
  section-F distinctiveness check.

## B. Conexiuni boards (4 groups × 4 tiles, labels hidden until solved, 4 mistakes)

Grounding: NYT Connections editorial practice (difficulty gradient; overlap as a
*designed* trap), Koster's red-herring budget rule, MCQ single-best-answer standards.

- **B1 Strict predicate per group.** Every member satisfies the group label as a
  checkable predicate of the SAME relation type. "Festivals" may contain only
  festivals — never the village that hosts one (cx_meme_net_136's Untold/Neversea/
  Electric Castle + **Bonțida** is the canonical failure). Mixing "is an X" with
  "is associated with X" members in one group = kill (Predicate Inconsistency).
- **B2 Type discipline.** A group mixing KG `node_type`s (3+1 outlier, or 2+2 split)
  is presumed broken unless the label explicitly names a type-agnostic predicate that
  every member still strictly satisfies (e.g. "Au Paris în biografie" over persons is
  fine; person+work mixes almost never are). Lint: `type_coherence`.
- **B3 Unique partition.** Exactly one defensible 4×4×4×4 partition of the 16 tiles.
  A tile that fits two groups' predicates equally well = kill. Lint `tile_fairness`
  (FAIL) fires when a tile has more on-board KG neighbors in a *type-compatible*
  foreign group (one holding ≥2 members of the tile's node_type) than in its own.
  The raw engine rule (`_board_quality`: any foreign group counts) is reported in the
  dossier as `fairness.engine_unfair_raw` — judges MUST read it: a board that passes
  `tile_fairness` but has a high raw count is thematically tangled and needs the B1–B5
  walk with extra suspicion.
- **B4 Red-herring budget.** Deliberate traps are the craft — but plausible-but-wrong
  placements must number FEWER than the 4-mistake budget (Koster's rule), and each
  must resolve uniquely once spotted. Lint: `red_herring_budget` on contested tiles.
- **B5 No mirrored groups.** Two groups in ≥3-way 1:1 strong correspondence
  (festivals ↔ their host cities; hosts ↔ their own shows; inventors ↔ their machines)
  make label-guessing a coin flip and read as lazy authoring. One crossing pair is a
  trap; three is a mirror. Lint `mirrored_groups` blocks pending boards and warns on
  approved stock.
- **B6 No generic-filler groups.** A group of bare dictionary abstractions
  ("Concert, Festival, Spectacol, Public") is not puzzle content, and its members act
  as archetype-magnets for other groups' proper nouns. Kill.
- **B7 Difficulty gradient.** Board has one anchor group an average player secures
  fast, and the hardest group uses a *nameable* trick (double meaning, shared name,
  hidden pattern, franchise), not just obscurity. No tier inversion: nothing in an
  `usor` board should demand rarer knowledge than a `greu` tile.
- **B8 Recognition per group.** ≥3 of 4 members pass A1 on their own; at most one
  deep-cut per group, and only on normal/greu.
- **B9 Label self-leakage.** A group label must not contain a member's name, and must
  not be trivially reverse-engineerable from a single member alone. Lint
  `label_self_leak` blocks a pending board when the normalized label repeats a complete
  member name (including short acronyms such as TVR); approved stock is warned for sweep.

## C. Contexto / Cald sau Rece targets (guess-by-association, rank feedback)

Grounding: Contexto.me curates common concrete nouns and excludes isolated
embeddings; Semantle's uncurated pool is the cautionary tale.

- **C1 Nameable-thing test.** The target is a concrete, spontaneously nameable thing
  (person, place, dish, work, event, object). Abstract categories, records,
  meta-concepts and "image-symbols" (Sonicitate, Pagaia din Deltă,
  Recensământul populației) = kill: nobody free-associates their way to them.
- **C2 Recognition ≥ band.** `usor` targets: universally known (school canon or
  prime-time fame). `normal`: broadly known. `greu`: still A1-recognizable — ONLY the
  associative path may get harder, never the fame. An unknown target is not "hard",
  it is unfair (Semantle failure).
- **C3 Dense, legible neighborhood.** ≥5 unique existing direct KG predecessors
  (guess → target, non-distractor, excluding the target itself) that are themselves
  recognizable, so early guesses give a gradient. Lint `contexto_incoming_floor`
  fails pending targets below five and warns on approved stock for a separate owner
  review. Bidirectional edges count in both directions; parallel edges count once.
  The numeric pass does not establish recognition or approval, and outgoing-only
  links and projected guesses cannot supply missing predecessors (ADR-0134).
  Engine floors reachable ≥120 and responsive ≥40 remain necessary but insufficient.
- **C4 Obvious opener exists.** At least one guess a naive player would try early
  (the category's most famous concept) must land warm (≤2 hops).
- **C5 No polysemy.** Target label has one dominant sense for Romanians.
- **C6 Salience banding.** Lint `salience_floor` (WARN): usor <0.60, normal <0.35,
  greu <0.20 — a flag for judge review, not an auto-kill (KG salience under-rates
  some famous nodes, e.g. Insulina 0.25).

## D. Lanțul Cuvintelor boards (directed semantic ladder)

- **D1 Recognizable endpoints.** Start and target independently pass A1; obscurity is
  never a substitute for route difficulty.
- **D2 Legible steps.** A plausible shortest route reads as a sequence of nameable
  associations. A path held together only by generic co-occurrence or taxonomy = kill.
- **D3 Real choice.** The dossier branch profile must leave multiple credible first hops
  and no single-node intermediate choke point; validator floors are necessary, not proof
  that the alternatives feel meaningful.
- **D4 Honest difficulty.** Difficulty comes from hop count and competing good routes,
  not from an unguessable endpoint or arbitrary directed edge.
- **D5 Satisfying arc.** Start and target are different enough to make the bridge feel
  discovered, while still belonging to a theme an average player can reason about.

## E. Alchimie boards (pair-combination crafting)

- **E1 Seed quality.** The 5–7 seeds are recognizable, category-coherent, and each looks
  potentially useful; no filler included only to satisfy the count.
- **E2 Intuitive openings.** At least two opening pairs produce outcomes a player could
  plausibly anticipate. The dossier count is a floor; judges assess semantic legibility.
- **E3 Inferable target.** The target is not merely present in graph closure: a short
  sequence of pair ideas gives a satisfying route toward it.
- **E4 No free answer.** The target is not a seed, alias, near-synonym, or obvious
  one-pair restatement. Difficulty comes from purposeful sequencing, not obscurity.
- **E5 Bounded choice.** The craft profile should offer options without exploding into
  a noisy closure where almost any pair works and the theme stops mattering.

## F. Romanian-relevance web checks (judge protocol, doubtful cases)

A verifier with web access confirms A1/A2/C2 by checking ≥2 independent signals:
1. **ro.wikipedia.org** article exists with non-trivial content; pageviews not a
   single-event spike.
2. **School canon**: appears in programa școlară / manuale (edu.ro, manuale.edu.ro)
   for limba română, istorie, geografie.
3. **National media**: hits in digi24 / HotNews / ProTV / Libertatea / GSP within the
   last 5 years (site-restricted search).
4. **Charts/broadcast**: Romanian radio/TV chart or festival-lineup presence (music),
   box office / audience data (film/TV).
5. **Trends**: sustained (multi-year, not one spike) Google Trends RO interest.
6. **Cross-generational test** ("ar ști-o și mama"): documented presence both pre-2010
   and current. Single-cohort or single-subculture legibility → fails A2 for usor/normal.
7. **Distinctiveness (A7)**: for a claimed X↔Y association, check whether sources tie X
   to Y *more than to the rest of Romania* (regional-cuisine overviews, biography,
   origin). If the same claim would hold for any region/class member, it is generic →
   the item fails A7.

## G. Judge-fleet protocol (fleet skill routing)

1. **Dossier**: `scripts/critique_pack.py --status pending --ids <exact-ids>
   --strict --dossier <dir>` emits one JSON per item and fails on unknown or
   filter-excluded IDs. Dossier degrees and Contexto neighbors use the runtime directed
   non-distractor graph. Each dossier carries the canonical pack-record and KG-snapshot
   digests plus `review_binding`, a SHA-256 over that dossier and the current rubric.
2. **Critique** (analyst / Sonnet): per item, walk B, C, D, or E above, simulate a player,
   name failure modes, and use the dossier's labeled routes or pair/recipe evidence for
   Lanț/Alchimie before proposing a verdict + claims needing web verification.
3. **Adversarial verify** (Opus, web access): refute-first — try to overturn the
   critique; run section-F checks on every A1/A2/C2 claim; settle the verdict. Gate
   mode verifies every item; only clean approved-stock sweeps may use the stable
   one-in-four sample. Model-returned IDs and review bindings must match the request.
4. **Batch-bound apply**: before staging, `import_candidates.py` requires complete factual
   and quality coverage for every raw candidate ref, binds both artifacts to the exact
   candidate-file SHA-256, and rejects missing/unknown/duplicate rows or unresolved
   `fix` verdicts before any graph or pack mutation. Surviving items stage as `pending`.
   Save each entry under the gate workflow result's `artifacts` key as
   `<game>_verdicts.json`; the version-2 artifact binds the exact cross-game input IDs,
   canonical dossier/rubric digest, every per-item final verdict, and complete verifier
   coverage. Legacy, stale, unverified, partially lost, or hand-combined batches fail
   closed. `apply_rereview.py` rebuilds the exact-batch dossiers, compares their bindings,
   then re-runs strict deterministic critique over the exact `promote` set against the
   prospective inventory. Same-batch rejects remain novelty debt during that check and
   are then recorded in a durable tombstone inventory before removal, so future exact,
   three-of-four, and half-board reskins stay blocked. `keep`, unrelated pending, and
   co-promoted rows also participate. Each tombstone binds its canonical group set,
   rejected record, review dossier, and exact gate artifact by SHA-256; group tampering
   fails closed. No pack copy is written before this passes.
   Approved-stock sweep proposals remain an owner decision.
   Verdict archives stay in the session scratchpad (v16 precedent). See ADR-0025.

## H. Lint reference (`scripts/critique_pack.py`)

| Check | Games | Level | Meaning |
|---|---|---|---|
| `tile_fairness` | conexiuni | FAIL | tile has more on-board neighbors in a *type-compatible* foreign group (≥2 members of its node_type) than its own; raw engine count (`_board_quality` parity) ships in the dossier as `engine_unfair_raw` |
| `red_herring_budget` | conexiuni | WARN ≥2, FAIL ≥4 | contested tiles (foreign pull == own pull > 0) |
| `mirrored_groups` | conexiuni | FAIL (new) / WARN (stock) | group pair with ≥3 disjoint strong (≥0.6) cross edges |
| `type_coherence` | conexiuni | WARN | 3+1 type outlier or 2+2 type split in a group |
| `board_type_shortcut` | conexiuni | FAIL for new four-type boards; otherwise WARN | all four groups are internally type-homogeneous and three or four distinct types expose most or all of the partition |
| `surface_predicate_crossfit` | conexiuni | FAIL (new) / WARN (stock) | a conservative literal parser proves that a foreign displayed tile also satisfies an intended prefix, suffix, contained-string, punctuation, digit/year, name/initial, one-word, or uppercase-length rule |
| `visible_string_worksheet` | conexiuni | WARN | at least three groups are provable literal display/name checks across multiple node types |
| `vague_predicate_wording` | conexiuni | FAIL (new) / WARN (stock) | recurring catch-all labels (`țin de`, `repere ale/din`, `apar în`, `legate/asociate de`, etc.) conceal an association bundle instead of stating one testable property |
| `duplicate_groups` | conexiuni | FAIL (new) / WARN (stock) | exact or three-of-four quad already in full inventory, selected batch, or durable rejection tombstones (pending gate), or approved stock (sweep/rank) |
| `board_reskin` | conexiuni | FAIL (new) / WARN (stock) | board shares at least 8 of 16 concepts with one inventory, selected, or rejected-tombstone board (pending gate), or approved board (sweep/rank) |
| `label_self_leak` | conexiuni | FAIL (new) / WARN (stock) | normalized group label repeats a complete member name or acronym |
| `contexto_incoming_floor` | contexto | FAIL (new) / WARN (stock) | fewer than five unique existing non-distractor guess-to-target neighbors, excluding the target itself; numeric pass leaves recognition and owner holds unassessed |
| `salience_floor` | contexto, lant, alchimie | WARN | target/endpoint salience below difficulty band (C6) |
| `generic_region_link` | conexiuni, contexto | WARN | gameplay leans on a non-distinctive region association (A7): board pairs regions with generically-linked tiles; target is (or is polluted by) a pan-Romanian concept claiming a region |
| `nondistinctive_region_link` | pack-wide | WARN | KG inventory of A7-suspect edges (≥2-region fan-out, or national-salience concept with a generic `related_to` region edge) — the edge-cleanup queue |
| `member_overuse` | pack-wide / selected batch | FAIL (new) / WARN (stock) | node appears in >8 approved boards, including projected promotion of selected pending candidates |

FAIL blocks promotion (`--strict` exits 1). WARN routes the item to the judge fleet —
it may pass with justification recorded in the verdict reasoning.
