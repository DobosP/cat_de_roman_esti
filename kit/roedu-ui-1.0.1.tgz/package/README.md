# RO-EDU core monorepo

Last verified: 2026-10-07

@roedu/ui 1.0.1 provides Preact 11 and light-DOM UI.
@roedu/web-kit 0.1.1 provides npm tooling and embedded Go delivery.
The [ADR ledger](docs/adr/README.md) records architecture and policy.

## Current state

S0a source milestones M0–M6 passed native unit/full/build at 214aada and automated
parent review. Full ran 40 checks, 16 HTTP browser cases and six exact screenshot
comparisons with zero CSP/axe violations; measured LCP 384 ms and INP 40 ms under
the committed throttle. Parent published immutable core-v1.0 at that code commit.
The fresh release comparison exposed compiler cache in the UI tarball.
The authorized core-v1.1 patch excludes compiler state and forces declaration
emission; [ADR-0008](docs/adr/0008-release-artifacts-exclude-compiler-state.md)
records the correction. Clean588 unit/full and two fresh builds passed;
parent fresh full also passed40checks. Final release review exposed Python
bytecode in the consumer-test kit despite identical cache-free fresh builds.
The authorized narrow repair excludes Python caches across packaging and
consumer boundaries, preserves Python sources and proves contaminated-kit
archive equality. Parent review and actual new execution trust are complete.
Final fixed-HEAD qualification and parent release remain pending; the final
report binds actual receipts and retained consumer/build archive comparisons.
Receipts live in `.gate/{unit,full,build}/result.json`; archive identity
and source identity remain separate. No physical-device, production or consumer
adoption is claimed by this source worktree.
The patch also implements the Cat-only sealed staged-UI contract and confined
same-repo Go audits from [ADR-0009](docs/adr/0009-corrective-release-and-staged-sdk.md).
Staged UI is pending; M2 hooks require actual active UI installation proof.
Bootstrap follows the wrapper's bound current descriptor and preserves earlier
receipts; host-private checks guard accepted source and result return.
The [ExecPlan](docs/execplans/core-v1.md) contains source progress and evidence;
the [program](docs/PROGRAM.md) freezes the release and consumer contracts.

Core-v1.0 was landed and published at214aada after independent fresh full.
Consumer bundle staging is held by a confirmed compiler-cache packaging mismatch
and first-adoption sequencing defects. The corrective core-v1.1 implementation
is governed by [native erratum E1](docs/PROGRAM.md#native-erratum-e1--first-consumer-and-corrective-core-release)
and the [bounded core patch](.agent/CORE-PATCH-1.md). No consumer adoption is claimed.

## Source and interfaces

| Area | Path | Surface |
| --- | --- | --- |
| Tokens | src/tokens/ | DTCG input, generated CSS/app themes, TS and Go constants |
| Layered CSS | src/css/ | reset, tokens, base, components, utilities, app |
| Components | src/preact/ | CSP-safe and keyboard accessible Preact components |
| Behaviors | src/behaviors/ | light-DOM elements, invoker and island protocol |
| Motion | src/motion/ | Presence, springs, Confetti and mini playback controls |
| Network/storage | src/net/, src/storage/ | same-origin CSRF and registered keys |
| Go delivery | web-kit/ | assets, static, csp, island, health, golden, routes, engine |
| Sample | web-kit/sample/ | three stress modules, Pongo2 and compiled templ pages |
| Gate | scripts/gate.sh | pinned Linux execution and bound evidence |
| Templates | web-kit/templates/ | shared gate files, repo hooks and CI reference |

## Consumption

Consumers select only committed kit/CORE_TAG and adopt through the owner
staging/sync/trust sequence. The [consumer notes](CONSUMER_NOTES.md) list every
breaking API/style change and the exact kit protocol. Import components from
@roedu/ui/preact, CSS from @roedu/ui/styles.css and one generated theme.
Reading comfort requires a self-paced surface and rejects timed/psychometric use.
Preact island adapters render into a stable owned child, then dispose it on abort.

## Verification and documentation

Every product build/test runs through the pinned native wrapper. Full adds real
PostgreSQL, an image-built app, all registered-page nonce checks, axe/vitals,
journeys and exact committed screenshot comparisons. Full permits no skips.
The [testing guide](docs/agent-testing.md) describes commands and evidence.
Requests and resolutions are append-only in [GATE_REQUESTS.md](GATE_REQUESTS.md).
Source maps: [agent map](docs/agent-map.md), [architecture](docs/architecture.md),
[theming](docs/theming.md), [tokens](docs/design-tokens.md),
[consumer guide](docs/consuming-web-react.md) and [LLM guides](docs/llm/README.md).
The original React 0.3.1 verification remains historical in [WORKLOG.md](WORKLOG.md).
