import assert from "node:assert/strict";
import {test} from "../test-api.mjs";
import {installSynthetic,boardFor} from "../fixtures.mjs";
import {ready,snapshot,depart,trigger,poll,recordExactlyOnce,settledFrames,evidence} from "../contracts.mjs";
test("CHARACTERIZATION: Conexiuni accepts leaving-screen selection and guess at frozen pin",async({page,context})=>{
 const f=await installSynthetic(context,"conexiuni",{nearWin:true});await ready(page,f);
 const retainedScreen=await page.locator(".screen").elementHandle();
 await retainedScreen.evaluate(node=>{window.__motionRetainedScreen=node;});
 const leaving=await depart(page,"conexiuni");assert.equal(leaving.mounted,true);
 assert.ok(leaving.tiles.every(t=>!t.disabled),"frozen absent Presence guard characterization");
 const activated=await page.evaluate(board=>{
  const n=document.querySelector(board);if(!n)throw Error("old board detached");
  for(const b of n.querySelectorAll("button"))b.click();return n.isConnected;
 },boardFor("conexiuni"));assert.equal(activated,true);
 await settledFrames(page);const selected=await snapshot(page,"conexiuni");assert.equal(selected.mounted,true);
 assert.equal(selected.tiles.filter(t=>t.pressed==="true").length,4);
 await page.evaluate(()=>{const b=[...document.querySelectorAll("button")].find(b=>b.textContent.trim()==="Verifică");if(!b)throw Error("missing verify");b.click();});
 await poll(()=>f.counts(),c=>c.mutations===1,"leaving guess not observed",200);
 await recordExactlyOnce(page,f);
 const writes=await page.evaluate(()=>window.__motionWrites);
 const screenStillMounted=writes.some(w=>w.played===1&&w.retainedScreenMounted);
 assert.equal(screenStillMounted,true,"native storage observation must prove record before old screen detachment");
 await evidence(test,page,f,{screenStillMounted,classification:"current-gap-observation; not a migration parity assertion",leaving,selected});
});
test("CHARACTERIZATION: Conexiuni held win can record during exit before unmount",async({page,context})=>{
 const f=await installSynthetic(context,"conexiuni",{nearWin:true});await ready(page,f);
 const retainedScreen=await page.locator(".screen").elementHandle();
 await retainedScreen.evaluate(node=>{window.__motionRetainedScreen=node;});
 const held=f.hold("terminal");await trigger(page,"conexiuni");await held.requested;
 const leaving=await depart(page,"conexiuni");assert.equal(leaving.mounted,true);
 held.release();await recordExactlyOnce(page,f);
 const writes=await page.evaluate(()=>window.__motionWrites);
 const screenStillMounted=writes.some(w=>w.played===1&&w.retainedScreenMounted);
 assert.equal(screenStillMounted,true,"native storage observation must prove record before old screen detachment");
 await evidence(test,page,f,{screenStillMounted,classification:"current-gap-observation; not an approved target",leaving});
});
