# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: conexiuni-action-recovery.spec.mjs >> a confirmed duplicate remains blocked after failed verification and manual read
- Location: e2e/conexiuni-action-recovery.spec.mjs:342:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Aproape: 3 din 4. Schimbă o piesă.', { exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Aproape: 3 din 4. Schimbă o piesă.', { exact: true }) with timeout 10000ms
  - waiting for getByText('Aproape: 3 din 4. Schimbă o piesă.', { exact: true })

```

```yaml
- button "Ieși la lista de jocuri": Ieși
- strong: Conexiuni
- group "Starea jocului": DIFICULTATE Ușor GREȘELI 3 rămase
- group: Reguli și ajutor
- status:
  - text: ACUM
  - strong: Schimbă o piesă
  - text: Aceeași combinație a fost deja verificată.
- img "3 greșeli disponibile"
- button "Schimbă o piesă" [disabled]
- status: "Aproape: 3 din 4. Schimbă o piesă."
- button "Sârma de rufe"
- button "Cauciucurile de iarnă"
- button "Revelionul la televizor"
- button "Sărbători în familie"
- button "Masa în familie"
- button "Vitrina cu bibelouri"
- button "Borcanele de zacuscă"
- button "Rude"
- button "Asociația de proprietari"
- button "Covor"
- button "Interfonul" [pressed]
- button "lift" [pressed]
- button "Întreținerea" [pressed]
- button "Mileurile croșetate"
- button "Carpeta de pe perete" [pressed]
- button "Bicicleta Pegas"
- button "Indiciu · încă 1 greșeală" [disabled]
- button "Amestecă"
- button "Golește"
- status
```

# Test source

```ts
  245 |   test(`a late ${missing ? "404" : "winning"} read cannot adopt or clear another tab's saved round`, async ({ page, context, request }) => {
  246 |     const initial = await prepare(page, request, { solved: 3 });
  247 |     const newer = await newerRound(request);
  248 |     await loseCommittedResponse(page, initial.game_id, "guess");
  249 |     const held = await holdRecovery(page, initial.game_id, missing);
  250 |     expect((await guess(page, initial.game_id, steps()[3])).status()).toBe(503);
  251 |     await held.requested;
  252 |     const other = await saveFromOtherTab(context, newer.game_id);
  253 |     held.release();
  254 |     await expect(currentGame(page)).toBeEnabled();
  255 |     await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toHaveCount(0);
  256 |     expect(await remembered(page)).toBe(newer.game_id);
  257 |     expect(await played(page)).toBe(0);
  258 |     const loaded = responseFor(page, newer.game_id, "", "GET");
  259 |     await currentGame(page).click();
  260 |     expect((await loaded).status()).toBe(200);
  261 |     await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  262 |     expect(await remembered(page)).toBe(newer.game_id);
  263 |     expect(await played(page)).toBe(0);
  264 |     await other.close();
  265 |   });
  266 | }
  267 | 
  268 | test("leaving during recovery preserves its pointer and stale completion cannot change a new screen", async ({ page, context, request }) => {
  269 |   const initial = await prepare(page, request, { solved: 3 });
  270 |   await loseCommittedResponse(page, initial.game_id, "guess");
  271 |   const held = await holdRecovery(page, initial.game_id);
  272 |   expect((await guess(page, initial.game_id, steps()[3])).status()).toBe(503);
  273 |   await held.requested;
  274 |   await page.getByRole("button", { name: "Ieși la lista de jocuri", exact: true }).click();
  275 |   await expect(page.getByRole("button", { name: /^Joacă Conexiuni —/ })).toBeVisible();
  276 |   expect(await remembered(page)).toBe(initial.game_id);
  277 |   const newer = await newerRound(request);
  278 |   const other = await saveFromOtherTab(context, newer.game_id);
  279 |   const loaded = responseFor(page, newer.game_id, "", "GET");
  280 |   await page.getByRole("button", { name: /^Joacă Conexiuni —/ }).click();
  281 |   expect((await loaded).status()).toBe(200);
  282 |   const oldCompleted = responseFor(page, initial.game_id, "", "GET");
  283 |   held.release();
  284 |   await oldCompleted;
  285 |   await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  286 |   await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toHaveCount(0);
  287 |   expect(await remembered(page)).toBe(newer.game_id);
  288 |   expect(await played(page)).toBe(0);
  289 |   await other.close();
  290 | });
  291 | 
  292 | test("an already different saved pointer pauses before any old-round mutation", async ({ page, context, request }) => {
  293 |   const initial = await prepare(page, request);
  294 |   const newer = await newerRound(request);
  295 |   const other = await saveFromOtherTab(context, newer.game_id);
  296 |   const counts = traffic(page, initial.game_id);
  297 |   await choose(page, steps()[0]);
  298 |   await page.getByRole("button", { name: "Verifică", exact: true }).click();
  299 |   await expect(currentGame(page)).toBeEnabled();
  300 |   expect(counts).toEqual({ reads: 0, mutations: 0 });
  301 |   expect(await (await request.get(gameURL(game, initial.game_id))).json()).toEqual(initial);
  302 |   expect(await remembered(page)).toBe(newer.game_id);
  303 |   await currentGame(page).click();
  304 |   await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  305 |   expect(await played(page)).toBe(0);
  306 |   await other.close();
  307 | });
  308 | 
  309 | test("a verified missing owned session returns to setup and conditionally clears its pointer", async ({ page, request }) => {
  310 |   const initial = await prepare(page, request);
  311 |   const counts = traffic(page, initial.game_id);
  312 |   for (const suffix of ["/guess", ""]) {
  313 |     await page.route(`**${gameURL(game, initial.game_id)}${suffix}`, (route) => route.fulfill({
  314 |       status: 404, contentType: "application/json", body: "{}",
  315 |     }), { times: 1 });
  316 |   }
  317 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(404);
  318 |   await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  319 |   expect(await remembered(page)).toBeNull();
  320 |   expect(await played(page)).toBe(0);
  321 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  322 | });
  323 | 
  324 | test("lost one-away feedback stays neutral and confirmed duplicate feedback still requires a change", async ({ page, request }) => {
  325 |   const initial = await prepare(page, request);
  326 |   const counts = traffic(page, initial.game_id);
  327 |   const committed = await loseCommittedResponse(page, initial.game_id, "guess");
  328 |   expect((await guess(page, initial.game_id, solution(game).practice)).status()).toBe(503);
  329 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Joc sincronizat. Poți continua." })).toBeVisible();
  330 |   expect(committed().one_away).toBe(true);
  331 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toHaveCount(0);
  332 |   const duplicate = responseFor(page, initial.game_id, "guess");
  333 |   await page.getByRole("button", { name: "Verifică", exact: true }).click();
  334 |   expect((await duplicate).status()).toBe(409);
  335 |   await expect(page.getByRole("button", { name: "Schimbă o piesă", exact: true })).toBeDisabled();
  336 |   await expect(page.locator(`${game.board} [aria-pressed=true]`)).toHaveCount(4);
  337 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toHaveCount(0);
  338 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).mistakes).toBe(1);
  339 |   expect(counts).toEqual({ reads: 2, mutations: 2 });
  340 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(200);
  341 |   await expect(page.locator(`${game.board} button`)).toHaveCount(12);
  342 | });
  343 | 
  344 | test("a confirmed duplicate remains blocked after failed verification and manual read", async ({ page, request }) => {
> 345 |   const initial = await prepare(page, request);
      |                                                                                       ^ Error: expect(locator).toBeVisible() failed
  346 |   expect((await guess(page, initial.game_id, solution(game).practice)).status()).toBe(200);
  347 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toBeVisible();
  348 |   const counts = traffic(page, initial.game_id);
  349 |   await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({
  350 |     status: 503, contentType: "application/json", body: "{}",
  351 |   }), { times: 1 });
  352 |   expect((await guess(page, initial.game_id, solution(game).practice)).status()).toBe(409);
  353 |   await expect(verify(page)).toBeEnabled();
  354 |   await verify(page).click();
  355 |   await expect(verify(page)).toHaveCount(0);
  356 |   await expect(page.getByRole("button", { name: "Schimbă o piesă", exact: true })).toBeDisabled();
  357 |   await expect(page.locator(`${game.board} [aria-pressed=true]`)).toHaveCount(4);
  358 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toHaveCount(0);
  359 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).mistakes).toBe(1);
  360 |   expect(counts).toEqual({ reads: 2, mutations: 1 });
  361 | });
  362 | 
```