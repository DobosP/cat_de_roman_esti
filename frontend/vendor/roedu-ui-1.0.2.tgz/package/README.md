# RO-EDU core monorepo

Last verified: 2026-10-07

@roedu/ui 1.0.2 retains the Preact 11 runtime with updated package metadata.
@roedu/web-kit 0.1.2 implements configured consumer version resolution.
The [ADR ledger](docs/adr/README.md) records architecture and policy.

## Current state

S0a UI/delivery is complete. Parent independently accepted clean unit/full and
reproducible build archives at 9acd440, landed main and published immutable
core-v1.1. Unit passed27 checks with only the permitted pg-live/no-dsn skip;
full passed40 checks and16 HTTP browser cases, six exact screenshot comparisons,
zero CSP/axe violations and no skips/retries. Parent fresh full passed at the same
source; lab LCP432 ms/INP40 ms is directional, not a phone measurement.
Canonical release keepers are retained by the parent. Earlier core-v1.0 remains
immutable; its compiler-cache reproduction defect is corrected by
[ADR-0008](docs/adr/0008-release-artifacts-exclude-compiler-state.md).

Linux implementation resumed on 2026-10-07 under the parent's recorded current
authority. The [Windows handover](docs/GUI_MIGRATION_HANDOFF.md) remains history.
Cat's original baseline, 16 fixtures/78 assertions and exact 30-file legacy freeze
retain their earlier accepted scope. First kit sync awaits the shared CORE_REQ3
correction in [ADR-0010](docs/adr/0010-configured-consumer-version-resolution.md).
Historical d0e6c7c passed unit28 plus the permitted PG skip and full41 with no
skips, six exact screenshots and independently checked185/231 bindings. Those
receipts do not qualify the recovered changed source.

The sealed Windows81 preparation is source-accepted and applied in the native
owning task worktree. [ADR-0012](docs/adr/0012-go-archive-budget-closure.md) records
the narrow budget Go archive closure and real parser/extracted-module regression.
[ADR-0013](docs/adr/0013-confined-declaration-preparation.md) records confined
pre-emission declaration regeneration, compatible with ADR-0008's postbuild stage.
Private bundle admission and Go planning preserve public exports and failure order;
their parity/refusal checks passed the actual dirty native unit run. The
[owning integration ExecPlan](docs/execplans/core-integration.md) records exact
selected-source provenance, current Linux checks and evidence retention.
Changed-source inner-loop unit passed28 checks plus only pg-live/no-dsn, with292
artifact hashes verified and21 declaration safety cases. Clean HEAD qualification
and complete fresh owning A/B comparisons are required for release. No core-v1.2
release is accepted; core-v1.1 remains the released kit. Future qualified source,
tree, image and archive identities remain UNSET until actually earned.
No Cat M0, active UI, physical-device or production completion is claimed.
Cat's original114,086-byte gzip entry also exceeds the40,960-byte limit.
[ADR-0011](docs/adr/0011-original-runtime-budget-qualification-order.md) corrects
preliminary acceptance ordering while keeping the budget red, the real device
checkpoint and the green M2 requirement before S0b unchanged.

The Cat-only sealed staged-UI contract and confined same-repo Go audits from
[ADR-0009](docs/adr/0009-corrective-release-and-staged-sdk.md) remain enforced.
Staged UI is pending; M2 requires actual active installation proof. Bootstrap
uses the bound current descriptor and host-private result checks. The
[core ExecPlan](docs/execplans/core-v1.md) preserves S0a history; the
[consumer resolver ExecPlan](docs/execplans/consumer-resolution.md) records the
current fix. [PROGRAM](docs/PROGRAM.md) retains the release and consumer gates.

## Source and interfaces

| Area | Path | Surface |
| --- | --- | --- |
| Tokens | src/tokens/ | DTCG input, generated CSS/app themes, TS and Go constants |
| Layered CSS | src/css/ | reset, tokens, base, components, utilities, app |
| Components | src/preact/ | CSP-safe and keyboard accessible Preact components |
| Behaviors | src/behaviors/ | light-DOM elements, invoker and island protocol |
| Motion | src/motion/ | Presence, springs, Confetti and mini playback controls |
| Network/storage | src/net/, src/storage/ | same-origin CSRF and registered keys |
| Go delivery | web-kit/ | assets, static, csp, island, health, golden, routes, engine |
| Sample | web-kit/sample/ | three stress modules, Pongo2 and compiled templ pages |
| Gate | scripts/gate.sh | pinned Linux execution and bound evidence |
| Templates | web-kit/templates/ | shared gate files, repo hooks and CI reference |

## Consumption

Consumers select only committed kit/CORE_TAG and adopt through the owner
staging/sync/trust sequence. The [consumer notes](CONSUMER_NOTES.md) list every
breaking API/style change and the exact kit protocol. Import components from
@roedu/ui/preact, CSS from @roedu/ui/styles.css and one generated theme.
Reading comfort requires a self-paced surface and rejects timed/psychometric use.
Preact island adapters render into a stable owned child, then dispose it on abort.

## Verification and documentation

The Last verified date includes frozen-source seal, raw Git preimages, selector
and context checks plus application and actual dirty unit. Final clean qualification
requires its own HEAD-bound receipts;
historical receipts above retain their original source scope.

Every product build/test runs through the pinned native wrapper. Full adds real
PostgreSQL, an image-built app, all registered-page nonce checks, axe/vitals,
journeys and exact committed screenshot comparisons. Full permits no skips.
The [testing guide](docs/agent-testing.md) describes commands and evidence.
Requests and resolutions are append-only in [GATE_REQUESTS.md](GATE_REQUESTS.md).
Source maps: [agent map](docs/agent-map.md), [architecture](docs/architecture.md),
[theming](docs/theming.md), [tokens](docs/design-tokens.md),
[consumer guide](docs/consuming-web-react.md) and [LLM guides](docs/llm/README.md).
The original React 0.3.1 verification remains historical in [WORKLOG.md](WORKLOG.md).
