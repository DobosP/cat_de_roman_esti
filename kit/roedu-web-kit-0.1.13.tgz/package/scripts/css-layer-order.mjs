import { readFileSync } from 'node:fs';
import { join,resolve } from 'node:path';

const canonicalNames='reset,tokens,base,components,utilities,app';
const stylesheet='roedu-ui.css';
function bytes(value) {
  if(typeof value!=='string'&&!(value instanceof Uint8Array))throw Error('stylesheet bytes required');
  return Buffer.from(value);
}

/** The owning base stylesheet is the source of the programme's layer order. */
export function layerOrderStatement(baseCss) {
  const match=/^\s*@layer\s+([a-z]+(?:\s*,\s*[a-z]+)*)\s*;/.exec(bytes(baseCss).toString('utf8'));
  if(!match||match[1].replaceAll(/\s/g,'')!==canonicalNames)throw Error('canonical base stylesheet layer order required');
  return `@layer ${match[1].replaceAll(/\s/g,'')};`;
}

export function prependLayerOrder(css,baseCss) {
  const original=bytes(css),statement=Buffer.from(layerOrderStatement(baseCss));
  if(!original.length)throw Error('nonempty emitted stylesheet required');
  if(original.subarray(0,statement.length).equals(statement))return original;
  // Do not rewrite or strip any existing rule, declaration or later statement.
  return Buffer.concat([statement,Buffer.from('\n'),original]);
}

/** Run after Vite emits/minifies CSS, before any writeBundle inventory hashes. */
export default function roeduCssLayerOrder() {
  let root;
  return {
    name:'roedu-css-layer-order',apply:'build',enforce:'post',
    configResolved(config){root=resolve(config.root);},
    generateBundle:{order:'post',handler(_options,bundle) {
      if(!root)throw Error('resolved owning root required for CSS layer order');
      const asset=bundle[stylesheet];
      if(!asset||asset.type!=='asset')throw Error('actual roedu-ui.css asset required');
      asset.source=prependLayerOrder(asset.source,readFileSync(join(root,'src/css/base.css')));
    }},
  };
}
