from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
import tomllib

WT = Path('/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity')
REVIEW = WT / 'docs/reviews/v91-recovery-and-mobile-clarity'
SCRATCH = Path(__file__).resolve().parent
BASE = 'e2e03638b90fc9248c33f70eedaa8c9c5fbd87ad'
OUT = {'checked_at': datetime.now(timezone.utc).isoformat(), 'errors': []}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def digest(path):
    return sha(path.read_bytes())

def check(ok, label):
    if not ok:
        OUT['errors'].append(label)

def js(path):
    return json.loads(path.read_bytes())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WT)

def mismatch(pins):
    return [p for p, value in pins.items() if not (WT / p).is_file() or digest(WT / p) != value]

def archive(path, entries, expected_sha, decoded_sha=None):
    raw = path.read_bytes()
    check(raw[4:8] == bytes(4), f'{path.name}: gzip mtime')
    check(sha(raw) == expected_sha, f'{path.name}: archive sha')
    decoded = gzip.decompress(raw)
    if decoded_sha:
        check(sha(decoded) == decoded_sha, f'{path.name}: decoded sha')
    with tarfile.open(fileobj=io.BytesIO(decoded)) as tar:
        members = [m for m in tar.getmembers() if m.isfile()]
        check(len({m.name for m in members}) == len(members), f'{path.name}: duplicate member')
        payloads = {m.name: tar.extractfile(m).read() for m in members}
    check(set(payloads) == set(entries), f'{path.name}: complete member set')
    for name, entry in entries.items():
        expected = entry if isinstance(entry, str) else entry['sha256']
        check(name in payloads and sha(payloads[name]) == expected, f'{path.name}: member sha {name}')
        if isinstance(entry, dict) and 'bytes' in entry:
            check(len(payloads[name]) == entry['bytes'], f'{path.name}: member bytes {name}')
    return payloads, {'archive_sha256': sha(raw), 'decoded_sha256': sha(decoded), 'member_count': len(payloads)}

manifest_path = REVIEW / 'review-manifest.json'
manifest_raw = manifest_path.read_bytes()
(SCRATCH / 'audited-review-manifest.json').write_bytes(manifest_raw)
manifest = json.loads(manifest_raw)
check(manifest['baseline_commit'] == BASE, 'ledger baseline')
groups = {k: v for k, v in manifest.items() if isinstance(v, dict)}
all_bindings = {}
for group, entries in groups.items():
    for path, value in entries.items():
        check(path not in all_bindings, f'ledger duplicate path: {path}')
        all_bindings[path] = value
        if group == 'removed_files':
            check(not (WT / path).exists(), f'removed path exists: {path}')
            check(sha(git('show', f'{BASE}:{path}')) == value, f'removed baseline blob: {path}')
        else:
            check((WT / path).is_file() and digest(WT / path) == value, f'ledger current sha: {path}')
changed = set(git('diff', '--no-renames', '--name-only', '-z', BASE).decode().split('\0')) - {''}
changed |= set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
manifest_name = str(manifest_path.relative_to(WT))
check(set(all_bindings) == changed - {manifest_name}, 'ledger coverage of every changed path except self')
check(len(all_bindings) == 480, 'ledger480 count')
check(sha(manifest_raw) == 'a63165d2c854657d0b38ce54f74cd20240e03c13b7fa85a3e6954b5ea9f39758', 'notified stable ledger hash')
OUT['audited_manifest'] = {'sha256': sha(manifest_raw), 'bindings': len(all_bindings),
                           'groups': {k: len(v) for k, v in groups.items()},
                           'changed_paths_including_manifest': len(changed),
                           'unbound_changed_paths': sorted(changed - set(all_bindings) - {manifest_name}),
                           'extra_bindings': sorted(set(all_bindings) - changed)}

initial_path = REVIEW / 'incomplete-integration/initial-freeze.json'
backend_path = REVIEW / 'backend-input-freeze.json'
final_path = REVIEW / 'integration-freeze.json'
initial, backend, final = js(initial_path), js(backend_path), js(final_path)
source_amend = js(REVIEW / 'source-freeze-amendment.json')
frontend_amend = js(REVIEW / 'frontend-test-amendment.json')
check(source_amend['initial_freeze_sha256'] == digest(initial_path), 'source amendment initial binding')
check(frontend_amend['backend_freeze_sha256'] == digest(backend_path), 'frontend amendment backend binding')
for before, after, amendment, label in [(initial, backend, source_amend, 'backend expectation'),
                                       (backend, final, frontend_amend, 'frontend setup')]:
    differences = {p: {'before': value, 'after': after.get(p)} for p, value in before.items() if after.get(p) != value}
    check(differences == amendment['changed_frozen_inputs'], f'{label}: exact documented amendment')
    new_paths = set(after) - set(before)
    check(all(p.startswith('docs/reviews/') for p in new_paths), f'{label}: extra serving input')
    OUT.setdefault('amendments', {})[label] = {'changed_paths': differences, 'new_review_inputs': len(new_paths)}
check(len(initial) == 1994 and len(backend) == 2035 and len(final) == 2091, 'freeze counts')
check(set(mismatch(initial)) == set(source_amend['changed_frozen_inputs']) | set(frontend_amend['changed_frozen_inputs']), 'initial current differences')
check(set(mismatch(backend)) == set(frontend_amend['changed_frozen_inputs']), 'backend current differences')
check(not mismatch(final), 'final2091 current hashes')
check(digest(final_path) == '5be289877b18d70887d4c0fa4282c6b83f941f29ea0dd942ffdf066a1304d3fc', 'notified stable freeze hash')
OUT['freezes'] = {'initial': {'count': len(initial), 'sha256': digest(initial_path)},
                 'backend': {'count': len(backend), 'sha256': digest(backend_path), 'current_differences': mismatch(backend)},
                 'final': {'count': len(final), 'sha256': digest(final_path), 'current_differences': mismatch(final)}}

verification = js(REVIEW / 'verification.json')
check(verification['result'] == 'passed' and len(verification['checks']) == 16, '16 final gates')
check(verification['input_freeze_sha256'] == digest(final_path), 'verification final freeze')
check(verification['backend_input_freeze_sha256'] == digest(backend_path), 'verification backend freeze')
logs = {}
OUT['gates'] = {}
for name, gate in verification['checks'].items():
    check(gate['exit_code'] == 0, f'{name}: gate exit')
    a = gate['archive']
    raw = (REVIEW / a['path']).read_bytes()
    decoded = gzip.decompress(raw)
    check(raw[4:8] == bytes(4) and a['gzip_mtime'] == 0, f'{name}: gzip mtime')
    check(sha(raw) == a['archive_sha256'] and len(raw) == a['archive_bytes'], f'{name}: archive')
    check(sha(decoded) == a['decoded_sha256'] == gate['log_sha256'] and len(decoded) == a['decoded_bytes'], f'{name}: decoded log')
    text = decoded.decode()
    check(text.splitlines()[-len(gate['tail']):] == gate['tail'] if gate['tail'] else text == '', f'{name}: receipt tail')
    logs[name] = text
    OUT['gates'][name] = {'exit_code': gate['exit_code'], 'command': gate['command'],
                          'archive_sha256': sha(raw), 'decoded_sha256': sha(decoded),
                          'last_line': text.splitlines()[-1] if text.splitlines() else ''}
for name in ['backend312', 'backend314']:
    check(re.search(r'^1652 passed in ', logs[name], re.M) is not None, f'{name}:1652 summary')
for name in ['accounts312', 'accounts314']:
    check(re.search(r'^53 passed in ', logs[name], re.M) is not None, f'{name}:53 summary')
check('ℹ pass 193' in logs['frontend_native'] and 'ℹ fail 0' in logs['frontend_native'], 'native193 summary')
browser_lines = re.findall(r'^\s*✓\s+(\d+) ', logs['browser'], re.M)
check(len(browser_lines) == 342 and len(set(browser_lines)) == 342, 'browser342 unique passing entries')
check('Running 342 tests using 2 workers' in logs['browser'] and '342 passed (10.0m)' in logs['browser'], 'browser342/2 summary')
check(verification['checks']['browser']['command'] == ['npm', 'run', 'test:e2e', '--', '--workers=2'], 'browser workers override')
config = (WT / 'frontend/playwright.config.mjs').read_text()
check(re.search(r'\bretries:\s*0\b', config) is not None, 'Playwright retries0')
check(not re.search(r'^\s*\d+ (?:failed|flaky|skipped)\b|^.*\(retry #\d+\)', logs['browser'], re.M), 'browser no failed/flaky/retry summary records')
check('119.08 KiB  total' in logs['frontend_build'] and '119.08 KiB  total' in logs['frontend_bundle'], 'bundle119.08')
check('GREEN: fixture is valid (0 errors)' in logs['fixture'] and 'games pack GREEN' in logs['pack'], 'validators summaries')
check('All checks passed!' in logs['ruff'] and logs['whitespace'] == '', 'lint/whitespace summary')
OUT['verification_sha256'] = digest(REVIEW / 'verification.json')
OUT['browser_configuration'] = {'config_sha256': digest(WT / 'frontend/playwright.config.mjs'),
                                 'workers': 2, 'retries': 0, 'unique_pass_entries': len(set(browser_lines))}

old_ui = js(REVIEW / 'final-ui-audit.json')
ui_pins = js(REVIEW / 'derived-recovery/final-candidate-manifest.json')['inputs']
check(mismatch(ui_pins) == ['frontend/e2e/solutions.py'], 'old focused final42 differs only documented test helper')
for p, h in ui_pins.items():
    if p == 'frontend/e2e/solutions.py':
        check(h == frontend_amend['changed_frozen_inputs'][p]['before'], 'historical helper pin binding')
check(digest(REVIEW / 'final-ui-audit.json') == all_bindings[str((REVIEW / 'final-ui-audit.json').relative_to(WT))], 'old UI audit remains byte exact')
OUT['earlier_ui_evidence'] = {'audit_sha256': digest(REVIEW / 'final-ui-audit.json'),
                             'expected_historical_pin_difference': ['frontend/e2e/solutions.py'],
                             'current_static_and_ui_source_mismatches': []}

alch_manifest = js(REVIEW / 'alchimie-test-setup/manifest.json')
alch, alch_receipt = archive(REVIEW / 'alchimie-test-setup/evidence.tar.gz', alch_manifest['entries'], alch_manifest['archive_sha256'])
before, after = json.loads(alch['solutions-before.json']), json.loads(alch['solutions-after.json'])
comparisons = {g: {k: before[g][k] == after[g][k] for k in ['initial', 'steps', 'practice']} for g in before}
check(len(comparisons) == 6 and all(all(x.values()) for x in comparisons.values()), 'all18 original helper fields exact')
for game in before:
    check(set(after[game]) - set(before[game]) == ({'hint_setup'} if game == 'alchimie' else set()), f'{game}: helper added-field scope')
    check(not (set(before[game]) - set(after[game])), f'{game}: no removed helper fields')
pairs = after['alchimie']['hint_setup']
owned = {row['id'] for row in after['alchimie']['initial']['inventory']}
check(len(pairs) == 11 and len({tuple(sorted(v.values())) for v in pairs}) == 11, '11 unique hint-setup pairs')
check(all(set(p) == {'a', 'b'} and p['a'] != p['b'] and set(p.values()) <= owned for p in pairs), 'owned pair IDs only')
check(not mismatch(json.loads(alch['focused-inputs.json'])), 'Alchimie focused30 pins current')
postcheck = json.loads(alch['focused-postcheck.json'])
check(postcheck['browser_passed'] == 34 and postcheck['browser_exit_code'] == 0 and postcheck['browser_retries'] == 0 and postcheck['changed_paths'] == [], 'Alchimie focused postcheck')
alch_log = alch['focused-browser.log'].decode()
check(len(re.findall(r'^\s*✓\s+\d+ ', alch_log, re.M)) == 34 and '34 passed' in alch_log, 'Alchimie34 raw pass lines')
independent = js(REVIEW / 'alchimie-test-setup/independent-review.json')
check(independent == json.loads(alch['independent-review.json']), 'Alchimie independent receipt exact')
check(independent['verdict'] == 'accept' and independent['findings'] == [], 'Alchimie independent acceptance')
check(not mismatch(independent['current_file_sha256']), 'Alchimie reviewed two files current')
comparison = json.loads(alch['solution-comparison.json'])
check(comparison['seeded_starts_sha256'] == digest(WT / 'frontend/e2e/seeded-starts.json'), 'unchanged seeded starts')
OUT['alchimie_test_setup'] = {**alch_receipt, 'existing_field_comparisons': comparisons,
                             'hint_setup_pairs': len(pairs), 'focused_passes': 34,
                             'focused_input_count': len(json.loads(alch['focused-inputs.json'])),
                             'independent_verdict': independent['verdict']}

OUT['preserved_red_runs'] = {}
for label, receipt_name, log_name, summary, expected_exit in [
    ('backend', 'backend312.json.gz', 'backend312.log.gz', '2 failed, 1265 passed', 2),
    ('browser', 'initial-browser.json.gz', 'initial-browser.log.gz', '338 passed', 1)]:
    receipt = json.loads(gzip.decompress((REVIEW / 'incomplete-integration' / receipt_name).read_bytes()))
    decoded = gzip.decompress((REVIEW / 'incomplete-integration' / log_name).read_bytes())
    check(sha(decoded) == receipt['log_sha256'] and receipt['exit_code'] == expected_exit and summary in decoded.decode(), f'preserved red {label}')
    if label == 'browser':
        check('2 failed' in decoded.decode(), 'preserved browser two failures')
    OUT['preserved_red_runs'][label] = {'exit_code': receipt['exit_code'], 'decoded_sha256': sha(decoded), 'summary': summary}
red_manifest = js(REVIEW / 'incomplete-integration/initial-browser-results-manifest.json')
_, OUT['preserved_red_browser_artifacts'] = archive(REVIEW / 'incomplete-integration/initial-browser-results.tar.gz', red_manifest['files'], red_manifest['archive_sha256'], red_manifest['decoded_sha256'])
sparse_manifest = js(REVIEW / 'sparse-recipe-audit/packaging.json')
_, OUT['sparse_recipe_sources'] = archive(REVIEW / 'sparse-recipe-audit/source-snapshots.tar.gz', sparse_manifest['members_sha256'], sparse_manifest['archive_sha256'], sparse_manifest['decoded_sha256'])

OUT['doc_lines'] = {p: len((WT / p).read_text().splitlines()) for p in ['docs/STATUS.md', 'docs/agent-map.md', 'docs/agent-testing.md']}
check(OUT['doc_lines'] == {'docs/STATUS.md': 109, 'docs/agent-map.md': 46, 'docs/agent-testing.md': 54}, 'doc counts')
automation = tomllib.loads(Path('/home/dobo/.codex/automations/romanian-arcade-version-loop/automation.toml').read_text())
OUT['stop_authority'] = {'id': automation['id'], 'kind': automation['kind'], 'status': automation['status'],
                         'adr0137_sha256': digest(WT / 'docs/adr/0137-finish-v91-and-stop-iteration-loop.md'),
                         'scope': 'Finish green local V91 merge and verified cleanup, then stop. No V92, push or deployment.'}
check(automation['status'] == 'PAUSED' and automation['kind'] == 'heartbeat', 'heartbeat remains paused')
check(git('branch', '--show-current').decode().strip() == 'feat/v91-recovery-and-mobile-clarity', 'V91 task branch')
packaging = js(REVIEW / 'sparse-recipe-audit/patch-packaging.json')
patch_raw = (REVIEW / 'sparse-recipe-audit' / packaging['archive']).read_bytes()
patch_decoded = gzip.decompress(patch_raw)
check(patch_raw[4:8] == bytes(4) and sha(patch_raw) == packaging['archive_sha256']
      and sha(patch_decoded) == packaging['decoded_sha256']
      and len(patch_raw) == packaging['archive_bytes'] and len(patch_decoded) == packaging['decoded_bytes'], 'raw patch lossless gzip packaging')
old_final = js(REVIEW / 'pre-packaging-input-freeze.json')
logical_patch = str((REVIEW / 'sparse-recipe-audit' / packaging['logical_name']).relative_to(WT))
check({p for p, value in old_final.items() if final.get(p) != value} == {logical_patch}, 'packaging only removed logical patch from freeze')
check(old_final[logical_patch] == packaging['decoded_sha256'], 'packaging bytes equal old2067 freeze')
check(all(p.startswith('docs/reviews/') for p in set(final) - set(old_final)), 'packaging new frozen inputs review-only')
old_manifest = js(REVIEW / 'pre-packaging-manifest.json')
check(sum(len(v) for v in old_manifest.values() if isinstance(v, dict)) == 475, 'preserved old475 ledger')
check(old_manifest['review_files'][logical_patch] == packaging['decoded_sha256'], 'packaging bytes equal old475 ledger')
OUT['patch_packaging'] = {**packaging, 'preserved_old_freeze_count': len(old_final),
                          'preserved_old_manifest_sha256': digest(REVIEW / 'pre-packaging-manifest.json'),
                          'new_review_freeze_inputs': len(set(final) - set(old_final))}
all_paths = set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
current_source_paths = {p for p in all_paths if (WT / p).is_file() and '/web/static/' not in p and
                        (p.startswith(('cat_de_roman_esti/', 'tests/', 'scripts/', 'frontend/')) or
                         p in ('pyproject.toml', 'constraints.txt', 'docs/CRITIQUE_RUBRIC.md'))}
check(not (current_source_paths - set(final)), 'all current source/test/data paths in final freeze')
OUT['source_coverage'] = {'current_source_paths': len(current_source_paths), 'unbound_source_paths': sorted(current_source_paths - set(final))}

OUT['verdict'] = 'accept' if not OUT['errors'] else 'reject'
OUT['runner_sha256'] = digest(Path(__file__))
(SCRATCH / 'receipt.json').write_text(json.dumps(OUT, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verdict': OUT['verdict'], 'errors': OUT['errors'], 'ledger_bindings': len(all_bindings),
                  'final_freeze': len(final), 'green_gates': len(OUT['gates']), 'browser_passes': len(browser_lines)}, indent=2))
raise SystemExit(0 if not OUT['errors'] else 1)
