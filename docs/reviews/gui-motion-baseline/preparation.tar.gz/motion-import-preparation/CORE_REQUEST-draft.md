Valid until: core/parent reviews and resolves the placement request — then replace this draft with the actual decision and integration evidence.

# CORE_REQUEST draft — motion runtime witness placement

DRAFT (REQ number unassigned) | blocking yes, for named-gate import/target qualification | app-local shim: none proposed | The prototype combines host Docker inspection and Playwright execution in one process, but the pinned runner has no Docker CLI/socket and the app has no host-published port.

Status: UNRESOLVED. Scratch draft only; not registered in roedu-ui/consumer CORE_REQUESTS.md, no ADR number or core ownership has been claimed. No bridge, socket mount, published port or wrapper bypass is implemented.

## Evidence and consequence

Canonical plan commit954088c9179412206ba97cd0e026c25737ccee85:
- pack/bootstrap/compose.gate.yml:11–21 mounts source/caches in runner; no Docker socket.
- :4 explicitly has no published host ports; :40 uses GATE_APP_URL=http://app:8080; :65–84 defines the private app service.
- pack/bootstrap/Dockerfile.toolchain:23–29 installs build/PG tools; the planned runner does not supply the host Docker CLI/socket.

Scratch prototype:
- io.mjs:102 calls inspectLiveContainer during preflight; :156–163 executes host Docker through unix:///var/run/docker.sock and resolves app from that process's network namespace.
- launch.mjs:19–20 launches Playwright in the same process/placement.

Copying this prototype into the compose runner fails runtime inspection. Running it wholly on the host loses the planned pinned-runner execution and cannot assume private app DNS/port access. Prototype portability to the named gate is therefore NOT_QUALIFIED and blocking. Host-side scoped Docker access proven elsewhere does not remove the runner/network placement gap.

## Bounded requested core capability

Provide a reviewed core-owned host-wrapper witness and scoped runner adapter, or another reviewed placement compatible with the private compose network and pinned runner. The host wrapper should own ephemeral compose lifecycle/inspection; Playwright should remain in the pinned runner.

Proposed provenance boundary, for core review:
1. Host wrapper selects only the current worktree's compose project/app/runner identities. Collect only public identity/network fields before and after the run: compose project/service, container IDs, running state, produced/running image IDs, toolchain image ID, shared network ID/alias/app IP, approved SHA/tree/source-set/assets/version-lock/harness/inventory digests.
2. Issue one fresh run nonce and descriptor digest. Deliver a bounded, versioned witness to the runner through the existing reviewed gate artifact/mount path, with trusted hash/producer provenance. A loose editable attestation file alone must not establish live identity.
3. Runner verifies the same descriptor and source/build digests, records its actual Node/package/browser identity and app DNS observation in its own namespace, and witnesses data-ui and full-origin served assets. Keep exact inventory/argv/config/media checks.
4. Host wrapper finalizes only after an exact successful runner exit and fresh complete receipt, re-inspects the same ephemeral identities, rejects drift/nonce/filter/profile mismatches, and ties both sides into result.json. Missing inspection/provenance is a red required check, never a skip.

Acceptance evidence, proposed only: one permitted end-to-end host-wrapper/pinned-runner/private-app integration run, before/after identity binding, preserved gate-lane inventory, and adversarial rejection of stale/forged/substituted host or runner witness. Retain fixed trust/protected-path rules. No source-mutant execution can be inferred.

No Docker socket exposure/mount, new generic host RPC/service, host-port publication, host-only Playwright fallback or weakened binding check is authorized as a workaround.

## Current scope and next owner action

69 Node guard/model checks passed;48 future browser cases remain unexecuted/unqualified. Original29 preview cases, three executed oracle controls and six unexecuted source variants retain their original scope.

Core/parent should decide the compatible placement and witness schema before the importer is used at S1. After review, register a real CORE_REQUEST number and supply the appropriate core pin/adapted prompt. This worker has only documented the requirement; it has not implemented a bridge or run a named gate.
