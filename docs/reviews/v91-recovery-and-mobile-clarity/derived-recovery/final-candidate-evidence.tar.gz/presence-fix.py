from pathlib import Path
root=Path('/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity')
for name in ['Intrusul','Perechi']:
 p=root/f'frontend/src/screens/{name}.tsx';s=p.read_text().replace('useCallback, useEffect, useMemo','useCallback, useEffect, useLayoutEffect, useMemo').replace('import { AnimatePresence, m }','import { AnimatePresence, m, useIsPresent }')
 s=s.replace('  const active = useActiveGame(GAME_KEY);','  const active = useActiveGame(GAME_KEY);\n  const isPresent = useIsPresent();',1)
 marker='  useEffect(() => () => actionOwner.invalidate(), [actionOwner]);'
 effect='''
  useLayoutEffect(() => {
    if (!isPresent) {
      actionOwner.invalidate();
'''+('      pendingFocus.current = null;\n      focusedTileBeforeMutation.current = null;\n' if name=='Perechi' else '')+'''    }
  }, [actionOwner, isPresent]);'''
 if name=='Perechi':
  marker='  const focusedTileBeforeMutation = useRef<string | null>(null);'
 s=s.replace(marker,marker+effect,1)
 s=s.replace('const actionsLocked = loading || busy || actionSync !== null;','const actionsLocked = !isPresent || loading || busy || actionSync !== null;')
 s=s.replace('      if (!acquireFlight(startInFlight)) return;','      if (!isPresent) return;\n      if (!acquireFlight(startInFlight)) return;',1)
 s=s.replace('[active, actionOwner, cancelResume, dismissRecovery]','[active, actionOwner, cancelResume, dismissRecovery, isPresent]')
 s=s.replace('if (!state || !finished || state.score === undefined) return;','if (!isPresent || !state || !finished || state.score === undefined) return;')
 s=s.replace('[active, finished, puzzleKey, recordOnce, state]','[active, finished, isPresent, puzzleKey, recordOnce, state]')
 # Only beginAction uses this indented guard; exit uses its own four-space block.
 s=s.replace('    if (startInFlight.current) return null;','    if (!isPresent || startInFlight.current) return null;',1)
 start=s.index('  const beginAction = ');end=s.index('  const mayAdoptAction = ',start)
 s=s[:start]+s[start:end].replace('}, [actionOwner]);','}, [actionOwner, isPresent]);')+s[end:]
 s=s.replace('    if (!state || busy || !actionSync) return;','    if (!isPresent || !state || busy || !actionSync) return;',1)
 s=s.replace('[state, busy, actionSync, actionOwner, beginAction, reconcile, retryResume]','[state, busy, actionSync, actionOwner, beginAction, isPresent, reconcile, retryResume]')
 s=s.replace('onClick={() => void retryActionSync()} disabled={busy}','onClick={() => void retryActionSync()} disabled={busy || !isPresent}')
 p.write_text(s)
