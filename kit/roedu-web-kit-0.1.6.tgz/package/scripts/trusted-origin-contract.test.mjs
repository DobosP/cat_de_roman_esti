// Synthetic NON-RELEASE shell/retention contracts; never app, browser or image qualification.
import assert from 'node:assert/strict';
import { test } from 'node:test';
import * as fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';

const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const root = process.cwd();
assert.equal(process.platform, 'linux');
assert.equal(root, '/work');
assert.equal(fs.realpathSync(root), root);
function regular(relative) {
  let current = root;
  const parts = relative.split('/');
  for (const [i, part] of parts.entries()) {
    assert(part && part !== '.' && part !== '..'); current = path.join(current, part);
    const st = fs.lstatSync(current); assert(!st.isSymbolicLink());
    assert(i === parts.length - 1 ? st.isFile() : st.isDirectory());
  }
  return current;
}
const descriptorRaw = fs.readFileSync(regular('.gate/wrapper-current.json'));
const descriptor = JSON.parse(descriptorRaw);
assert.equal(descriptor.schema, 1);
assert(['unit', 'full'].includes(descriptor.target));
assert(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(descriptor.invocation));
assert(/^[0-9a-f]{40}$/.test(descriptor.sha));
assert(/^[0-9a-f]{64}$/.test(descriptor.tree_sha256));
assert(/^sha256:[0-9a-f]{64}$/.test(descriptor.toolchain_digest));
assert.equal(descriptor.sha, process.env.GATE_SHA);
assert.equal(descriptor.tree_sha256, process.env.GATE_TREE_SHA256);
assert.equal(descriptor.toolchain_digest, process.env.TOOLCHAIN_DIGEST);
assert.equal(descriptor.config_path, `.gate/${descriptor.target}/wrapper-kit-config.json`);
assert(fs.readFileSync(regular(`.gate/${descriptor.target}/wrapper-current.json`)).equals(descriptorRaw));
const configRaw = fs.readFileSync(regular(descriptor.config_path));
assert.equal(hash(configRaw), descriptor.config_file_sha256);
const captured = JSON.parse(configRaw);
for (const key of ['target', 'sha', 'tree_sha256', 'toolchain_digest', 'config_sha256']) assert.equal(captured[key], descriptor[key]);
assert.equal(hash(JSON.stringify(captured.config)), descriptor.config_sha256);
const wrapper = fs.readFileSync(regular('scripts/gate.sh'), 'utf8');
const begin = '# TRUSTED_ORIGIN_FUNCTIONS_BEGIN\n', end = '# TRUSTED_ORIGIN_FUNCTIONS_END';
assert.equal(wrapper.split(begin).length, 2); assert.equal(wrapper.split(end).length, 2);
const functions = wrapper.slice(wrapper.indexOf(begin) + begin.length, wrapper.indexOf(end));
const container = 'a'.repeat(64), image = `sha256:${'b'.repeat(64)}`;
function shell(body, options = {}) {
  const output = spawnSync('bash', ['--noprofile', '--norc', '-s'], {
    cwd: options.cwd ?? root, env: { ...process.env, ...options.env },
    input: `set -euo pipefail\n${functions}\n${body}\n`, encoding: 'utf8', maxBuffer: 1024 * 1024,
  });
  assert(!output.error, output.error?.message);
  return output;
}
function stubs({ current = container, actualImage = image, running = 'true', composeRC = 0, inspectRC = 0 } = {}) {
  // In-memory command doubles intentionally bypass the real 15s external observation launcher.
  // They exercise guard decisions only; native Docker/Compose/timeout are NOT established.
  return `runtime_observation() { "$@"; }\nfixture_compose() { [ "$*" = '--profile full ps -q app' ] || return 91; printf '%s' '${current}'; return ${composeRC}; }\nMDC=(fixture_compose)\ndocker() { [ "$1" = inspect ] && [ "$2" = -f ] && [ "$3" = '{{.Image}} {{.State.Running}}' ] && [ "$4" = '${container}' ] || return 92; printf '%s' '${actualImage} ${running}'; return ${inspectRC}; }\n`;
}
function guard(options, expectedContainer = container, expectedImage = image) {
  return shell(`${stubs(options)}verify_app_container '${expectedContainer}' '${expectedImage}'`);
}

test('root and shipped controls preserve exact bytes; no public flags or environment input added', () => {
  for (const file of ['gate.sh', 'compose.gate.yml']) {
    const rootFile = file === 'gate.sh' ? 'scripts/gate.sh' : file;
    assert(fs.readFileSync(regular(rootFile)).equals(fs.readFileSync(regular(`web-kit/templates/${file}`))));
  }
  // Runtime topology/browser proofs are separately required; these are source-owner bindings only.
  assert(wrapper.includes('GATE_APP_URL=http://localhost:8080'));
  assert(wrapper.includes('--profile unit run --no-deps --rm -T --user "$(id -u):$(id -g)" runner node'));
});
test('actual Bash router admits only fixed unit/full services', () => {
  for (const [profile, expected] of [['unit', 'runner'], ['full', 'runner-full']]) {
    const result = shell(`runner_service '${profile}'`); assert.equal(result.status, 0, result.stderr); assert.equal(result.stdout, `${expected}\n`);
  }
  for (const profile of ['', 'baseline', 'host', 'full extra']) assert.notEqual(shell(`runner_service '${profile}'`).status, 0);
});
test('same actual fixture container and immutable running image pass the extracted guard', () => {
  assert.equal(guard({}).status, 0);
});
test('unit post-task guard keeps the original rc without querying app association', () => {
  const result = shell('MDC=(false); docker() { return 99; }; profile=unit; running_container=not-an-app; rc=7; stage=task; check_app_after_task; [ "$rc" = 7 ] && [ "$stage" = task ]');
  assert.equal(result.status, 0, result.stderr);
});
test('same-image recreation, wrong image, stopped app and missing or multiple service IDs refuse', () => {
  for (const options of [{ current: 'c'.repeat(64) }, { actualImage: `sha256:${'c'.repeat(64)}` }, { running: 'false' }, { current: '' }, { current: `${container}\n${container}` }, { composeRC: 7 }, { inspectRC: 9 }]) assert.notEqual(guard(options).status, 0);
  for (const value of ['', 'a'.repeat(63), `${container} `, `${container}\n${container}`]) assert.notEqual(guard({}, value).status, 0);
  assert.notEqual(guard({}, container, 'sha256:wrong').status, 0);
});

// Physical probes stay outside .gate/{unit,full}; only regular lossless evidence is returned.
// This is synthetic NON-RELEASE data, not an app/native qualification receipt.
const uid = process.getuid();
function safeDirectory(absolute, privateMode = false) {
  assert.equal(fs.realpathSync(root), root);
  const relative = path.relative(root, absolute);
  assert(relative && !relative.startsWith('..') && !path.isAbsolute(relative));
  let current = root;
  for (const part of relative.split(path.sep)) {
    assert(part && part !== '.' && part !== '..'); current = path.join(current, part);
    const st = fs.lstatSync(current);
    assert(st.isDirectory() && !st.isSymbolicLink() && st.uid === uid);
    // The actual wrapper owns these ordinary shared-mode directories. Only
    // fixture keepers/cases require private modes; no existing mode is changed.
    if (current === path.join(root, '.gate') || current === path.join(root, '.gate', descriptor.target)) {
      assert.equal(st.mode & 0o002, 0, 'world-writable wrapper evidence ancestor');
    } else {
      assert.equal(st.mode & 0o7777, 0o700, 'private evidence ancestor must be0700');
    }
  }
  assert.equal(fs.realpathSync(absolute), absolute);
  const before = fs.lstatSync(absolute);
  if (privateMode) assert.equal(before.mode & 0o7777, 0o700);
  const fd = fs.openSync(absolute, fs.constants.O_RDONLY | fs.constants.O_DIRECTORY | fs.constants.O_NOFOLLOW);
  const opened = fs.fstatSync(fd);
  assert.equal(opened.dev, before.dev); assert.equal(opened.ino, before.ino);
  return fd;
}
function privateChild(parent, name, allowExisting = false) {
  assert(name === '.gate' || /^[a-zA-Z0-9-]+$/.test(name));
  const fd = safeDirectory(parent);
  try {
    try { fs.mkdirSync(`/proc/self/fd/${fd}/${name}`, { mode: 0o700 }); }
    catch (error) { if (!allowExisting || error.code !== 'EEXIST') throw error; }
    const child = path.join(parent, name), check = safeDirectory(child, true); fs.closeSync(check);
    return child;
  } finally { fs.closeSync(fd); }
}
function writeExclusive(directory, name, raw) {
  assert(/^[a-zA-Z0-9.-]+$/.test(name) && !['.', '..'].includes(name));
  const parent = safeDirectory(directory);
  try {
    const fd = fs.openSync(`/proc/self/fd/${parent}/${name}`, fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | fs.constants.O_NOFOLLOW, 0o600);
    try { assert(fs.fstatSync(fd).isFile()); fs.writeFileSync(fd, raw); fs.fsyncSync(fd); }
    finally { fs.closeSync(fd); }
    fs.fsyncSync(parent);
  } finally { fs.closeSync(parent); }
}
function currentContext() {
  assert(fs.readFileSync(regular('.gate/wrapper-current.json')).equals(descriptorRaw));
  assert(fs.readFileSync(regular(`.gate/${descriptor.target}/wrapper-current.json`)).equals(descriptorRaw));
  assert(fs.readFileSync(regular(descriptor.config_path)).equals(configRaw));
  return {
    label: 'synthetic NON-RELEASE fixture association only',
    invocation: descriptor.invocation, target: descriptor.target, sha: descriptor.sha,
    tree_sha256: descriptor.tree_sha256, toolchain_digest: descriptor.toolchain_digest,
    config_sha256: descriptor.config_sha256, config_file_sha256: descriptor.config_file_sha256,
    descriptor_sha256: hash(descriptorRaw), descriptor_raw_base64: descriptorRaw.toString('base64'),
    config_raw_base64: configRaw.toString('base64'),
  };
}
function snapshotCase(local) {
  const entries = [];
  function walk(absolute, relative = '.') {
    const st = fs.lstatSync(absolute);
    if (st.isSymbolicLink()) {
      const text = fs.readlinkSync(absolute), after = fs.lstatSync(absolute);
      assert.equal(after.dev, st.dev); assert.equal(after.ino, st.ino);
      entries.push({ path: relative, type: 'link', mode: st.mode & 0o7777, text });
    } else if (st.isDirectory()) {
      const fd = fs.openSync(absolute, fs.constants.O_RDONLY | fs.constants.O_DIRECTORY | fs.constants.O_NOFOLLOW);
      try {
        const before = fs.fstatSync(fd); assert.equal(before.dev, st.dev); assert.equal(before.ino, st.ino);
        entries.push({ path: relative, type: 'directory', mode: st.mode & 0o7777 });
        for (const name of fs.readdirSync(`/proc/self/fd/${fd}`).sort()) {
          assert(name && !['.', '..'].includes(name));
          walk(`/proc/self/fd/${fd}/${name}`, relative === '.' ? name : `${relative}/${name}`);
        }
        const after = fs.fstatSync(fd);
        for (const key of ['dev', 'ino', 'mode', 'mtimeMs', 'ctimeMs']) assert.equal(after[key], before[key]);
      } finally { fs.closeSync(fd); }
    } else {
      assert(st.isFile());
      const fd = fs.openSync(absolute, fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW);
      try {
        const before = fs.fstatSync(fd); assert(before.isFile());
        assert.equal(before.dev, st.dev); assert.equal(before.ino, st.ino);
        const raw = fs.readFileSync(fd), after = fs.fstatSync(fd);
        for (const key of ['dev', 'ino', 'size', 'mode', 'mtimeMs', 'ctimeMs']) assert.equal(after[key], before[key]);
        assert.equal(raw.length, st.size);
        entries.push({ path: relative, type: 'file', mode: st.mode & 0o7777, bytes: raw.length, sha256: hash(raw), raw_base64: raw.toString('base64') });
      } finally { fs.closeSync(fd); }
    }
  }
  walk(local); return entries;
}
function noTargetLinks() {
  const target = path.join(root, '.gate', descriptor.target);
  const fd = safeDirectory(target); fs.closeSync(fd);
  function walk(absolute) {
    const st = fs.lstatSync(absolute); assert(!st.isSymbolicLink(), 'unchanged wrapper target symlink guard would refuse');
    if (st.isDirectory()) for (const name of fs.readdirSync(absolute)) walk(path.join(absolute, name));
    else assert(st.isFile());
  }
  walk(target);
}
let fixtureRoot, runId;
const cases = new Map();
function retainCase(local, label = 'final') {
  assert(['input', 'final'].includes(label));
  const context = currentContext(), entries = snapshotCase(local);
  const raw = Buffer.from(`${JSON.stringify({ schema: 1, synthetic: 'NON-RELEASE', context, physical_root: local, entries }, null, 2)}\n`);
  const key = `${local}/${label}`, old = cases.get(key);
  if (old) {
    assert(raw.equals(old.raw), 'physical case changed after regular snapshot');
    assert(fs.readFileSync(regular(old.archive_relative)).equals(raw));
    noTargetLinks(); return old;
  }
  const target = path.join(root, '.gate', descriptor.target), stem = `trusted-origin-${runId}-${path.basename(local)}-${label}`;
  const inventory = Buffer.from(`${JSON.stringify({ schema: 1, synthetic: 'NON-RELEASE', context, physical_root: local, entries: entries.map(({ raw_base64, ...entry }) => entry) }, null, 2)}\n`);
  const reference = Buffer.from(`${JSON.stringify({ schema: 1, synthetic: 'NON-RELEASE', context, physical_root: local, physical_keeper: fixtureRoot, archive: `${stem}.archive.json`, archive_sha256: hash(raw), inventory: `${stem}.inventory.json`, inventory_sha256: hash(inventory), manual_preservation: 'Capture entire mirror ROOT/target/context and physical keeper before EVERY --fresh/reset; target rsync does not return physical keeper' }, null, 2)}\n`);
  writeExclusive(target, `${stem}.archive.json`, raw);
  writeExclusive(target, `${stem}.inventory.json`, inventory);
  writeExclusive(target, `${stem}.physical-ref.json`, reference);
  const record = { raw, entries, archive_relative: `.gate/${descriptor.target}/${stem}.archive.json`, inventory_relative: `.gate/${descriptor.target}/${stem}.inventory.json`, reference_relative: `.gate/${descriptor.target}/${stem}.physical-ref.json` };
  cases.set(key, record); noTargetLinks();
  console.log(`NON-RELEASE physical keeper ${fixtureRoot}; regular archive ${record.archive_relative}; capture whole mirror ROOT/target/context/keeper BEFORE EVERY RESET`);
  return record;
}
function fixture(t, { gate = true } = {}) {
  currentContext();
  if (!fixtureRoot) {
    const gateParent = path.join(root, '.gate');
    const parent = privateChild(gateParent, 'trusted-origin-physical', true);
    runId = randomUUID(); fixtureRoot = privateChild(parent, runId);
  }
  const local = privateChild(fixtureRoot, `case-${randomUUID()}`);
  // Register before any case contents/assertions; failure fixtures are never removed.
  t.after(() => retainCase(local));
  if (gate) { const gateDirectory = privateChild(local, '.gate'); privateChild(gateDirectory, 'full'); }
  return local;
}
const rawResult = Buffer.from('{"status":"pass","synthetic":"NON-RELEASE; not application evidence"}\n');
test('runtime mismatch quarantines exact raw bytes and retains original failed task rc', t => {
  const local = fixture(t), result = path.join(local, '.gate/full/result.json'); fs.writeFileSync(result, rawResult);
  retainCase(local, 'input');
  const actual = shell(`${stubs({ current: 'c'.repeat(64) })}profile=full; running_container=${container}; GATE_APP_IMAGE_ID=${image}; tdir=full; sha=${'d'.repeat(40)}; GATE_TREE_SHA256=${'e'.repeat(64)}; rc=7; stage=task; check_app_after_task; [ "$rc" = 2 ] && [ "$stage" = runtime-app-changed ]`, { cwd: local });
  assert.equal(actual.status, 0, actual.stderr); assert(!fs.existsSync(result));
  assert(fs.readFileSync(path.join(local, '.gate/full/runtime-rejected-result.json')).equals(rawResult));
  const rejection = JSON.parse(fs.readFileSync(path.join(local, '.gate/full/wrapper-fail.json')));
  assert.equal(rejection.status, 'fail'); assert.equal(rejection.primary_rc, 7); assert.equal(rejection.retention, 'retained');
});
test('successful association retains failed task result unchanged', t => {
  const local = fixture(t), result = path.join(local, '.gate/full/result.json'); fs.writeFileSync(result, rawResult);
  retainCase(local, 'input');
  const actual = shell(`${stubs()}profile=full; running_container=${container}; GATE_APP_IMAGE_ID=${image}; tdir=full; rc=7; stage=task; check_app_after_task; [ "$rc" = 7 ]`, { cwd: local });
  assert.equal(actual.status, 0, actual.stderr); assert(fs.readFileSync(result).equals(rawResult));
});
test('existing diagnostic collision never overwrites historical bytes or leaves result authority', t => {
  const local = fixture(t), directory = path.join(local, '.gate/full'); fs.writeFileSync(path.join(directory, 'result.json'), rawResult);
  const canary = Buffer.from('existing NON-RELEASE diagnostic'); fs.writeFileSync(path.join(directory, 'runtime-rejected-result.json'), canary);
  retainCase(local, 'input');
  const actual = shell('tdir=full; retain_rejected_app_result', { cwd: local });
  assert.notEqual(actual.status, 0); assert(fs.readFileSync(path.join(directory, 'runtime-rejected-result.json')).equals(canary)); assert(!fs.existsSync(path.join(directory, 'result.json')));
  fs.writeFileSync(path.join(directory, 'result.json'), rawResult, { flag: 'wx' });
  const rejected = shell(`${stubs({ current: 'c'.repeat(64) })}profile=full; running_container=${container}; GATE_APP_IMAGE_ID=${image}; tdir=full; sha=${'d'.repeat(40)}; GATE_TREE_SHA256=${'e'.repeat(64)}; rc=7; stage=task; check_app_after_task; [ "$rc" = 2 ]`, { cwd: local });
  assert.equal(rejected.status, 0, rejected.stderr);
  const failure = JSON.parse(fs.readFileSync(path.join(directory, 'wrapper-fail.json')));
  assert.equal(failure.status, 'fail'); assert.equal(failure.primary_rc, 7); assert.equal(failure.retention, 'failed');
  assert(fs.readFileSync(path.join(directory, 'runtime-rejected-result.json')).equals(canary)); assert(!fs.existsSync(path.join(directory, 'result.json')));
});
test('symlink destination cannot change its confined sibling canary', t => {
  const local = fixture(t), directory = path.join(local, '.gate/full'), canary = path.join(local, 'canary');
  fs.writeFileSync(canary, 'NON-RELEASE unchanged canary'); fs.writeFileSync(path.join(directory, 'result.json'), rawResult);
  fs.symlinkSync('../../canary', path.join(directory, 'runtime-rejected-result.json'));
  retainCase(local, 'input');
  const actual = shell('tdir=full; retain_rejected_app_result', { cwd: local });
  assert.notEqual(actual.status, 0); assert.equal(fs.readFileSync(canary, 'utf8'), 'NON-RELEASE unchanged canary'); assert(!fs.existsSync(path.join(directory, 'result.json')));
});
test('nonregular source refuses without following its confined link', t => {
  const local = fixture(t), directory = path.join(local, '.gate/full'), canary = path.join(local, 'canary'); fs.writeFileSync(canary, 'NON-RELEASE unchanged source');
  fs.symlinkSync('../../canary', path.join(directory, 'result.json'));
  retainCase(local, 'input');
  const actual = shell('tdir=full; retain_rejected_app_result', { cwd: local });
  assert.notEqual(actual.status, 0); assert.equal(fs.readFileSync(canary, 'utf8'), 'NON-RELEASE unchanged source'); assert(!fs.existsSync(path.join(directory, 'result.json')));
});
test('missing result records absent rather than retained or a fabricated raw diagnostic', t => {
  const local = fixture(t), directory = path.join(local, '.gate/full');
  retainCase(local, 'input');
  const absent = shell('tdir=full; retain_rejected_app_result', { cwd: local });
  assert.equal(absent.status, 0, absent.stderr); assert.equal(absent.stdout, 'absent\n');
  const actual = shell(`${stubs({ current: 'c'.repeat(64) })}profile=full; running_container=${container}; GATE_APP_IMAGE_ID=${image}; tdir=full; sha=${'d'.repeat(40)}; GATE_TREE_SHA256=${'e'.repeat(64)}; rc=7; stage=task; check_app_after_task; [ "$rc" = 2 ]`, { cwd: local });
  assert.equal(actual.status, 0, actual.stderr);
  const rejection = JSON.parse(fs.readFileSync(path.join(directory, 'wrapper-fail.json')));
  assert.equal(rejection.status, 'fail'); assert.equal(rejection.primary_rc, 7); assert.equal(rejection.retention, 'absent');
  assert(!fs.existsSync(path.join(directory, 'runtime-rejected-result.json'))); assert(!fs.existsSync(path.join(directory, 'result.json')));
});
test('actual evidence ancestor symlinks refuse without changing confined sibling result bytes', t => {
  for (const layer of ['gate', 'target']) {
    const local = fixture(t, { gate: false }), referent = privateChild(local, 'actual-evidence');
    if (layer === 'gate') { privateChild(referent, 'full'); fs.symlinkSync('actual-evidence', path.join(local, '.gate')); }
    else { privateChild(local, '.gate'); fs.symlinkSync('../actual-evidence', path.join(local, '.gate/full')); }
    const directory = layer === 'gate' ? path.join(referent, 'full') : referent;
    fs.writeFileSync(path.join(directory, 'result.json'), rawResult);
    retainCase(local, 'input');
    const actual = shell('tdir=full; retain_rejected_app_result', { cwd: local });
    assert.notEqual(actual.status, 0); assert(fs.readFileSync(path.join(directory, 'result.json')).equals(rawResult));
    assert(!fs.existsSync(path.join(directory, 'runtime-rejected-result.json')));
    assert(fs.lstatSync(layer === 'gate' ? path.join(local, '.gate') : path.join(local, '.gate/full')).isSymbolicLink());
  }
});
test('physical links survive outside target while regular lossless evidence passes unchanged symlink guard', t => {
  const local = fixture(t), canary = path.join(local, 'canary'), probe = path.join(local, 'probe');
  // A fixture-local .gate/full is not either actual wrapper-owned ancestor.
  // Change only this fresh owned directory through its verified no-follow FD.
  const privateTarget = path.join(local, '.gate/full'), privateFD = safeDirectory(privateTarget, true);
  try {
    fs.fchmodSync(privateFD, 0o775);
    assert.throws(() => writeExclusive(privateTarget, 'must-not-publish.json', rawResult), /private evidence ancestor must be0700/);
    assert(!fs.existsSync(path.join(privateTarget, 'must-not-publish.json')));
  } finally {
    fs.fchmodSync(privateFD, 0o700); fs.closeSync(privateFD);
  }
  const bytes = Buffer.from([0, 255, 10, 128, 65]); fs.writeFileSync(canary, bytes, { mode: 0o640 }); fs.symlinkSync('canary', probe);
  const kept = retainCase(local); noTargetLinks();
  const scan = spawnSync('find', [`.gate/${descriptor.target}`, '-type', 'l', '-print', '-quit'], { cwd: root, encoding: 'utf8' });
  assert(!scan.error, scan.error?.message); assert.equal(scan.status, 0, scan.stderr); assert.equal(scan.stdout, '');
  assert(fs.lstatSync(probe).isSymbolicLink()); assert.equal(fs.readlinkSync(probe), 'canary'); assert(fs.readFileSync(canary).equals(bytes));
  const archive = JSON.parse(fs.readFileSync(regular(kept.archive_relative)));
  const file = archive.entries.find(row => row.path === 'canary'), link = archive.entries.find(row => row.path === 'probe');
  assert(Buffer.from(file.raw_base64, 'base64').equals(bytes)); assert.equal(file.bytes, bytes.length); assert.equal(file.sha256, hash(bytes));
  assert.equal(file.mode, fs.lstatSync(canary).mode & 0o7777); assert.equal(link.text, 'canary'); assert.equal(link.mode, fs.lstatSync(probe).mode & 0o7777);
  assert.equal(archive.context.invocation, descriptor.invocation); assert.equal(archive.context.target, descriptor.target);
  assert.equal(archive.context.sha, descriptor.sha); assert.equal(archive.context.tree_sha256, descriptor.tree_sha256);
  assert(Buffer.from(archive.context.descriptor_raw_base64, 'base64').equals(descriptorRaw));
  assert(Buffer.from(archive.context.config_raw_base64, 'base64').equals(configRaw));
  for (const relative of [kept.archive_relative, kept.inventory_relative, kept.reference_relative]) assert(fs.lstatSync(regular(relative)).isFile());
});
