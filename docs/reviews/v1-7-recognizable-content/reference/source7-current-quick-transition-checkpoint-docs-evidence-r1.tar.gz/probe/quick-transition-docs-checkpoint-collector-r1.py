import pathlib,json,hashlib,tarfile,io,datetime,time,stat,os,shutil,ctypes,sys
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"):raise RuntimeError("optimized metadata refused")
S=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7");R=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-7");D=R/"docs/reviews/v1-7-recognizable-content"
a=json.loads((S/"quick-pin-source-checkpoint-admission-r2.json").read_bytes());assert time.time()<a["deadline_epoch"]
H=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
spec=json.loads((S/"probe/native-docs-quick-transition-spec-r1.json").read_bytes())
for name,h in spec["protected"].items():assert H(name)==h
review={"kind":"root transcription of actual docs dispatch/outcome review and root owner closure","actual_reviewer":"/root/continuation_audit","dispatch_verdict":"ACCEPT_CURRENT_QUICK_TRANSITION_DOCS_DISPATCH_ONLY","dispatch_freeze_utc":"2026-10-09T16:03:39.213789Z","actual_verdict":"ACCEPT_ACTUAL_NATIVE_DOCS_QUICK_TRANSITION_CHECKPOINT_EVIDENCE_ONLY","actual_freeze_utc":"2026-10-09T16:05:16.019663Z","bound_result_sha256":"33521b0c074aa52552df565387dd02e609b0272962680f0b6355e8f4f05d408f","all1765pins_independently_fresh_verified":True,"root_CIM_tool_return":{"checked_utc":"2026-10-09T16:04:52.5592172Z","recorded_pid_numbers":[28492,4188,16080],"remaining":[]},"owner_limit":"native16080 generation bound inrawresult; parent/controller generations notdurablycaptured; currentPIDabsence andsuccessfulownershipcontrolledexit only; transientunsampledGit/sourceworkers excluded","genuine_outer_exit":0,"scope":"one currentWindowsdocs checker; noGo/game/installed/version qualification"}
p=S/"quick-pin-checkpoint-docs-review-r1.json"
with p.open("x",encoding="utf-8") as f:json.dump(review,f,indent=2);f.write("\n")
names=["probe/native-docs-quick-transition-spec-r1.json","probe/native-docs-windows-r3.py","probe/native-docs-direct-r1.py","quick-pin-source-checkpoint-admission-r2.json","quick-pin-checkpoint-docs-actual-admission-r1.json","quick-pin-checkpoint-docs-review-r1.json","quick-transition-durable-copy-receipt-r1.json","quick-five-pin-actual-review-r1.json","quick-five-pin-source-evidence-r1.json","quick-five-pin-source-evidence-r1.tar.gz","native-docs-quick-transition-checkpoint-r1/result.json","native-docs-quick-transition-checkpoint-r1/stdout.json","native-docs-quick-transition-checkpoint-r1/stderr.log","probe/quick-transition-docs-checkpoint-collector-r1.py"]
items=[(n,S/n) for n in names]+[("checkpoint/docs/STATUS.md",R/"docs/STATUS.md"),("checkpoint/README.md",D/"README.md")]
arc=S/"quick-transition-checkpoint-docs-evidence-r1.tar.gz"
with arc.open("xb") as out:
 with tarfile.open(fileobj=out,mode="w:gz") as t:
  for n,p in items:
   q=p.lstat();assert stat.S_ISREG(q.st_mode) and not stat.S_ISLNK(q.st_mode) and not q.st_file_attributes&0x400 and q.st_nlink==1
   b=p.read_bytes();x=tarfile.TarInfo(n);x.size=len(b);x.mode=0o600;t.addfile(x,io.BytesIO(b))
 out.flush();os.fsync(out.fileno())
assert arc.stat().st_size<512*1024
rows=[]
with tarfile.open(arc,"r:gz") as t:
 assert t.getnames()==[n for n,p in items]
 for x,(n,p) in zip(t,items):
  b=t.extractfile(x).read();assert x.isfile() and b==p.read_bytes();rows.append(dict(path=n,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
def count(root):
 total=files=dirs=0;pending=[pathlib.Path(root)]
 while pending:
  p=pending.pop();b=p.lstat();assert stat.S_ISDIR(b.st_mode) and not stat.S_ISLNK(b.st_mode) and not b.st_file_attributes&0x400;dirs+=1
  with os.scandir(p) as it:
   for e in it:
    q=e.stat(follow_symlinks=False);assert not stat.S_ISLNK(q.st_mode) and not q.st_file_attributes&0x400
    if stat.S_ISDIR(q.st_mode):pending.append(pathlib.Path(e.path))
    else:
     q=pathlib.Path(e.path).lstat();assert stat.S_ISREG(q.st_mode) and not stat.S_ISLNK(q.st_mode) and not q.st_file_attributes&0x400 and q.st_nlink==1
     total+=q.st_size;files+=1
  z=p.lstat();assert (b.st_dev,b.st_ino)==(z.st_dev,z.st_ino)
 return dict(bytes=total,files=files,dirs=dirs)
counts={p:count(p) for p in a["accounting_roots"]};total=sum(x["bytes"] for x in counts.values());G=1<<30
class M(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","tp","ap","tv","av","extra"]]
m=M();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
assert total-a["baseline_bytes"]+(1<<20)<=G and shutil.disk_usage(S).free-(1<<20)>=16*G and m.available>=16*G and time.time()<a["deadline_epoch"]
j={"kind":"current-isolated-Quick-transition-and-pins-native-docs-portable-evidence-v1","archive_sha256":H(arc),"archive_bytes":arc.stat().st_size,"members":rows,"all_root_raw_readback":True,"closed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"original_start_epoch":a["start_epoch"],"original_deadline_epoch":a["deadline_epoch"],"original_full4root_baseline":a["baseline_bytes"],"full4root_counts_beforemanifest":counts,"growth_beforemanifest":total-a["baseline_bytes"],"final_metadata_reserve_bytes":1<<20,"disk_free_bytes":shutil.disk_usage(S).free,"Windows_available_bytes":m.available,"source_metadata_RSS":"unmeasured","current_native_owner":False,"scope":"docs checkpoint only; Source6live/V1.7uninstalled"}
manifest=S/"quick-transition-checkpoint-docs-evidence-r1.json"
with manifest.open("x",encoding="utf-8") as f:json.dump(j,f,indent=2);f.write("\n")
for src,dst in [(S/"native-docs-quick-transition-checkpoint-r1/result.json",D/"go-source7-current-quick-transition-checkpoint-docs-results-r1.json"),(arc,D/"reference/source7-current-quick-transition-checkpoint-docs-evidence-r1.tar.gz"),(manifest,D/"go-source7-current-quick-transition-checkpoint-docs-evidence-r1.json")]:
 with dst.open("xb") as f:f.write(src.read_bytes())
 assert dst.read_bytes()==src.read_bytes()
print(json.dumps({"archive_sha256":H(arc),"archive_bytes":arc.stat().st_size,"members":len(rows),"manifest_sha256":H(manifest),"closed_utc":j["closed_utc"],"growth":j["growth_beforemanifest"]}))
