import {defineConfig} from "./test-api.mjs";
import {fileURLToPath} from "node:url";
const root=fileURLToPath(new URL("./",import.meta.url));
const port=Number(process.env.MOTION_PREVIEW_PORT||8936);
export default defineConfig({
 testDir:"./tests",outputDir:"./results/artifacts",fullyParallel:false,workers:1,retries:0,
 timeout:20000,expect:{timeout:4000},
 reporter:[["list"],["json",{outputFile:root+"results/playwright.json"}]],
 use:{baseURL:process.env.MOTION_BASE_URL||"http://127.0.0.1:"+port,locale:"ro-RO",timezoneId:"Europe/Bucharest",
  viewport:{width:1280,height:900},trace:"retain-on-failure",screenshot:"only-on-failure",
  launchOptions:process.env.MOTION_CHROMIUM_PATH?{executablePath:process.env.MOTION_CHROMIUM_PATH}:{}},
 projects:[
  {name:"motion-on",testMatch:/.*(?:presence|owned|characterization|sensitivity|replay)\.spec\.mjs/,use:{reducedMotion:"no-preference"}},
  {name:"reduce",testMatch:/.*(?:owned|reduced)\.spec\.mjs/,use:{reducedMotion:"reduce"}}
 ],
 webServer:process.env.MOTION_BASE_URL?undefined:{
  command:process.execPath+" server.mjs",cwd:root,url:"http://127.0.0.1:"+port+"/__preview_health",
  reuseExistingServer:false,timeout:10000
 }
});
