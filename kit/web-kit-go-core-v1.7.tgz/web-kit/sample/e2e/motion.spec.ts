import './diagnostics';
import { test,expect } from '../../playwright/index.mjs';
test('pw-motion actual motion-on Presence, Confetti and truthful WAAPI',async({page})=>{
  if(!process.env.GATE_APP_URL)throw Error('Live app required');
  await page.goto('/motion');
  await expect(page.locator('[data-island="stress-presence"]')).toContainText('Panel 0');
  const island=page.locator('[data-island="stress-presence"]');
  await island.getByRole('button',{name:'Replace panel'}).click();
  await expect.poll(()=>page.evaluate(()=>document.getAnimations().some(a=>(a.effect as KeyframeEffect).getKeyframes().some(k=>k.opacity!==undefined)))).toBe(true);
  // REQ-7 variant: the exiting panel is retained by its own scale/spring tracks (longer than the 180 ms default) until they settle.
  const exit=await page.evaluate(()=>document.getAnimations().filter(a=>(a.effect as KeyframeEffect).target?.classList.contains('roedu-presence')&&(a.effect as KeyframeEffect).target?.getAttribute('data-state')==='exiting').map(a=>({duration:Number(a.effect!.getComputedTiming().duration),transform:(a.effect as KeyframeEffect).getKeyframes().map(k=>k.transform).filter(Boolean)})));
  expect(exit.length).toBe(2);expect(exit.every(a=>a.duration>180)).toBe(true);expect(exit.flatMap(a=>a.transform)).toEqual(['scale(1)','scale(0.4)']);
  await expect(island.locator('[data-present="false"]')).toHaveText('Panel 0');
  await expect(island).toContainText('Panel 1');
  await expect(island.locator('[data-state="exiting"]')).toHaveCount(0);
  await island.getByRole('button',{name:'Toggle confetti'}).click();
  await expect.poll(()=>page.evaluate(()=>document.getAnimations().filter(a=>(a.effect as KeyframeEffect).target?.classList.contains('roedu-confetti-particle')).length)).toBe(12);
  await page.evaluate(async()=>{await Promise.all(document.getAnimations().map(a=>a.finished.catch(()=>{})));});
  await expect.poll(()=>page.evaluate(()=>document.getAnimations().length)).toBe(0);
  await page.emulateMedia({reducedMotion:'reduce'});
  await island.getByRole('button',{name:'Replace panel'}).click();await expect(island).toContainText('Panel 2');
  await expect.poll(()=>page.evaluate(()=>document.getAnimations().length)).toBe(0);
});
