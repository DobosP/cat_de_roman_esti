from __future__ import annotations
import dataclasses,hashlib,importlib,json,os,subprocess
from pathlib import Path
from urllib.parse import urlencode
os.environ.update(DJANGO_SETTINGS_MODULE="cat_de_roman_esti.web.settings",CAT_ACCOUNTS_ENABLED="0",CAT_DEBUG="0",ROEDU_API_URL="",ROEDU_API_KEY="")
import django
django.setup()
from django.test import Client
from cat_de_roman_esti.wordgames import contexto as C, alchimie_explore as E
from cat_de_roman_esti.wordgames.discovery_world import get_world,MAX_CONCEPTS,MAX_RECIPES,MAX_COMPATIBLE_VERSIONS,MAX_CATALOG_BYTES
from cat_de_roman_esti.wordgames.service import get_service
from tests.content_scenarios import contexto_seed
ROOT=Path.cwd();OUT=ROOT/"docs/reviews/v98-meaningful-connections";OUT.mkdir(parents=True,exist_ok=True)
BASE="240c4591f31c1b8bec59fb5680d4e66f5f0788fe"
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==BASE
files=["cat_de_roman_esti/fixtures/"+n for n in ["kg_sample.json","games_pack.json","board_rankings_v37.json","derived_catalog_v38.json","alchimie_discovery_world_v92.json","alchimie_recipe_extensions_v92.json","quick_games_v92.json"]]
files += ["cat_de_roman_esti/wordgames/"+n for n in ["service.py","contexto.py","discovery_world.py","alchimie_explore.py","lant_relations.py"]]
files += ["frontend/src/explorationSave.ts","frontend/src/components/StartFailureNotice.tsx","scripts/build_alchimie_discovery_world.py","docs/CRITIQUE_RUBRIC.md","tests/fixtures/cat_mobile_app_pack_contract.json"]
pins={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in files}
client=Client();events=[];sessions=[]
def call(method,path,data=None):
 response=getattr(client,method)(path,data or {},content_type="application/json") if method=="post" else client.get(path)
 assert response.status_code==200,(path,response.status_code,response.content[:200])
 payload=response.json();normalized=dict(payload)
 if "game_id" in normalized:normalized["game_id"]="normalized-ephemeral-session"
 events.append({"method":method.upper(),"path":path if "/games/" not in path and "/explore/" not in path else path.replace(path.split("/games/")[-1].split("/")[0],"SESSION") if "/games/" in path else path.replace(path.split("/explore/")[-1].split("/")[0],"SESSION"),"input":data,"status":200,"response":normalized})
 return payload
try:
 for game in ["alchimie","intrusul","perechi","conexiuni","contexto","lant"]:
  query={"seed":38,"difficulty":"usor"}
  if game in ["intrusul","perechi"]:query["starter"]=1
  initial=call("post",f"/api/wordgames/{game}/games?"+urlencode(query));gid=initial["game_id"];module=importlib.import_module("cat_de_roman_esti.wordgames."+game);sessions.append((module.store,gid))
  fetched=call("get",f"/api/wordgames/{game}/games/{gid}");assert fetched["game_id"]==gid
 target="n_v4via_usa";seed=contexto_seed(target,difficulty="usor",category="viata_de_roman")
 initial=call("post","/api/wordgames/contexto/games?"+urlencode({"seed":seed,"difficulty":"usor","category":"viata_de_roman"}));gid=initial["game_id"];sessions.append((C.store,gid));assert C.store.get(gid).target==target
 path=f"/api/wordgames/contexto/games/{gid}"
 accepted=call("post",path+"/guess",{"text":"casă"});assert accepted["ok"] and not accepted["won"]
 missing=[]
 for word in ["intrare","toc","toc de ușă","balama","lemn"]:
  before=call("get",path);answer=call("post",path+"/guess",{"text":word});after=call("get",path)
  assert not answer["ok"] and answer["attempts"]==before["attempts"] and after==before,word
  missing.append({"word":word,"accepted":False,"attempts_before":before["attempts"],"attempts_after":after["attempts"],"message":answer["message"]})
 won=call("post",path+"/guess",{"text":"ușă"});assert won["won"] and won["attempts"]==accepted["attempts"]+1
 world=get_world();initial=call("post","/api/alchimie/explore");gid=initial["game_id"];sessions.append((E.store,gid));session=E.store.get(gid)
 pair=next(pair for pair in world.recipes if set(pair)<=set(session.owned));crafted=call("post",f"/api/alchimie/explore/{gid}/combine",dict(zip(["a","b"],pair)));assert len(crafted["progress"]["discoveries"])==1
 fetched=call("get",f"/api/alchimie/explore/{gid}");assert fetched["progress"]==crafted["progress"]
 restored=call("post","/api/alchimie/explore",{"progress":crafted["progress"],"goal_id":crafted["goal_id"]});sessions.append((E.store,restored["game_id"]));assert restored["progress"]==crafted["progress"] and len(restored["compatible_recipe_hashes"])==9
finally:
 for store,gid in sessions:store.delete(gid)
for n,h in pins.items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h,n
svc=get_service();kg=json.loads((ROOT/files[0]).read_bytes());pack=json.loads((ROOT/files[1]).read_bytes());catalog=json.loads((ROOT/files[4]).read_bytes());door=next(n for n in kg["kg_nodes"] if n["id"]==target)
record={"date":"2026-09-23","baseline_commit":BASE,"kind":"v98-kickoff-baseline","source_sha256":pins,"requests":len(events),"sessions_cleaned":len(sessions),"response_scope":"Complete response objects with random game_id normalized; request URLs use SESSION placeholders. In-process Django BFF, not a browser or human playtest.","events":events,"door":{"node":door,"public_seed":seed,"missing_inputs":missing,"valid_control":"casă","winning_control":"ușă"},"world":{"concepts":len(catalog["concepts"]),"recipes":len(catalog["recipes"]),"histories":len(catalog["compatible_versions"]),"max_concepts":MAX_CONCEPTS,"max_recipes":MAX_RECIPES,"max_histories":MAX_COMPATIBLE_VERSIONS,"max_bytes":MAX_CATALOG_BYTES,"bytes":(ROOT/files[4]).stat().st_size},"pack_counts":pack["meta"]["counts"],"candidate_mutations":0}
(OUT/"baseline.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
print("GREEN",len(events),"fresh BFF requests;",len(sessions),"sessions deleted;5 unknown door inputs remain free; exploratory progress restores;all",len(pins),"pins unchanged")
