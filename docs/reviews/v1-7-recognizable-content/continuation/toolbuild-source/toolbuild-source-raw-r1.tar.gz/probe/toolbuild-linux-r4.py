import json,os,pathlib,signal,subprocess,sys,time,hashlib,stat as filemode
spec_bytes=pathlib.Path(sys.argv[1]).read_bytes()
expected_spec=sys.argv[2]
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"): raise RuntimeError("optimized Python refused")
if hashlib.sha256(spec_bytes).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")
spec=json.loads(spec_bytes.decode("utf-8"))
index=int(sys.argv[3]); step=spec["steps"][index]; run=pathlib.Path(spec["linux_run"])
mono_deadline=time.monotonic()+spec["deadline_epoch"]-time.time()
if spec["deadline_epoch"]-spec["started_epoch"]!=1200: raise RuntimeError("campaign duration drift")
cancel=run/"cancel"; pgid=None; child=None; initial=None; peak=0; error=None; cleanup_attempted=False; cleanup_confirmed=False
def emit(v): print(json.dumps(v,separators=(",",":")),flush=True)
def stat(pid):
 try:
  t=pathlib.Path("/proc",str(pid),"stat").read_text(); f=t[t.rfind(")")+2:].split()
  return int(f[2]),int(f[19]),int(f[21])*os.sysconf("SC_PAGE_SIZE"),f[0]
 except (FileNotFoundError,ProcessLookupError): return None
def group():
 rows=[]
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdigit(): continue
  v=stat(p.name)
  if v and (int(p.name)==os.getpid() or v[0]==pgid): rows.append((int(p.name),*v))
 return rows
def memory():
 return int(next(x.split()[1] for x in pathlib.Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))*1024
stopping=False
def interrupted(signum,frame):
 global stopping
 stopping=True
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
def spec_pin():
 if hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")
def cleanup():
 global child,pgid,initial,cleanup_attempted,cleanup_confirmed
 if cleanup_attempted:
  if cleanup_confirmed:return
  raise RuntimeError("prior cleanup uncertain; refusing repeated process-group action")
 cleanup_attempted=True
 if child is None:
  cleanup_confirmed=True
  return
 leader=stat(child.pid)
 if leader is not None and initial is not None and leader[1]!=initial[1]: raise RuntimeError("owned leader generation changed")
 if any(x[1]==pgid and x[4]!="Z" for x in group()):
  try: os.killpg(pgid,signal.SIGTERM)
  except ProcessLookupError: pass
  end=time.monotonic()+2
  while time.monotonic()<end and any(x[1]==pgid and x[4]!="Z" for x in group()): time.sleep(.05)
  if any(x[1]==pgid and x[4]!="Z" for x in group()):
   try: os.killpg(pgid,signal.SIGKILL)
   except ProcessLookupError: pass
 child.wait(timeout=5)
 if any(x[1]==pgid for x in group()): raise RuntimeError("owned group still present")
 cleanup_confirmed=True;child=None;pgid=None;initial=None

def target_and_namespace(after=False):
 root=pathlib.Path(spec["linux_stage"]);names=set();pending=[root]
 while pending:
  with os.scandir(pending.pop()) as entries:
   for entry in entries:
    info=entry.stat(follow_symlinks=False)
    if filemode.S_ISLNK(info.st_mode):raise RuntimeError("stage symlink refused: "+entry.path)
    if filemode.S_ISDIR(info.st_mode):pending.append(pathlib.Path(entry.path))
    elif filemode.S_ISREG(info.st_mode):names.add(str(pathlib.Path(entry.path).relative_to(root)))
    else:raise RuntimeError("stage nonregular refused: "+entry.path)
 assert names==set(spec["stage_files"]),"full stage namespace drift"
 assert not (root/".cat-content-ops.lock").exists(),"operator lock present"
 target=pathlib.Path(spec["linux_target"])
 assert target==root/"cat_de_roman_esti/fixtures/quick_games_v92.json"
 expected=spec["target_after_sha256"] if after else spec["target_before_sha256"]
 assert hashlib.sha256(target.read_bytes()).hexdigest()==expected,"Quick target pin drift"

try:
 spec_pin()
 assert not stopping and not cancel.exists(),"pre-admission cooperative cancel"
 target_and_namespace()
 assert hashlib.sha256(pathlib.Path("/usr/bin/python3.14").read_bytes()).hexdigest()==spec["python_sha256"]
 assert memory()>=spec["memory_floor"]
 assert time.time()<spec["deadline_epoch"]-195
 for path,digest in spec["linux_protected"].items():
  assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
 executable=pathlib.Path(step["argv"][0]); assert os.access(executable,os.X_OK),"preserved operator execute access absent"
 assert hashlib.sha256(executable.read_bytes()).hexdigest()==spec["go_sha256"]
 env=os.environ.copy()
 for name in ("GO_TELEMETRY_CHILD","GO_TELEMETRY_CHILD_UPLOAD","GOCACHEPROG"):env.pop(name,None)
 env.update({"GOMAXPROCS":"2","GOTOOLCHAIN":"local","GOPROXY":"off","GOSUMDB":"off","GOPRIVATE":"","GONOPROXY":"none","GONOSUMDB":"none","TEST_TELEMETRY_DIR":str(pathlib.Path(spec["linux_build_root"])/"telemetry"),"GOENV":"off","GOWORK":"off","CGO_ENABLED":"0","GOOS":"linux","GOARCH":"amd64","GOAMD64":"v1","GOEXPERIMENT":"","GOFLAGS":"-mod=readonly","GOROOT":spec["linux_goroot"],"GOCACHE":spec["linux_gocache"],"GOMODCACHE":spec["linux_gomodcache"],"GOPATH":spec["linux_gopath"],"GOTMPDIR":str(run/"tmp"),"TMPDIR":str(run/"tmp")})
 for key in ("linux_gocache","linux_gomodcache","linux_gopath"):
  owned=pathlib.Path(spec[key]);base=pathlib.Path(spec["linux_build_root"]);assert owned.is_relative_to(base) and owned.is_dir(),key
 assert spec["target_before_sha256"]==spec["target_after_sha256"],"build cannot alter current Quick target"
 assert (pathlib.Path(spec["linux_build_root"])/"telemetry/mode").read_bytes()==b"off 2026-10-08\n","owned Go telemetry off mode drift"
 assert executable==pathlib.Path(spec["linux_goroot"])/"bin/go","only preserved qualified Go executable"
 assert step["argv"][:4]==[str(executable),"-C",str(pathlib.Path(spec["linux_stage"])/"go-backend"),"build"]
 assert step["argv"][4:8]==["-p","2","-o",step["linux_output"]]
 assert step["argv"][8:]==["./cmd/"+step["name"]]
 assert step["name"] in ("cat-content-rail","cat-content")
 assert pathlib.Path(step["linux_output"]).parent==base/"tools" and not pathlib.Path(step["linux_output"]).exists(),"fresh owned build output"
 with (run/(step["name"]+".stdout.log")).open("wb") as out,(run/(step["name"]+".stderr.log")).open("wb") as err:
  spec_pin();assert not stopping and not cancel.exists(),"cooperative signal/cancel before launch"
  assert memory()>=spec["memory_floor"]
  assert time.monotonic()<mono_deadline-195 and time.time()<spec["deadline_epoch"]-195
  assert not stopping and not cancel.exists(),"immediate pre-Popen cancel"
  child=subprocess.Popen(step["argv"],cwd=spec["linux_stage"],env=env,stdout=out,stderr=err,start_new_session=True)
  pgid=child.pid; initial=stat(pgid); assert initial is not None
  while True:
   rows=group(); rss=sum(x[3] for x in rows); peak=max(peak,rss)
   emit({"kind":"sample","rss":rss,"peak":peak,"pid":child.pid,"start_ticks":initial[1]})
   if stopping or rss>spec["rss_cap"] or memory()<spec["memory_floor"] or cancel.exists() or (time.time()>=spec["deadline_epoch"]-180 or time.monotonic()>=mono_deadline-180): raise RuntimeError("native RSS/memory/cancel/reserve guard")
   done=os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
   if done is not None: break
   time.sleep(.25)
  assert done.si_code==os.CLD_EXITED and done.si_status==0,("command exited",done.si_code,done.si_status)
 cleanup();spec_pin();target_and_namespace(after=True)
 output=pathlib.Path(step["linux_output"]);assert output.is_file() and output.read_bytes()[:6]==b"\x7fELF\x02\x01" and output.read_bytes()[18:20]==b"\x3e\x00" and os.access(output,os.X_OK),"fresh Linux ELF output"
 emit({"kind":"build-output","step":step["name"],"output_sha256":hashlib.sha256(output.read_bytes()).hexdigest(),"output_bytes":output.stat().st_size})
 for path,digest in spec["linux_protected"].items(): assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
 assert hashlib.sha256(pathlib.Path("/usr/bin/python3.14").read_bytes()).hexdigest()==spec["python_sha256"]
 assert not stopping,"cooperative signal before completion"
 emit({"kind":"complete","step":step["name"],"returncode":0,"native_peak":peak,"group_absent":True})
except BaseException as exc:
 error=repr(exc);absent=False
 try: cleanup();absent=True
 except BaseException as cleanup_error: error+=";cleanup="+repr(cleanup_error)
 emit({"kind":"failed","step":step["name"],"error":error,"native_peak":peak,"group_absent":absent})
 sys.exit(1)

