// Build-time proof only. Motion remains the exact declared runtime dependency.
import { createHash } from 'node:crypto';
import { realpathSync } from 'node:fs';
import { relative, resolve } from 'node:path';

export const MOTION_PROOF = 'motion-consumer-proof.json';
export const motionExternal = /^motion(?:\/|$)/;
const engine = /^(.*\/node_modules\/(motion|motion-dom|motion-utils|framer-motion))(?:\/|$)/;
const require = (condition, message) => { if (!condition) throw Error(message); };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');

export function assertLibraryMotion(modules, imports) {
  require(Array.isArray(modules) && modules.length > 0 && Array.isArray(imports), 'actual library module/import graph required');
  require(['motion', 'motion/mini'].every(id => imports.includes(id)), 'published UI must retain both external Motion imports');
  require(!modules.some(id => engine.test(id)), 'published UI embeds a Motion implementation');
  require(imports.filter(id => motionExternal.test(id)).every(id => ['motion', 'motion/mini'].includes(id)), 'unexpected Motion surface in UI output');
}

export function assertConsumerMotion({ modules, rendered, entry, uiPrefix, resolutions }) {
  require(Array.isArray(modules) && Array.isArray(rendered) && resolutions?.length === 2, 'actual consumer module graph required');
  const graph = new Map(modules.map(row => [row.id, row]));
  require(graph.size === modules.length && graph.has(entry), 'unique graph and actual consumer entry required');
  require(rendered.includes(entry) && rendered.some(id => id.startsWith(uiPrefix)), 'both consumer and packed UI must survive tree shaking');
  const roots = new Map();
  for (const row of modules) {
    const match = engine.exec(row.id);
    if (match) {
      require(!row.external, 'consumer must bundle its installed Motion dependency');
      require(!roots.has(match[2]) || roots.get(match[2]) === match[1], 'consumer resolves duplicate Motion package roots');
      roots.set(match[2], match[1]);
    }
  }
  for (const [index, specifier] of ['motion', 'motion/mini'].entries()) {
    const row = resolutions[index];
    require(row.specifier === specifier && graph.has(row.id) && !graph.get(row.id).external && engine.test(row.id), 'actual installed Motion resolution required');
    require(graph.get(entry).imports.includes(row.id), 'consumer direct Motion import missing from graph');
    require(modules.some(module => module.id.startsWith(uiPrefix) && module.imports.includes(row.id)), 'packed UI does not share the consumer Motion resolution');
  }
  require(roots.has('motion') && rendered.some(id => engine.test(id)), 'actual emitted Motion implementation required');
  require(rendered.filter(id => engine.test(id)).every((id, index, ids) => ids.indexOf(id) === index), 'Motion module emitted in more than one chunk');
  return [...roots].sort(([a], [b]) => a.localeCompare(b)).map(([name, path]) => ({ name, path }));
}

export function motionLibraryBoundary() {
  return { name: 'roedu-motion-library-boundary', apply: 'build', generateBundle(_options, bundle) {
    const chunks = Object.values(bundle).filter(item => item.type === 'chunk');
    assertLibraryMotion(chunks.flatMap(item => Object.keys(item.modules)), chunks.flatMap(item => [...item.imports, ...item.dynamicImports]));
  } };
}

export function motionConsumerBoundary({ entry, uiDirectory }) {
  let root;
  return { name: 'roedu-motion-consumer-boundary', apply: 'build',
    configResolved(config) { root = realpathSync(config.root); },
    async generateBundle(_options, bundle) {
      const actualEntry = realpathSync(resolve(root, entry)), uiPrefix = realpathSync(uiDirectory) + '/';
      require(actualEntry.startsWith(root + '/') && uiPrefix.startsWith(root + '/node_modules/'), 'isolated installed consumer required');
      const modules = [...this.getModuleIds()].map(id => {
        const item = this.getModuleInfo(id); require(item, 'missing actual Vite module record');
        return { id, external: item.isExternal, imports: item.importedIds };
      });
      const resolutions = [];
      for (const specifier of ['motion', 'motion/mini']) {
        const item = await this.resolve(specifier, actualEntry);
        require(item && !item.external && realpathSync(item.id) === item.id, 'canonical installed Motion module required');
        resolutions.push({ specifier, id: item.id });
      }
      const chunks = Object.values(bundle).filter(item => item.type === 'chunk');
      const rendered = chunks.flatMap(item => Object.entries(item.modules).filter(([, data]) => data.renderedLength > 0).map(([id]) => id));
      const roots = assertConsumerMotion({ modules, rendered, entry: actualEntry, uiPrefix, resolutions });
      const local = id => relative(root, id).split('\\').join('/');
      const proof = { schema: 1, scope: 'emitted-javascript-module-graph', entry: local(actualEntry), ui_directory: local(uiDirectory),
        resolutions: resolutions.map(row => ({ ...row, id: local(row.id) })), roots: roots.map(row => ({ ...row, path: local(row.path) })),
        motion_modules: modules.filter(row => engine.test(row.id)).map(row => local(row.id)).sort(),
        rendered_motion_modules: rendered.filter(id => engine.test(id)).map(local).sort(),
        chunks: chunks.map(item => ({ path: item.fileName, bytes: Buffer.byteLength(item.code), sha256: hash(item.code) })).sort((a, b) => a.path.localeCompare(b.path)) };
      this.emitFile({ type: 'asset', fileName: MOTION_PROOF, source: JSON.stringify(proof, null, 2) + '\n' });
    },
  };
}
