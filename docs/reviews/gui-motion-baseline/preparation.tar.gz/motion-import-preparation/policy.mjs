import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {resolve,isAbsolute} from "node:path";
export const BASELINE_SHA="bb99e81333b497ac90fc78e231d88d51367538db";
export const PROFILES=new Set(["baseline-diagnostic","target-acceptance"]);
export function canonical(value){
 if(Array.isArray(value))return value.map(canonical);
 if(value&&typeof value==="object")return Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])]));
 return value;
}
export const digest=value=>createHash("sha256").update(typeof value==="string"?value:JSON.stringify(canonical(value))).digest("hex");
export const requireHash=(v,label)=>assert.match(v||"",/^[a-f0-9]{64}$/,label+" must be sha256");
export const caseId=c=>[c.project,resolve(c.file),c.title].join("|");
export function parseLaunch(argv){
 assert.equal(argv.length,3,"exactly profile, absolute binding file, reviewed binding sha256; no filters or extra flags");
 const [profile,path,sha]=argv;assert.ok(PROFILES.has(profile),"unknown or absent profile");
 assert.ok(isAbsolute(path),"binding path must be absolute");requireHash(sha,"reviewed binding digest");
 return{profile,path,sha};
}
export function rejectAmbient(env){
 const unsafe=Object.keys(env).filter(k=>/^MOTION_|^IMPORT_|^PLAYWRIGHT_|^PW_TEST_|^NODE_OPTIONS$|^NODE_PATH$|^npm_config_|^DOCKER_/i.test(k));
 assert.deepEqual(unsafe,[],"ambient runner overrides forbidden (names only): "+unsafe.join(","));
}
export function validateBinding(b,actual,profile){
 assert.equal(b.schema_version,1,"binding schema");
 assert.equal(b.profile,profile,"wrong profile");
 assert.ok(PROFILES.has(profile),"unknown profile");
 assert.equal(b.status,"READY_FOR_REVIEWED_RUN","binding is not an available reviewed run");
 for(const [key,value]of Object.entries(actual))assert.deepEqual(b[key],value,"binding drift: "+key);
 const u=new URL(b.app.base_url);
 assert.ok(["127.0.0.1","localhost","app"].includes(u.hostname),"only isolated app origins");
 assert.ok(u.protocol==="http:"&&!u.username&&!u.password&&!u.search&&!u.hash&&u.pathname==="/","origin must be isolated HTTP without credentials/path/query");
 assert.equal(b.harness.case_inventory_sha256,digest(b.inventory),"inventory binding");
 assert.equal(new Set(b.inventory.map(caseId)).size,b.inventory.length,"duplicate expected cases");
 assert.ok(b.inventory.length>0,"empty inventory");
 assert.equal(b.browser.cli_version,b.browser.test_version,"CLI/test module mismatch");
 assert.equal(b.browser.actual_version,b.browser.expected_version,"browser version drift");
 assert.equal(b.source.build_source_sha,b.source.head,"build/source HEAD mismatch");
 assert.equal(b.source.build_source_tree,b.source.tree,"build/source tree mismatch");
 if(profile==="baseline-diagnostic"){
  assert.equal(b.source.head,BASELINE_SHA,"diagnostic source must be exact frozen pin");
  assert.equal(b.app.ui,null,"frozen shell has no data-ui marker");
  assert.equal(b.build.source_reproduced,false,"do not invent diagnostic source rebuild");
  assert.equal(b.build.assets_sha256,b.build.frozen_assets_sha256,"diagnostic bytes must be canonical frozen build");
  assert.equal(b.browser.scope,"historical-preview-mismatch","diagnostic runner mismatch must stay explicit");
  assert.equal(b.browser.cli_version,"1.62.1","preserve original preview tool scope");
  assert.equal(b.browser.revision,"1243","preserve original cached browser revision scope");
  assert.equal(b.inventory.length,29,"complete original diagnostic inventory required");
 }else{
  assert.notEqual(b.source.head,BASELINE_SHA,"frozen React cannot satisfy future target");
  assert.equal(b.source.dirty,false,"target source must be clean");
  assert.equal(b.app.ui,"preact","target must serve Preact identity");
  assert.equal(b.browser.scope,"reviewed-pinned-triple","target browser must use reviewed triple");
  assert.equal(b.browser.cli_version,"1.63.0","required M0 Playwright triple");
  assert.equal(b.browser.revision,b.browser.package_revision,"browser revision/package mismatch");
  assert.ok(b.browser.actual_version.includes(b.browser.package_browser_version),"browser executable/package version mismatch");
  assert.equal(b.build.source_reproduced,true,"target requires reviewed build receipt");
  assert.equal(b.build.receipt.status,"PASS","red/unexecuted build");
  assert.equal(b.build.receipt.source_sha,b.source.head,"build receipt stale HEAD");
  assert.equal(b.build.receipt.source_tree,b.source.tree,"build receipt stale tree");
  assert.equal(b.build.receipt.assets_sha256,b.build.assets_sha256,"build receipt wrong assets");
  assert.equal(b.build.receipt.toolchain_digest,b.toolchain_digest,"build receipt toolchain mismatch");
  assert.equal(b.build.receipt.versions_lock_sha256,b.versions_lock_sha256,"build receipt versions mismatch");
  assert.match(b.core_tag||"",/^core-v\d+\.\d+$/,"reviewed core pin required");
  assert.match(b.runtime.image_digest||"",/^sha256:[a-f0-9]{64}$/,"target image digest required");
  assert.equal(b.runtime.receipt.status,"PASS","runtime attestation unavailable");
  assert.equal(b.runtime.receipt.image_digest,b.runtime.image_digest,"runtime image mismatch");
  assert.equal(b.build.receipt.image_digest,b.runtime.image_digest,"built image does not match running image");
  assertRuntimeOrigin(b.runtime,b.app);
  assert.equal(b.browser.core_version,b.browser.cli_version,"playwright-core version mismatch");
  requireHash(b.browser.package_closure_sha256,"loaded package closure");
  requireHash(b.node.executable_sha256,"actual Node executable");
  assert.equal(b.node.version,b.node.expected_version,"Node runtime/version mismatch");
  assert.equal(b.runtime.receipt.source_sha,b.source.head,"runtime source mismatch");
  assert.equal(b.runtime.receipt.assets_sha256,b.build.assets_sha256,"runtime assets mismatch");
  assert.equal(b.runtime.receipt.base_url,b.app.base_url,"runtime origin mismatch");
  assert.ok(Date.parse(b.runtime.receipt.valid_until)>Date.now(),"runtime attestation expired");
  assert.notEqual(b.build.assets_sha256,b.build.frozen_assets_sha256,"frozen assets cannot become target");
  assert.ok(b.build.entry_scripts.length>0,"no target entry scripts");
  for(const p of b.build.entry_scripts)assert.ok(!b.build.frozen_js_sha256.includes(b.build.assets[p]),"frozen JS entry cannot masquerade as target");
  assert.ok(b.inventory.every(c=>!c.title.startsWith("CHARACTERIZATION")&&!c.file.includes("characterization")),"leakage diagnostics forbidden in target");
 }
 assert.equal(b.source_mutants_executed,false,"source mutants remain unexecuted");
 return true;
}
export function assertChildSuccess(child){
 assert.ok(!child.error,"launch error");
 assert.equal(child.signal,null,"child terminated by signal");
 assert.equal(child.status,0,"child status must be exactly zero (null is failure)");
}
export function validateReceipt(report,descriptor,{child,reportMtimeMs,finishedAt}){
 assertChildSuccess(child);
 const unsigned={...descriptor};delete unsigned.descriptor_sha256;
 assert.equal(digest(unsigned),descriptor.descriptor_sha256,"receipt descriptor integrity");
 const {binding:b,run_id,descriptor_sha256,started_at}=descriptor;
 assert.ok(reportMtimeMs>=started_at&&reportMtimeMs<=finishedAt+1000,"stale receipt timestamp");
 assert.ok(Date.parse(report.stats?.startTime)>=started_at-1000,"stale receipt start time");
 assert.ok(Date.parse(report.stats.startTime)<=finishedAt,"receipt starts after completion");
 assert.equal(report.config.version,b.browser.cli_version,"reported runner version mismatch");
 assert.equal(report.config.configFile,descriptor.config_file,"config/argv identity mismatch");
 assert.equal(report.config.updateSnapshots,"none","snapshot update mode forbidden");
 assert.deepEqual(descriptor.argv,[b.node.executable,b.browser.package_root+"/cli.js","test","-c",descriptor.config_file],"exact unfiltered CLI invocation required");
 assert.equal(report.config?.forbidOnly,true,"forbidOnly must be enabled");
 assert.equal(report.config?.shard,null,"sharding forbidden");
 assert.equal(report.config?.maxFailures,0,"fail-fast truncation forbidden");
 assert.equal(report.config?.workers,1,"reviewed serial matrix required");
 assert.deepEqual((report.config.projects||[]).map(p=>p.name).sort(),["motion-on","reduce"],"exact two projects required");
 for(const p of report.config.projects){assert.equal(p.retries,0,"configured retries forbidden");assert.equal(p.repeatEach,1,"repeated/filtered executions forbidden");}
 const expected=new Map(b.inventory.map(c=>[caseId(c),c])),seen=new Set();
 const observedProjects=new Set();const rows=[];
 function walk(s,parents=[]){
  for(const spec of s.specs||[]){
   const scopes=[...parents,s.title].slice(1).filter(Boolean);
   const title=[...scopes,spec.title].join(" › ");
   for(const t of spec.tests||[]){
    const file=resolve(report.config.rootDir,spec.file);
    const id=caseId({project:t.projectName,file,title});
    assert.ok(expected.has(id),"unexpected case: "+id);assert.ok(!seen.has(id),"duplicate case: "+id);seen.add(id);observedProjects.add(t.projectName);
    assert.equal(t.expectedStatus,"passed","skip/todo/fixme/expected failure forbidden");
    assert.equal(t.results?.length,1,"exactly one execution per required case");
    assert.equal(t.status,"expected","case status");
    const result=t.results[0];assert.equal(result.status,"passed","case did not pass");
    assert.equal(result.retry,0,"retry-success forbidden");assert.equal(spec.ok,true,"spec not OK");
    assert.ok(!(t.annotations||[]).some(a=>["skip","fixme","fail","slow"].includes(a.type)),"disabled/expected-failure annotations forbidden");
    const attachment=(result.attachments||[]).filter(a=>a.name==="binding-evidence");
    assert.equal(attachment.length,1,"one fresh binding witness per case");
    const e=attachment[0].parsed;assert.ok(e,"binding evidence must be materialized by trusted receipt loader");
    assert.equal(e.run_id,run_id,"wrong/stale run ID");assert.equal(e.descriptor_sha256,descriptor_sha256,"wrong run descriptor");
    assert.equal(e.profile,b.profile,"wrong evidence profile");assert.equal(e.case_id,id,"case witness mismatch");
    assert.equal(e.source_head,b.source.head,"source witness mismatch");assert.equal(e.source_tree,b.source.tree,"tree witness mismatch");
    assert.equal(e.build_assets_sha256,b.build.assets_sha256,"build witness mismatch");
    assert.equal(e.image_digest,b.runtime.image_digest,"image witness mismatch");
    assert.equal(e.browser_version,b.browser.actual_version,"browser witness mismatch");
    assert.equal(e.ui,b.app.ui,"served UI mismatch");
    assert.equal(e.reduced,t.projectName==="reduce","actual media preference mismatch");
    assert.equal(e.selection,"complete-inventory-no-filters","filtered witness");
    assert.deepEqual(e.argv,descriptor.argv,"CLI argv witness mismatch");
    assert.deepEqual(e.effective_config,{grep:[{source:".*",flags:""}],grepInvert:null,projectGrep:[{source:".*",flags:""}],projectGrepInvert:null,updateSnapshots:"none",forbidOnly:true,retries:0,repeatEach:1,shard:null},"effective filtering/config forbidden");
    assert.equal(e.package_closure_sha256,b.browser.package_closure_sha256,"dependency closure witness mismatch");
    assert.equal(e.node_executable_sha256,b.node.executable_sha256,"actual Node witness mismatch");
    assert.ok(Array.isArray(e.served_assets)&&e.served_assets.length>0,"no served-asset identity");
    assertWebAssets(b.build.assets,b.build.entry_scripts,b.profile==="target-acceptance"?b.build.frozen_entry_js_sha256:[],e.served_assets,e.html_script_entries,new URL(b.app.base_url).origin,e.html_script_origins);
    for(const entry of b.build.entry_scripts)assert.ok(e.served_assets.some(a=>a.path===entry&&a.sha256===b.build.assets[entry]),"entry script not witnessed");
    assert.equal(e.source_mutants_executed,false,"false source-mutant claim");
    rows.push({id,profile:b.profile,passed:true});
   }
  }
  for(const nested of s.suites||[])walk(nested,[...parents,s.title]);
 }
 for(const suite of report.suites||[])walk(suite);
 assert.deepEqual([...seen].sort(),[...expected.keys()].sort(),"incomplete required case inventory");
 assert.deepEqual([...observedProjects].sort(),["motion-on","reduce"],"missing motion profile");
 const stats=report.stats;assert.equal(stats.expected,expected.size,"aggregate count mismatch");
 for(const k of ["unexpected","skipped","flaky"])assert.equal(stats[k],0,"aggregate "+k);
 assert.deepEqual(report.errors||[],[],"top-level runner errors");
 return{profile:b.profile,case_count:rows.length,scope:b.profile==="target-acceptance"?"motion-subgate-evidence-only":"diagnostic-only",formal_gate:false,source_mutants_executed:false,rows};
}

export function verifyFrozenRows(canonicalRows,manifestRows,copyHashes){
 const expected=new Map(canonicalRows.map(r=>[r.path,r.sha256]));
 assert.equal(expected.size,canonicalRows.length,"duplicate canonical paths");
 assert.equal(new Set(manifestRows.map(r=>r.path)).size,manifestRows.length,"duplicate manifest paths");
 assert.deepEqual(manifestRows.map(r=>r.path).sort(),[...expected.keys()].sort(),"canonical file membership drift");
 for(const row of manifestRows){
  assert.ok(!isAbsolute(row.path)&&!row.path.split("/").includes(".."),"manifest path escape");
  assert.equal(row.sha256,expected.get(row.path),"manifest differs from canonical Git");
  assert.equal(copyHashes[row.path],expected.get(row.path),"copy differs from canonical Git");
 }
 return true;
}

export function assertRuntimeOrigin(runtime,app){
 assert.equal(runtime.live.container_id,runtime.container_id,"live container identity mismatch");
 assert.equal(runtime.live.image_digest,runtime.image_digest,"live runtime image mismatch");
 assert.equal(runtime.live.running,true,"runtime container stopped");
 const u=new URL(app.base_url),port=u.port||"80";
 if(u.hostname==="app")assert.ok(runtime.live.network_ips.includes(runtime.live.app_resolved_ip),"app DNS must address inspected container");
 else assert.ok(Object.values(runtime.live.ports).flatMap(v=>v||[]).some(p=>p.HostPort===port&&["0.0.0.0","127.0.0.1","::"].includes(p.HostIp)),"app port must map to inspected container");
 return true;
}
export function assertWebAssets(assets,entryScripts,frozenEntries,observed,scripts,appOrigin=null,scriptOrigins=[]){
 assert.deepEqual([...scripts].sort(),[...entryScripts].sort(),"extra or wrong executable script entries");
 if(appOrigin){assert.equal(scriptOrigins.length,scripts.length,"script origin witness missing");assert.ok(scriptOrigins.every(o=>o===appOrigin),"cross-origin executable script");}
 for(const row of observed){
  if(appOrigin)assert.equal(row.origin,appOrigin,"cross-origin fetched asset");
  assert.equal(row.sha256,assets[row.path],"unexpected executable/style/asset response");
  if(row.path.endsWith(".js")||row.path.endsWith(".mjs"))assert.ok(!frozenEntries.includes(row.sha256),"frozen SPA entry loaded through bootstrap");
 }
 return true;
}
