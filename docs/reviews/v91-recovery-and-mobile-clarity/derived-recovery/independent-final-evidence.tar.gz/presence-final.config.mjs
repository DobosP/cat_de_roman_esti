import original from "/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/playwright.config.mjs";
export default {...original,
  testDir: "/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/e2e",
  outputDir: "/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/recovery-review/presence-final-results",
  webServer: undefined,
  reporter: [["list"], ["json", {outputFile: "/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/recovery-review/presence-final-results.json"}]],
  use: {...original.use, baseURL: "http://127.0.0.1:8188", screenshot: "on", trace: "on"},
};
