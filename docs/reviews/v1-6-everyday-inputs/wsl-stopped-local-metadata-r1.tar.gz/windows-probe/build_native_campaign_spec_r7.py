import hashlib,json,pathlib
R=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-6')
S=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-6')
D=R/'docs/reviews/v1-6-everyday-inputs'
OLD='d318b9b3638e4de18d31fac17897c196'
NEW='43a6894fd7a94b3587c744815884c9f3'
R12='adda73a297bad19565b95d3d1ece92a842b9cccb8bf994e0089d0f2474b37858'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
p=D/'wsl-native-campaign-spec-r4.json'
assert sha(p)=='75458396c0627f65c11dba5828bbaf6bfc147d314b91b2e8679e823273f565b3'
spec=json.loads(p.read_bytes().replace(OLD.encode(),NEW.encode()))
allowed={'docs/STATUS.md','docs/reviews/v1-6-everyday-inputs/README.md'}
changed=[]
for key,wanted in spec['inputs'].items():
 got=sha(R/key)
 if got!=wanted:
  assert key in allowed, 'protected canonical pin changed: '+key
  changed.append(key)
  spec['inputs'][key]=got; spec['unchanged'][key]=got
for p in D.rglob('*'):
 if p.is_file():
  assert not p.is_symlink(), 'static evidence symlink'
  key=p.relative_to(R).as_posix()
  got=sha(p)
  if key in spec['inputs']: assert spec['inputs'][key]==got
  spec['inputs'][key]=got; spec['unchanged'][key]=got
assert sha(S/'probe/run_worktree_lane_wsl_r13.py')==R12
spec['runner_sha256']=R12
linuxS='/mnt/c/Users/Paul Work/personal_repos/_temp/codex__content-v1-6'
for rel in ('probe/run_worktree_lane_wsl_r13.py','probe/go-tool-telemetry-r1/mode','probe/prepare_runtime_readset_mirror_wsl_r6.py','probe/check_descriptor_copy_pure_wsl_r4.py','probe/check_r12_telemetry_delta_pure_wsl_r1.py','probe/invoke_pure_capture_r1.ps1','probe/capture_runtime_mirror_r6_r1.ps1'):
 spec['scratch_bindings'][linuxS+'/'+rel]=sha(S/rel)
spec['scratch_bindings']['/usr/bin/python3.14']='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
ns=json.loads((D/'wsl-native-namespace-spec-r1.json').read_bytes())
for key in ('runtime_namespace','canonical_go_namespace'): spec[key]=ns[key]
lifecycle=[]
for label in ('wsl-r12-actual-active-r17','wsl-r12-actual-finalization-r17','wsl-r12-actual-queued-r17','wsl-r12-failed-lane-cli-r3'):
 result=D/(label+'-result.json'); parent=D/(label+'-parent.json')
 observed=json.loads(result.read_bytes()); capture=json.loads(parent.read_bytes())
 assert observed.get('passed',observed.get('status')=='passed') is True, label
 assert observed.get('work_finished_elapsed_seconds') is not None and observed['work_finished_elapsed_seconds']<=24
 assert observed['elapsed_seconds']<=30 and capture['elapsed_seconds']<=30 and capture['exit_code']==0
 assert capture['interpreter_immediate_pre']['sha256']==capture['interpreter_post']['sha256']=='52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'
 lifecycle.append({'result':result.relative_to(R).as_posix(),'result_sha256':sha(result),'parent':parent.relative_to(R).as_posix(),'parent_sha256':sha(parent)})
for rel in ('probe/check_runner_signal_wsl_actual_r17.py','probe/invoke_actual_capture_r3.ps1','probe/check_r13_failed_lane_cli_wsl_r3.py','probe/invoke_r13_failed_lane_cli_capture_r3.ps1'):
 target=S/rel
 if target.suffix=='.py': assert sha(target)==sha(D/'methods'/(target.name+'.txt'))
 spec['scratch_bindings'][linuxS+'/'+rel]=sha(target)
spec['lifecycle_gate_evidence']=lifecycle
spec['schema']='v1-6-wsl-mixed-native-spec-r7'
spec['contract']='Source-only, unadmitted replacement specification: independently qualified byte-identical ext4 read mirror and exact R13 early-interrupt mixed-root runner. All nineteen complementary cases freshly run in exhaustive 5/5/5/4 groups, then canonical CLI race/vet/docs. One immutable 20-minute campaign retains original752431588 cumulative growth baseline, both volume floors, 2GiB RSS,1GiB growth,2 threads/jobs,180s metadata reserve and195s launch cutoff. Prior failed clocks, copies and outcomes remain failed and preserved. Source review, actual lifecycle evidence and a prompt exact immutable admission delta review precede serial-all execution.'
spec['prepared_mirror_evidence']={'path':'docs/reviews/v1-6-everyday-inputs/wsl-runtime-mirror-r6-result.json','sha256':sha(D/'wsl-runtime-mirror-r6-result.json'),'uuid':NEW,'reader_files':172,'reader_bytes':57335773,'native_qualification':False}
spec['fixed_telemetry_mode']={'path':linuxS+'/probe/go-tool-telemetry-r1/mode','bytes':4,'sha256':'b470b84cf0cd3189e10615bffea7d5cbd9f61134ba1c2cfd513ddd45b776a5f6','global_setting_changed':False}
assert len(spec['commands'])==7 and spec['inputs']==spec['unchanged']
out=D/'wsl-native-campaign-spec-r7.json'
blob=(json.dumps(spec,sort_keys=True,indent=2)+'\n').encode()
with out.open('xb') as f: f.write(blob)
print(json.dumps({'path':str(out),'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'canonical_pins':len(spec['inputs']),'scratch_pins':len(spec['scratch_bindings']),'refreshed_current_docs':changed,'status':'SOURCE_ONLY_NOT_ADMITTED'}))
