from pathlib import Path
import ctypes,datetime,hashlib,json,os,shutil,sys,time
S=Path("C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7")
R=Path("C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-7")
t=S/'probe/native-authcore-race-compile-template-r4.json';blob=t.read_bytes()
if hashlib.sha256(blob).hexdigest()!='2b1245be9c38c4d01a28d8eab46d5e7245e0dd8b3c442ba7e79a83a163d8010a':raise RuntimeError('template drift')
review_path=S/'probe/native-authcore-race-compile-source-approval-r2.json'; review=json.loads(review_path.read_text())
closure_path=S/'authcore-accounting-repair-boundary-r1.json';closure=json.loads(closure_path.read_text())
if review['decision']!='ACCEPT_RACE_COMPILE_SOURCE_METHOD_TEMPLATE_AND_CONTROL_SOURCE_ONLY' or review['template_sha256']!='2b1245be9c38c4d01a28d8eab46d5e7245e0dd8b3c442ba7e79a83a163d8010a':raise RuntimeError('actual source review absent')
if closure['outcome']!='source_phase_complete' or closure['closed_epoch']>=closure['substantive_cutoff_epoch']:raise RuntimeError('source phase not successfully closed')
spec=json.loads(blob);old=Path("C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/toolbuild-r1")
roots=[R,S,old/'gocache',old/'gomodcache']
def count(root):
    n=0;pending=[root]
    while pending:
        with os.scandir(pending.pop()) as entries:
            for e in entries:
                st=e.stat(follow_symlinks=False)
                if getattr(st,'st_file_attributes',0)&0x400:raise RuntimeError('reparse accounting')
                if e.is_dir(follow_symlinks=False):pending.append(e.path)
                elif e.is_file(follow_symlinks=False):n+=st.st_size
                else:raise RuntimeError('nonregular accounting')
    return n
class M(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ('total','available','tp','ap','tv','av','extra')]
m=M();m.length=ctypes.sizeof(m)
if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise RuntimeError('memory unavailable')
disk=shutil.disk_usage(R).free;measures={str(p):count(p) for p in roots}
if disk<17*(1<<30) or m.available<16*(1<<30):raise RuntimeError('native start resourcefloor')
source=json.loads((S/'SDK-recovery-admission-r1.json').read_text())
# Retain the successful SDK recovery's growth anchor conservatively across this next phase.
baseline=source['baseline_total'];actual=sum(measures.values())
if actual-baseline+(1<<20)>1<<30:raise RuntimeError('combined source/native growth')
start=time.time()
spec.update(started_epoch=start,deadline_epoch=start+1200,full_R_S_baseline=baseline,host_launcher_pid=int(sys.argv[1]))
p=Path(spec['windows_spec']);p.open('x',encoding='utf-8',newline='\n').write(json.dumps(spec,indent=2,sort_keys=True)+'\n')
pin=hashlib.sha256(p.read_bytes()).hexdigest()
record={'schema':'single-authcore-race-compile-actual-admission-v1','valid_until':'immutable deadline or guardfailure; then history',
 'spec_sha256':pin,'spec':str(p),'started_epoch':start,'deadline_epoch':start+1200,
 'disk_free_bytes':disk,'available_physical_bytes':m.available,'current_full_owned_roots':measures,'current_total':actual,
 'conservative_growth_anchor':baseline,'growth_before_native':actual-baseline,'host_launcher_pid':int(sys.argv[1]),
 'only_late_fields':['started_epoch','deadline_epoch','full_R_S_baseline','host_launcher_pid'],
 'independent_method_template_review':review,'source_review_sha256':hashlib.sha256(review_path.read_bytes()).hexdigest(),'source_boundary_sha256':hashlib.sha256(closure_path.read_bytes()).hexdigest(),'immutable_inputs_exclusive_no_concurrent_SDK_writers':True,'prior_failed_campaign':'native-authcore-race-compile-r1 FAILED transient Go directory count, raw evidence retained; independently reviewed W4 repair, genuinely new campaign',
 'independent_source_inputs_review':'/root/qualification_ledger SOURCE-ONLY 2026-10-09T09:09:45.907013Z',
 'actual_dispatch':'WITHHELD until independent exact actual admission review; parent shell held',
 'SDK_source_recovery_complete':True,'failed_clock_reset':False}
(S/'native-authcore-race-compile-actual-admission-r2.json').open('x',encoding='utf-8',newline='\n').write(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'spec_sha256':pin,'spec':str(p),'at_epoch':start,'deadline_epoch':start+1200,'launcher_pid':int(sys.argv[1]),'disk':disk,'memory':m.available,'growth_anchor':baseline,'current_growth':actual-baseline}))
