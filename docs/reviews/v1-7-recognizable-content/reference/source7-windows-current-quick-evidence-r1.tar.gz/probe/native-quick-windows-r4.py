import pathlib,json,hashlib,os,sys,time,stat,ctypes,queue,shutil,subprocess,threading,signal
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"):raise RuntimeError("optimized refused")
stopping=False
def interrupted(signum,frame):
 global stopping
 stopping=True
signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
spec_path=pathlib.Path(sys.argv[1]);expected_spec=sys.argv[2];raw=spec_path.read_bytes()
assert hashlib.sha256(raw).hexdigest()==expected_spec
spec=json.loads(raw);common=pathlib.Path(spec["windows_common"]);common_bytes=common.read_bytes();assert hashlib.sha256(common_bytes).hexdigest()==spec["common_sha256"]
exec(compile(common_bytes,str(common),"exec"))
validate_contract(spec);assert spec_path==pathlib.Path(spec["windows_spec"])
run=pathlib.Path(spec["windows_run"]);absent(run);run.mkdir();(run/"tmp").mkdir();(run/"empty-bin").mkdir()
root=pathlib.Path(spec["windows_R"]);scratch=pathlib.Path(spec["windows_S"]);cancel=run/"cancel";GiB=1<<30
mono_deadline=time.monotonic()+spec["deadline_epoch"]-time.time()
class MEM(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","totalPage","availablePage","totalVirtual","availableVirtual","extra"]]
class PMC(ctypes.Structure):
 _fields_=[("cb",ctypes.c_ulong),("faults",ctypes.c_ulong)]+[(x,ctypes.c_size_t) for x in ["peakWS","WS","peakPaged","paged","peakNonpaged","nonpaged","pagefile","peakPagefile"]]
kernel=ctypes.WinDLL("kernel32",use_last_error=True);psapi=ctypes.WinDLL("psapi",use_last_error=True)
kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
kernel.CloseHandle.argtypes=[ctypes.c_void_p];psapi.GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.POINTER(PMC),ctypes.c_ulong]
def host_rss(pid,required=True):
 h=kernel.OpenProcess(0x410,False,pid)
 if not h:
  if not required: return 0
  raise RuntimeError("host RSS process unavailable")
 try:
  m=PMC();m.cb=ctypes.sizeof(m);assert psapi.GetProcessMemoryInfo(h,ctypes.byref(m),m.cb)
  return m.WS
 finally: kernel.CloseHandle(h)
def observe_linux_sample(prior,event):
 values=[event["rss"],event.get("peak",0)]
 if any(type(x) is not int or x<0 for x in values):raise RuntimeError("invalid Linux RSS telemetry")
 return max(prior,*values)

def carrier_rss():
 try: return host_rss(carrier.pid)
 except (RuntimeError,AssertionError):
  if carrier.poll() is not None: return 0
  raise
def available():
 m=MEM();m.length=ctypes.sizeof(m);assert kernel.GlobalMemoryStatusEx(ctypes.byref(m));return m.available
def count():
 total=0;roots=[pathlib.Path(x) for x in spec["accounting_roots"]];identity={}
 for p in roots:directory(p);s=p.lstat();identity[p]=(s.st_dev,s.st_ino)
 pending=list(roots)
 while pending:
  d=pending.pop()
  try:
   s=d.lstat();assert filemode.S_ISDIR(s.st_mode) and not filemode.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400
   with os.scandir(d) as es:
    for e in es:
     try:s=e.stat(follow_symlinks=False)
     except FileNotFoundError:
      p=pathlib.Path(e.path)
      allowed=p.parent==pathlib.Path(spec["windows_output_root"]) and p.name.startswith(".native-content-rail-")
      if carrier is not None and carrier.poll() is None and allowed:
       try:p.lstat()
       except FileNotFoundError:continue
       raise RuntimeError("transient reappeared or dangling link remains")
      raise
     assert not filemode.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400
     if filemode.S_ISDIR(s.st_mode):pending.append(pathlib.Path(e.path))
     else:assert filemode.S_ISREG(s.st_mode);total+=s.st_size
  except FileNotFoundError:raise
 for p,value in identity.items():
  s=p.lstat();assert filemode.S_ISDIR(s.st_mode) and not filemode.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400 and (s.st_dev,s.st_ino)==value
 return total
full_readset_checks=[]
def full_pins(index,boundary):
 start=time.time();assert hashfile(spec_path)==expected_spec
 full_readset(spec,"windows")
 full_readset_checks.append({"step":index,"boundary":boundary,"started_epoch":start,"finished_epoch":time.time(),"protected_files":len(spec["windows_protected"])})
def pins(after=False):
 assert hashfile(spec_path)==expected_spec
 for p in spec["windows_critical"]:assert hashfile(p)==spec["windows_protected"][p]
 assert not (pathlib.Path(spec["windows_stage"])/".cat-content-ops.lock").exists()
MAX_STATE=65536
STATE_RESERVE=MAX_STATE*2+4096
def publish(v,failed=False):
 b=(json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode("utf-8")
 assert len(b)<=MAX_STATE,"state publication size guard"
 assert count()-spec["full_R_S_baseline"]+STATE_RESERVE<=spec["growth_cap"],"reserved publication growth guard"
 assert shutil.disk_usage(root).free-STATE_RESERVE>=16*GiB,"reserved publication disk guard"
 assert available()>=spec["memory_floor"],"publication memory guard"
 reserve=0 if failed else 180
 assert time.time()<spec["deadline_epoch"]-reserve and time.monotonic()<mono_deadline-reserve,"publication deadline guard"
 p=run/"state.json";tmp=run/"state.part";tmp.write_bytes(b);os.replace(tmp,p)
 assert count()-spec["full_R_S_baseline"]<=spec["growth_cap"],"post-publication growth guard"
 assert shutil.disk_usage(root).free>=16*GiB and available()>=spec["memory_floor"],"post-publication resource guard"
 assert time.time()<spec["deadline_epoch"]-reserve and time.monotonic()<mono_deadline-reserve,"post-publication deadline guard"

def resources(reserve=180,disk_floor=16*GiB):
 assert not stopping,"cooperative signal"
 assert time.time()<spec["deadline_epoch"]-reserve and time.monotonic()<mono_deadline-reserve,"immutable metadata reserve guard"
 assert shutil.disk_usage(root).free>=disk_floor and (disk_floor>16*GiB or shutil.disk_usage(root).free-STATE_RESERVE>=disk_floor) and available()>=spec["memory_floor"],"disk/memory/metadata reserve guard"
 measured=count();assert measured-baseline+STATE_RESERVE<=spec["growth_cap"],"whole R/S growth/metadata reserve guard"
 assert not stopping,"cooperative signal after resource count"
 assert time.time()<spec["deadline_epoch"]-reserve and time.monotonic()<mono_deadline-reserve,"post-count immutable reserve"
 return measured
baseline=spec["full_R_S_baseline"];peak=0;completed=[];carrier=None;events=None;reader=None;cleanup_status="no child launched"
state={"kind":"running","started_epoch":spec["started_epoch"],"deadline_epoch":spec["deadline_epoch"],"baseline":baseline,"completed":completed,"full_readset_checks":full_readset_checks,"rss_scope":"Windows controller+actualPowerShellparent+WSLcarrier+sampledLinuxsupervisor/ownednativegroup; sourceworkers excluded"}
try:
 resources(195,17*GiB);pins();resources(195,17*GiB)
 directory(spec["windows_output_root"])
 for step in spec["steps"]:absent(step["windows_output"])
 publish(state)
 for index,step in enumerate(spec["steps"]):
  pins();resources(195);absent(step["windows_output"]);full_pins(index,"pre");resources(195)
  proposal_sha=completed[0]["output_sha256"] if index else ""
  if index:assert hashfile(spec["steps"][0]["windows_output"])==proposal_sha
  events=queue.Queue(maxsize=256);complete=None;result=None;latest=0;last_count=0
  cleanup_status="owned Linux group unconfirmed"
  reader=None
  carrier=subprocess.Popen(["wsl.exe","--exec","/usr/bin/python3.14",spec["linux_guard"],spec["linux_spec"],expected_spec,str(index),proposal_sha],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding="utf-8")
  def read(owned=carrier):
   global stopping
   try:
    for line in owned.stdout:
     assert len(line)<=65536
     events.put(load_json(line),timeout=2)
   except BaseException:stopping=True
  reader=threading.Thread(target=read,daemon=True);reader.start()
  tp=run/(step["name"]+".telemetry.jsonl")
  with tp.open("xb") as stream:
   while True:
    assert not stopping
    while True:
     try:event=events.get_nowait()
     except queue.Empty:break
     b=(json.dumps(event,separators=(",",":"))+"\n").encode();assert stream.tell()+len(b)<=4*(1<<20);stream.write(b);stream.flush()
     if event["kind"]=="sample":latest=observe_linux_sample(latest,event)
     elif event["kind"]=="complete":complete=event
     elif event["kind"]=="quick-output":result=event
     elif event["kind"]=="failed":raise RuntimeError(event["error"])
     else:raise RuntimeError("unknown native event")
    total=latest+host_rss(os.getpid())+host_rss(spec["host_launcher_pid"])+carrier_rss();peak=max(peak,total)
    assert total<=spec["rss_cap"] and available()>=spec["memory_floor"]
    assert time.time()<spec["deadline_epoch"]-180 and time.monotonic()<mono_deadline-180
    if time.monotonic()-last_count>=2:
     assert shutil.disk_usage(root).free>=16*GiB and count()-baseline<=spec["growth_cap"];last_count=time.monotonic()
    if carrier.poll() is not None and not reader.is_alive() and events.empty():break
    time.sleep(.25)
  reader.join(timeout=3);assert not reader.is_alive() and carrier.wait()==0 and complete and complete["returncode"]==0 and complete["group_absent"] is True
  cleanup_status="owned Linux group confirmed absent"
  controller_stderr=carrier.stderr.read();assert controller_stderr==""
  (run/(step["name"]+".controller.stderr.log")).write_bytes(controller_stderr.encode())
  assert result and result["step"]==step["name"] and result["output_sha256"]==hashfile(step["windows_output"])
  stdout=(run/(step["name"]+".stdout.log")).read_bytes();stderr=(run/(step["name"]+".stderr.log")).read_bytes()
  assert len(stdout)<=1024 and json_equal(load_json(stdout),{"mode":"proposal" if index==0 else "audit","ok":True,"rail":"quick"}) and stderr==b""
  assert result["stdout_sha256"]==hashlib.sha256(stdout).hexdigest() and result["stderr_bytes"]==0
  assert pathlib.Path(step["windows_output"]).lstat().st_size<=4*(1<<20),"native MaxBytes"
  data=load_json(pathlib.Path(step["windows_output"]).read_bytes());candidate=load_json(pathlib.Path(spec["windows_candidate"]).read_bytes());reference=load_json(pathlib.Path(spec["windows_reference"]).read_bytes())
  if index==0:check_proposal(data,candidate,reference,spec)
  else:
   assert hashfile(spec["steps"][0]["windows_output"])==proposal_sha
   proposal=load_json(pathlib.Path(spec["steps"][0]["windows_output"]).read_bytes());check_proposal(proposal,candidate,reference,spec);check_audit(data,proposal,proposal_sha,spec)
   assert result["proposal_sha256"]==proposal_sha
  full_pins(index,"post");resources();pins()
  completed.append({"step":step["name"],"output_sha256":hashfile(step["windows_output"]),"output_bytes":pathlib.Path(step["windows_output"]).stat().st_size,"native_peak":complete["native_peak"]})
  carrier=None;state.update(completed=completed,parent_inclusive_peak=peak,cleanup=cleanup_status);publish(state)
 assert [(x["step"],x["boundary"]) for x in full_readset_checks]==[(0,"pre"),(0,"post"),(1,"pre"),(1,"post")]
 state.update(kind="passed",finished_epoch=time.time(),parent_inclusive_peak=peak,final_growth=count()-baseline,scope="prospective Quick proposal+audit only; no transition/adoption/versionqualification",cleanup=cleanup_status)
 publish(state);resources();pins();assert not stopping
 assert time.time()<spec["deadline_epoch"]-180 and time.monotonic()<mono_deadline-180 and available()>=spec["memory_floor"],"immediate final PASS reserve/memory"
 print(json.dumps({"kind":"PASS","completed":len(completed),"parent_inclusive_peak":peak,"growth":state["final_growth"]}))
except BaseException as exc:
 cancel.write_bytes(b"cancel")
 if carrier is not None and carrier.poll() is None:
  try:carrier.wait(timeout=12)
  except subprocess.TimeoutExpired:carrier.terminate();carrier.wait(timeout=5)
 reader_shutdown="not started"
 if reader is not None:
  if reader.ident is not None:reader.join(timeout=3)
  reader_shutdown="unconfirmed" if reader.is_alive() else ("not started" if reader.ident is None else "confirmed stopped")
  if reader.is_alive():cleanup_status="owned group or reader shutdown unconfirmed"
 if carrier is not None and (reader is None or not reader.is_alive()):
  for pipe in (carrier.stdout,carrier.stderr):
   if pipe is not None:pipe.close()
 if events is not None:
  while not events.empty():
   event=events.get_nowait()
   if event.get("kind")!="sample":
    with (run/"cleanup-events.jsonl").open("ab") as out:out.write((json.dumps(event)+"\n").encode())
   if event.get("group_absent") is True and reader_shutdown!="unconfirmed":cleanup_status="owned Linux group confirmed absent"
 state.update(kind="failed",error=repr(exc),finished_epoch=time.time(),parent_inclusive_peak=peak,cleanup=cleanup_status,reader_shutdown=reader_shutdown,completed=completed)
 try:publish(state,failed=True)
 except BaseException as secondary:state["failed_publication_error"]=repr(secondary)
 print(json.dumps({"kind":"FAILED","error":repr(exc),"cleanup":cleanup_status,"failed_publication_error":state.get("failed_publication_error")}));raise
