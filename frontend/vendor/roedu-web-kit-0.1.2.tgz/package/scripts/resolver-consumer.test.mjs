// SYNTHETIC CONSUMER PROTOCOL FIXTURES ONLY. Actual shipped CLI/native Go
// commands execute, but these archives, receipts and initial lock graphs never
// qualify Cat's original runtime, a dependency install or an application gate.
import * as fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { test } from 'node:test';
import { makeUiAdoptionFixture, fixtureArchive, fixtureHash } from './ui-adoption-fixture.mjs';
import { inspectUiAdoption, loadKit } from './kit-sync.mjs';

const source = process.cwd();
const base = '/scratch/_temp';
const APP = 'cat_de_roman_esti';
const KIT = 'github.com/DobosP/roedu-ui/web-kit';
const AUTH = 'example.test/synthetic-cat/shared-go/authcore';
const OIDC = 'github.com/coreos/go-oidc/v3';
const OAUTH = 'golang.org/x/oauth2';
const CRYPTO = 'golang.org/x/crypto';
const FONT = '@fontsource-variable/inter';
const OTHER_FONT = '@fontsource/atkinson-hyperlegible';
const json = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const observations = [];
const sources = new Map();

function snapshot(root) {
  const rows = [];
  function walk(directory) {
    for (const name of fs.readdirSync(directory).sort()) {
      const file = path.join(directory, name), stat = fs.lstatSync(file), relative = path.relative(root, file);
      if (stat.isSymbolicLink()) rows.push([relative, 'symlink', fs.readlinkSync(file)]);
      else if (stat.isDirectory()) { rows.push([relative, 'directory', stat.mode & 0o777]); walk(file); }
      else { assert.ok(stat.isFile(), `nonregular synthetic source: ${relative}`); rows.push([relative, 'file', stat.mode & 0o777, fixtureHash(fs.readFileSync(file))]); }
    }
  }
  walk(root);
  return rows;
}

function record(command, args, cwd, child) {
  const row = {
    command, args, cwd, exit_code: child.status ?? -1, signal: child.signal ?? null,
    stdout: child.stdout ?? '', stderr: child.stderr ?? '',
    stdout_sha256: fixtureHash(child.stdout ?? ''), stderr_sha256: fixtureHash(child.stderr ?? ''),
  };
  observations.push(row);
  assert.equal(child.error, undefined, `${command} could not execute: ${child.error?.message}`);
  assert.equal(child.signal, null, `${command} was interrupted`);
  return row;
}

function registryPackage(name, versions, latest = versions.at(-1)) {
  return [ `https://registry.npmjs.org/${name}`, {
    name, 'dist-tags': { latest }, versions: Object.fromEntries(versions.map(version => [version, { name, version }])),
    time: Object.fromEntries(versions.map(version => [version, '2026-10-07T00:00:00.000Z'])),
  } ];
}

function registryRecords() {
  return Object.fromEntries([
    registryPackage('preact', ['11.0.0']), registryPackage('motion', ['14.0.0']),
    registryPackage('@babel/core', ['7.29.7', '8.0.6']), registryPackage('npm', ['12.2.0']),
    registryPackage('preact-iso', ['2.12.1', '2.12.2']),
    registryPackage(FONT, ['5.2.6', '5.2.8']), registryPackage(OTHER_FONT, ['5.2.6', '5.2.8']),
    ['https://nodejs.org/dist/index.json', [{ version: 'v26.10.0', date: '2026-10-07', lts: false }]],
    ['https://go.dev/dl/?mode=json', [{ version: 'go1.27.1', stable: true, files: [] }]],
    ['https://proxy.golang.org/github.com/a-h/templ/@latest', { Version: 'v0.3.960', Time: '2026-10-07T00:00:00Z' }],
    [`https://proxy.golang.org/${OIDC}/@latest`, { Version: 'v3.19.0', Time: '2026-10-07T00:00:00Z' }],
    [`https://proxy.golang.org/${OAUTH}/@latest`, { Version: 'v0.36.0', Time: '2026-10-07T00:00:00Z' }],
    [`https://proxy.golang.org/${CRYPTO}/@latest`, { Version: 'v0.43.0', Time: '2026-10-07T00:00:00Z' }],
    // Deliberately no metadata for local AUTH/KIT, banned React, transitive
    // Framer, another app, frozen Playwright/images/apt or environment rows.
  ]);
}

function coreRows(core) {
  const stamp = entry => ({ ...entry, date: '2026-10-06', source: `synthetic-immutable-floor:${entry.tool}` });
  core.tools = core.tools.map(stamp);
  core.tools.push(...[
    { tool: '@babel/core', kind: 'npm', scope: 'core', version: '7.29.7', exception: 'Synthetic approved Babel7 peer constraint', approved_by: 'Synthetic fixture owner only' },
    { tool: 'node', kind: 'runtime', scope: 'core', version: '26.10.0', rebuild: 'toolchain' },
    { tool: 'npm', kind: 'npm', scope: 'core', version: '12.2.0', rebuild: 'toolchain' },
    { tool: 'go', kind: 'runtime', scope: 'core', version: '1.27.1', rebuild: 'toolchain' },
    { tool: 'github.com/a-h/templ', kind: 'gomod', scope: 'core', version: 'v0.3.960' },
    { tool: 'playwright', kind: 'npm', scope: 'core', version: '1.63.0' },
    { tool: '@playwright/test', kind: 'npm', scope: 'core', version: '1.63.0' },
    { tool: 'playwright-image', kind: 'image', scope: 'core', version: '1.63.0', digest: 'sha256:' + 'd'.repeat(64) },
    { tool: 'postgres', kind: 'image', scope: 'core', version: '16.11', digest: 'sha256:' + 'e'.repeat(64) },
    { tool: 'git', kind: 'apt', scope: 'core', version: '1:2.47.3-0+deb13u1' },
    { tool: 'react', kind: 'npm', scope: 'core', status: 'banned', version: null, observed_latest: '19.2.7' },
    { tool: 'react-dom', kind: 'npm', scope: 'core', status: 'banned', version: null, observed_latest: '19.2.7' },
    { tool: 'docker', kind: 'runtime', scope: 'environment', version: '28.5.1' },
  ].map(stamp));
  return core;
}

function frozen(f, target = 'gen') {
  const config = f.config, directory = target.replaceAll(':', '-');
  const capture = {
    schema: 1, target, sha: f.env.GATE_SHA, tree_sha256: f.env.GATE_TREE_SHA256,
    toolchain_digest: f.env.TOOLCHAIN_DIGEST, config, config_sha256: fixtureHash(JSON.stringify(config)),
  };
  const captureBytes = json(capture);
  f.put('resolver-config.json', json(config));
  f.put(`.gate/${directory}/wrapper-kit-config.json`, captureBytes);
  f.put('.gate/wrapper-current.json', json({
    schema: 1, invocation: randomUUID(), target, sha: capture.sha, tree_sha256: capture.tree_sha256,
    toolchain_digest: capture.toolchain_digest, config_sha256: capture.config_sha256,
    config_path: `.gate/${directory}/wrapper-kit-config.json`, config_file_sha256: fixtureHash(captureBytes),
  }));
}

async function fixture(fn) {
  assert.equal(process.platform, 'linux');
  assert.equal(source, '/work', 'consumer fixtures execute only through the pinned native wrapper');
  assert.equal(fs.realpathSync(base), base);
  const parent = fs.mkdtempSync(path.join(base, 'synthetic-resolver-consumer-'));
  const root = path.join(parent, 'repo');
  fs.mkdirSync(root);
  try {
    const f = makeUiAdoptionFixture(root, { oldSidecar: true });
    f.parent = parent;
    f.config.npm_dir = 'tools/gui-bootstrap-webkit';
    f.config.go_dirs = ['go-backend'];
    f.env = {
      ...process.env, GATE_VERSIONS_RESOLVE: '1', GATE_SHA: 'a'.repeat(40), GATE_TREE_SHA256: 'b'.repeat(64),
      TOOLCHAIN_DIGEST: 'sha256:' + 'c'.repeat(64), GOTOOLCHAIN: 'local', GOWORK: 'off', GOENV: 'off',
    };
    f.records = registryRecords();
    f.metadata = path.join(parent, 'registry.json');
    const helper = path.join(root, f.config.npm_dir);
    for (const name of ['scripts', 'lint', 'schemas']) {
      fs.cpSync(path.join(source, 'web-kit', name), path.join(helper, name), {
        recursive: true,
        filter: file => !file.split(path.sep).some(part => ['__pycache__', 'node_modules', '.gate', '.vitest'].includes(part)) && !/\.py[co]$/i.test(file),
      });
    }
    f.put(`${f.config.npm_dir}/package.json`, fs.readFileSync(path.join(source, 'web-kit/package.json')));
    f.put(`${f.config.npm_dir}/versions.lock.json`, fs.readFileSync(path.join(source, 'versions.lock.json')));
    for (const row of snapshot(helper).filter(row => row[1] === 'file')) {
      const file = path.posix.join('web-kit', row[0]);
      if (file !== 'web-kit/versions.lock.json') sources.set(file, row[3]);
    }
    f.launcher = path.join(helper, 'scripts/resolve-versions.sh');
    const core = coreRows(JSON.parse(f.bundle.kitFiles.get('package/versions.lock.json')));
    f.core = structuredClone(core);
    f.bundle.kitFiles.set('package/versions.lock.json', json(core));
    f.bundle.archives.set(f.bundle.kitName, fixtureArchive(f.bundle.kitFiles));
    for (const [filename, bytes] of f.bundle.archives) f.put(`kit/${filename}`, bytes);
    f.put('kit/SHA256SUMS', [...f.bundle.archives].map(([filename, bytes]) => `${fixtureHash(bytes)}  ${filename}\n`).join(''));
    const lock = structuredClone(core);
    lock.tools.push(
      { tool: 'preact-iso', kind: 'npm', scope: 'app', apps: [APP], version: '2.12.1', source: 'synthetic-original-app:preact-iso', date: '2026-10-06' },
      { tool: 'maplibre-gl', kind: 'npm', scope: 'app', apps: ['social_media_activities_app'], version: '6.12.0', source: 'synthetic-other-app:maplibre-gl', date: '2026-10-06' },
    );
    f.originalVersions = structuredClone(lock);
    f.put('versions.lock.json', json(lock));
    // The original receipt snapshots remain untouched. These are explicitly
    // synthetic *initial* live graph additions, never a generated npm lock or
    // evidence that dependencies have been installed/reconciled by npm.
    Object.assign(f.manifest.dependencies, { preact: '^11.0.0', motion: '^14.0.0', 'preact-iso': '^2.12.1', [FONT]: '^5.2.6', [OTHER_FONT]: '^5.2.6' });
    const kitPointer = `file:vendor/${f.bundle.kitName}`, kitBytes = f.bundle.archives.get(f.bundle.kitName);
    f.manifest.devDependencies = { '@roedu/web-kit': kitPointer };
    f.put(`${f.config.vendor_dir}/${f.bundle.kitName}`, kitBytes);
    f.put(`${f.config.vendor_dir}/${f.bundle.kitName}.sha256`, `${fixtureHash(kitBytes)}  ${f.bundle.kitName}\n`);
    f.lock.packages[''] = structuredClone(f.manifest);
    for (const [name, version] of [['preact', '11.0.0'], ['motion', '14.0.0'], ['preact-iso', '2.12.1'], [FONT, '5.2.6'], [OTHER_FONT, '5.2.6']]) f.lock.packages[`node_modules/${name}`] = { version };
    f.lock.packages['node_modules/@roedu/web-kit'] = { version: '0.1.1', resolved: kitPointer, integrity: 'sha512-' + createHash('sha512').update(kitBytes).digest('base64') };
    f.put(f.manifestPath, json(f.manifest));
    f.put(f.lockPath, json(f.lock));
    f.put('go-backend/go.mod', `module example.test/synthetic-cat/server\n\ngo 1.27.1\n\nrequire (\n\t${KIT} v0.0.0-core-v1.1\n\t${AUTH} v0.0.0\n\t${OIDC} v3.18.0\n\t${OAUTH} v0.31.0\n)\n\nreplace ${KIT} => ./third_party/webkit\n\nreplace ${AUTH} => ../shared-go/authcore\n`);
    // Initial checksum syntax is synthetic input for the native source audit;
    // no downloaded content, generated Go sums or installation is claimed.
    const fixtureSum = 'h1:' + Buffer.alloc(32, 7).toString('base64');
    f.put('go-backend/go.sum', `${OIDC} v3.18.0 ${fixtureSum}\n${OAUTH} v0.31.0 ${fixtureSum}\n`);
    f.put('go-backend/fixture.go', 'package fixture\n// Synthetic source module; this is never a product build.\n');
    f.put('shared-go/authcore/go.mod', `module ${AUTH}\n\ngo 1.27.1\n\nrequire ${CRYPTO} v0.39.0\n`);
    f.put('shared-go/authcore/go.sum', `${CRYPTO} v0.39.0 ${fixtureSum}\n`);
    f.put('shared-go/authcore/fixture.go', 'package authcore\n// Synthetic same-repository closure only.\n');
    for (const [name, bytes] of f.bundle.goFiles) f.put(`go-backend/third_party/webkit/${name.slice(8)}`, bytes);
    f.put('.gate.env', [
      `TOOLCHAIN_IMAGE=${core.toolchain_image.version}`, `TOOLCHAIN_DIGEST=${core.toolchain_image.image_id}`,
      'COMPOSE_FILE=compose.gate.yml', 'SYNC_BACK=versions.lock.json frontend/package.json frontend/package-lock.json go-backend/go.mod go-backend/go.sum shared-go/authcore/go.mod shared-go/authcore/go.sum',
      'PG_MAJOR=16', 'PG_SCRATCH_ROOT=/scratch/pg', 'GATE_PARALLEL_MAX=4', 'GATE_DB_IMAGE=postgres:16.11',
      'CSP_STAGE=report-only', 'APP_DOCKERFILE=Dockerfile', 'QUALIFY_ARGS=', '',
    ].join('\n'));
    f.put('Taskfile.yml', `version: '3'\nsilent: true\ntasks:\n  repo:kit-config:\n    cmds:\n      - node --input-type=module -e "import fs from 'node:fs';process.stdout.write(fs.readFileSync('resolver-config.json'))"\n`);
    frozen(f);
    assert.equal(fs.existsSync(path.join(root, 'package.json')), false);
    assert.equal(fs.existsSync(path.join(root, 'web-kit')), false);
    assert.equal(inspectUiAdoption(root, f.config, loadKit(root)).pending, true, 'real production staged receipt preflight accepts only this synthetic sealed input');
    return await fn(f);
  } finally { fs.rmSync(parent, { recursive: true, force: true }); }
}

function resolve(f, envPatch = {}) {
  fs.writeFileSync(f.metadata, json(f.records));
  const args = [f.launcher, '--fixture', f.metadata];
  const child = spawnSync('bash', args, { cwd: f.root, env: { ...f.env, ...envPatch }, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024, timeout: 30000 });
  return record('bash', args, f.root, child);
}

function failedWithoutWrites(f, expected, envPatch) {
  const before = snapshot(f.root), result = resolve(f, envPatch);
  assert.notEqual(result.exit_code, 0, 'actual shipped resolver must refuse this input');
  if (expected) assert.match(result.stderr, expected);
  assert.deepEqual(snapshot(f.root), before, 'refused resolution must not alter bytes, modes, files, directories or symlink targets');
  assert.equal(fs.existsSync(path.join(f.root, '.gate/gen/result.json')), false, 'fixtures never manufacture an application gate result');
  return result;
}

function nativeModule(f, relative) {
  const args = ['mod', 'edit', '-json', path.join(f.root, relative, 'go.mod')];
  const cwd = path.join(f.root, relative), before = fs.readFileSync(path.join(cwd, 'go.mod'));
  const child = spawnSync('go', args, { cwd, env: f.env, encoding: 'utf8', maxBuffer: 4 * 1024 * 1024, timeout: 30000 });
  const row = record('go', args, cwd, child);
  assert.equal(row.exit_code, 0, row.stderr);
  assert.deepEqual(fs.readFileSync(path.join(cwd, 'go.mod')), before, 'native -json observation must be read-only');
  return JSON.parse(row.stdout);
}

function mixedOAuthBaseline(f) {
  const lock = JSON.parse(fs.readFileSync(path.join(f.root, 'versions.lock.json')));
  assert.equal(lock.tools.some(row => row.tool === OAUTH), false, 'fixture starts with unregistered OAuth');
  lock.tools.push({ tool: OAUTH, kind: 'gomod', scope: 'app', apps: [APP], version: 'v0.31.0', source: 'synthetic-registered-app:oauth2', date: '2026-10-06' });
  f.put('versions.lock.json', json(lock));
  f.put('shared-go/authcore/go.mod', `module ${AUTH}\n\ngo 1.27.1\n\nrequire (\n\t${CRYPTO} v0.39.0\n\t${OAUTH} v0.35.0\n)\n`);
  const existing = fs.readFileSync(path.join(f.root, 'shared-go/authcore/go.sum'), 'utf8');
  // Synthetic prior content-hash syntax only, matching the actual local input
  // version. No downloaded module or generated checksum evidence is claimed.
  const hash = 'h1:' + Buffer.alloc(32, 7).toString('base64');
  f.put('shared-go/authcore/go.sum', `${existing}${OAUTH} v0.35.0 ${hash}\n`);
}

test('synthetic consumer shipped launcher resolves only Cat owners and native same-repo Go closure', () => fixture(f => {
  const before = snapshot(f.root), helperBefore = snapshot(path.join(f.root, f.config.npm_dir));
  const result = resolve(f);
  assert.equal(result.exit_code, 0, result.stderr);
  const report = JSON.parse(result.stdout);
  assert.equal(report.schema, 1); assert.equal(report.check, 'versions-resolve'); assert.equal(report.status, 'pass');
  assert.equal(report.role, 'consumer'); assert.equal(report.app, APP);
  assert.ok(Array.isArray(report.native_commands));
  const go = report.native_commands.filter(row => row.command === 'go');
  assert.ok(go.some(row => row.args.includes('-json')), 'retain actual native Go parser streams');
  assert.ok(go.some(row => row.args.some(arg => arg.startsWith('-require='))), 'exact Go pins must come from real native Go edits');
  for (const row of go) {
    assert.equal(row.exit_code, 0, row.stderr); assert.equal(typeof row.stdout, 'string'); assert.equal(typeof row.stderr, 'string');
    if (row.stdout_sha256) assert.equal(row.stdout_sha256, fixtureHash(row.stdout));
    if (row.stderr_sha256) assert.equal(row.stderr_sha256, fixtureHash(row.stderr));
  }
  const lock = JSON.parse(fs.readFileSync(path.join(f.root, 'versions.lock.json')));
  for (const floor of f.core.tools) assert.deepEqual(lock.tools.find(row => row.tool === floor.tool), floor, `preserve complete immutable floor ${floor.tool}`);
  assert.deepEqual(lock.toolchain_image, f.core.toolchain_image); assert.equal(lock.core_tag, f.core.core_tag);
  assert.deepEqual(lock.tools.find(row => row.tool === 'maplibre-gl'), f.originalVersions.tools.find(row => row.tool === 'maplibre-gl'));
  const expected = new Map([['preact-iso', '2.12.2'], [FONT, '5.2.8'], [OTHER_FONT, '5.2.8'], [OIDC, 'v3.19.0'], [OAUTH, 'v0.36.0'], [CRYPTO, 'v0.43.0']]);
  for (const [tool, version] of expected) {
    const entry = lock.tools.find(row => row.tool === tool);
    assert.ok(entry, `register actual direct owner ${tool}`); assert.equal(entry.version, version);
    assert.equal(entry.scope, 'app'); assert.deepEqual(entry.apps, [APP]); assert.match(entry.date, /^\d{4}-\d{2}-\d{2}$/);
    assert.match(entry.source, /^https:\/\/(registry\.npmjs\.org|proxy\.golang\.org)\//);
  }
  assert.equal(lock.tools.some(row => row.tool === AUTH || row.tool === KIT), false, 'local modules never acquire remote app version rows');
  const manifest = JSON.parse(fs.readFileSync(path.join(f.root, f.manifestPath)));
  for (const [name, version] of [['preact', '11.0.0'], ['motion', '14.0.0'], ['preact-iso', '2.12.2'], [FONT, '5.2.8'], [OTHER_FONT, '5.2.8']]) assert.equal(manifest.dependencies[name], version);
  for (const name of ['@roedu/ui', 'react', 'react-dom', 'framer-motion']) assert.equal(manifest.dependencies[name], f.manifest.dependencies[name], `never normalize sealed or banned/transitive-only declaration ${name}`);
  assert.deepEqual(manifest.devDependencies, f.manifest.devDependencies, 'preserve the canonical local kit archive pointer exactly');
  const server = nativeModule(f, 'go-backend'), auth = nativeModule(f, 'shared-go/authcore');
  const serverRequirements = new Map(server.Require.map(row => [row.Path, row.Version]));
  assert.equal(serverRequirements.get(OIDC), expected.get(OIDC)); assert.equal(serverRequirements.get(OAUTH), expected.get(OAUTH));
  assert.equal(serverRequirements.get(KIT), 'v0.0.0-core-v1.1'); assert.equal(serverRequirements.get(AUTH), 'v0.0.0');
  assert.deepEqual(server.Replace.map(row => [row.Old.Path, row.New.Path]).sort(), [[AUTH, '../shared-go/authcore'], [KIT, './third_party/webkit']].sort());
  assert.equal(auth.Require.find(row => row.Path === CRYPTO).Version, expected.get(CRYPTO));
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(f.root, 'resolver-config.json'))).go_dirs, ['go-backend'], 'authcore stays an audited dependency, never a kit receiver');
  assert.deepEqual(snapshot(path.join(f.root, f.config.npm_dir)), helperBefore, 'helper package and tooling stay read-only');
  const allowed = new Set(['versions.lock.json', f.manifestPath, 'go-backend/go.mod', 'shared-go/authcore/go.mod']);
  assert.deepEqual(snapshot(f.root).filter(row => !allowed.has(row[0])), before.filter(row => !allowed.has(row[0])), 'locks, sums, original SDK/receipt/snapshots, kit inputs and frozen configuration remain byte/mode identical');
  assert.equal(fs.existsSync(path.join(f.root, 'package.json')), false); assert.equal(fs.existsSync(path.join(f.root, 'web-kit')), false);
  assert.equal(fs.existsSync(path.join(f.root, '.gate/gen/result.json')), false);
}));

test('synthetic consumer shipped launcher reconciles registered OAuth from distinct native per-module baselines', () => fixture(f => {
  mixedOAuthBaseline(f);
  const before = snapshot(f.root), helperBefore = snapshot(path.join(f.root, f.config.npm_dir));
  const result = resolve(f);
  assert.equal(result.exit_code, 0, result.stderr);
  const report = JSON.parse(result.stdout);
  assert.equal(report.schema, 1); assert.equal(report.check, 'versions-resolve'); assert.equal(report.status, 'pass');
  assert.equal(report.role, 'consumer'); assert.equal(report.app, APP);
  assert.equal(report.go_input_baselines.version_policy, 'resolver-input-baseline');
  for (const [dir, version] of [['go-backend', 'v0.31.0'], ['shared-go/authcore', 'v0.35.0']]) {
    const module = report.go_input_baselines.modules.find(row => row.dir === dir);
    assert.equal(module.mod_sha256, before.find(row => row[0] === dir + '/go.mod')[3], `input baseline binds actual original ${dir} bytes`);
    assert.equal(module.requirements.find(row => row.module === OAUTH).version, version, `input proof retains distinct original ${dir} OAuth version`);
  }
  assert.ok(Array.isArray(report.native_commands));
  const go = report.native_commands.filter(row => row.command === 'go');
  for (const dir of ['go-backend', 'shared-go/authcore']) {
    assert.ok(go.some(row => row.cwd === dir && row.args.includes('-json')), `retain actual input parser for ${dir}`);
    assert.ok(go.some(row => row.cwd === dir && row.args.includes(`-require=${OAUTH}@v0.36.0`)), `native exact OAuth edit for ${dir}`);
  }
  for (const row of go) {
    assert.equal(row.exit_code, 0, row.stderr); assert.equal(typeof row.stdout, 'string'); assert.equal(typeof row.stderr, 'string');
    if (row.stdout_sha256) assert.equal(row.stdout_sha256, fixtureHash(row.stdout));
    if (row.stderr_sha256) assert.equal(row.stderr_sha256, fixtureHash(row.stderr));
  }
  const lock = JSON.parse(fs.readFileSync(path.join(f.root, 'versions.lock.json')));
  const oauth = lock.tools.filter(row => row.tool === OAUTH);
  assert.equal(oauth.length, 1); assert.equal(oauth[0].version, 'v0.36.0');
  assert.equal(oauth[0].scope, 'app'); assert.deepEqual(oauth[0].apps, [APP]);
  assert.ok(report.changes.some(row => row.tool === OAUTH && row.from === 'v0.31.0' && row.to === 'v0.36.0'));
  for (const floor of f.core.tools) assert.deepEqual(lock.tools.find(row => row.tool === floor.tool), floor, `preserve complete immutable floor ${floor.tool}`);
  assert.deepEqual(lock.toolchain_image, f.core.toolchain_image); assert.equal(lock.core_tag, f.core.core_tag);
  assert.deepEqual(lock.tools.find(row => row.tool === 'maplibre-gl'), f.originalVersions.tools.find(row => row.tool === 'maplibre-gl'));
  assert.equal(lock.tools.some(row => row.tool === AUTH || row.tool === KIT), false);
  const server = nativeModule(f, 'go-backend'), auth = nativeModule(f, 'shared-go/authcore');
  assert.equal(server.Require.find(row => row.Path === OAUTH).Version, 'v0.36.0');
  assert.equal(auth.Require.find(row => row.Path === OAUTH).Version, 'v0.36.0');
  assert.equal(server.Require.find(row => row.Path === KIT).Version, 'v0.0.0-core-v1.1');
  assert.equal(server.Require.find(row => row.Path === AUTH).Version, 'v0.0.0');
  assert.deepEqual(server.Replace.map(row => [row.Old.Path, row.New.Path]).sort(), [[AUTH, '../shared-go/authcore'], [KIT, './third_party/webkit']].sort());
  const manifest = JSON.parse(fs.readFileSync(path.join(f.root, f.manifestPath)));
  for (const name of ['@roedu/ui', 'react', 'react-dom', 'framer-motion']) assert.equal(manifest.dependencies[name], f.manifest.dependencies[name]);
  assert.deepEqual(manifest.devDependencies, f.manifest.devDependencies);
  assert.deepEqual(snapshot(path.join(f.root, f.config.npm_dir)), helperBefore, 'helper tooling is immutable');
  const allowed = new Set(['versions.lock.json', f.manifestPath, 'go-backend/go.mod', 'shared-go/authcore/go.mod']);
  assert.deepEqual(snapshot(f.root).filter(row => !allowed.has(row[0])), before.filter(row => !allowed.has(row[0])), 'distinct-baseline resolution preserves original SDK/receipt/snapshots, current configuration, kit, locks, sums and helper bytes/modes');
  assert.equal(fs.existsSync(path.join(f.root, '.gate/gen/result.json')), false);
}));

test('synthetic consumer distinct local OAuth baseline still requires its exact prior content hash', async () => {
  const expected = /shared-go\/authcore\/go\.sum: requirement has no actual content hash golang\.org\/x\/oauth2/;
  await fixture(f => {
    mixedOAuthBaseline(f);
    const file = path.join(f.root, 'shared-go/authcore/go.sum');
    f.put('shared-go/authcore/go.sum', fs.readFileSync(file, 'utf8').split('\n').filter(line => !line.startsWith(OAUTH + ' ')).join('\n'));
    failedWithoutWrites(f, expected);
  });
  await fixture(f => {
    mixedOAuthBaseline(f);
    const file = path.join(f.root, 'shared-go/authcore/go.sum');
    f.put('shared-go/authcore/go.sum', fs.readFileSync(file, 'utf8').replace(`${OAUTH} v0.35.0 `, `${OAUTH} v0.31.0 `));
    failedWithoutWrites(f, expected);
  });
  await fixture(f => {
    mixedOAuthBaseline(f);
    const file = path.join(f.root, 'shared-go/authcore/go.sum');
    f.put('shared-go/authcore/go.sum', fs.readFileSync(file, 'utf8').replace(`${OAUTH} v0.35.0 `, `${OAUTH} v0.35.0/go.mod `));
    failedWithoutWrites(f, expected);
  });
});

test('synthetic consumer requires wrapper resolution authorization and bound current gen configuration', async () => {
  await fixture(f => failedWithoutWrites(f, /Only native gen --resolve-versions may resolve versions/, { GATE_VERSIONS_RESOLVE: '0' }));
  await fixture(f => { frozen(f, 'unit'); failedWithoutWrites(f, /target|invocation|gen/i); });
  await fixture(f => { fs.unlinkSync(path.join(f.root, '.gate/wrapper-current.json')); failedWithoutWrites(f); });
  await fixture(f => { const value = JSON.parse(fs.readFileSync(path.join(f.root, 'resolver-config.json'))); value.app = 'ro_teacher'; f.put('resolver-config.json', json(value)); failedWithoutWrites(f, /config|phase|checksum/i); });
  await fixture(f => { const current = JSON.parse(fs.readFileSync(path.join(f.root, '.gate/wrapper-current.json'))); current.tree_sha256 = '9'.repeat(64); f.put('.gate/wrapper-current.json', json(current)); failedWithoutWrites(f, /identity|config/i); });
});

test('synthetic consumer late registry failure is transactional after earlier eligible app choices', () => fixture(f => {
  delete f.records[`https://proxy.golang.org/${CRYPTO}/@latest`];
  failedWithoutWrites(f, /fixture|metadata|crypto/i);
}));

test('synthetic consumer latest core changes require KIT_BUMP and cannot mutate frozen floors', async () => {
  await fixture(f => { f.records['https://registry.npmjs.org/preact'] = registryPackage('preact', ['11.0.0', '11.0.1'])[1]; failedWithoutWrites(f, /KIT_BUMP|core|floor/i); });
  await fixture(f => { f.records['https://proxy.golang.org/github.com/a-h/templ/@latest'].Version = 'v0.3.961'; failedWithoutWrites(f, /KIT_BUMP|core|floor/i); });
  await fixture(f => { f.records['https://nodejs.org/dist/index.json'][0].version = 'v26.10.1'; failedWithoutWrites(f, /KIT_BUMP|core|floor|REBUILD/i); });
  await fixture(f => { const lock = JSON.parse(fs.readFileSync(path.join(f.root, 'versions.lock.json'))); lock.tools.find(row => row.tool === 'preact').version = '11.0.1'; f.put('versions.lock.json', json(lock)); failedWithoutWrites(f, /core|floor|canonical/i); });
});

test('synthetic consumer refuses selected-app and actual undeclared-owner downgrades before writes', async () => {
  await fixture(f => { const lock = JSON.parse(fs.readFileSync(path.join(f.root, 'versions.lock.json'))); lock.tools.find(row => row.tool === 'preact-iso').version = '2.99.0'; f.put('versions.lock.json', json(lock)); failedWithoutWrites(f, /downgrade|lower/i); });
  await fixture(f => { f.lock.packages[`node_modules/${FONT}`].version = '5.99.0'; f.put(f.lockPath, json(f.lock)); failedWithoutWrites(f, /downgrade|lower/i); });
  await fixture(f => {
    f.put('shared-go/authcore/go.mod', `module ${AUTH}\n\ngo 1.27.1\n\nrequire ${CRYPTO} v0.99.0\n`);
    f.put('shared-go/authcore/go.sum', fs.readFileSync(path.join(f.root, 'shared-go/authcore/go.sum'), 'utf8').replace(' v0.39.0 ', ' v0.99.0 '));
    failedWithoutWrites(f, /downgrade|lower/i);
  });
});

test('synthetic consumer prerelease-only app metadata cannot produce partial manifest or Go pins', () => fixture(f => {
  f.records[`https://registry.npmjs.org/${OTHER_FONT}`] = registryPackage(OTHER_FONT, ['5.3.0-rc.1'])[1];
  failedWithoutWrites(f, /stable|prerelease/i);
}));

test('synthetic consumer alias and unsupported file owners refuse before any resolution write', async () => {
  await fixture(f => { f.manifest.dependencies[FONT] = `npm:${OTHER_FONT}@5.2.8`; f.lock.packages[''] = structuredClone(f.manifest); f.put(f.manifestPath, json(f.manifest)); f.put(f.lockPath, json(f.lock)); failedWithoutWrites(f, /alias|literal|registry|unsupported/i); });
  await fixture(f => { f.manifest.dependencies['unregistered-local'] = 'file:../outside-package'; f.lock.packages[''] = structuredClone(f.manifest); f.put(f.manifestPath, json(f.manifest)); f.put(f.lockPath, json(f.lock)); failedWithoutWrites(f, /file|local|literal|registry|unsupported/i); });
});

test('synthetic consumer requires unchanged sealed UI0.3 phase/receipt/archive before dependency edits', async () => {
  await fixture(f => { delete f.config.ui_adoption; frozen(f); failedWithoutWrites(f, /UI|staged|0\.3/i); });
  await fixture(f => { f.put(f.config.ui_adoption.legacy.receipt, '{}\n'); failedWithoutWrites(f, /receipt|UI_ADOPTION/i); });
  await fixture(f => { f.put(`${f.config.vendor_dir}/${f.old.filename}`, 'corrupted original SDK'); failedWithoutWrites(f, /SDK|archive|UI_ADOPTION/i); });
});

test('synthetic consumer configured owner and current metadata ancestors refuse symlinks', async () => {
  await fixture(f => {
    const owner = path.join(f.root, f.manifestPath), outside = path.join(f.parent, 'outside-manifest.json'), bytes = fs.readFileSync(owner);
    fs.writeFileSync(outside, bytes); fs.unlinkSync(owner); fs.symlinkSync(outside, owner);
    failedWithoutWrites(f, /[Ss]ymlink|regular/i); assert.deepEqual(fs.readFileSync(outside), bytes);
  });
  await fixture(f => {
    const relative = '.gate/gen/wrapper-kit-config.json', file = path.join(f.root, relative), outside = path.join(f.parent, 'outside-capture.json'), bytes = fs.readFileSync(file);
    fs.writeFileSync(outside, bytes); fs.unlinkSync(file); fs.symlinkSync(outside, file);
    failedWithoutWrites(f, /[Ss]ymlink|regular/i); assert.deepEqual(fs.readFileSync(outside), bytes);
  });
});

test('synthetic consumer local Go closure refuses escapes, symlinks and module aliases transactionally', async () => {
  await fixture(f => {
    const file = path.join(f.root, 'go-backend/go.mod');
    f.put('go-backend/go.mod', fs.readFileSync(file, 'utf8').replace('../shared-go/authcore', '../../outside-authcore'));
    failedWithoutWrites(f, /escape|repository|relative|replacement/i);
  });
  await fixture(f => {
    const original = path.join(f.root, 'shared-go/authcore'), held = path.join(f.parent, 'outside-authcore');
    fs.renameSync(original, held); const outsideBefore = snapshot(held); fs.symlinkSync(held, original);
    failedWithoutWrites(f, /[Ss]ymlink|regular|ancestor/i); assert.deepEqual(snapshot(held), outsideBefore);
  });
  await fixture(f => { f.put('shared-go/authcore/go.mod', `module example.test/wrong-module-identity\n\ngo 1.27.1\n\nrequire ${CRYPTO} v0.39.0\n`); failedWithoutWrites(f, /identity|module|replacement/i); });
});

test('synthetic consumer configured paths reject traversal aliases and package identity changes', async () => {
  await fixture(f => { f.config.vendor_dir = 'frontend/../frontend/vendor'; frozen(f); failedWithoutWrites(f, /path|literal/i); });
  await fixture(f => { f.config.npm_dir = 'tools/../gui-bootstrap-webkit'; frozen(f); failedWithoutWrites(f, /path|literal/i); });
  await fixture(f => { f.put(`${f.config.npm_dir}/package.json`, json({ name: 'synthetic-wrong-helper-owner', version: '0.1.1', type: 'module' })); failedWithoutWrites(f, /package|kit|owner/i); });
  await fixture(f => { f.config.vendor_dir = `${f.config.npm_dir}/vendor`; frozen(f); failedWithoutWrites(f, /immutable|tool|owner|config|receipt|overlap/i); });
});

test.after(() => {
  console.log(JSON.stringify({
    schema: 1, check: 'synthetic-consumer-resolver-fixtures', synthetic: true,
    application_qualification: false, dependency_install_claim: false,
    sources: [...sources].sort(([a], [b]) => a.localeCompare(b)).map(([file, sha256]) => ({ path: file, sha256 })),
    commands: observations,
  }));
});
