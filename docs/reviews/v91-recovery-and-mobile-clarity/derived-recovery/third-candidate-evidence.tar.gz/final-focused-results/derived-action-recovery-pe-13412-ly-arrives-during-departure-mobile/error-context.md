# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: derived-action-recovery.spec.mjs >> perechi >> browser Back preserves the saved round when a winning reply arrives during departure
- Location: e2e/derived-action-recovery.spec.mjs:295:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - generic:
    - status
  - generic [ref=e8]:
    - banner [ref=e9]:
      - generic [ref=e10]:
        - heading "Cât de român ești?" [level=1] [ref=e11]:
          - generic [ref=e12]: Cât
          - generic [ref=e13]: de
          - generic [ref=e14]: român
          - generic [ref=e15]: ești?
        - button "Activează sunetul" [ref=e16] [cursor=pointer]:
          - generic [aria-hidden] [ref=e17]: 🔇
      - paragraph [ref=e18]: "De la Ștefan cel Mare la Las Fierbinți: șase jocuri scurte din cultura și viața românească."
    - region [ref=e19]:
      - generic [ref=e20]:
        - generic [ref=e21]:
          - generic [aria-hidden] [ref=e22]: ☀️
          - generic [ref=e23]:
            - heading "Circuitul de azi" [level=2] [ref=e24]
            - paragraph [ref=e25]: Doar pe acest dispozitiv.
        - status "0 din 6 jocuri terminate azi, 0 din 6000 de puncte" [ref=e26]:
          - strong [ref=e27]: 0/6
          - generic [ref=e28]: 0/6000 pct
      - list "Progresul jocurilor de azi" [ref=e29]:
        - listitem [ref=e30]:
          - button "Deschide Alchimie — neterminat azi" [ref=e31] [cursor=pointer]:
            - generic [aria-hidden] [ref=e32]: ⚗️
            - generic [ref=e33]: Alchimie
            - generic [aria-hidden] [ref=e34]: Joacă →
        - listitem [ref=e35]:
          - button "Deschide Intrusul — neterminat azi" [ref=e36] [cursor=pointer]:
            - generic [aria-hidden] [ref=e37]: 🔎
            - generic [ref=e38]: Intrusul
            - generic [aria-hidden] [ref=e39]: Joacă →
        - listitem [ref=e40]:
          - button "Deschide Perechi — neterminat azi" [ref=e41] [cursor=pointer]:
            - generic [aria-hidden] [ref=e42]: 🧠
            - generic [ref=e43]: Perechi
            - generic [aria-hidden] [ref=e44]: Joacă →
        - listitem [ref=e45]:
          - button "Deschide Conexiuni — neterminat azi" [ref=e46] [cursor=pointer]:
            - generic [aria-hidden] [ref=e47]: 🧩
            - generic [ref=e48]: Conexiuni
            - generic [aria-hidden] [ref=e49]: Joacă →
        - listitem [ref=e50]:
          - button "Deschide Cald sau Rece — neterminat azi" [ref=e51] [cursor=pointer]:
            - generic [aria-hidden] [ref=e52]: 🔥
            - generic [ref=e53]: Cald sau Rece
            - generic [aria-hidden] [ref=e54]: Joacă →
        - listitem [ref=e55]:
          - button "Deschide Lanțul Cuvintelor — neterminat azi" [ref=e56] [cursor=pointer]:
            - generic [aria-hidden] [ref=e57]: 🔗
            - generic [ref=e58]: Lanțul Cuvintelor
            - generic [aria-hidden] [ref=e59]: Joacă →
    - generic [ref=e60]:
      - button "Joacă Alchimie — Combină și descoperă" [ref=e61] [cursor=pointer]:
        - generic [ref=e62]:
          - generic [aria-hidden] [ref=e63]: ⚗️
          - generic [ref=e64]: Combină și descoperă
        - strong [ref=e65]: Alchimie
        - paragraph [ref=e66]: Alege două concepte și făurește ținta.
        - generic [ref=e67]: Joacă →
      - button "Joacă Intrusul — Începe aici" [ref=e69] [cursor=pointer]:
        - generic [ref=e70]:
          - generic [aria-hidden] [ref=e71]: 🔎
          - generic [ref=e72]: Începe aici
        - strong [ref=e73]: Intrusul
        - paragraph [ref=e74]: Trei cuvinte au o legătură. Atinge intrusul.
        - generic [ref=e75]:
          - generic [ref=e76]: Joacă →
          - generic [ref=e77]: 🌱 Nivel de început
      - button "Joacă Perechi — Potrivește câte două" [ref=e78] [cursor=pointer]:
        - generic [ref=e79]:
          - generic [aria-hidden] [ref=e80]: 🧠
          - generic [ref=e81]: Potrivește câte două
        - strong [ref=e82]: Perechi
        - paragraph [ref=e83]: Atinge două cuvinte care merg împreună.
        - generic [ref=e84]:
          - generic [ref=e85]: Joacă →
          - generic [ref=e86]: ★ record 1000
      - button "Joacă Conexiuni — Găsește grupurile" [ref=e87] [cursor=pointer]:
        - generic [ref=e88]:
          - generic [aria-hidden] [ref=e89]: 🧩
          - generic [ref=e90]: Găsește grupurile
        - strong [ref=e91]: Conexiuni
        - paragraph [ref=e92]: Alege câte patru cuvinte care merg împreună.
        - generic [ref=e93]: Joacă →
      - button "Joacă Cald sau Rece — Mai cald, mai rece" [ref=e95] [cursor=pointer]:
        - generic [ref=e96]:
          - generic [aria-hidden] [ref=e97]: 🔥
          - generic [ref=e98]: Mai cald, mai rece
        - strong [ref=e99]: Cald sau Rece
        - paragraph [ref=e100]: Ghicește secretul urmărind căldura.
        - generic [ref=e101]: Joacă →
      - button "Joacă Lanțul Cuvintelor — Leagă conceptele" [ref=e103] [cursor=pointer]:
        - generic [ref=e104]:
          - generic [aria-hidden] [ref=e105]: 🔗
          - generic [ref=e106]: Leagă conceptele
        - strong [ref=e107]: Lanțul Cuvintelor
        - paragraph [ref=e108]: Sari din cuvânt în cuvânt până la țintă.
        - generic [ref=e109]: Joacă →
    - generic [ref=e111]:
      - generic [ref=e112]:
        - group "Istoric" [ref=e113]:
          - button "Top" [pressed] [ref=e114] [cursor=pointer]
          - button "Azi" [ref=e115] [cursor=pointer]
          - button "Istoric" [ref=e116] [cursor=pointer]
        - generic [ref=e117]:
          - button "Export" [ref=e118] [cursor=pointer]:
            - generic [aria-hidden] [ref=e119]: ⬇
            - text: Export
          - button "Import" [ref=e120] [cursor=pointer]:
            - generic [aria-hidden] [ref=e121]: ⬆
            - text: Import
      - generic [ref=e122]:
        - generic [ref=e123]:
          - generic [ref=e124]:
            - generic [ref=e125]: Alchimie
            - strong [ref=e126]: "0"
          - generic [ref=e127]: Fără scor
        - generic [ref=e128]:
          - generic [ref=e129]:
            - generic [ref=e130]: Intrusul
            - strong [ref=e131]: "0"
          - generic [ref=e132]: Fără scor
        - generic [ref=e133]:
          - generic [ref=e134]:
            - generic [ref=e135]: Perechi
            - strong [ref=e136]: "1"
          - generic [ref=e137]:
            - generic [ref=e138]: 0 greșeli
            - strong [ref=e139]: "1000"
        - generic [ref=e140]:
          - generic [ref=e141]:
            - generic [ref=e142]: Conexiuni
            - strong [ref=e143]: "0"
          - generic [ref=e144]: Fără scor
        - generic [ref=e145]:
          - generic [ref=e146]:
            - generic [ref=e147]: Cald sau Rece
            - strong [ref=e148]: "0"
          - generic [ref=e149]: Fără scor
        - generic [ref=e150]:
          - generic [ref=e151]:
            - generic [ref=e152]: Lanțul Cuvintelor
            - strong [ref=e153]: "0"
          - generic [ref=e154]: Fără scor
      - generic [ref=e156]:
        - generic [ref=e157]:
          - generic [ref=e158]: "1"
          - generic [ref=e159]:
            - strong [ref=e160]: Perechi
            - generic [ref=e161]: 0 greșeli
        - generic [ref=e162]:
          - generic [ref=e163]: 08.09, 23:45
          - strong [ref=e164]: "1000"
    - paragraph [ref=e165]: Toate cele șase jocuri folosesc aceeași hartă de legături culturale românești.
```

# Test source

```ts
  214 |       await perform();
  215 |       await expect(page.locator(`.${game.key}-feedback`)).toHaveText("Joc sincronizat. Poți continua.");
  216 |       expect(await server(request, game, initial.game_id)).toEqual(initial);
  217 |       expect(counts).toEqual({ reads: 1, mutations: 1 });
  218 |     });
  219 | 
  220 |     for (const phase of ["mutation", "read"]) {
  221 |       test(`a wrong game id in ${phase} cannot replace the displayed round`, async ({ page, request }) => {
  222 |         const { initial, action, perform } = await prepare(page, request, game, "hint");
  223 |         const counts = traffic(page, game, initial.game_id);
  224 |         if (phase === "read") await loseResponse(page, game, initial.game_id, action);
  225 |         await page.route(`**${gameURL(game, initial.game_id)}${phase === "mutation" ? `/${action}` : ""}`, async (route) => {
  226 |           const response = await route.fetch();
  227 |           await route.fulfill({ json: { ...await response.json(), game_id: "wrong-session" } });
  228 |         }, { times: 1 });
  229 |         await perform();
  230 |         if (phase === "read") {
  231 |           await expect(verify(page)).toBeEnabled();
  232 |           await allLocked(page, game);
  233 |           await verify(page).click();
  234 |         }
  235 |         await expect(cue(page, game)).toBeVisible();
  236 |         expect(await saved(page, game)).toBe(initial.game_id);
  237 |         expect(counts).toEqual({ reads: phase === "mutation" ? 1 : 2, mutations: 1 });
  238 |       });
  239 |     }
  240 | 
  241 |     test("owned confirmed 404 returns to intro and forgets only the missing round", async ({ page, request }) => {
  242 |       const { initial, action, perform } = await prepare(page, request, game);
  243 |       const counts = traffic(page, game, initial.game_id);
  244 |       await loseResponse(page, game, initial.game_id, action);
  245 |       await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({ status: 404, json: {} }), { times: 1 });
  246 |       await perform();
  247 |       await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  248 |       expect(await saved(page, game)).toBeNull();
  249 |       expect(counts).toEqual({ reads: 1, mutations: 1 });
  250 |     });
  251 | 
  252 |     test("an already changed saved pointer prevents a mutation and loads the current round", async ({ page, request, context }) => {
  253 |       const { initial } = await prepare(page, request, game, "hint");
  254 |       const counts = traffic(page, game, initial.game_id);
  255 |       const { tab, fresh } = await replaceSaved(context, request, game);
  256 |       await hint(page, game).click();
  257 |       await expect(currentGame(page)).toBeEnabled();
  258 |       await allLocked(page, game);
  259 |       expect(counts).toEqual({ reads: 0, mutations: 0 });
  260 |       await currentGame(page).click();
  261 |       await expect(currentGame(page)).toHaveCount(0);
  262 |       await expect(page.locator(game.board)).toBeVisible();
  263 |       expect(await saved(page, game)).toBe(fresh.game_id);
  264 |       expect((await server(request, game, initial.game_id)).hints_used).toBe(0);
  265 |       await tab.close();
  266 |     });
  267 | 
  268 |     for (const phase of ["mutation", "read", "missing-read", "removed-pointer"]) {
  269 |       test(`a changed saved round rejects an old winning ${phase} completion without scoring`, async ({ page, request, context }) => {
  270 |         const { initial, action, perform } = await prepare(page, request, game, "win");
  271 |         const counts = traffic(page, game, initial.game_id);
  272 |         const mutation = phase === "mutation" || phase === "removed-pointer";
  273 |         if (!mutation) await loseResponse(page, game, initial.game_id, action);
  274 |         const held = await holdResponse(page, game, initial.game_id, mutation ? action : "", phase === "missing-read");
  275 |         const performed = perform();
  276 |         await held.requested;
  277 |         const { tab, fresh } = await replaceSaved(context, request, game, phase === "removed-pointer");
  278 |         held.release();
  279 |         await performed;
  280 |         await expect(currentGame(page)).toBeEnabled();
  281 |         await expect(result(page)).toHaveCount(0);
  282 |         await allLocked(page, game);
  283 |         expect(await played(page, game)).toBe(0);
  284 |         expect(await saved(page, game)).toBe(fresh?.game_id ?? null);
  285 |         expect(counts).toEqual({ reads: mutation ? 0 : 1, mutations: 1 });
  286 |         await currentGame(page).click();
  287 |         await expect(currentGame(page)).toHaveCount(0);
  288 |         if (fresh) await expect(page.locator(game.board)).toBeVisible();
  289 |         else await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  290 |         expect(await played(page, game)).toBe(0);
  291 |         await tab.close();
  292 |       });
  293 |     }
  294 | 
  295 |     test("browser Back preserves the saved round when a winning reply arrives during departure", async ({ page, request }) => {
  296 |       await page.goto("/");
  297 |       const title = game.key === "intrusul" ? "Intrusul" : "Perechi";
  298 |       await page.getByRole("button", { name: new RegExp(`^Joacă ${title} —`) }).click();
  299 |       const created = page.waitForResponse((response) => response.request().method() === "POST" && new URL(response.url()).pathname === `/api/wordgames/${game.key}/games`);
  300 |       await page.getByRole("button", { name: /^Joacă(?: →)?$/ }).click();
  301 |       const initial = await (await created).json();
  302 |       await expect(page.locator(game.board)).toBeVisible();
  303 |       const steps = solution(game).steps;
  304 |       for (const step of steps.slice(0, -1)) await act(page, game, step);
  305 |       const counts = traffic(page, game, initial.game_id);
  306 |       const held = await holdResponse(page, game, initial.game_id, steps.at(-1).action);
  307 |       const performed = act(page, game, steps.at(-1));
  308 |       await held.requested;
  309 |       await page.goBack();
  310 |       await expect(page).toHaveURL("/");
  311 |       held.release();
  312 |       await performed;
  313 |       await expect(page.locator(game.board)).toHaveCount(0);
> 314 |       expect(await played(page, game)).toBe(0);
      |                                        ^ Error: expect(received).toBe(expected) // Object.is equality
  315 |       expect(await saved(page, game)).toBe(initial.game_id);
  316 |       expect(counts).toEqual({ reads: 0, mutations: 1 });
  317 |       expect((await server(request, game, initial.game_id)).won).toBe(true);
  318 |     });
  319 | 
  320 |     for (const phase of ["mutation", "read", "unmounted"]) {
  321 |       test(`exit invalidates a held winning ${phase} reply and resume records once`, async ({ page, request }) => {
  322 |         const { initial, action, perform } = await prepare(page, request, game, "win");
  323 |         const counts = traffic(page, game, initial.game_id);
  324 |         if (phase === "read") await loseResponse(page, game, initial.game_id, action);
  325 |         const held = await holdResponse(page, game, initial.game_id, phase === "read" ? "" : action);
  326 |         const performed = perform();
  327 |         await held.requested;
  328 |         await page.getByRole("button", { name: "Ieși la lista de jocuri" }).click();
  329 |         if (phase === "unmounted") await expect(page.locator(game.board)).toHaveCount(0);
  330 |         held.release();
  331 |         await performed;
  332 |         await expect(page.locator(game.board)).toHaveCount(0);
  333 |         expect(await played(page, game)).toBe(0);
  334 |         expect(await saved(page, game)).toBe(initial.game_id);
  335 |         expect(counts).toEqual({ reads: phase === "read" ? 1 : 0, mutations: 1 });
  336 |         await page.goto(game.path);
  337 |         await expect(result(page)).toBeVisible();
  338 |         await expect.poll(() => played(page, game)).toBe(1);
  339 |         expect((await server(request, game, initial.game_id)).won).toBe(true);
  340 |       });
  341 |     }
  342 |   });
  343 | }
  344 | 
```