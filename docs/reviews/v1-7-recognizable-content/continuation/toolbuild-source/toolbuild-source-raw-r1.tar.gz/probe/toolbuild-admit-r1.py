import ctypes,hashlib,json,os,pathlib,shutil,stat,sys,time,datetime
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"):raise RuntimeError("optimized Python refused")
r=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-7-qualification");s=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification");probe=s/"probe";d=s/"toolbuild-r1"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
template=probe/"toolbuild-method-template-r1.json";template_bytes=template.read_bytes();expected_template=sys.argv[3];assert len(expected_template)==64;assert hashlib.sha256(template_bytes).hexdigest()==expected_template;v=json.loads(template_bytes)
method=d/"method-review-r1.json";expected_method=sys.argv[2];method_bytes=method.read_bytes();assert len(expected_method)==64 and hashlib.sha256(method_bytes).hexdigest()==expected_method
assert len(v["steps"])==2 and [x["name"] for x in v["steps"]]==["cat-content-rail","cat-content"]
assert v["go_sha256"]=="30969f97169d7f43fe6a085873d75613adc21e30818a8c61d95bd27275df4624"
for x in v["steps"]:
 assert x["argv"]==[v["linux_goroot"]+"/bin/go","-C",v["linux_stage"]+"/go-backend","build","-p","2","-o",x["linux_output"],"./cmd/"+x["name"]]
 assert pathlib.Path(x["windows_output"]).parent==pathlib.Path(v["windows_build_root"])/"tools" and not pathlib.Path(x["windows_output"]).exists()
 assert x["linux_output"]==v["linux_build_root"]+"/tools/"+x["name"]
assert v["target_before_sha256"]=="26b7dc0e7a4db0cd665c2593d86e55b2d5edff98f478374e0a8f3917e320512a" and v["target_after_sha256"]=="26b7dc0e7a4db0cd665c2593d86e55b2d5edff98f478374e0a8f3917e320512a"
for p,want in v["windows_protected"].items():assert sha(pathlib.Path(p))==want,p
assert sha(pathlib.Path(v["windows_target"]))==v["target_before_sha256"]
def lp(p):
 q=p.as_posix();assert q[1:3]==":/";return "/mnt/"+q[0].lower()+q[2:]
extras=[template,method,pathlib.Path(__file__),s/"toolbuild-method-source-admission-r1.json"]+list(d.glob("*.json"))
for p in extras:
 digest=expected_template if p==template else expected_method if p==method else sha(p)
 prior=v["windows_protected"].get(str(p));assert prior is None or prior==digest,"refusing immutable pin refresh"
 prior_linux=v["linux_protected"].get(lp(p));assert prior_linux is None or prior_linux==digest,"refusing immutable Linux pin refresh"
 v["windows_protected"][str(p)]=digest;v["linux_protected"][lp(p)]=digest
for p,want in v["windows_protected"].items():assert sha(pathlib.Path(p))==want,p
def count():
 total=0;pending=[r,s]
 while pending:
  with os.scandir(pending.pop()) as entries:
   for entry in entries:
    st=entry.stat(follow_symlinks=False)
    if getattr(st,"st_file_attributes",0)&0x400 or stat.S_ISLNK(st.st_mode):raise RuntimeError("owned reparse path")
    if stat.S_ISDIR(st.st_mode):pending.append(entry.path)
    elif stat.S_ISREG(st.st_mode):total+=st.st_size
    else:raise RuntimeError("owned nonregular path")
 return total
class M(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","totalPage","availablePage","totalVirtual","availableVirtual","extra"]]
m=M();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));disk=shutil.disk_usage(r).free;baseline=count()
assert disk>=17*1024**3 and m.available>=16*1024**3
now=time.time();v.update({"native_execution":"Fresh immutable two-tool pure-Go build admission; dispatch only after exact independent full source/resource/spec check; no stage mutation/operator/audit","started_epoch":now,"deadline_epoch":now+1200,"full_R_S_baseline":baseline,"host_launcher_pid":int(sys.argv[1]),"admission":{"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"disk_free_bytes":disk,"available_physical_bytes":m.available,"whole_R_S_baseline":baseline,"pre_dispatch_source_RSS":"unmeasured; native executor/controller group sampling begins at dispatch","method_sha256":expected_method}})
p=probe/"toolbuild-native-spec-r1.json";receipt=s/"toolbuild-native-admission-r1.json"
assert not p.exists() and not receipt.exists(),"fresh publication destinations already exist"
spec_bytes=(json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode("utf8");spec_digest=hashlib.sha256(spec_bytes).hexdigest()
receipt_bytes=(json.dumps({"spec_sha256":spec_digest,"spec":str(p),"admission":v["admission"],"started_epoch":now,"deadline_epoch":now+1200,"steps":v["steps"],"pending":"Independent exact spec/readset check; no Go tool build dispatched"},ensure_ascii=False,indent=2)+"\n").encode("utf8")
with p.open("xb") as stream:stream.write(spec_bytes)
with receipt.open("xb") as stream:stream.write(receipt_bytes)
assert sha(p)==spec_digest and receipt.read_bytes()==receipt_bytes,"exclusive publication drift"
print(json.dumps({"spec_sha256":spec_digest,"started_epoch":now,"deadline_epoch":now+1200,"protected_paths":len(v["windows_protected"]),"disk_free_bytes":disk,"available_physical_bytes":m.available,"full_R_S_baseline":baseline}))

