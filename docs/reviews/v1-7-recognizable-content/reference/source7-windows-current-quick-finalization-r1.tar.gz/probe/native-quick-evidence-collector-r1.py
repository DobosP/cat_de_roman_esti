
import pathlib,json,hashlib,os,stat,time,datetime,tarfile,ctypes,shutil
S=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7");P=S/"probe";O=S/"source7-current-quick-refresh-r1"
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open("xb") as f:f.write((json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode())
specpath=P/"native-quick-spec-r1.json";assert h(specpath)=="f64e30dec2c68cd250d0ff8f1458f96fda1a781579f1368170d8056e42c7539d"
v=json.loads(specpath.read_bytes());assert time.time()<v["deadline_epoch"]
n={};common=pathlib.Path(v["windows_common"]);assert h(common)==v["common_sha256"];exec(compile(common.read_bytes(),str(common),"exec"),n)
n["validate_contract"](v);n["full_readset"](v,"windows")
p=n["load_json"]((O/"proposal.json").read_bytes());a=n["load_json"]((O/"audit.json").read_bytes());c=n["load_json"](pathlib.Path(v["windows_candidate"]).read_bytes());ref=n["load_json"](pathlib.Path(v["windows_reference"]).read_bytes())
ps=h(O/"proposal.json");aus=h(O/"audit.json");assert ps=="fefea7b90e85988838519b0a0a8a594ce61ba171d5556d6dcb554b2feb179d0b" and aus=="1c6dc29547645bbb2efd291fb424a10d6a928c3aa4f43302dc6976151d665bd7"
n["check_proposal"](p,c,ref,v);n["check_audit"](a,p,ps,v)
state=n["load_json"]((O/"run/state.json").read_bytes());assert state["kind"]=="passed" and state["baseline"]==v["full_R_S_baseline"]
assert [(x["step"],x["boundary"],x["protected_files"]) for x in state["full_readset_checks"]]==[(i,b,1238) for i in (0,1) for b in ("pre","post")]
assert state["finished_epoch"]<v["deadline_epoch"]-180 and state["parent_inclusive_peak"]<=v["rss_cap"] and state["final_growth"]<=v["growth_cap"]
assert [x["step"] for x in state["completed"]]==["quick-proposal","quick-audit"]
samples=[];leaders=set()
for i,step in enumerate(v["steps"]):
 name=step["name"];events=[n["load_json"](x) for x in (O/"run"/(name+".telemetry.jsonl")).read_bytes().splitlines()]
 assert events[-1]["kind"]=="complete" and events[-1]["returncode"]==0 and events[-1]["group_absent"] is True
 assert events[-1]["native_peak"]==state["completed"][i]["native_peak"]<=v["rss_cap"]
 sample=[x for x in events if x["kind"]=="sample"];assert sample
 assert all(type(x["rss"]) is int and type(x["peak"]) is int and 0<=x["rss"]<=v["rss_cap"] and 0<=x["peak"]<=v["rss_cap"] for x in sample)
 nativeoutput=[x for x in events if x["kind"]=="quick-output"];assert len(nativeoutput)==1
 assert nativeoutput[0]["output_sha256"]==h(pathlib.Path(step["windows_output"]))==state["completed"][i]["output_sha256"]
 if i:assert nativeoutput[0]["proposal_sha256"]==ps
 out=(O/"run"/(name+".stdout.log")).read_bytes();assert n["json_equal"](n["load_json"](out),dict(mode="proposal" if i==0 else "audit",ok=True,rail="quick"))
 for suffix in ("stderr.log","controller.stderr.log"):assert (O/"run"/(name+"."+suffix)).read_bytes()==b""
 samples.append(dict(step=name,samples=len(sample),native_peak=events[-1]["native_peak"],complete=events[-1],output=nativeoutput[0]))
 leaders|={(x["pid"],x["start_ticks"]) for x in sample if "pid" in x}
linux=json.loads((S/"native-quick-linux-closure-r1.json").read_bytes());assert linux["observed_recorded_pids"]==linux["observed_recorded_groups"]==[] and {(x["pid"],x["start_ticks"]) for x in linux["recorded_child_generations"]}==leaders
finals={}
for role,identity in (("factual","/root/qualification_ledger"),("quality","/root/continuation_audit")):
 f=O/(role+"-final-r1.json");x=n["load_json"](f.read_bytes());assert x["kind"]=="quick-content-final-v1" and x["role"]==role and x["reviewer"]==identity and x["catalog_sha256"]==ps and x["audit_sha256"]==aus and x["verdict"]=="accept";finals[role]=dict(sha256=h(f),bytes=f.stat().st_size,reviewer=identity)
outer=S/"native-quick-outer-tool-observation-r1.json";save(outer,dict(kind="root-tool-return-transcription",session_id=50692,observed_utc="2026-10-09T14:46:45Z",actual_tool_exit_code=0,actual_terminal_stdout='{"kind": "PASS", "completed": 2, "parent_inclusive_peak": 305487872, "growth": 10257249}\n',scope="genuine outer tool completion observed by root; separate from native raw logs/state"))
windows=S/"native-quick-windows-closure-r1.json";save(windows,dict(kind="root-CIM-tool-return-transcription",observed_utc="2026-10-09T14:48:29Z",recorded_process_generations=[dict(pid=29668,creation_utc="2026-10-09T14:39:06.346376Z"),dict(pid=25428,creation_utc="2026-10-09T14:42:32.723926Z"),dict(pid=29492,creation_utc="2026-10-09T14:42:36.723120Z"),dict(pid=44968,creation_utc="2026-10-09T14:39:06.642353Z")],current_rows=[],scope="recorded generations absent; audit carrier generation and Linux supervisor IDs were not durably captured; their closure also relies on actual complete/carrier/outer exit and independent matching-argv absence"))
def count(root):
 nbytes=files=dirs=0;stack=[pathlib.Path(root)]
 while stack:
  q=stack.pop();st=q.lstat();assert stat.S_ISDIR(st.st_mode) and not getattr(st,"st_file_attributes",0)&0x400;dirs+=1
  for e in os.scandir(q):
   st=e.stat(follow_symlinks=False);assert not stat.S_ISLNK(st.st_mode) and not getattr(st,"st_file_attributes",0)&0x400
   if stat.S_ISDIR(st.st_mode):stack.append(pathlib.Path(e.path))
   else:assert stat.S_ISREG(st.st_mode);nbytes+=st.st_size;files+=1
 return dict(bytes=nbytes,files=files,dirs=dirs)
counts={x:count(x) for x in v["accounting_roots"]};total=sum(x["bytes"] for x in counts.values());assert total-v["full_R_S_baseline"]+(16<<20)<=v["growth_cap"] and shutil.disk_usage(S).free>=16<<30
result=S/"native-quick-actual-results-r1.json";save(result,dict(kind="actual-quick-two-step-results-v1",spec_sha256=h(specpath),admission_sha256=h(S/"native-quick-actual-admission-r1.json"),source_boundary_sha256=h(S/"quick-parent-correction-source-boundary-r3.json"),proposal_sha256=ps,audit_sha256=aus,proposal_bytes=(O/"proposal.json").stat().st_size,audit_bytes=(O/"audit.json").stat().st_size,authored_boards=85,rated_boards=85,nodes=322,replays=85,requests=a["requests"],games=dict(intrusul=45,perechi=40),public_seed_range=[min(x["public_seed"] for x in a["replays"]),max(x["public_seed"] for x in a["replays"])],runtime_sources=131,source_bindings=9,all_privacy_terminal_score_checks=True,protected_post_files=1238,immutable_stage_files=1200,immutable_stage_dirs=224,full_readset_checks=state["full_readset_checks"],native_steps=samples,parent_inclusive_peak=state["parent_inclusive_peak"],declared_RSS_scope=state["rss_scope"],RSS_limitations="sampled declared PS/controller/WSL/Linux group only; console helper excluded, no continuous or whole OS process-tree claim; source/metadata/resource-probe RSS unmeasured",original_baseline=v["full_R_S_baseline"],native_final_growth=state["final_growth"],fresh_root_counts=counts,fresh_total=total,fresh_growth=total-v["full_R_S_baseline"],finished_epoch=state["finished_epoch"],deadline_epoch=v["deadline_epoch"],outer_observation_sha256=h(outer),windows_closure_sha256=h(windows),linux_closure_sha256=h(S/"native-quick-linux-closure-r1.json"),finals=finals,actual_reviews=dict(factual=dict(reviewer="/root/qualification_ledger",frozen_utc="2026-10-09T14:50:00.541123Z",verdict="accept"),quality=dict(reviewer="/root/continuation_audit",frozen_utc="2026-10-09T14:50:31Z",verdict="ACCEPT_ACTUAL_QUICK_PROPOSAL_AND_AUDIT_EVIDENCE_ONLY")),scope="accepted exact prospective Quick catalog/audit and genuine same-role finals only; stage unchanged, Source6 live, no Quick transition/installation/V1.7 qualification",next_action="fresh source-reviewed guarded isolated Quick transition, then affected derived/pin/current authority/installed audit/finals and full V1.7 gates"))
members=[specpath,S/"native-quick-actual-admission-r1.json",P/"native-quick-dispatch-approval-r1.json",S/"quick-parent-correction-source-boundary-r3.json",S/"quick-parent-correction-source-r3.tar.gz",S/"quick-parent-correction-source-archive-r3.json",common,P/"native-quick-windows-r4.py",P/"native-quick-linux-r3.py",P/"native-quick-template-r9.json",pathlib.Path(v["windows_candidate"]),pathlib.Path(v["windows_source"]),pathlib.Path(v["windows_factual"]),pathlib.Path(v["windows_quality"]),outer,windows,S/"native-quick-linux-closure-r1.json",result]
members+=sorted(q for q in O.rglob("*") if q.is_file())
archive=S/"native-quick-complete-evidence-r1.tar.gz";assert not archive.exists()
manifest=[dict(path=q.relative_to(S).as_posix(),sha256=h(q),bytes=q.stat().st_size) for q in members]
with tarfile.open(archive,"w:gz") as out:
 for q in members:out.add(q,arcname=q.relative_to(S).as_posix(),recursive=False)
lookup={q.relative_to(S).as_posix():q for q in members}
with tarfile.open(archive,"r:gz") as inp:
 assert len(inp.getmembers())==len(members)
 for row in inp:assert inp.extractfile(row).read()==lookup[row.name].read_bytes()
assert time.time()<v["deadline_epoch"]
post={x:count(x) for x in v["accounting_roots"]};finaltotal=sum(x["bytes"] for x in post.values());assert finaltotal-v["full_R_S_baseline"]+(1<<20)<=v["growth_cap"] and shutil.disk_usage(S).free>=16<<30
receipt=S/"native-quick-complete-evidence-r1.json";save(receipt,dict(kind="actual-quick-complete-evidence-manifest-v1",archive_sha256=h(archive),archive_bytes=archive.stat().st_size,result_sha256=h(result),members=manifest,all_member_readback=True,closed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_native_deadline_epoch=v["deadline_epoch"],original_resource_baseline=v["full_R_S_baseline"],fresh_full_root_counts=post,final_total=finaltotal,final_growth_before_manifest=finaltotal-v["full_R_S_baseline"],reserved_final_metadata_bytes=1<<20,metadata_RSS="unmeasured",scope="exact actual Quick evidence/finals; no transition/installed/release qualification"))
print(json.dumps(dict(archive_sha256=h(archive),archive_bytes=archive.stat().st_size,members=len(members),manifest_sha256=h(receipt),result_sha256=h(result),final_growth=finaltotal-v["full_R_S_baseline"],closed_utc=json.loads(receipt.read_bytes())["closed_utc"])))
