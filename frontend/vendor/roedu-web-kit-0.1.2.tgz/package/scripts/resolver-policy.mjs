import assert from 'node:assert/strict';

export const stable = value => typeof value === 'string' && /^v?\d+\.\d+\.\d+$/.test(value);
export function compare(a, b) {
  assert.ok(stable(a) && stable(b), `Incomparable stable versions: ${a}/${b}`);
  const aa=a.replace(/^v/,'').split('.').map(BigInt),bb=b.replace(/^v/,'').split('.').map(BigInt);
  for(let i=0;i<3;i++)if(aa[i]!==bb[i])return aa[i]>bb[i]?1:-1;
  return 0;
}
export function selectStable(metadata, major) {
  assert.ok(metadata && typeof metadata.versions === 'object', 'Registry version map required');
  return Object.keys(metadata.versions).filter(v=>stable(v)&&(!major||v.startsWith(`${major}.`))).sort(compare).at(-1);
}
export const frozenTool = entry => ['playwright','@playwright/test','playwright-image','postgres'].includes(entry.tool)
  || ['image','apt'].includes(entry.kind) || entry.scope==='environment' || entry.status==='banned' || entry.status==='transitive-only';
export async function resolveEntry(entry, get, date) {
  if(frozenTool(entry)||!entry.version)return structuredClone(entry);
  let version=entry.version,source=entry.source,released=entry.released;
  if(entry.kind==='npm') {
    const url=`https://registry.npmjs.org/${entry.tool}`,metadata=await get(url);
    version=entry.tool==='@babel/core'?selectStable(metadata,7):stable(metadata['dist-tags']?.latest)?metadata['dist-tags'].latest:selectStable(metadata);
    assert.ok(stable(version),`${entry.tool}: no stable release`);
    source=`${url}/${version}`;released=metadata.time?.[version]?.slice(0,10);
  } else if(entry.kind==='gomod') {
    const escaped=entry.tool.replace(/[A-Z]/g,c=>'!'+c.toLowerCase());
    const metadata=await get(`https://proxy.golang.org/${escaped}/@latest`);
    version=metadata.Version;assert.ok(stable(version),`${entry.tool}: prerelease/pseudo-version`);
    assert.ok(typeof metadata.Time==='string',`${entry.tool}: release time required`);
    source=`https://proxy.golang.org/${escaped}/@v/${version}.info`;released=metadata.Time.slice(0,10);
  } else if(entry.kind==='runtime'&&entry.tool==='node') {
    const metadata=(await get('https://nodejs.org/dist/index.json')).filter(x=>stable(x.version)).sort((a,b)=>compare(a.version,b.version)).at(-1);
    assert.ok(metadata,'Node: no stable release');version=metadata.version.slice(1);released=metadata.date;
  } else if(entry.kind==='runtime'&&entry.tool==='go') {
    const metadata=(await get('https://go.dev/dl/?mode=json')).filter(x=>x.stable&&stable(x.version?.slice(2))).sort((a,b)=>compare(a.version.slice(2),b.version.slice(2))).at(-1);
    assert.ok(metadata,'Go: no stable release');version=metadata.version.slice(2);
  } else return structuredClone(entry);
  assert.ok(compare(version,entry.version)>=0,`${entry.tool}: downgrade ${entry.version}->${version}`);
  if((entry.rebuild||entry.kind==='runtime')&&version!==entry.version)throw Error(`TOOLCHAIN REBUILD NEEDED ${entry.tool} ${entry.version}->${version}`);
  return {...structuredClone(entry),version,source,date,...(released?{released}:{})};
}
