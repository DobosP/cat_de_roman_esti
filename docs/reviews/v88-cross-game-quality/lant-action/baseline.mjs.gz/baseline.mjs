import { chromium } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v88-cross-game-quality/frontend/node_modules/playwright/index.mjs';
import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
const root='/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v88-cross-game-quality';
const out='/home/dobo/work/_temp/feat__v88-cross-game-quality/lant-action';
const steps=JSON.parse(execFileSync('/home/dobo/work/cat_de_roman_esti/.venv/bin/python',[`${root}/frontend/e2e/solutions.py`,'lant'],{cwd:root,env:{...process.env,PYTHONPATH:root},encoding:'utf8'})).steps;
const browser=await chromium.launch();
const page=await browser.newPage();
await page.route('**/api/wordgames/lant/games?*',r=>{const u=new URL(r.request().url());u.searchParams.set('seed','38');return r.continue({url:u.toString()});});
async function start(){await page.goto('http://127.0.0.1:8188/lant'); const wait=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname==='/api/wordgames/lant/games');await page.getByRole('button',{name:/^Joacă(?: →)?$/}).click();return (await wait).json();}
async function act(step){const wait=page.waitForResponse(r=>new URL(r.url()).pathname.endsWith('/move'));await page.getByRole('textbox',{name:'Următorul concept'}).fill(step.payload.text);await page.getByRole('textbox',{name:'Următorul concept'}).press('Enter');const r=await wait;await page.getByRole('textbox',{name:'Următorul concept'}).waitFor({state:'visible'});return r;}
const game=await start();const id=game.game_id;let committedHint;
await page.route(`**/games/${id}/hint`,async r=>{const response=await r.fetch();committedHint=await response.json();await r.fulfill({status:503,contentType:'application/json',body:'{}'});},{times:1});
let wait=page.waitForResponse(r=>new URL(r.url()).pathname.endsWith('/hint'));await page.getByRole('button',{name:'💡 Indiciu',exact:true}).click();await wait;await page.getByRole('button',{name:'💡 Indiciu',exact:true}).waitFor({state:'visible'});
const afterHint=await (await page.request.get(`http://127.0.0.1:8188/api/wordgames/lant/games/${id}`)).json();
await page.screenshot({path:`${out}/baseline-lost-hint.png`,fullPage:true});
wait=page.waitForResponse(r=>new URL(r.url()).pathname.endsWith('/hint'));await page.getByRole('button',{name:'💡 Indiciu',exact:true}).click();const retriedHint=await(await wait).json();
for(const step of steps.slice(0,-1))await act(step);
let committedWin; await page.route(`**/games/${id}/move`,async r=>{const response=await r.fetch();committedWin=await response.json();await r.fulfill({status:503,contentType:'application/json',body:'{}'});},{times:1});
await act(steps.at(-1));await page.getByRole('textbox',{name:'Următorul concept'}).isEnabled();
const afterWin=await(await page.request.get(`http://127.0.0.1:8188/api/wordgames/lant/games/${id}`)).json();
const proof={baseline:'fa8cffd',committedHint,retriedHint,readHasEarnedHint:Object.hasOwn(afterHint,'earned_hint'),committedWin,serverWon:afterWin.won,clientHasResult:await page.getByRole('button',{name:'Copiază rezultatul'}).count(),played:await page.evaluate(()=>JSON.parse(localStorage.getItem('cat_wordgame_scores_v1')||'{}').lant?.played??0)};
writeFileSync(`${out}/baseline-proof.json`,JSON.stringify(proof,null,2)+'\n');await page.screenshot({path:`${out}/baseline-lost-win.png`,fullPage:true});await browser.close();console.log(JSON.stringify({readHasEarnedHint:proof.readHasEarnedHint,firstHint:committedHint.stage,retryHint:retriedHint.stage,serverWon:proof.serverWon,clientHasResult:proof.clientHasResult,played:proof.played}));
