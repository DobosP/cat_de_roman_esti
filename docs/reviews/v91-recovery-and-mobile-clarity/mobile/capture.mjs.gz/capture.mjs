import { chromium } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/node_modules/@playwright/test/index.mjs';
import { mkdir, writeFile } from 'node:fs/promises';
const [phase, widthText, port='8189'] = process.argv.slice(2);
const width=Number(widthText), directory=`/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/mobile/${phase}`;
await mkdir(directory,{recursive:true});
const browser=await chromium.launch();
const rows=[];
for(const [key,path,board] of [['alchimie','alchimie','.alchemy-inventory-grid'],['intrusul','intrusul','.intrusul-grid'],['perechi','perechi','.perechi-grid'],['conexiuni','conexiuni','.connections-grid'],['contexto','cald-rece','[aria-label="Concept de ghicit"]'],['lant','lant','[aria-label="Următorul concept"]']]) {
 const context=await browser.newContext({viewport:{width,height:850},reducedMotion:'reduce',locale:'ro-RO',isMobile:width<=640,hasTouch:width<=640});
 const page=await context.newPage(); page.setDefaultTimeout(60000);
 await page.route(`**/api/wordgames/${key}/games?*`,async route=>{const url=new URL(route.request().url());url.searchParams.set('seed','38');await route.continue({url:String(url)});});
 await page.goto(`http://127.0.0.1:${port}/${path}`);
 await page.getByRole('button',{name:/^Joacă(?: →)?$/}).click();
 await page.locator(board).waitFor({state:'visible'});
 for(const state of ['live','resume']) {
  if(state==='resume'){await page.reload();await page.locator(board).waitFor({state:'visible'});await page.getByText(/^Joc reluat\./).waitFor({state:'visible'});}
  await page.evaluate(async()=>{await document.fonts.ready;await Promise.all(document.getAnimations().filter(a=>Number.isFinite(a.effect?.getComputedTiming().endTime)).map(a=>a.finished.catch(()=>{})));});
  const metrics=await page.evaluate(()=>{
   const rect=e=>{if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,right:r.right,bottom:r.bottom};};
   const hud=document.querySelector('.hud');const notice=document.querySelector('.roedu-toast');const header=document.querySelector('.game-shell-header');
   const items=hud?[...hud.children].map(e=>({text:e.textContent,rect:rect(e)})):[];
   return {viewport:{width:innerWidth,height:innerHeight},pageWidth:document.documentElement.scrollWidth,screenWidth:document.querySelector('.screen-pad').scrollWidth,header:rect(header),hud:rect(hud),hudScrollWidth:hud?.scrollWidth,title:rect(document.querySelector('.game-shell-title')),exit:rect(header?.querySelector('button')),notice:rect(notice),items};
  });
  const name=`${key}-${width}-${state}`;await page.screenshot({path:`${directory}/${name}.png`});rows.push({key,state,width,...metrics});console.log(JSON.stringify({phase,key,state,width,header:metrics.header,hud:metrics.hud,hudScrollWidth:metrics.hudScrollWidth,notice:metrics.notice}));
 }
 await context.close();
}
await writeFile(`${directory}/metrics-${width}.json`,JSON.stringify(rows,null,2)+'\n');await browser.close();
