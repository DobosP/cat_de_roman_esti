from pathlib import Path
import difflib
import hashlib

root = Path('/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity')
scratch = Path('/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/sparse-recipe-audit')
relative = 'tests/test_alchimie_sparse_recipes.py'
original = (root / relative).read_text()
source = original.replace(
    'from tests.content_history import before_v88_fixture, before_v88_pack  # noqa: E402',
    'from tests.content_history import (  # noqa: E402\n'
    '    before_v88_fixture,\n'
    '    before_v88_pack,\n'
    '    before_v91_artifact,\n'
    ')',
)
fixture = '''@pytest.fixture(scope="module")
def v90_projection_snapshot(approved_projections):
    """Restore only the reviewed Sport seeds; preserve the complete V90 contract."""
    fixtures = Path(__file__).resolve().parents[1] / "cat_de_roman_esti/fixtures"
    graph = json.loads((fixtures / "kg_sample.json").read_bytes())
    assert before_v91_artifact(graph, "kg_sample.json") == graph
    current = json.loads((fixtures / "games_pack.json").read_bytes())
    previous = before_v91_artifact(current, "games_pack.json")
    before = {row["id"]: row for row in previous["alchimie"]}
    after = {row["id"]: row for row in current["alchimie"]}
    assert before.keys() == after.keys()
    assert [key for key in before if before[key] != after[key]] == ["al_sport_083"]
    record = before["al_sport_083"]
    old_projection = A._build_recipe_projection(
        record["seeds"], record["target"], record["category"],
    )
    assert old_projection is not None
    rows, minima = [], []
    for item, projection in approved_projections[0]:
        if item.id == "al_sport_083":
            projection = old_projection
        rows.append(_projection_row(item, projection))
        minima.extend(A._route_quality(route)[0] for route in projection.routes)
    return rows, minima


'''
marker = 'def test_all_approved_boards_have_sparse_deterministic_target_routes(\n'
assert source.count(marker) == 1
source = source.replace(marker, fixture + marker)
source = source.replace(
    '    approved_projections, v87_projection_snapshot,\n',
    '    approved_projections, v87_projection_snapshot, v90_projection_snapshot,\n',
)
old_assert = '    assert [row for row in rows if row["id"] != "al_gastronomie_107"] == historical_rows\n'
new_assert = '''    previous_rows, _previous_minima = v90_projection_snapshot
    assert len(previous_rows) == 80
    assert hashlib.sha256(json.dumps(
        previous_rows, sort_keys=True, separators=(",", ":"),
    ).encode()).hexdigest() == (
        "422eb7f711b6cfb1593a0d3b8b8176f16afdf412303b1c65e1da14a1c6ecf1ad"
    )
    assert [row for row in previous_rows if row["id"] != "al_gastronomie_107"] == historical_rows
    assert hashlib.sha256(json.dumps(
        rows, sort_keys=True, separators=(",", ":"),
    ).encode()).hexdigest() == (
        "1e8a7956c6a63bb62d6e9ca42dc00d240efe02438bb33c7344805a5223094d04"
    )
    assert [old["id"] for old, new in zip(previous_rows, rows, strict=True)
            if old != new] == ["al_sport_083"]
'''
assert source.count(old_assert) == 1
source = source.replace(old_assert, new_assert)
source = source.replace(
    '    assert recipe_count == 555  # V88 adds five reviewed Cremșnit recipes.\n'
    '    assert tied_count == 77\n',
    '    assert sum(len(row["recipes"]) for row in previous_rows) == 555\n'
    '    assert sum(len(recipe) == 4 for row in previous_rows for recipe in row["recipes"]) == 77\n'
    '    assert recipe_count == 554  # V91 replaces Sport 083\'s seven recipes with six.\n'
    '    assert tied_count == 76  # Its old two-result recipe is no longer needed.\n',
)
source = source.replace(
    '    assert median(selected_minima) == pytest.approx(0.67)\n',
    '    assert median(v90_projection_snapshot[1]) == pytest.approx(0.67)\n'
    '    assert median(selected_minima) == pytest.approx(0.68)\n',
)
assert source != original
patch = ''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True),
                                   fromfile='a/' + relative, tofile='b/' + relative))
(scratch/'sparse-recipe-expectations.patch').write_text(patch)
(scratch/'candidate-original-layout.py').write_text(source)
# The scratch-only pytest copy explicitly reads the unchanged repository fixtures.
# The proposed repository patch above retains the normal __file__-relative lookup.
scratch_source = source.replace('Path(__file__).resolve().parents[1]', repr(str(root)))
(scratch/'test_candidate_sparse_recipes.py').write_text(scratch_source.replace(
    repr(str(root)) + ' / "cat_de_roman_esti/fixtures"',
    'Path(' + repr(str(root)) + ') / "cat_de_roman_esti/fixtures"',
))
print('Original source SHA256:', hashlib.sha256(original.encode()).hexdigest())
print('Proposed source SHA256:', hashlib.sha256(source.encode()).hexdigest())
print(patch)
