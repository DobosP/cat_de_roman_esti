import './diagnostics';
import { test,expect } from '../../playwright/index.mjs';
import { readFileSync,writeFileSync,mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
test('csp-trap measured browser events, console and actual server reports',async({page,request})=>{
  if(!process.env.GATE_APP_URL)throw Error('Live app required');
  const consoleEvents:string[]=[];
  page.on('console',message=>{if(/Content Security Policy|TrustedHTML|TrustedScript|TrustedScriptURL|violates.*policy/i.test(message.text()))consoleEvents.push(message.text());});
  await page.addInitScript(()=>{
    (window as typeof window & {roeduViolations:string[]}).roeduViolations=[];
    document.addEventListener('securitypolicyviolation',event=>(window as typeof window & {roeduViolations:string[]}).roeduViolations.push(`${event.violatedDirective}:${event.blockedURI}`));
  });
  const manifest=JSON.parse(readFileSync('web-kit/sample/embedfs/dist/.vite/manifest.json','utf8'));const entry=manifest['src/sample/main.ts'];expect(entry).toBeTruthy();
  const expectedCss=new Set<string>(),expectedPreloads=new Set<string>(),visited=new Set<string>();
  function closure(key:string){if(visited.has(key))return;visited.add(key);const item=manifest[key];expect(item).toBeTruthy();for(const file of item.css??[])expectedCss.add(`/static/${file}`);for(const dependency of item.imports??[]){expectedPreloads.add(`/static/${manifest[dependency].file}`);closure(dependency);}}
  closure('src/sample/main.ts');
  const allowedCss=new Set(expectedCss),allowedJs=new Set<string>(),allEntries=new Set<string>();
  function allClosure(key:string){if(allEntries.has(key))return;allEntries.add(key);const item=manifest[key];expect(item).toBeTruthy();allowedJs.add(`/static/${item.file}`);for(const file of item.css??[])allowedCss.add(`/static/${file}`);for(const dep of [...item.imports??[],...item.dynamicImports??[]])allClosure(dep);}
  allClosure('src/sample/main.ts');
  const appURL=new URL(process.env.GATE_APP_URL);
  const assetPath=(value:string)=>{const url=new URL(value);expect(url.origin).toBe(appURL.origin);expect(url.href).toBe(new URL(url.pathname,appURL).href);return url.pathname;};
  let browserViolations=0;const pages=['/','/pongo2','/islands','/behaviors','/motion','/templ'];const nonceObservations:{page:string;nonce_sha256:string;scripts:number;json:number;assetLinks:number;module:string;css:string[];preloads:string[];module_url:string;css_urls:string[];preload_urls:string[]}[]=[];
  for(const path of pages){
    const response=await page.goto(path);expect(response?.status()).toBe(200);
    const headers=response!.headers();const stage=process.env.CSP_STAGE??'report-only';
    expect(headers[stage==='enforced'?'content-security-policy':'content-security-policy-report-only']).toContain("script-src-attr 'none'");
    const policy=headers[stage==='enforced'?'content-security-policy':'content-security-policy-report-only'];
    const nonce=policy.match(/'nonce-([^']+)'/)?.[1];expect(nonce).toBeTruthy();
    const directives=new Map(policy.split(';').map(d=>d.trim().split(/\s+/)).filter(d=>d[0]).map(d=>[d[0],d.slice(1)]));
    for(const [name,tokens] of [['default-src',["'self'"]],['script-src',["'self'",`'nonce-${nonce}'`,"'strict-dynamic'"]],['script-src-attr',["'none'"]],['style-src',["'self'",`'nonce-${nonce}'`]],['style-src-attr',["'none'"]],['object-src',["'none'"]],['base-uri',["'self'"]],['frame-ancestors',["'none'"]],['form-action',["'self'"]],['connect-src',["'self'"]],['worker-src',["'self'"]],['report-uri',['/csp-report']]] as const)expect(directives.get(name)).toEqual([...tokens]);
    expect(policy).not.toMatch(/unsafe-inline|unsafe-eval/);
    const tags=await page.evaluate(()=>({scripts:[...document.scripts].map(script=>({type:script.type,id:script.id,src:script.src,nonce:script.nonce})),links:[...document.querySelectorAll<HTMLLinkElement>('link[rel="stylesheet"],link[rel="modulepreload"]')].map(link=>({rel:link.rel,href:link.href,nonce:link.nonce}))}));
    expect(tags.scripts.some(script=>script.type==='module'&&script.src)).toBe(true);expect(tags.scripts.filter(script=>script.type==='application/json').length).toBe(7);expect(tags.links.length).toBeGreaterThan(0);
    for(const script of tags.scripts)expect(script.nonce).toBe(nonce);for(const link of tags.links)expect(link.nonce).toBe(nonce);
    const moduleURLs=tags.scripts.filter(script=>script.type==='module'&&script.src).map(script=>script.src),cssURLs=tags.links.filter(link=>link.rel==='stylesheet').map(link=>link.href),preloadURLs=tags.links.filter(link=>link.rel==='modulepreload').map(link=>link.href);
    const modules=moduleURLs.map(assetPath);expect(modules).toEqual([`/static/${entry.file}`]);
    const css=cssURLs.map(assetPath),preloads=preloadURLs.map(assetPath);
    for(const file of expectedCss)expect(css).toContain(file);for(const file of expectedPreloads)expect(preloads).toContain(file);
    for(const file of css)expect(allowedCss.has(file)).toBe(true);for(const file of preloads)expect(allowedJs.has(file)).toBe(true);
    nonceObservations.push({page:path,nonce_sha256:createHash('sha256').update(nonce!).digest('hex'),scripts:tags.scripts.length,json:tags.scripts.filter(script=>script.type==='application/json').length,assetLinks:tags.links.length,module:modules[0],css,preloads,module_url:moduleURLs[0],css_urls:cssURLs,preload_urls:preloadURLs});
    await expect(page.locator('[data-island="stress-counter"][data-load="eager"]')).toContainText('Increment counter');
    await page.locator('[data-island="stress-counter"][data-load="interaction"]').click();
    await expect(page.locator('[data-island="stress-counter"][data-load="interaction"]')).toContainText('Increment counter');
    await page.getByRole('button',{name:'Sample person',exact:true}).focus();
    await expect(page.locator('roedu-hovercard')).toContainText('Sample person');
    await page.getByRole('button',{name:'Text size',exact:true}).click();
    await page.getByRole('button',{name:'Reset comfort',exact:true}).click();
    browserViolations+=await page.evaluate(()=>(window as typeof window & {roeduViolations:string[]}).roeduViolations.length);
  }
  // Browser report delivery is asynchronous; observe the server after all pages.
  await page.waitForTimeout(400);
  const reports=await request.get('/__gate/csp');expect(reports.status()).toBe(200);
  const server=await reports.json();expect(server.stage).toBe(process.env.CSP_STAGE??'report-only');expect(Number.isInteger(server.violations)).toBe(true);
  expect(new Set(nonceObservations.map(x=>x.nonce_sha256)).size).toBe(pages.length);
  const measurements={schema:1,sha:process.env.GATE_SHA,tree_sha256:process.env.GATE_TREE_SHA256,app_image_id:process.env.GATE_APP_IMAGE_ID,stage:server.stage,violations:server.violations+browserViolations+consoleEvents.length,legacy_violations:0,pages:pages.length,browser:browserViolations,server:server.violations,console:consoleEvents,server_directives:server.directives,nonceObservations};
  mkdirSync('.gate/full',{recursive:true});writeFileSync('.gate/full/csp-measurement.json',JSON.stringify(measurements,null,2)+'\n');
  expect(measurements.violations).toBe(0);
});
