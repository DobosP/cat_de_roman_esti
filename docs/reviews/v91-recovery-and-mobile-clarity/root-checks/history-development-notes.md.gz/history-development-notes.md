Initial targeted Ruff check failed E501 in tests/test_v91_content_history.py:26 (108 >100 columns), solely the mobile hash literal. Wrapped the value without changing it; final Ruff gate pending.
