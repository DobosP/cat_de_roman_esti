import pathlib,json,hashlib,os,stat,time,datetime,tarfile,io,sys
if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):raise RuntimeError('optimized source mutation refused before side effects')
S=pathlib.Path(r"C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7")
I=S/"source7-candidate-1200";O=S/"source7-current-quick-pin-update-r2"
a=json.loads((S/"quick-pin-source-checkpoint-admission-r2.json").read_bytes());assert time.time()<a["cutoff_epoch"]
old=b"34c11c48b28b45c53a741290837288d302c98cea51e4346fb64669d7188c7a8c";new=b"fefea7b90e85988838519b0a0a8a594ce61ba171d5556d6dcb554b2feb179d0b"
expected={
"go-backend/internal/contentbuild/build.go":("60d9c5262287d52cf4e2d97fee056f1462cc3c554dd15cfb0ab267a96304dd61",1,"c3bc41e90784244e69ebc59401dee6c582b29ed16fe5e59e53283c8c5f661756"),
"cat_de_roman_esti/wordgames/quick_catalog.py":("be3a07e7e32f5b97dfb84a45f0ff4fb75e750fa61b86f129dbb805e85a1751c6",1,"c78cbe29238a8bd9093760ef569b1e68b9ec9b92b527b98385b96f1a05050ab4"),
"go-backend/internal/contentbuild/source7_build_test.go":("080273c51ccf9592baf98515cf42faaf96ecaffe955170f3f1db7019468fd3dc",1,"d9da4a0b77878b7a62d1cc1a353795c6305932afbbc0a2e8cb2f7ba5e2377236"),
"go-backend/internal/httpapi/source7_ordinary_inputs_test.go":("b7f67cd5f7d164b10b1440cda4c8c9d5298d8c30fd78f8b2daeb9110c0a724a2",2,"0378594786df7c65805d1d19c2a06f48c3d12b9f35d73b65412132a44a4941ee"),
"go-backend/internal/httpapi/source7_held_inputs_test.go":("b4fcdd32cf38049e1b7e55219f652660ea3249317866e26cd5017331c8d515ff",1,"a13626777cef1a1575154458a4ac423088d575e8c7dbe5d5d22f18c2cfdcdc5e")}
H=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((S/"native-quick-transition-post-I1200-r1.json").read_bytes())
def inventory():
 files={};dirs=[]
 for root,ds,fs in os.walk(I,followlinks=False):
  p=pathlib.Path(root);q=p.lstat();assert stat.S_ISDIR(q.st_mode) and not stat.S_ISLNK(q.st_mode) and not q.st_file_attributes&0x400
  assert time.time()<a["cutoff_epoch"]
  rel=p.relative_to(I).as_posix();dirs.append(rel);assert stat.S_IMODE(q.st_mode)==m["windows_dir_modes"][rel]
  for n in fs:
   x=p/n;r=x.relative_to(I).as_posix();st=x.lstat();assert stat.S_ISREG(st.st_mode) and not stat.S_ISLNK(st.st_mode) and not st.st_file_attributes&0x400 and st.st_nlink==1
   assert stat.S_IMODE(st.st_mode)==m["windows_file_modes"][r]
   files[r]=H(x.read_bytes())
 assert set(files)==set(m["stage_files"]) and set(dirs)==set(m["stage_dirs"])
 return files,sorted(dirs)
before,dirs=inventory();assert before==m["stage_files"]
assert not O.exists() and not O.is_symlink();O.mkdir()
rows=[];images={}
for rel,(sha,n,aftersha) in expected.items():
 p=I/rel;b=p.read_bytes();assert H(b)==sha and b.count(old)==n and new not in b
 z=b.replace(old,new);assert len(z)==len(b) and H(z)==aftersha
 images[rel]=(b,z);rows.append({"path":rel,"before_sha256":sha,"after_sha256":aftersha,"bytes":len(b),"substitutions":n})
# Save every exact before-image before the first write.
with (O/"before-images.tar.gz").open("xb") as f:
 with tarfile.open(fileobj=f,mode="w:gz") as t:
  for rel,(b,z) in images.items():
   x=tarfile.TarInfo(rel);x.mode=0o600;x.size=len(b);t.addfile(x,io.BytesIO(b))
 f.flush();os.fsync(f.fileno())
with tarfile.open(O/"before-images.tar.gz","r:gz") as t:
 for x in t:assert t.extractfile(x).read()==images[x.name][0]
assert time.time()<a["cutoff_epoch"]
for rel,(b,z) in images.items():
 assert time.time()<a["cutoff_epoch"]
 p=I/rel;st=p.lstat();assert p.read_bytes()==b and st.st_nlink==1
 with p.open("r+b") as f:f.write(z);f.flush();os.fsync(f.fileno())
 q=p.lstat();assert (q.st_dev,q.st_ino,q.st_mode,q.st_size)==(st.st_dev,st.st_ino,st.st_mode,st.st_size) and p.read_bytes()==z
after,dirs2=inventory();want=dict(before)
for r in rows:want[r["path"]]=r["after_sha256"]
assert after==want and dirs2==dirs and len(after)==1200
bindings=json.loads((S/"native-quick-transition-post-bindings-r1.json").read_bytes());runtime=dict(bindings["runtime131"])
assert set(runtime)&set(expected)=={"go-backend/internal/contentbuild/build.go"}
runtime["go-backend/internal/contentbuild/build.go"]=expected["go-backend/internal/contentbuild/build.go"][2]
for rel,h in runtime.items():assert H((I/rel).read_bytes())==h
j={"kind":"exact-five-current-Quick-source-pin-update-v1","closed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"admission_sha256":H((S/"quick-pin-source-checkpoint-admission-r2.json").read_bytes()),"updates":rows,"full_stage_files":after,"full_stage_dirs":dirs,"runtime131":runtime,"source9":bindings["source9"],"Windows_modes_all_preserved":True,"Linux_modes":"not independently sampled by this Windows source writer; prior Linux mode baseline preserved; later native readset required","only_runtime_change":"go-backend/internal/contentbuild/build.go","derivedpin_unchanged":"df3a01bb5bdbf8c34973b6bc43c9179ab9ffbe0fc6552fb73b5cd1e9bfb24af9","frozen_Source6_preserved":True,"native_execution":False,"scope":"source pins only; bundle078657/digest388c assertions stale; freshaffectedproducer/export/installedQuickaudit/samerolefinals required; not testqualification"}
assert time.time()<a["cutoff_epoch"]
with (O/"result.json").open("x",encoding="utf-8") as f:json.dump(j,f,indent=2);f.write("\n")
with (O/"after-images.tar.gz").open("xb") as f:
 with tarfile.open(fileobj=f,mode="w:gz") as t:
  for rel,(b,z) in images.items():
   x=tarfile.TarInfo(rel);x.mode=0o600;x.size=len(z);t.addfile(x,io.BytesIO(z))
with tarfile.open(O/"after-images.tar.gz","r:gz") as t:
 for x in t:assert t.extractfile(x).read()==images[x.name][1]
assert time.time()<a["cutoff_epoch"]
print(json.dumps({"result_sha256":H((O/"result.json").read_bytes()),"updates":rows,"stage_files":len(after),"runtime_rows":len(runtime),"native_execution":False}))
