import assert from "node:assert/strict";
import {readFileSync,readdirSync,statSync,existsSync,realpathSync,mkdirSync,rmSync,writeFileSync} from "node:fs";
import {resolve,relative,isAbsolute,join,basename,dirname} from "node:path";
import {execFileSync,spawnSync} from "node:child_process";
import {createHash,randomUUID} from "node:crypto";
import {fileURLToPath} from "node:url";
import {BASELINE_SHA,digest,validateBinding,requireHash,assertChildSuccess,verifyFrozenRows} from "./policy.mjs";
export const ROOT=fileURLToPath(new URL("./",import.meta.url));
export const BASE=resolve(ROOT,"../motion-baseline");
export const shaFile=p=>createHash("sha256").update(readFileSync(p)).digest("hex");
export function inside(root,p){
 const actual=realpathSync(resolve(root,p));const prefix=realpathSync(root)+"/";
 assert.ok(actual.startsWith(prefix),"path/symlink escape");return actual;
}
const git=(root,...args)=>execFileSync("git",["-C",root,...args],{encoding:"utf8"}).trim();
export function verifyOriginalSeal(){
 const seal=JSON.parse(readFileSync(join(ROOT,"original-baseline-seal.json")));
 for(const f of seal.files)assert.equal(shaFile(inside(seal.root,f.path)),f.sha256,"original baseline changed: "+f.path);
 return{files:seal.files.length,pass:true};
}
export function gitBoundFrozen(){
 const source=JSON.parse(readFileSync(join(BASE,"frozen-source.json")));
 const repo="/home/dobo/work/cat_de_roman_esti";
 const actualNames=execFileSync("git",["-C",repo,"ls-tree","-r","--name-only",BASELINE_SHA,"frontend/src","cat_de_roman_esti/web/static","frontend/package.json","frontend/package-lock.json","frontend/vite.config.ts","frontend/playwright.config.mjs","frontend/e2e/derived-action-recovery.spec.mjs"],{encoding:"utf8"}).trim().split("\n").sort();
 assert.deepEqual(source.files.map(f=>f.path).sort(),actualNames,"frozen manifest membership drift");
 const rows=[];
 for(const f of source.files){
  assert.ok(!f.path.includes("..")&&!isAbsolute(f.path),"invalid frozen path");
  const bytes=execFileSync("git",["-C",repo,"show",BASELINE_SHA+":"+f.path],{maxBuffer:8*1024*1024});
  const sha=createHash("sha256").update(bytes).digest("hex");
  assert.equal(f.sha256,sha,"manifest does not match canonical Git object");
  assert.equal(shaFile(inside(BASE,"frozen/"+f.path)),sha,"copy differs from canonical Git object");
  rows.push({path:f.path,sha256:sha});
 }
 verifyFrozenRows(rows,source.files,Object.fromEntries(rows.map(r=>[r.path,r.sha256])));
 return rows.sort((a,b)=>a.path.localeCompare(b.path));
}
export function collectAssets(buildRoot){
 const manifest=JSON.parse(readFileSync(inside(buildRoot,".vite/manifest.json")));
 const names=new Set(["index.html",".vite/manifest.json"]);
 const entry=[];
 for(const record of Object.values(manifest)){
  for(const p of [record.file,...(record.css||[]),...(record.assets||[])])if(p)names.add(p);
  if(record.isEntry)entry.push(record.file);
 }
 const assets={};
 for(const path of [...names].sort()){
  assert.ok(!isAbsolute(path)&&!path.split("/").includes(".."),"asset path escape");
  assets[path]=shaFile(inside(buildRoot,path));
 }
 return{assets,entry_scripts:entry.sort(),assets_sha256:digest(assets)};
}
export function harnessIdentity(){
 const manifest=JSON.parse(readFileSync(join(ROOT,"prepared-files.json")));
 const hashes={};for(const row of manifest.files){
  hashes[row.path]=shaFile(inside(ROOT,row.path));assert.equal(hashes[row.path],row.sha256,"prepared harness drift: "+row.path);
 }
 return{files_sha256:digest(hashes),case_inventory_sha256:null};
}
export function inspectBinding(path,reviewedSha,profile){
 requireHash(reviewedSha,"reviewed binding sha");
 assert.ok(path.endsWith(".json")&&!/(\.env|credential|secret|transcript|auth\.json|\.codex)/i.test(path),"public binding JSON only");
 assert.equal(shaFile(path),reviewedSha,"binding differs from reviewed digest");
 const b=JSON.parse(readFileSync(path));
 assert.equal(b.status,"READY_FOR_REVIEWED_RUN","binding is not yet qualified for a reviewed launch");
 assert.equal(b.profile,profile,"wrong launch profile");verifyOriginalSeal();
 const frozen=gitBoundFrozen();
 const inventories=JSON.parse(readFileSync(join(ROOT,"profiles.json")));
 assert.deepEqual(b.inventory,inventories[profile].inventory,"binding cannot edit required inventory");
 const sourceRoot=realpathSync(b.source.repo_root);
 const diagnostic=profile==="baseline-diagnostic";
 let head,tree,dirty,sourceFiles;
 if(diagnostic){head=BASELINE_SHA;tree=git(sourceRoot,"rev-parse",BASELINE_SHA+"^{tree}");dirty=false;sourceFiles=frozen;}
 else{
  head=git(sourceRoot,"rev-parse","HEAD");tree=git(sourceRoot,"rev-parse","HEAD^{tree}");
  dirty=git(sourceRoot,"status","--porcelain")!=="";
  const names=execFileSync("git",["-C",sourceRoot,"ls-files","frontend/src","frontend/package.json","frontend/package-lock.json","frontend/vite.config.ts","go-backend/go.mod","go-backend/go.sum","go-backend/internal/httpapi/website.go","Dockerfile"],{encoding:"utf8"}).trim().split("\n");
  assert.ok(names.length>0,"missing target source files");
  sourceFiles=names.sort().map(p=>({path:p,sha256:shaFile(inside(sourceRoot,p))}));
  const protectedNames=frozen.filter(f=>f.path.startsWith("frontend/src/api/")||["frontend/src/asyncControl.mjs","frontend/src/scores.ts","frontend/src/gameActionRecovery.mjs"].includes(f.path));
  for(const row of protectedNames)assert.equal(shaFile(inside(sourceRoot,row.path)),row.sha256,"protected API/score/ownership source changed");
 }
 const built=collectAssets(b.build.root);
 const frozenBuilt=collectAssets(join(BASE,"frozen/cat_de_roman_esti/web/static"));
 const pRoot=realpathSync(b.browser.package_root);
 const cliVersion=JSON.parse(readFileSync(join(pRoot,"package.json"))).version;
 const coreRoot=realpathSync(join(pRoot,"../playwright-core"));
 const coreVersion=JSON.parse(readFileSync(join(coreRoot,"package.json"))).version;
 const testPackage=cliVersion; // CLI and test.mjs are bound from this same installed Playwright package.
 const testModule=join(pRoot,"test.mjs");assert.ok(existsSync(testModule),"Playwright test module absent");
 const browsers=JSON.parse(readFileSync(join(pRoot,"../playwright-core/browsers.json"))).browsers;
 const browserRow=browsers.find(r=>r.name==="chromium-headless-shell");assert.ok(browserRow,"Chromium package revision absent");
 const executable=realpathSync(b.browser.executable);assert.ok(statSync(executable).isFile(),"browser executable not file");
 assert.ok(["chrome","chrome-headless-shell"].includes(basename(executable))&&/chromium(?:_headless_shell)?-\d+\//.test(executable),"reviewed Chromium executable layout required");
 const browserVersion=execFileSync(executable,["--version"],{encoding:"utf8"}).trim();
 const h=harnessIdentity();h.case_inventory_sha256=digest(b.inventory);
 if(!diagnostic){
  for(const p of [b.build.receipt_path,b.runtime.receipt_path])assert.ok(p.endsWith(".json")&&!/(\.env|credential|secret|transcript|auth\.json|\.codex)/i.test(p),"public gate receipt JSON only");
 }
 const receipt=diagnostic?null:JSON.parse(readFileSync(b.build.receipt_path));
 if(!diagnostic)assert.equal(shaFile(b.build.receipt_path),b.build.receipt_sha256,"unreviewed build receipt drift");
 const runtime=diagnostic?b.runtime:{...b.runtime,receipt:JSON.parse(readFileSync(b.runtime.receipt_path)),live:inspectLiveContainer(b.runtime.container_id,b.app.base_url)};
 if(!diagnostic)assert.equal(shaFile(b.runtime.receipt_path),b.runtime.receipt_sha256,"runtime attestation digest drift");
 const actual={
  core_tag:diagnostic?null:readFileSync(inside(sourceRoot,"kit/CORE_TAG"),"utf8").trim(),runtime,
  node:{...b.node,executable:realpathSync(process.execPath),version:process.version,executable_sha256:shaFile(realpathSync(process.execPath))},
  inventory:inventories[profile].inventory,harness:h,
  source:{...b.source,head,tree,dirty,source_files_sha256:digest(sourceFiles)},
  build:{...b.build,...built,frozen_assets_sha256:frozenBuilt.assets_sha256,
   frozen_entry_js_sha256:frozenBuilt.entry_scripts.map(p=>frozenBuilt.assets[p]).sort(),
   frozen_js_sha256:Object.entries(frozenBuilt.assets).filter(([p])=>p.endsWith(".js")).map(([,sha])=>sha).sort(),receipt},
  browser:{...b.browser,core_version:coreVersion,package_closure_sha256:digest({playwright:packageClosure(pRoot),core:packageClosure(coreRoot)}),cli_version:cliVersion,test_version:testPackage,actual_version:browserVersion,
   executable_sha256:shaFile(executable),cli_sha256:shaFile(join(pRoot,"cli.js")),test_module_sha256:shaFile(testModule),
   package_revision:browserRow.revision,package_browser_version:browserRow.browserVersion,
   revision:executable.match(/chromium(?:_headless_shell)?-(\d+)\//)?.[1]||null}
 };
 if(!diagnostic){
  const lock=inside(sourceRoot,"versions.lock.json");
  assert.equal(realpathSync(b.versions_lock_path),lock,"only canonical target versions lock");
  assert.equal(shaFile(lock),b.versions_lock_sha256,"versions lock drift");
  assert.match(b.toolchain_digest||"",/^sha256:[a-f0-9]{64}$/,"pinned toolchain image digest required");
 }
 validateBinding(b,actual,profile);
 return{binding:b,profile,reviewed_binding_sha256:reviewedSha,state_sha256:digest(actual),actual};
}
export function reserveRun(root=join(ROOT,"runs"),runId=randomUUID()){
 const out=resolve(root,runId);assert.ok(out.startsWith(resolve(root)+"/"),"run path escape");
 mkdirSync(out);const report=join(out,"playwright.json");
 assert.equal(existsSync(report),false,"stale report path");
 rmSync(report,{force:true}); // only a new, exclusive run directory; no prior history is removed
 return{out,report,runId};
}
export function runProcessSafely(command,args,options,spawn=spawnSync){
 const result=spawn(command,args,options);
 assertChildSuccess({status:result.status,signal:result.signal||null,error:result.error||null});
 return result;
}
export function materializeEvidence(report,out){
 function walk(s){
  for(const spec of s.specs||[])for(const t of spec.tests||[])for(const r of t.results||[])for(const a of r.attachments||[]){
   if(a.name!=="binding-evidence")continue;
   const bytes=a.body?Buffer.from(a.body,"base64"):readFileSync(inside(out,relative(out,a.path)));a.parsed=JSON.parse(bytes);
  }
  for(const child of s.suites||[])walk(child);
 }
 for(const s of report.suites||[])walk(s);return report;
}

export function packageClosure(root){
 const rows=[];
 function walk(dir){for(const entry of readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){
  const p=join(dir,entry.name);assert.ok(!entry.isSymbolicLink(),"package closure symlink not admitted");
  if(entry.isDirectory())walk(p);else if(entry.isFile())rows.push({path:relative(root,p),sha256:shaFile(p)});
 }}walk(root);assert.ok(rows.length>0,"empty package closure");return rows;
}
export function inspectLiveContainer(id,baseUrl){
 assert.match(id||"",/^[a-f0-9]{64}$/,"literal reviewed ephemeral app container ID required");
 const format="{{.Id}}|{{.Image}}|{{.State.Running}}|{{json .NetworkSettings.Ports}}|{{range .NetworkSettings.Networks}}{{.IPAddress}} {{end}}";
 const out=execFileSync("docker",["--host","unix:///var/run/docker.sock","container","inspect","--format",format,id],{encoding:"utf8"}).trim();
 const [container_id,image_digest,running,ports,ips]=out.split("|");
 const network_ips=(ips||"").trim().split(/\s+/).filter(Boolean);
 let app_resolved_ip=null;if(new URL(baseUrl).hostname==="app")app_resolved_ip=execFileSync("getent",["ahostsv4","app"],{encoding:"utf8"}).trim().split(/\s+/)[0];
 return{container_id,image_digest,running:running==="true",ports:JSON.parse(ports),network_ips,app_resolved_ip};
}
