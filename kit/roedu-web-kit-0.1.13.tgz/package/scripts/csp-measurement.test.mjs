import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { fixtureTar } from './kit-sync.mjs';
import { manifestDescriptor, verifyFrozenDescriptor, loadBrowserDescriptor, validateCspMeasurement, coreCspPagesMatch } from './csp-measurement.mjs';

// Synthetic in-memory contract fixtures only. No browser observation, source
// receipt or gate result is produced, persisted or claimed as actual evidence.
const hash = value => createHash('sha256').update(value).digest('hex');
const json = value => Buffer.from(JSON.stringify(value));
const appURL = 'http://localhost:8080';
const context = { sha: 'a'.repeat(40), tree_sha256: 'b'.repeat(64), stage: 'enforced', started: '2026-10-13T08:00:00.000Z' };
const appImageId = `sha256:${'c'.repeat(64)}`;
function manifest(prefix = 'current') {
  return {
    'index.html': { file: `assets/${prefix}.js`, isEntry: true, css: [`assets/${prefix}.css`], imports: ['_shared.js'], dynamicImports: ['src/route.ts'] },
    '_shared.js': { file: `assets/${prefix}-shared.js`, css: [`assets/${prefix}-shared.css`] },
    'src/route.ts': { file: `assets/${prefix}-route.js`, css: [`assets/${prefix}-route.css`], imports: ['_shared.js'] },
  };
}
const currentDeclaration = { inventory: 'frontend/e2e/inventory.json', asset_root: 'go/embedfs/dist', entry: 'index.html', asset_prefix: '/' };
function currentDescriptor() { return manifestDescriptor(currentDeclaration, json(manifest()), appURL); }
function frozenFixture(modifyManifest = value => value) {
  const frozenManifest = modifyManifest(manifest('frozen'));
  const members = new Map([['.vite/manifest.json', json(frozenManifest)], ['index.html', Buffer.from('<!doctype html>synthetic')]]);
  for (const entry of Object.values(frozenManifest)) {
    for (const filename of [entry.file, ...entry.css ?? [], ...entry.assets ?? []]) members.set(filename, Buffer.from(`synthetic ${filename}`));
  }
  const archive = gzipSync(fixtureTar(members));
  const descriptor = { receipt: 'legacy/original-bundle.json', receipt_sha256: '', archive: 'legacy/original.tgz', archive_sha256: hash(archive),
    manifest_sha256: hash(members.get('.vite/manifest.json')), asset_root: 'go/embedfs/legacy', entry: 'index.html', asset_prefix: '/' };
  const receipt = { schema: 1, sha: 'd'.repeat(40), tree_sha256: 'e'.repeat(64), toolchain_digest: `sha256:${'f'.repeat(64)}`,
    archive: descriptor.archive, sha256: descriptor.archive_sha256,
    files: [...members].map(([path, bytes]) => ({ path, bytes: bytes.length, sha256: hash(bytes) })) };
  descriptor.receipt_sha256 = hash(json(receipt));
  const files = new Map([[descriptor.receipt, json(receipt)], [descriptor.archive, archive],
    [`${descriptor.archive}.sha256`, Buffer.from(`${descriptor.archive_sha256}  original.tgz\n`)],
    ...[...members].map(([name, bytes]) => [`${descriptor.asset_root}/${name}`, bytes])]);
  const read = name => { if (!files.has(name)) throw Error('Missing synthetic member'); return files.get(name); };
  const listFiles = base => [...files.keys()].filter(name => name.startsWith(`${base}/`)).map(name => name.slice(base.length + 1));
  const options = { read, listFiles, appURL };
  const rewriteReceipt = change => {
    change(receipt); files.set(descriptor.receipt, json(receipt)); descriptor.receipt_sha256 = hash(json(receipt));
  };
  return { descriptor, members, receipt, files, options, rewriteReceipt };
}
function observation(descriptor, page, nonce) {
  const css = [...descriptor.eagerCss], preloads = [...descriptor.eagerPreloads], pathname = file => new URL(descriptor.url(file)).pathname;
  return { page, nonce_sha256: hash(nonce), scripts: 2, json: 1, assetLinks: css.length + preloads.length,
    module: pathname(descriptor.manifest[descriptor.entry].file), module_url: descriptor.url(descriptor.manifest[descriptor.entry].file),
    css: css.map(pathname), css_urls: css.map(descriptor.url), preloads: preloads.map(pathname), preload_urls: preloads.map(descriptor.url) };
}
function measurement(frozen = false) {
  const descriptor = currentDescriptor();
  const measured = { schema: 1, sha: context.sha, tree_sha256: context.tree_sha256, app_image_id: appImageId, stage: context.stage,
    violations: 0, legacy_violations: 0, pages: 1, nonceObservations: [observation(descriptor, '/', 'current nonce')] };
  if (frozen) {
    const f = frozenFixture(); descriptor.frozen = verifyFrozenDescriptor(f.descriptor, f.options);
    measured.pages = 2; measured.frozen_pages = 1; measured.frozenNonceObservations = [observation(descriptor.frozen, '/old?mode=explore', 'frozen nonce')];
  }
  return { measured, context, descriptor, role: 'consumer', appURL, appImageId, mtimeMs: Date.parse(context.started) + 1 };
}

void test('current descriptor preserves complete dynamic and eager asset closures', () => {
  const value = currentDescriptor();
  assert.deepEqual([...value.eagerCss].sort(), ['assets/current-shared.css', 'assets/current.css']);
  assert.deepEqual([...value.eagerPreloads], ['assets/current-shared.js']);
  assert.equal(value.files.size, 6); assert.equal(value.allowedCss.has('assets/current-route.css'), true);
  assert.equal(value.allowedJs.has('assets/current-route.js'), true);
});
void test('manifest cycles terminate without dropping their required eager assets', () => {
  const value = manifest(); value['_shared.js'].imports = ['index.html'];
  const result = manifestDescriptor(currentDeclaration, json(value), appURL);
  assert.equal(result.eagerPreloads.has('assets/current.js'), true); assert.equal(result.files.size, 6);
});
void test('manifest rejects missing entries/imports, unsafe assets and non-JavaScript preloads', () => {
  for (const mutate of [
    m => { delete m['index.html']; }, m => { delete m['_shared.js']; }, m => { m['index.html'].file = '../outside.js'; },
    m => { m['index.html'].file = 'assets/a.js?query'; }, m => { m['index.html'].file = 'assets/%61.js'; },
    m => { m['index.html'].css = ['assets/a.js']; }, m => { m['_shared.js'].file = 'assets/shared.css'; },
    m => { m['index.html'].imports.push('_shared.js'); }, m => { m['index.html'].dynamicImports = ['missing']; },
  ]) { const value = manifest(); mutate(value); assert.throws(() => manifestDescriptor(currentDeclaration, json(value), appURL)); }
});
void test('descriptor rejects asset-prefix URL aliases and unsafe roots/entries', () => {
  for (const patch of [{ asset_prefix: '//evil/' }, { asset_prefix: '/assets/../' }, { asset_prefix: '/assets/?x/' },
    { asset_prefix: '/assets/#x/' }, { asset_prefix: '/%61ssets/' }, { asset_prefix: '/static/\n' }, { asset_prefix: '/static/\r' },
    { asset_root: '../outside' }, { entry: '../outside.js' }])
    assert.throws(() => manifestDescriptor({ ...currentDeclaration, ...patch }, json(manifest()), appURL));
});
void test('frozen descriptor binds receipt, archive, sidecar, manifest and every actual member', () => {
  const f = frozenFixture(), result = verifyFrozenDescriptor(f.descriptor, f.options);
  assert.equal(result.manifest['index.html'].file, 'assets/frozen.js');
  assert.equal(result.artifacts.length, f.members.size + 3);
  assert.deepEqual(result.files, manifestDescriptor({ ...currentDeclaration, asset_root: f.descriptor.asset_root }, json(manifest('frozen')), appURL).files);
});
void test('frozen descriptor refuses omitted declarations, unpinned hashes and unknown fields', () => {
  for (const mutate of [
    d => { delete d.receipt; }, d => { d.receipt_sha256 = 'unset'; }, d => { d.archive_sha256 = 'unset'; },
    d => { d.manifest_sha256 = 'unset'; }, d => { d.waive = true; }, d => { d.receipt = '.gate/prior.json'; },
    d => { d.asset_root = '../external'; }, d => { d.archive = '/external.tgz'; },
  ]) { const f = frozenFixture(); mutate(f.descriptor); assert.throws(() => verifyFrozenDescriptor(f.descriptor, f.options)); }
});
void test('frozen descriptor rejects tampered receipt/archive/sidecar/tree and manifest bindings', () => {
  for (const mutate of [
    f => f.files.set(f.descriptor.receipt, Buffer.from('{}')),
    f => f.files.set(f.descriptor.archive, Buffer.from('bad archive')),
    f => f.files.set(`${f.descriptor.archive}.sha256`, Buffer.from('bad sidecar')),
    f => f.files.set(`${f.descriptor.asset_root}/assets/frozen.js`, Buffer.from('changed bytes')),
    f => { f.descriptor.manifest_sha256 = '0'.repeat(64); },
    f => f.files.delete(`${f.descriptor.asset_root}/.vite/manifest.json`),
    f => f.files.set(`${f.descriptor.asset_root}/extra.js`, Buffer.from('extra member')),
  ]) { const f = frozenFixture(); mutate(f); assert.throws(() => verifyFrozenDescriptor(f.descriptor, f.options)); }
});
void test('frozen receipt rejects duplicate/missing/extra members, wrong byte counts and producer identity', () => {
  for (const change of [
    r => r.files.push({ ...r.files[0] }), r => r.files.pop(), r => { r.files[0].bytes++; },
    r => { r.files[0].sha256 = '0'.repeat(64); }, r => { r.files[0].path = '../outside'; },
    r => { r.archive = 'legacy/other.tgz'; }, r => { r.sha256 = '0'.repeat(64); }, r => { r.sha = 'not a SHA'; },
    r => { r.tree_sha256 = 'not a digest'; }, r => { r.toolchain_digest = 'not a digest'; },
    r => { r.files = r.files.filter(file => file.path !== '.vite/manifest.json'); },
  ]) { const f = frozenFixture(); f.rewriteReceipt(change); assert.throws(() => verifyFrozenDescriptor(f.descriptor, f.options)); }
});
void test('frozen archive parser remains the real strict kit parser', () => {
  const f = frozenFixture(), damaged = Buffer.from(f.files.get(f.descriptor.archive)); damaged[0] ^= 255;
  f.files.set(f.descriptor.archive, damaged); f.descriptor.archive_sha256 = hash(damaged);
  f.files.set(`${f.descriptor.archive}.sha256`, Buffer.from(`${hash(damaged)}  original.tgz\n`));
  f.rewriteReceipt(r => { r.sha256 = hash(damaged); });
  assert.throws(() => verifyFrozenDescriptor(f.descriptor, f.options));
});
void test('frozen manifest must resolve its declared entry and complete import closure', () => {
  const f = frozenFixture(); f.descriptor.entry = 'missing.html';
  assert.throws(() => verifyFrozenDescriptor(f.descriptor, f.options));
  const missing = frozenFixture(m => { m['index.html'].imports = ['missing.js']; return m; });
  assert.throws(() => verifyFrozenDescriptor(missing.descriptor, missing.options));
  for (const mutate of [m => { delete m['index.html'].isEntry; }, m => { m['index.html'].isEntry = false; }]) {
    const absent = frozenFixture(m => { mutate(m); return m; }); assert.throws(() => verifyFrozenDescriptor(absent.descriptor, absent.options));
  }
  const dynamic = frozenFixture(); dynamic.descriptor.entry = 'src/route.ts';
  assert.throws(() => verifyFrozenDescriptor(dynamic.descriptor, dynamic.options));
});
void test('ordinary consumers and explicit mixed current/frozen measurements pass the same observation rules', () => {
  for (const frozen of [false, true]) assert.deepEqual(validateCspMeasurement(measurement(frozen)), { stage: 'enforced', violations: 0, legacy_violations: 0 });
});
void test('all aggregate violation counts survive frozen classification without subtraction', () => {
  const f = measurement(true); f.measured.violations = 3; f.measured.legacy_violations = 2;
  assert.deepEqual(validateCspMeasurement(f), { stage: 'enforced', violations: 3, legacy_violations: 2 });
});
void test('freshness, source, image, policy and exact total page coverage are mandatory', () => {
  for (const mutate of [
    f => { f.measured.sha = '0'.repeat(40); }, f => { f.measured.tree_sha256 = '0'.repeat(64); },
    f => { f.measured.app_image_id = `sha256:${'0'.repeat(64)}`; }, f => { f.measured.stage = 'report-only'; },
    f => { f.mtimeMs = Date.parse(context.started) - 1; }, f => { f.measured.pages = 1; }, f => { f.measured.pages = 3; },
    f => { f.measured.violations = -1; }, f => { f.measured.legacy_violations = -1; }, f => { f.measured.pages = 2.5; },
    f => { f.measured.frozen_pages = 0; }, f => { f.measured.frozenNonceObservations = []; },
    f => { f.measured.nonceObservations = []; f.measured.pages = f.measured.frozen_pages; },
  ]) { const f = measurement(true); mutate(f); assert.throws(() => validateCspMeasurement(f)); }
});
void test('frozen measurements cannot be smuggled into undeclared consumers or the core sample', () => {
  for (const mutate of [f => { delete f.descriptor.frozen; }, f => { f.role = 'core'; },
    f => { f.measured.frozenNonceObservations = []; f.measured.frozen_pages = 0; delete f.descriptor.frozen; }]) {
    const f = measurement(true); mutate(f); assert.throws(() => validateCspMeasurement(f));
  }
  assert.throws(() => loadBrowserDescriptor({ root: '/unused', role: 'core', browser: { frozen: {} }, appURL }), /Core cannot/);
});
void test('page paths and nonces are unique across both bundles, including query-selected routes', () => {
  for (const field of ['page', 'nonce_sha256']) {
    const f = measurement(true); f.measured.frozenNonceObservations[0][field] = f.measured.nonceObservations[0][field];
    assert.throws(() => validateCspMeasurement(f));
  }
  for (const page of ['https://evil.test/', '//evil.test/', '/a/../old', '/old#fragment', '/old\\evil']) {
    const f = measurement(true); f.measured.frozenNonceObservations[0].page = page; assert.throws(() => validateCspMeasurement(f));
  }
});
void test('both bundles reject wrong module, omitted eager assets, malformed nonces and duplicate links', () => {
  for (const set of ['nonceObservations', 'frozenNonceObservations']) for (const mutate of [
    o => { o.nonce_sha256 = 'unset'; }, o => { o.scripts = 0; }, o => { o.json = 3; },
    o => { o.module = '/assets/wrong.js'; o.module_url = appURL + o.module; },
    o => { o.css.pop(); o.css_urls.pop(); o.assetLinks--; },
    o => { o.preloads = []; o.preload_urls = []; o.assetLinks = o.css.length; },
    o => { o.css.push(o.css[0]); o.css_urls.push(o.css_urls[0]); o.assetLinks++; },
    o => { o.css_urls.pop(); }, o => { o.assetLinks++; },
  ]) { const f = measurement(true); mutate(f.measured[set][0]); assert.throws(() => validateCspMeasurement(f)); }
});
void test('each asset URL must be exact same-origin without query/hash/credential or encoding aliases', () => {
  for (const set of ['nonceObservations', 'frozenNonceObservations']) for (const location of ['module_url', 'css_urls', 'preload_urls']) for (const change of [
    url => url.replace('localhost:8080', 'evil.test'), url => `${url}?query=1`, url => `${url}#fragment`,
    url => url.replace('http://', 'http://user@'), url => url.replace('/assets/', '/%61ssets/'),
    url => url.replace('/assets/', '/wrong/../assets/'), url => ' ' + url,
  ]) {
    const f = measurement(true), o = f.measured[set][0];
    if (location === 'module_url') o[location] = change(o[location]); else o[location][0] = change(o[location][0]);
    assert.throws(() => validateCspMeasurement(f));
  }
});
void test('a frozen archive member cannot substitute for the exact declared module or eager stylesheet', () => {
  const f = measurement(true), o = f.measured.frozenNonceObservations[0];
  o.module = '/assets/frozen-route.js'; o.module_url = appURL + o.module;
  assert.throws(() => validateCspMeasurement(f));
  const other = measurement(true), target = other.measured.frozenNonceObservations[0];
  target.css[0] = '/assets/frozen-route.css'; target.css_urls[0] = appURL + target.css[0];
  assert.throws(() => validateCspMeasurement(other));
});
void test('the core sample retains its exact six exported pages and rejects missing/extra/substitute pages', () => {
  const pages = ['/', '/pongo2', '/islands', '/behaviors', '/motion', '/templ'], f = measurement();
  f.role = 'core'; f.measured.pages = pages.length;
  f.measured.nonceObservations = pages.map((page, i) => observation(f.descriptor, page, `core nonce ${i}`));
  assert.equal(validateCspMeasurement(f).violations, 0); assert.equal(coreCspPagesMatch(f.measured, pages), true);
  for (const routes of [pages.slice(1), [...pages, '/extra'], pages.map(page => page === '/templ' ? '/replacement' : page)]) {
    const altered = { nonceObservations: routes.map(page => ({ page })) }; assert.equal(coreCspPagesMatch(altered, pages), false);
  }
});
