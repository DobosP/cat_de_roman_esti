import assert from "node:assert/strict";
import {test} from "../test-api.mjs";
import {installSynthetic,boardFor} from "../fixtures.mjs";
import {ready,snapshot,depart,activateLeaving,assertLocked,assertNoRecord,assertCounts,settledFrames,evidence,sampleExit} from "../contracts.mjs";
for(const game of ["intrusul","perechi"]){
 test(game+": retained idle board blocks guess/match and hint during exit",async({page,context})=>{
  await page.emulateMedia({reducedMotion:"no-preference"}); // exact M0 Presence requirement
  const fixture=await installSynthetic(context,game);await ready(page,fixture);
  if(game==="perechi")await page.locator(boardFor(game)+" button").first().click();
  const before=await snapshot(page,game),counts=fixture.counts();
  assert.equal(before.reduced,false);assert.ok(before.tiles.every(t=>!t.disabled));assert.ok(before.hint.every(t=>!t.disabled));
  const leaving=await depart(page,game);assertLocked(leaving);
  const activated=await activateLeaving(page,game);assert.equal(activated.mounted,true);
  const samples=await sampleExit(page,game,3);
  const after=await snapshot(page,game);assertLocked(after);
  assertNoRecord(before,after);assertCounts(counts,fixture.counts());
  assert.deepEqual(after.tiles.map(t=>t.pressed),leaving.tiles.map(t=>t.pressed),"selection accepted while leaving");
  assert.ok(new Set(samples.map(s=>s.transform)).size>1,"motion-on transform interpolation control");
  await evidence(test,page,fixture,{before,leaving,after,samples});
 });
}
