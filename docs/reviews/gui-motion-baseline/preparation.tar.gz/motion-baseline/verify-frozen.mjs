import {readFileSync} from "node:fs";
import {createHash} from "node:crypto";
import {fileURLToPath} from "node:url";
import assert from "node:assert/strict";
const manifest=JSON.parse(readFileSync(new URL("./frozen-source.json",import.meta.url),"utf8"));
for(const f of manifest.files){
 const bytes=readFileSync(new URL("./frozen/"+f.path,import.meta.url));
 assert.equal(createHash("sha256").update(bytes).digest("hex"),f.sha256,f.path+" changed");
}
console.log("Frozen pin "+manifest.source_commit+": "+manifest.files.length+" hashes PASS");
