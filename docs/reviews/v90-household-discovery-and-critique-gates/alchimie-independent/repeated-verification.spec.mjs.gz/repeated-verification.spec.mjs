import { test, expect } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates/frontend/node_modules/@playwright/test/index.mjs';
import { writeFileSync } from 'node:fs';
import { games, gameURL, deterministicStarts, start, solution, activeKey } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates/frontend/e2e/games.mjs';
const game = games[0];

test('repeated failed verification retains the bench and does not replay the paid clue', async ({ page, request }) => {
  await deterministicStarts(page, game);
  const initial = await start(page, game);
  let unlocked = initial;
  for (let a = 0; a < initial.inventory.length && !unlocked.hint_available; a++) {
    for (let b = a + 1; b < initial.inventory.length && !unlocked.hint_available; b++) {
      const response = await request.post(`${gameURL(game, initial.game_id)}/combine`, { data: { a: initial.inventory[a].id, b: initial.inventory[b].id } });
      expect(response.status()).toBe(200);
      unlocked = await response.json();
    }
  }
  expect(unlocked.hint_available).toBe(true);
  await page.reload();
  await expect(page.locator(game.board)).toBeVisible();
  for (const label of solution(game).steps[0].labels) {
    await page.locator(game.board).getByRole('button', { name: new RegExp(`^${label}(?:,|$)`) }).click();
  }
  const selected = page.getByRole('button', { name: /^Scoate .* din alambic$/ });
  await expect(selected).toHaveCount(2);
  const counts = { reads: 0, mutations: 0 };
  page.on('request', request => {
    const path = new URL(request.url()).pathname;
    if (request.method() === 'GET' && path === gameURL(game, initial.game_id)) counts.reads++;
    if (request.method() === 'POST' && path.startsWith(gameURL(game, initial.game_id) + '/')) counts.mutations++;
  });
  let paid;
  await page.route(`**${gameURL(game, initial.game_id)}/hint`, async route => {
    const response = await route.fetch();
    expect(response.status()).toBe(200);
    paid = await response.json();
    await route.fulfill({ status: 503, contentType: 'application/json', body: '{}' });
  }, { times: 1 });
  await page.route(`**${gameURL(game, initial.game_id)}`, route => route.fulfill({ status: 503, contentType: 'application/json', body: '{}' }), { times: 3 });
  await page.getByRole('button', { name: '💡 Indiciu', exact: true }).click();
  const retry = page.getByRole('button', { name: 'Verifică jocul', exact: true });
  for (let reads = 1; reads <= 3; reads++) {
    await expect(retry).toBeEnabled();
    expect(counts).toEqual({ reads, mutations: 1 });
    await expect(selected).toHaveCount(2);
    for (const button of await selected.all()) await expect(button).toBeDisabled();
    await expect(page.getByRole('button', { name: 'Golește', exact: true })).toBeDisabled();
    await expect(page.getByRole('button', { name: 'Combină cele două concepte selectate' })).toBeDisabled();
    await expect(page.getByRole('button', { name: '💡 Indiciu', exact: true })).toBeDisabled();
    await expect(page.getByRole('button', { name: /Reia același joc/ })).toBeDisabled();
    for (const button of await page.locator(`${game.board} button`).all()) await expect(button).toBeDisabled();
    await page.keyboard.press('Escape');
    await page.keyboard.press('Enter');
    await expect(selected).toHaveCount(2);
    expect(counts).toEqual({ reads, mutations: 1 });
    if (reads < 3) {
      // Two clicks in one JS turn exercise the synchronous owner before React rerenders.
      await retry.evaluate(button => { button.click(); button.click(); });
      await expect.poll(() => counts.reads).toBe(reads + 1);
    }
  }
  await retry.click();
  await expect(retry).toHaveCount(0);
  await expect(page.locator('.alchemy-earned-hint')).toHaveText(paid.earned_hint.message);
  await expect(selected).toHaveCount(0);
  const fresh = await (await request.get(gameURL(game, initial.game_id))).json();
  expect(fresh.hints_used).toBe(1);
  expect(fresh.earned_hint).toEqual(paid.earned_hint);
  expect(counts).toEqual({ reads: 4, mutations: 1 });
  expect(await page.evaluate(key => localStorage.getItem(key), activeKey(game))).toBe(initial.game_id);
  writeFileSync(test.info().outputPath('receipt.json'), JSON.stringify({ project: test.info().project.name, counts, hints_used: fresh.hints_used, earned_hint: fresh.earned_hint, bench_preserved_after_failed_reads: 3, successful_read_cleared_selection: true }, null, 2) + '\n');
});
