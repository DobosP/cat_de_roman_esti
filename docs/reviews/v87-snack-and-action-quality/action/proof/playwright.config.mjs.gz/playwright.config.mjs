import base from "/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v87-snack-and-action-quality/frontend/playwright.config.mjs";
export default {
  ...base,
  testDir: "/home/dobo/work/_temp/feat__v87-snack-and-action-quality/action/proof",
  outputDir: "/home/dobo/work/_temp/feat__v87-snack-and-action-quality/action/proof/results",
  projects: base.projects.filter((project) => project.name === "desktop"),
};
