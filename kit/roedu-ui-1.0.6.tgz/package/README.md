# RO-EDU core monorepo

Last verified: 2026-10-09 — UI1.0.6/WK0.1.6 deps passed; first unit failed fixture-mode policy (13 cases:5PASS/8FAIL). Bounded test-only correction applied; replay/full pending. Core-v1.5 remains immutable.

Released @roedu/ui 1.0.5 / @roedu/web-kit 0.1.5 align Rolldown 1.2.13.
[ADR-0016](docs/adr/0016-rolldown-forward-pin.md) records the released forward pin; [ADR-0017](docs/adr/0017-trusted-full-browser-loopback.md) proposes full-runner loopback. Source tests NOT RUN; no successor release/adoption.
The [ADR ledger](docs/adr/README.md) records architecture and policy.

## Current state

Core-v1.5 is qualified and atomically published at immutable source `5a66f70131d67a01f12ae9735da1923258019c17`, tree
`2d456ddfe494c9986fcd23ddfa56f83947203c6840c6d66ae7d8a24036fba350`.
Annotated tag object: `d1a6c60f7ff53d32681b37a9813285a2abbbc067`.
Clean unit passed 28 plus only pg-live/no-dsn; fresh full passed 41 with zero skips/retries,
16 HTTP Chromium cases once, six exact PNGs and zero CSP/axe violations.
Fresh A/B and owning-tag builds passed 5 each; all seven outputs were byte-identical.
Actual deps moved Rolldown 1.2.12→1.2.13; exact-pin repeat ran no update and retained identical lock bytes.
Node, native TypeScript 7, Vite8.3.3 and toolchain image stayed unchanged; Go A/B matched 41 full-mode files/55,203 bytes.
The five-file bundle passed 12 actual parser/sync/npm/Go commands, vet/race 11 packages/66 tests
and repeat no drift; 37 byte/mode artifact rows were independently verified in source/mirror.
[Release evidence](docs/reviews/gui-core-v15/README.md) binds archives and physical keepers.
Scope is Linux/local desktop Chromium and disposable PG, not Cat/device/production qualification.

Core-v1.4 remains immutable at12cbefb/tagdd2006c0: unit 28 + PG skip/full 41/16 cases/six PNGs/CSP+axe zero,
builds 5/seven equal outputs and canonical 41-file/55,213-byte Go/11-package/66-test proof.
[V1.4 evidence](docs/reviews/gui-core-v14/README.md) retains hashes/scopes; all 20 alias regression cases passed there.

Core-v1.3 remains immutable at 95aec253/tag 68d8d0b9: unit 28 + PG skip/full 41/16 cases/six PNGs/CSP+axe zero,
builds 5/seven equal outputs and canonical 41-file/55,206-byte Go/11-package/66-test proof.
[V1.3 evidence](docs/reviews/gui-core-v13/README.md) retains exact hashes and scopes; ADR-0014's classifier correction remains enforced.

Core-v1.2 stays immutable at9e0a88e/tagb5e1c817: unit 28 + PG skip, worker/parent full 41,
16 cases/six PNGs/CSP+axe zero, builds 5/seven equal outputs/ten actual consumer packs.
Its 41-file/55,202-byte Go/11-package/66-test scope and full identities stay in [v1.2 evidence](docs/reviews/gui-core-v12/README.md).

Earlier core-v1.0/v1.1 remain immutable; v1.1 source 9acd440 passed unit 27 + PG skip,
full/parent full 40 checks, 16 cases, six PNGs, zero CSP/axe/skips/retries. Lab 432 ms LCP/40 ms INP
and the compiler-cache correction retain their scope in [WORKLOG](WORKLOG.md) and [ADR-0008](docs/adr/0008-release-artifacts-exclude-compiler-state.md).

Paul directly resumed Linux implementation on 2026-10-08; the [living handoff](docs/GUI_MIGRATION_HANDOFF.md)
supersedes the historical pause/source-only Windows transfer. Five verified layers are applied:
38 Cat source paths (including 15 accepted style files), 2 eager accounting paths, 9 Cat/2 core docs and 6 Node alignment paths.
Original 16 fixtures/78 assertions, the exact 30-file legacy freeze and sealed packets retain their earlier scope.
The CORE_REQ3 correction in [ADR-0010](docs/adr/0010-configured-consumer-version-resolution.md) is released;
adoption requires the clean idle owner sequence; d0e6c7c unit 28 + PG skip/full 41, six screenshots/185/231 bindings retain that historical scope.

The sealed Windows81 core-v1.2 source remains applied; [ADR-0012](docs/adr/0012-go-archive-budget-closure.md)
records Go closure and [ADR-0013](docs/adr/0013-confined-declaration-preparation.md) records confined declaration regeneration.
Private bundle/Go parity and refusal checks passed actual qualification with public exports/failure order preserved.
The [integration ExecPlan](docs/execplans/core-integration.md) retains provenance, checks and evidence.
At core-v1.2, unit verified 292 artifact hashes/21 declaration cases; each full verified 337.
Its owning Git Go A/B hash remains `f499198a0b229b6b04488344724f5ba8873c6e1bd8da64096b76cc371f228bb4`.
Cat's original 114,086-byte gzip entry still exceeds 40,960; M0/M1 remain unqualified.
Its physical Samsung Chrome/Internet checkpoint remains UNMET. Active UI adoption,
production and S0b templ migration remain pending.
[ADR-0011](docs/adr/0011-original-runtime-budget-qualification-order.md) corrects
preliminary acceptance ordering while keeping the budget red, the real device
checkpoint and the green M2 requirement before S0b unchanged.

Paul's accepted startup calculation includes entry/static JS/CSS plus immediately mounted AccountBar,
counted once; decision: `cat_de_roman_esti/docs/adr/0185-accepted-eager-startup-bundle-accounting.md`.
Cat owning86a162d handover records actual FULL2db FAIL201: frontend319/backend1302/HTTP1207 pass;
browser894/900, six failures; native WebLocks absent at HTTP alias, two score losses are fallback-consistent inference.
GEN156bf7d1/eace4880's27/29, startup124,714/122,880 and unreached900 remain historical, not the latest result.
Actual startup122,743/122,880 is not phone proof; all20 route JS rows RED at40,960; Home115,181/117,271.
Browser failure prevented receipt/image-asset witnesses/CSP/9PNG/axe/vitals; image IID alone is not qualification.
Installed WK0.1.5/React19/UI0.3 remain; successor/full/CSP/device/formalKIT_BUMP/activeUI1-M2 are pending.
Frontend120KiB JS/CSS and canonical40,960/30,720 JS stay distinct/unchanged; no E3 non-budget-failure waiver.

The Cat-only sealed staged-UI contract and confined same-repo Go audits from
[ADR-0009](docs/adr/0009-corrective-release-and-staged-sdk.md) remain enforced.
Staged UI is pending; M2 requires actual active installation proof. Bootstrap
uses the bound current descriptor and host-private result checks. The
[core ExecPlan](docs/execplans/core-v1.md) preserves S0a history; the
[consumer resolver ExecPlan](docs/execplans/consumer-resolution.md) records the
current fix. [PROGRAM](docs/PROGRAM.md) retains the release and consumer gates.

## Source and interfaces

| Area | Path | Surface |
| --- | --- | --- |
| Tokens | src/tokens/ | DTCG input, generated CSS/app themes, TS and Go constants |
| Layered CSS | src/css/ | reset, tokens, base, components, utilities, app |
| Components | src/preact/ | CSP-safe and keyboard accessible Preact components |
| Behaviors | src/behaviors/ | light-DOM elements, invoker and island protocol |
| Motion | src/motion/ | Presence, springs, Confetti and mini playback controls |
| Network/storage | src/net/, src/storage/ | same-origin CSRF and registered keys |
| Go delivery | web-kit/ | assets, static, csp, island, health, golden, routes, engine |
| Sample | web-kit/sample/ | three stress modules, Pongo2 and compiled templ pages |
| Gate | scripts/gate.sh | pinned Linux execution and bound evidence |
| Templates | web-kit/templates/ | shared gate files, repo hooks and CI reference |

## Consumption

Consumers select only committed kit/CORE_TAG and adopt through the owner
staging/sync/trust sequence. The [consumer notes](CONSUMER_NOTES.md) list every
breaking API/style change and the exact kit protocol. Import components from
@roedu/ui/preact, CSS from @roedu/ui/styles.css and one generated theme.
Reading comfort requires a self-paced surface and rejects timed/psychometric use.
Preact island adapters render into a stable owned child, then dispose it on abort.

## Verification and documentation

Published UI1.0.5/web-kit0.1.5/Go identities bind immutable5a66f701; earlier releases retain their own sources.
This later documentation HEAD is not a qualified archive source. README is packaged:
repacking changed metadata would change archive bytes; a subsequent product release
must bump affected package versions rather than replace these published archives.
Core-v1.5's fresh qualification supersedes earlier NOT RUN state; this update runs documentation checks only.
Parent owns consumer staging and later release operations; no published archive is repacked here.
Cat/device/production, parent-owned captures and earlier receipts retain their scopes.

Every product build/test runs through the pinned native wrapper. Full adds real
PostgreSQL, an image-built app, all registered-page nonce checks, axe/vitals,
journeys and exact committed screenshot comparisons. Full permits no skips.
The [testing guide](docs/agent-testing.md) describes commands and evidence.
Requests and resolutions are append-only in [GATE_REQUESTS.md](GATE_REQUESTS.md).
Source maps: [agent map](docs/agent-map.md), [architecture](docs/architecture.md),
[theming](docs/theming.md), [tokens](docs/design-tokens.md),
[consumer guide](docs/consuming-web-react.md) and [LLM guides](docs/llm/README.md).
The original React 0.3.1 verification remains historical in [WORKLOG.md](WORKLOG.md).
