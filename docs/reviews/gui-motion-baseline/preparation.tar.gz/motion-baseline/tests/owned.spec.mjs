import assert from "node:assert/strict";
import {test} from "../test-api.mjs";
import {installSynthetic,boardFor} from "../fixtures.mjs";
import {ready,snapshot,depart,trigger,poll,assertLocked,assertNoRecord,assertCounts,settledFrames,recordExactlyOnce,evidence} from "../contracts.mjs";
test.beforeEach(async({page},info)=>{
 await page.emulateMedia({reducedMotion:info.project.name==="reduce"?"reduce":"no-preference"});
 assert.equal(await page.evaluate(()=>matchMedia("(prefers-reduced-motion: reduce)").matches),info.project.name==="reduce");
});
for(const game of ["intrusul","perechi"]){
 test(game+": present completion is locally recorded and uploaded once",async({page,context})=>{
  const f=await installSynthetic(context,game,{nearWin:true});await ready(page,f);await trigger(page,game);
  await recordExactlyOnce(page,f);const counts=f.counts();assert.equal(counts.mutations,1);
  await evidence(test,page,f);
 });
 for(const mode of ["terminal","hint","503"]){
  test(game+": owned "+mode+" reply is cancelled at exit while still mounted",async({page,context})=>{
   const f=await installSynthetic(context,game,{nearWin:mode==="terminal"});await ready(page,f);
   const before=await snapshot(page,game);const held=f.hold(mode);
   await trigger(page,game,mode==="hint"?"hint":"terminal");await held.requested;
   const counts=f.counts();assert.equal(counts.mutations,1);
   const leaving=await depart(page,game);assertLocked(leaving);
   held.release();
   await poll(()=>f.ledger.filter(r=>r.method==="POST"&&r.path.includes("/games/")).at(-1)?.delivery,v=>v==="finished"||v==="failed","held mutation never reached a network outcome",200);
   await settledFrames(page);
   const after=await snapshot(page,game);assertLocked(after);assertNoRecord(before,after);assertCounts(counts,f.counts());
   assert.ok(after.feedback===""||after.feedback===leaving.feedback,"late reply introduced new feedback");
   assert.equal(await page.locator("."+game+"-sync-recovery").count(),0,"late 503 introduced recovery UI");
   assert.equal(await page.getByRole("button",{name:"Copiază rezultatul",exact:true}).count(),0,"late terminal result adopted");
   const cue=await page.locator(game==="intrusul"?".intrusul-clue":".perechi-hint").count();assert.equal(cue,0,"late hint adopted");
   await poll(()=>page.locator(boardFor(game)).count(),n=>n===0,"old board never detached");
   if(mode!=="terminal"){assertNoRecord(before,await snapshot(page,game));assertCounts(counts,f.counts());}
   if(mode==="terminal"){
    await poll(()=>page.locator(boardFor(game)).count(),n=>n===0,"old board never detached");
    await page.goto("/"+game);await recordExactlyOnce(page,f);
    const completedScreen=await page.locator(".screen").elementHandle();
    await page.evaluate(()=>document.querySelector('.account-bar a[href="/clasament"]').click());
    await page.waitForFunction(node=>!node.isConnected,completedScreen);
    await page.goBack();
    await poll(()=>page.getByRole("button",{name:/^Joacă(?: →)?$/}).count(),n=>n>0,"resume completion not cleared");
    const stable=await snapshot(page,game);assert.equal(stable.played,1);assert.equal(stable.recent,1);assert.equal(stable.receipts,1);
    assert.equal(f.counts().uploads,1);
   }
   await evidence(test,page,f,{before,leaving,after});
  });
 }
}
test("anonymous completion still records one local row and receipt",async({page,context})=>{
 const f=await installSynthetic(context,"intrusul",{anonymous:true});await ready(page,f);
 await trigger(page,"intrusul");await recordExactlyOnce(page,f,{anonymous:true});await evidence(test,page,f);
});
