import pathlib,json,hashlib,os,stat as filemode,math
def reject_constant(v):raise ValueError("nonfinite JSON")
def unique_pairs(pairs):
 out={}
 for k,v in pairs:
  if k in out:raise ValueError("duplicate JSON key")
  out[k]=v
 return out
def load_json(raw):return json.loads(raw,object_pairs_hook=unique_pairs,parse_constant=reject_constant)
def hashfile(p):
 p=pathlib.Path(p);s=p.lstat()
 assert filemode.S_ISREG(s.st_mode) and not filemode.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400 and s.st_nlink==1 and s.st_size<=128*(1<<20),"ordinary bounded protected file"
 return hashlib.sha256(p.read_bytes()).hexdigest()
def directory(p):
 p=pathlib.Path(p)
 for q in [p,*p.parents]:
  s=q.lstat();assert filemode.S_ISDIR(s.st_mode) and not filemode.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400,"ordinary directory chain"
 assert p.resolve(strict=True)==p,"canonical directory"
def absent(p):
 p=pathlib.Path(p);directory(p.parent)
 try:p.lstat()
 except FileNotFoundError:return
 raise AssertionError("fresh absent output required")
def translated_windows_path(value):
 q=value.replace(chr(92),"/")
 assert len(q)>3 and q[1:3]==":/" and q[0].isalpha() and all(x not in ("..",".","") for x in q[3:].split("/")),"absolute canonical Windows path"
 return "/mnt/"+q[0].lower()+q[2:]
def validate_contract(v,clock=True):
 assert isinstance(v,dict)
 for k in ("R","S","stage","run","spec","output_root","candidate","source","factual","quality","binary","common","reference"):
  assert translated_windows_path(v["windows_"+k])==v["linux_"+k],"crosshost path"
 assert v["rss_cap"]==2*(1<<30) and v["growth_cap"]==1<<30 and v["memory_floor"]==16*(1<<30),"fixed caps"
 assert v["rail_sha256"]=="e702a52c4eb8621218d321c4fb08645b1fa03cf0ca97c099d7114757095f3043"
 assert len(v["stage_files"])==1200 and len(v["runtime_bindings"])==131 and len(v["source_bindings"])==9
 assert {translated_windows_path(p):h for p,h in v["windows_protected"].items()}==v["linux_protected"],"complete crosshost readset"
 if clock:
  assert v["deadline_epoch"]-v["started_epoch"]==1200 and type(v["host_launcher_pid"]) is int and v["host_launcher_pid"]>0
 out=v["linux_output_root"];prefix=[v["linux_binary"],"quick","--root",v["linux_stage"],"--source",v["linux_source"]]
 expected=[prefix+["--candidate",v["linux_candidate"],"--factual-review",v["linux_factual"],"--quality-review",v["linux_quality"],"--proposal",out+"/proposal.json"],prefix+["--audit-catalog",out+"/proposal.json","--audit-out",out+"/audit.json"]]
 assert [x["name"] for x in v["steps"]]==["quick-proposal","quick-audit"]
 for n,x in enumerate(v["steps"]):
  assert x["argv"]==expected[n] and translated_windows_path(x["windows_output"])==x["linux_output"]
  assert x["linux_output"]==out+("/proposal.json" if n==0 else "/audit.json")
def full_readset(v,flavor):
 for p,h in v[flavor+"_protected"].items():
  directory(pathlib.Path(p).parent);assert hashfile(p)==h,p
 root=pathlib.Path(v[flavor+"_stage"]);directory(root);files=set();dirs={"."};stack=[root]
 while stack:
  p=stack.pop();s=p.lstat();assert filemode.S_ISDIR(s.st_mode) and not filemode.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400
  for e in os.scandir(p):
   q=pathlib.Path(e.path);s=q.lstat();rel=q.relative_to(root).as_posix()
   assert not filemode.S_ISLNK(s.st_mode) and not getattr(s,"st_file_attributes",0)&0x400
   if filemode.S_ISDIR(s.st_mode):dirs.add(rel);stack.append(q)
   else:assert filemode.S_ISREG(s.st_mode) and s.st_nlink==1;files.add(rel)
 assert files==set(v["stage_files"]) and dirs==set(v["stage_dirs"]),"complete immutable stage namespace"
 assert not (root/".cat-content-ops.lock").exists(),"operator lock"
def json_equal(a,b):
 return json.dumps(a,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False)==json.dumps(b,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False)
def check_proposal(p,c,reference,v):
 assert p["kind"]=="quick-content-catalog-v1" and p["candidate_sha256"]==v["candidate_sha256"]
 assert p["excluded"]==[] and len(p["authored"])==len(p["boards"])==85 and len(p["nodes"])==322
 assert json_equal({k:x for k,x in p.items() if k!="reviews"},{k:x for k,x in reference.items() if k!="reviews"}),"deterministic semantic catalog/ranks/nodes/bindings preserved; original review signatures not reused"
 assert json_equal(p["authored"],c["boards"]) and len({x["id"] for x in p["authored"]})==85
 assert len(p["reviews"])==2 and {x["role"]:x["reviewer"] for x in p["reviews"]}==v["reviewer_ids"] and {x["role"]:x["sha256"] for x in p["reviews"]}==v["review_hashes"]
 a={(x["game"],x["source_id"]):x for x in p["authored"]};rated={(x["game"],x["source_id"]):x for x in p["boards"]}
 assert len(a)==len(rated)==85 and a.keys()==rated.keys() and len({x["id"] for x in p["boards"]})==85
 for key,x in rated.items():
  assert all(json_equal(x[k],a[key][k]) for k in ("game","source_id","category","difficulty","payload"))
  assert type(x["standard_score"]) in (int,float) and math.isfinite(x["standard_score"]) and x["standard_score"]>=55
def check_audit(a,p,proposal_sha,v):
 assert a["kind"]=="quick-content-live-audit-v1" and a["passed"] is True and type(a["native_audit_version"]) is int and a["native_audit_version"]==1
 assert a["candidate_sha256"]==v["candidate_sha256"] and a["catalog_sha256"]==proposal_sha and a["core_boards_preserved"] is True
 assert type(a["requests"]) is int and a["requests"]==460
 rated={x["id"]:x for x in p["boards"]};replays=a["replays"]
 assert len(rated)==len(replays)==85 and len({x["id"] for x in replays})==85 and {x["id"] for x in replays}==set(rated),"rated replay namespace"
 assert sum(x["game"]=="intrusul" for x in replays)==45 and sum(x["game"]=="perechi" for x in replays)==40
 for x in replays:
  assert all(json_equal(x[k],rated[x["id"]][k]) for k in ("id","game","source_id","category"))
  assert type(x["public_seed"]) is int and 0<=x["public_seed"]<5000
  assert x["hidden_answers_preserved"] is True and x["terminal_get_preserved"] is True and type(x["score"]) is int and x["score"]==1000
 rt=a["runtime_sources"];assert len(rt)==131 and len({x["path"] for x in rt})==131 and {x["path"]:x["sha256"] for x in rt}==v["runtime_bindings"]
 assert a["source_bindings"]==v["source_bindings"]
