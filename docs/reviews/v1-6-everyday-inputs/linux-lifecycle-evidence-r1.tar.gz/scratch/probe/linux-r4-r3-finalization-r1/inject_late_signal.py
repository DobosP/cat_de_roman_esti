import importlib.util,json,os,pathlib,signal,sys
runner=pathlib.Path(sys.argv[1]); admission=sys.argv[2]; marker=pathlib.Path(sys.argv[3])
spec=importlib.util.spec_from_file_location('owned_guard',runner)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
real=m.digest;fired=False
def observed(path):
 global fired
 if pathlib.Path(path).suffix=='.log' and not fired:
  fired=True
  marker.write_text(json.dumps({'phase':'log-hashing','signal':int(signal.SIGINT),'pid':os.getpid()}))
  os.kill(os.getpid(),signal.SIGINT)
 return real(path)
m.digest=observed
signal.signal(signal.SIGTERM,m.on_signal);signal.signal(signal.SIGINT,m.on_signal)
sys.argv=[str(runner),admission,'0']
raise SystemExit(m.main())
