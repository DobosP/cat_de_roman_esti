# Independent raw gastronomy facts

Valid until: either bound raw candidate changes — then treat as history.

Cremșnit passes this factual screen. [The original 2014 recipe](https://jamilacuisine.ro/prajitura-cremsnit-pas-cu-pas-reteta-video/)
uses pastry sheets, milk, sugar and vanilla; its [linked puff-pastry recipe](https://jamilacuisine.ro/aluat-de-foietaj-pas-cu-pas-reteta-video/)
uses flour and water with other ingredients. These support the proposed ingredient
associations. The five seeds are not a complete literal recipe; generic Aluat is
broader than laminated pastry. Actual sparse openings and assembly still need review.

The original Diplomat proposal needs revision. [Jamila’s Diplomat recipe](https://jamilacuisine.ro/tort-diplomat-facut-in-casa-reteta-video/)
uses pișcoturi, fruit including oranges and whipping cream. The served Smântână seed,
however, expressly denotes fermented cream and accepts “smântână fermentată”; the
served Frișcă node expressly denotes whipped sweet cream. Sources for whipping cream
do not independently support a sour-cream-to-sweet-cream transformation. No such
substitution is accepted here. The manufacturer Oetker page was challenge-blocked;
I did not treat the author’s quotation as independent proof.

[BărbatLaCratiță’s original pișcot recipe](https://www.barbatlacratita.ro/2016/03/piscoturi-de-casa.html)
independently confirms flour, separated egg whites and powdered-sugar dusting. This
supports the pișcot side of the candidate, but cannot repair its fermented-cream seed.
The source recipe also uses yolks and other ingredients: none of these pair associations
is a sufficient cooking instruction.

`verify_factual.json` binds both exact raw entries and records one unresolved `fix`.
The importer must not stage these gastronomy bytes as a fully clean batch. This factual
screen neither determines final playability nor approves promotion. Agent judgments
are not human playtesting.
