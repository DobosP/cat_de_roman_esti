import './diagnostics';
import { test, expect } from '../../playwright/index.mjs';
import type { Page } from '@playwright/test';

if (!process.env.GATE_APP_URL) throw Error('Journeys require the actual sample app image');

type MountEvent = { key: string; error: string | null };
type AnimationObservation = { target: Element; animation: Animation };
type ListenerObservation = { listener: EventListenerOrEventListenerObject | null; signal?: AbortSignal; removed: boolean };
type JourneyWindow = Window & {
  __journeyMounts: MountEvent[];
  __journeyAnimations: AnimationObservation[];
  __journeyListeners: ListenerObservation[];
  __journeyDetached?: HTMLElement;
};

async function openPage(page: Page, route: string) {
  await page.addInitScript(() => {
    const observed = window as JourneyWindow;
    observed.__journeyMounts = [];
    document.addEventListener('island:mounted', event => {
      const detail = (event as CustomEvent).detail;
      observed.__journeyMounts.push({ key: detail.key, error: detail.error?.message ?? null });
    });
    // Observe the actual browser Animation objects; never change their timing.
    observed.__journeyAnimations = [];
    const animate = Element.prototype.animate;
    Element.prototype.animate = function (...args) {
      const animation = animate.apply(this, args);
      observed.__journeyAnimations.push({ target: this, animation });
      return animation;
    };
    // Retain the real listener and AbortSignal so detachment proves disposal.
    observed.__journeyListeners = [];
    const add = EventTarget.prototype.addEventListener;
    const remove = EventTarget.prototype.removeEventListener;
    EventTarget.prototype.addEventListener = function (type, listener, options) {
      if (this === document && type === 'roedu:sample') {
        observed.__journeyListeners.push({ listener, signal: typeof options === 'object' ? options?.signal : undefined, removed: false });
      }
      add.call(this, type, listener, options);
    };
    EventTarget.prototype.removeEventListener = function (type, listener, options) {
      if (this === document && type === 'roedu:sample') {
        for (const record of observed.__journeyListeners) if (record.listener === listener) record.removed = true;
      }
      remove.call(this, type, listener, options);
    };
  });
  const response = await page.goto(route);
  expect(response?.status()).toBe(200);
  await expect(page.getByText(route === '/templ' ? 'Compiled templ delivery is ready.' : 'Embedded pongo2 delivery is ready.', { exact: true })).toBeVisible();
  const policy = response!.headers()[process.env.CSP_STAGE === 'enforced' ? 'content-security-policy' : 'content-security-policy-report-only'];
  const nonce = policy.match(/'nonce-([^']+)'/)?.[1];
  expect(nonce).toBeTruthy();
  const bindings = await page.evaluate(() => ({
    scripts: [...document.scripts].map(script => ({ id: script.id, type: script.type, nonce: script.nonce })),
    hosts: [...document.querySelectorAll<HTMLElement>('[data-props]')].map(host => ({ id: host.dataset.props, key: host.dataset.island, load: host.dataset.load })),
  }));
  const json = bindings.scripts.filter(script => script.type === 'application/json');
  expect(json).toHaveLength(7);
  expect(bindings.hosts).toHaveLength(7);
  expect(new Set(json.map(script => script.id)).size).toBe(7);
  expect(bindings.hosts.map(host => host.id).sort()).toEqual(json.map(script => script.id).sort());
  for (const script of bindings.scripts) expect(script.nonce).toBe(nonce);
  expect(bindings.hosts.filter(host => host.key).map(host => host.load).sort()).toEqual(['eager', 'idle', 'interaction', 'visible']);
  await expect.poll(() => page.evaluate(() => (window as JourneyWindow).__journeyMounts.map(event => event.key).sort())).toEqual(['stress-counter', 'stress-events', 'stress-presence']);
  expect(await page.evaluate(() => (window as JourneyWindow).__journeyMounts.every(event => event.error === null))).toBe(true);
}

for (const route of ['/pongo2', '/templ']) {
  test(`pw-journeys ${route} counters preserve independent Go props and mount interaction once`, async ({ page }) => {
    await openPage(page, route);
    const eager = page.locator('[data-island="stress-counter"][data-load="eager"]');
    const interaction = page.locator('[data-island="stress-counter"][data-load="interaction"]');
    const props = await page.locator('[data-island="stress-counter"]').evaluateAll(hosts => hosts.map(host => {
      const id = (host as HTMLElement).dataset.props!;
      return JSON.parse(document.getElementById(id)!.textContent!);
    }));
    expect(props).toEqual([{ count: 0 }, { count: 1 }]);
    await expect(eager.locator('output')).toHaveText('0');
    await expect(interaction).toHaveText('Server skeleton');
    await eager.getByRole('button', { name: 'Increment counter' }).click();
    await eager.getByRole('button', { name: 'Increment counter' }).click();
    await expect(eager.locator('output')).toHaveText('2');
    await interaction.dispatchEvent('pointerdown');
    await expect(interaction.locator('output')).toHaveText('1');
    await interaction.getByRole('button', { name: 'Increment counter' }).focus();
    await page.keyboard.press('Enter');
    await expect(interaction.locator('output')).toHaveText('2');
    await expect(eager.locator('output')).toHaveText('2');
    await interaction.dispatchEvent('pointerdown');
    await interaction.dispatchEvent('keydown');
    expect(await page.evaluate(() => (window as JourneyWindow).__journeyMounts.filter(event => event.key === 'stress-counter').length)).toBe(2);
  });

  test(`pw-journeys ${route} Presence swaps keyed panels and Confetti completes real animations`, async ({ page }) => {
    await openPage(page, route);
    const island = page.locator('[data-island="stress-presence"]');
    await expect(island.locator('.roedu-presence')).toHaveCount(1);
    await expect(island.locator('[data-present]')).toHaveText('Panel 0');
    for (const version of [1, 2]) {
      await island.getByRole('button', { name: 'Replace panel' }).click();
      await expect(island.locator('[data-present="true"]')).toHaveText(`Panel ${version}`);
      await expect(island.locator('.roedu-presence')).toHaveCount(1);
      await expect(island.locator('[data-state="exiting"]')).toHaveCount(0);
    }
    expect(await page.evaluate(() => (window as JourneyWindow).__journeyAnimations.some(record => record.target.classList.contains('roedu-presence') && (record.animation.effect as KeyframeEffect).getKeyframes().some(frame => frame.opacity !== undefined)))).toBe(true);
    await island.getByRole('button', { name: 'Toggle confetti' }).click();
    await expect.poll(() => page.evaluate(() => (window as JourneyWindow).__journeyAnimations.filter(record => record.target.classList.contains('roedu-confetti-particle')).length)).toBe(12);
    const confetti = await page.evaluate(() => (window as JourneyWindow).__journeyAnimations.filter(record => record.target.classList.contains('roedu-confetti-particle')).map(record => ({ duration: record.animation.effect!.getTiming().duration, opacity: (record.animation.effect as KeyframeEffect).getKeyframes().map(frame => frame.opacity) })));
    expect(confetti).toEqual(Array.from({ length: 12 }, () => ({ duration: 150, opacity: ['1', '0'] })));
    await expect.poll(() => page.evaluate(() => document.getAnimations().length)).toBe(0);
    await expect(island.locator('.roedu-confetti')).toHaveAttribute('aria-hidden', 'true');
    await expect(island.locator('.roedu-confetti-particle')).toHaveCount(12);
    await island.getByRole('button', { name: 'Toggle confetti' }).click();
    await expect(island.locator('.roedu-confetti')).toHaveCount(0);
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await island.getByRole('button', { name: 'Replace panel' }).click();
    await expect(island.locator('[data-present="true"]')).toHaveText('Panel 3');
    await expect.poll(() => page.evaluate(() => document.getAnimations().length)).toBe(0);
  });

  test(`pw-journeys ${route} events respond once and detachment aborts the actual listener`, async ({ page }) => {
    await openPage(page, route);
    const island = page.locator('[data-island="stress-events"]');
    await expect.poll(() => page.evaluate(() => (window as JourneyWindow).__journeyListeners.filter(record => !record.removed && !record.signal?.aborted).length)).toBe(1);
    await expect(island.locator('output')).toHaveText('0');
    await island.getByRole('button', { name: 'Send event' }).click();
    await expect(island.locator('output')).toHaveText('1');
    await page.evaluate(() => document.dispatchEvent(new Event('roedu:sample')));
    await expect(island.locator('output')).toHaveText('2');
    await island.evaluate(element => {
      (window as JourneyWindow).__journeyDetached = element as HTMLElement;
      element.remove();
    });
    await expect.poll(() => page.evaluate(() => (window as JourneyWindow).__journeyListeners.every(record => record.signal?.aborted && record.removed))).toBe(true);
    expect(await page.evaluate(() => (window as JourneyWindow).__journeyListeners.length)).toBe(1);
    expect(await page.evaluate(() => (window as JourneyWindow).__journeyDetached!.childElementCount)).toBe(0);
    await page.evaluate(() => {
      document.dispatchEvent(new Event('roedu:sample'));
      (window as JourneyWindow).__journeyDetached!.remove();
    });
    expect(await page.evaluate(() => (window as JourneyWindow).__journeyListeners.filter(record => !record.removed && !record.signal?.aborted).length)).toBe(0);
  });
}
