import pathlib,json,hashlib,os,sys,time,signal,subprocess,threading
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"):raise RuntimeError("optimized refused")
expected_spec=sys.argv[2];raw=pathlib.Path(sys.argv[1]).read_bytes();assert hashlib.sha256(raw).hexdigest()==expected_spec
spec=json.loads(raw);common=pathlib.Path(spec["linux_common"]);common_bytes=common.read_bytes();assert hashlib.sha256(common_bytes).hexdigest()==spec["common_sha256"]
exec(compile(common_bytes,str(common),"exec"));validate_contract(spec)
assert sys.argv[1]==spec["linux_spec"];index=int(sys.argv[3]);assert index in (0,1);step=spec["steps"][index];proposal_sha=sys.argv[4]
run=pathlib.Path(spec["linux_run"]);cancel=run/"cancel";mono_deadline=time.monotonic()+spec["deadline_epoch"]-time.time()
pgid=None;child=None;initial=None;peak=0;cleanup_attempted=False;cleanup_confirmed=False;stopping=False
emit_lock=threading.Lock()
def emit(v):
 with emit_lock:print(json.dumps(v,separators=(",",":")),flush=True)

def stat(pid):
 try:
  t=pathlib.Path("/proc",str(pid),"stat").read_text(); f=t[t.rfind(")")+2:].split()
  return int(f[2]),int(f[19]),int(f[21])*os.sysconf("SC_PAGE_SIZE"),f[0]
 except (FileNotFoundError,ProcessLookupError): return None

def group():
 rows=[]
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdigit(): continue
  v=stat(p.name)
  if v and (int(p.name)==os.getpid() or v[0]==pgid): rows.append((int(p.name),*v))
 return rows

def memory():
 return int(next(x.split()[1] for x in pathlib.Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))*1024

def interrupted(signum,frame):
 global stopping
 stopping=True

def spec_pin():
 if hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")

def cleanup():
 global child,pgid,initial,cleanup_attempted,cleanup_confirmed
 if cleanup_attempted:
  if cleanup_confirmed:return
  raise RuntimeError("prior cleanup uncertain; refusing repeated process-group action")
 cleanup_attempted=True
 if child is None:
  cleanup_confirmed=True
  return
 leader=stat(child.pid)
 if leader is not None and initial is not None and leader[1]!=initial[1]: raise RuntimeError("owned leader generation changed")
 if any(x[1]==pgid and x[4]!="Z" for x in group()):
  try: os.killpg(pgid,signal.SIGTERM)
  except ProcessLookupError: pass
  end=time.monotonic()+2
  while time.monotonic()<end and any(x[1]==pgid and x[4]!="Z" for x in group()): time.sleep(.05)
  if any(x[1]==pgid and x[4]!="Z" for x in group()):
   try: os.killpg(pgid,signal.SIGKILL)
   except ProcessLookupError: pass
 child.wait(timeout=5)
 if any(x[1]==pgid for x in group()): raise RuntimeError("owned group still present")
 cleanup_confirmed=True;child=None;pgid=None;initial=None
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
sampler_stop=threading.Event();supervisor_peak=0
def sample_supervisor():
 global stopping,supervisor_peak
 try:
  while not sampler_stop.is_set():
   rows=group();rss=sum(x[3] for x in rows);supervisor_peak=max(supervisor_peak,rss)
   emit({"kind":"sample","rss":rss,"peak":supervisor_peak,"phase":"supervisor-and-owned-session"})
   if stopping or cancel.exists() or rss>spec["rss_cap"] or memory()<spec["memory_floor"] or time.time()>=spec["deadline_epoch"]-180:stopping=True
   sampler_stop.wait(.25)
 except BaseException as exc:
  stopping=True;emit({"kind":"failed","error":"supervisor sampler: "+repr(exc),"group_absent":False})

def stop_sampler():
 sampler_stop.set();sampler.join(timeout=3)
 if sampler.is_alive():raise RuntimeError("sampler termination unconfirmed")
sampler=threading.Thread(target=sample_supervisor);sampler.start()
try:
 spec_pin();assert not stopping and not cancel.exists()
 assert hashfile("/usr/bin/python3.14")==spec["python_sha256"]
 full_readset(spec,"linux")
 executable=pathlib.Path(spec["linux_binary"]);assert hashfile(executable)==spec["rail_sha256"] and os.access(executable,os.X_OK)
 absent(step["linux_output"]);directory(spec["linux_output_root"]);directory(run/"empty-bin");assert list((run/"empty-bin").iterdir())==[]
 if index:
  assert len(proposal_sha)==64 and hashfile(spec["steps"][0]["linux_output"])==proposal_sha
 else:assert proposal_sha==""
 env={"GOMAXPROCS":"2","GOMEMLIMIT":"1536MiB","GOTOOLCHAIN":"local","GOPROXY":"off","GOSUMDB":"off","HOME":str(run/"tmp"),"TMPDIR":str(run/"tmp"),"PATH":str(run/"empty-bin")}
 stdout=run/(step["name"]+".stdout.log");stderr=run/(step["name"]+".stderr.log");absent(stdout);absent(stderr)
 with stdout.open("xb") as out,stderr.open("xb") as err:
  spec_pin();assert not stopping and not cancel.exists() and memory()>=spec["memory_floor"]
  assert time.time()<spec["deadline_epoch"]-195 and time.monotonic()<mono_deadline-195
  child=subprocess.Popen(step["argv"],cwd=spec["linux_stage"],env=env,stdout=out,stderr=err,start_new_session=True)
  pgid=child.pid;initial=stat(pgid);assert initial is not None
  while True:
   rows=group();rss=sum(x[3] for x in rows);peak=max(peak,rss)
   emit({"kind":"sample","rss":rss,"peak":peak,"pid":child.pid,"start_ticks":initial[1]})
   assert not stopping and not cancel.exists() and memory()>=spec["memory_floor"] and rss<=spec["rss_cap"]
   assert time.time()<spec["deadline_epoch"]-180 and time.monotonic()<mono_deadline-180
   assert stdout.stat().st_size<=1024 and stderr.stat().st_size<=1024**2
   output=pathlib.Path(step["linux_output"])
   if output.exists():assert output.stat().st_size<=4*(1<<20)
   done=os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
   if done is not None:break
   time.sleep(.25)
  assert done.si_code==os.CLD_EXITED and done.si_status==0
 cleanup();spec_pin();full_readset(spec,"linux")
 assert stderr.read_bytes()==b"" and len(stdout.read_bytes())<=1024
 assert json_equal(load_json(stdout.read_bytes()),{"mode":"proposal" if index==0 else "audit","ok":True,"rail":"quick"})
 output=pathlib.Path(step["linux_output"]);assert output.stat().st_size<=4*(1<<20)
 if index:assert hashfile(spec["steps"][0]["linux_output"])==proposal_sha
 emit({"kind":"quick-output","step":step["name"],"output_sha256":hashfile(output),"output_bytes":output.stat().st_size,"stdout_sha256":hashfile(stdout),"stderr_bytes":0,"proposal_sha256":proposal_sha})
 stop_sampler();assert not stopping and not cancel.exists() and memory()>=spec["memory_floor"] and time.time()<spec["deadline_epoch"]-180 and time.monotonic()<mono_deadline-180
 peak=max(peak,supervisor_peak);assert peak<=spec["rss_cap"]
 emit({"kind":"sample","rss":sum(x[3] for x in group()),"peak":peak,"phase":"terminal"})
 assert not stopping and not cancel.exists() and memory()>=spec["memory_floor"] and time.time()<spec["deadline_epoch"]-180 and time.monotonic()<mono_deadline-180,"immediate completion check"
 emit({"kind":"complete","step":step["name"],"returncode":0,"native_peak":peak,"group_absent":True})
except BaseException as exc:
 error=repr(exc);absent_group=False
 try:cleanup();absent_group=True
 except BaseException as secondary:error+=";cleanup="+repr(secondary)
 try:stop_sampler()
 except BaseException as secondary:error+=";sampler="+repr(secondary)
 emit({"kind":"failed","step":step["name"],"error":error,"native_peak":max(peak,supervisor_peak),"group_absent":absent_group});sys.exit(1)
