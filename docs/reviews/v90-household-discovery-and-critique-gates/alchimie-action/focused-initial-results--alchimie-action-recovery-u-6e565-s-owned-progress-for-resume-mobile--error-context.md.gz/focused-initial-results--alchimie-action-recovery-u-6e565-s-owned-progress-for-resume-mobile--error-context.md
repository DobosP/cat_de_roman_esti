# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: alchimie-action-recovery.spec.mjs >> unmount invalidates an old mutation reply and preserves owned progress for resume
- Location: e2e/alchimie-action-recovery.spec.mjs:304:3

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: locator.click: Test timeout of 45000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Înapoi la jocuri' })

```

# Page snapshot

```yaml
- generic [ref=f1e4]:
  - generic [ref=f1e7]:
    - generic [ref=f1e8]:
      - generic [ref=f1e9]:
        - button "Ieși la lista de jocuri" [ref=f1e10] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e11]: ←
          - text: Ieși
        - strong [ref=f1e12]: Alchimie
      - group "Starea jocului" [ref=f1e14]:
        - generic "Dificultate" [ref=f1e15]:
          - generic [ref=f1e16]: Mod
          - generic [ref=f1e17]: Ușor
        - generic [ref=f1e18]:
          - generic [ref=f1e19]: Categorie
          - generic [ref=f1e20]: Sport
        - generic [ref=f1e21]:
          - generic [ref=f1e22]: Combinații
          - generic [ref=f1e23]: "2"
        - generic [ref=f1e24]:
          - generic [ref=f1e25]: Descoperite
          - generic [ref=f1e26]: "0"
    - group [ref=f1e27]:
      - generic "Reguli și ajutor" [ref=f1e28] [cursor=pointer]
    - generic [ref=f1e30]:
      - generic [ref=f1e31]: ȚINTA DE FĂURIT
      - generic [ref=f1e32]:
        - generic [aria-hidden] [ref=f1e33]: ◎
        - heading "Liga Campionilor la handbal" [level=2] [ref=f1e34]
      - paragraph [ref=f1e35]: Competiția europeană majoră de club în care Cristina Neagu a strălucit.
    - generic [ref=f1e36]:
      - generic [aria-hidden] [ref=f1e37]: 👆
      - generic [ref=f1e38]:
        - generic [ref=f1e39]: ACUM
        - strong [ref=f1e40]: Alege două concepte
        - generic [ref=f1e41]: Pornește din inventar.
      - generic [ref=f1e42]: 0/2
    - generic [ref=f1e43]:
      - generic [ref=f1e44]:
        - generic [ref=f1e45]: alege…
        - generic [aria-hidden] [ref=f1e46]: +
        - generic [ref=f1e47]: alege…
      - generic [ref=f1e48]:
        - button "💡 Indiciu" [disabled] [ref=f1e49]
        - button "Combină cele două concepte selectate" [disabled] [ref=f1e50]: …
    - region "Inventar" [ref=f1e51]:
      - generic [ref=f1e52]:
        - generic [ref=f1e53]: INVENTAR · 3 ÎN JOC
        - generic [ref=f1e54]:
          - generic [ref=f1e55]: ● pereche gata
          - generic [ref=f1e56]: 3 puse deoparte
      - group "Filtrează inventarul" [ref=f1e57]:
        - button "Recente 3" [ref=f1e58] [cursor=pointer]
        - button "Utile 3" [pressed] [ref=f1e59] [cursor=pointer]
        - button "Toate 6" [ref=f1e60] [cursor=pointer]
      - searchbox "Caută în toate conceptele descoperite" [ref=f1e61]
      - generic [ref=f1e62]:
        - button "Washington Bullets, gata pentru o combinație utilă" [disabled] [ref=f1e63] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e64]: ●
          - text: Washington Bullets
        - button "Cristina Neagu, gata pentru o combinație utilă" [disabled] [ref=f1e65] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e66]: ●
          - text: Cristina Neagu
        - button "Tricolorii, gata pentru o combinație utilă" [disabled] [ref=f1e67] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e68]: ●
          - text: Tricolorii
    - generic [ref=f1e69]:
      - button "↻ Reia același joc" [disabled] [ref=f1e70]
      - button "⚗ Alt joc" [disabled] [ref=f1e71]
      - button "⚙ Schimbă opțiunile" [disabled] [ref=f1e72]
  - status
```

# Test source

```ts
  211 |   await page.clock.fastForward(4000);
  212 |   await page.clock.runFor(500);
  213 |   await expect(verify(page)).toBeVisible();
  214 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  215 |   expect(await remembered(page)).toBe(initial.game_id);
  216 |   await settledScreenshot(page, "read-only-recovery.png", page.locator(".alchemy-sync-recovery"));
  217 |   const response = responseFor(page, initial.game_id, "", "GET");
  218 |   await verify(page).click();
  219 |   expect((await response).status()).toBe(200);
  220 |   await expect(verify(page)).toHaveCount(0);
  221 |   await expect(page.locator(".alchemy-earned-hint")).toBeVisible();
  222 |   expect(counts).toEqual({ reads: 2, mutations: 1 });
  223 |   expect((await serverState(request, initial.game_id)).hints_used).toBe(1);
  224 | });
  225 | 
  226 | test("an uncommitted failed combine reads unchanged state without inventing discovery", async ({ page, request }) => {
  227 |   const initial = await prepare(page, request);
  228 |   const counts = traffic(page, initial.game_id);
  229 |   await page.route(`**${gameURL(game, initial.game_id)}/combine`, (route) => route.fulfill({ status: 503, contentType: "application/json", body: "{}" }), { times: 1 });
  230 |   expect((await act(page, game, steps()[0])).status()).toBe(503);
  231 |   await expect(page.getByText("Joc sincronizat. Poți continua.", { exact: true })).toBeVisible();
  232 |   const fresh = await serverState(request, initial.game_id);
  233 |   expect(fresh.moves).toBe(0);
  234 |   expect(fresh.inventory).toEqual(initial.inventory);
  235 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  236 | });
  237 | 
  238 | test("a GET with another game id fails closed until an owned read succeeds", async ({ page, request }) => {
  239 |   const initial = await prepare(page, request);
  240 |   const counts = traffic(page, initial.game_id);
  241 |   await loseCommittedResponse(page, initial.game_id, "combine");
  242 |   await page.route(`**${gameURL(game, initial.game_id)}`, async (route) => {
  243 |     const response = await route.fetch();
  244 |     const body = await response.json();
  245 |     await route.fulfill({ json: { ...body, game_id: "wrong-session" } });
  246 |   }, { times: 1 });
  247 |   await act(page, game, steps()[0]);
  248 |   await expect(verify(page)).toBeEnabled();
  249 |   expect(await remembered(page)).toBe(initial.game_id);
  250 |   await verify(page).click();
  251 |   await expect(verify(page)).toHaveCount(0);
  252 |   expect(counts).toEqual({ reads: 2, mutations: 1 });
  253 | });
  254 | 
  255 | test("an owned confirmed 404 forgets only that round and returns to setup", async ({ page, request }) => {
  256 |   const initial = await prepare(page, request);
  257 |   const counts = traffic(page, initial.game_id);
  258 |   await loseCommittedResponse(page, initial.game_id, "combine");
  259 |   await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({ status: 404, contentType: "application/json", body: "{}" }), { times: 1 });
  260 |   await act(page, game, steps()[0]);
  261 |   await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  262 |   expect(await remembered(page)).toBeNull();
  263 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  264 | });
  265 | 
  266 | test("another tab's pointer prevents mutation and loads its current round", async ({ page, request, context }) => {
  267 |   const initial = await prepare(page, request, { hints: 1 });
  268 |   const counts = traffic(page, initial.game_id);
  269 |   const { other, fresh } = await saveFromOtherTab(context, request);
  270 |   await hintButton(page).click();
  271 |   await expect(currentGame(page)).toBeEnabled();
  272 |   expect(counts).toEqual({ reads: 0, mutations: 0 });
  273 |   await currentGame(page).click();
  274 |   await expect(currentGame(page)).toHaveCount(0);
  275 |   await expect(page.locator(game.board)).toBeVisible();
  276 |   expect(await remembered(page)).toBe(fresh.game_id);
  277 |   expect((await serverState(request, initial.game_id)).hints_used).toBe(0);
  278 |   await other.close();
  279 | });
  280 | 
  281 | for (const phase of ["mutation", "read", "missing-read"]) {
  282 |   test(`a changed saved round rejects an old ${phase} completion`, async ({ page, request, context }) => {
  283 |     const initial = await prepare(page, request, { hints: 1 });
  284 |     const counts = traffic(page, initial.game_id);
  285 |     if (phase !== "mutation") await loseCommittedResponse(page, initial.game_id, "hint");
  286 |     const held = await holdResponse(page, initial.game_id, phase === "mutation" ? "hint" : "", phase === "missing-read");
  287 |     const clicked = hintButton(page).click();
  288 |     await held.requested;
  289 |     const { other, fresh } = await saveFromOtherTab(context, request);
  290 |     held.release();
  291 |     await clicked;
  292 |     await expect(currentGame(page)).toBeEnabled();
  293 |     await expect(page.locator(".alchemy-earned-hint")).toHaveCount(0);
  294 |     expect(await remembered(page)).toBe(fresh.game_id);
  295 |     expect(counts).toEqual({ reads: phase === "mutation" ? 0 : 1, mutations: 1 });
  296 |     await currentGame(page).click();
  297 |     await expect(currentGame(page)).toHaveCount(0);
  298 |     expect(await remembered(page)).toBe(fresh.game_id);
  299 |     await other.close();
  300 |   });
  301 | }
  302 | 
  303 | for (const phase of ["mutation", "read"]) {
  304 |   test(`unmount invalidates an old ${phase} reply and preserves owned progress for resume`, async ({ page, request }) => {
  305 |     const initial = await prepare(page, request, { hints: 1 });
  306 |     const counts = traffic(page, initial.game_id);
  307 |     if (phase === "read") await loseCommittedResponse(page, initial.game_id, "hint");
  308 |     const held = await holdResponse(page, initial.game_id, phase === "mutation" ? "hint" : "");
  309 |     const clicked = hintButton(page).click();
  310 |     await held.requested;
> 311 |     await page.getByRole("button", { name: "Înapoi la jocuri" }).click();
      |                                                                  ^ Error: locator.click: Test timeout of 45000ms exceeded.
  312 |     held.release();
  313 |     await clicked;
  314 |     await expect(page.locator(game.board)).toHaveCount(0);
  315 |     expect(await remembered(page)).toBe(initial.game_id);
  316 |     expect(await played(page)).toBe(0);
  317 |     expect(counts).toEqual({ reads: phase === "mutation" ? 0 : 1, mutations: 1 });
  318 |     await page.goto(game.path);
  319 |     await expect(page.locator(".alchemy-earned-hint")).toBeVisible();
  320 |     expect((await serverState(request, initial.game_id)).hints_used).toBe(1);
  321 |   });
  322 | }
  323 | 
  324 | test("failed verification can start a fresh round without replaying the old action", async ({ page, request }) => {
  325 |   const initial = await prepare(page, request, { hints: 1 });
  326 |   const counts = traffic(page, initial.game_id);
  327 |   await loseCommittedResponse(page, initial.game_id, "hint");
  328 |   await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({ status: 503, contentType: "application/json", body: "{}" }), { times: 1 });
  329 |   await askHint(page, initial.game_id);
  330 |   await expect(verify(page)).toBeEnabled();
  331 |   await page.locator(".alchimie-other-board").click();
  332 |   await expect(verify(page)).toHaveCount(0);
  333 |   await expect.poll(() => remembered(page)).not.toBe(initial.game_id);
  334 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  335 |   expect((await serverState(request, initial.game_id)).hints_used).toBe(1);
  336 | });
  337 | 
```