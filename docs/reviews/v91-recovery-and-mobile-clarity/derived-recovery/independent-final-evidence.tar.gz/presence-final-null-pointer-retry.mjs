import assert from 'node:assert/strict';
import { chromium } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/node_modules/playwright/index.mjs';
import { games, activeKey, gameURL, deterministicStarts, solution, start, act } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/e2e/games.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root = process.cwd();
const outputDir = '/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/recovery-review';
const hash = async (path) => createHash('sha256').update(await readFile(path)).digest('hex');
const inputs = {};
for (const path of ['frontend/src/screens/Intrusul.tsx', 'frontend/src/screens/Perechi.tsx', 'frontend/src/gameActionRecovery.mjs', 'cat_de_roman_esti/web/static/.vite/manifest.json', 'cat_de_roman_esti/web/static/index.html']) inputs[path] = await hash(path);
const manifest = JSON.parse(await readFile('cat_de_roman_esti/web/static/.vite/manifest.json', 'utf8'));
for (const [key, value] of Object.entries(manifest)) if (/Intrusul|Perechi|index.html|useSavedGameResume/.test(key)) inputs[`cat_de_roman_esti/web/static/${value.file}`] = await hash(`cat_de_roman_esti/web/static/${value.file}`);
const browser = await chromium.launch({ headless: true });
const observations = [];
try {
 for (const game of games.filter((g) => g.derived)) {
  const context = await browser.newContext({ baseURL: 'http://127.0.0.1:8188', viewport: { width: 390, height: 844 }, locale: 'ro-RO', timezoneId: 'Europe/Bucharest', reducedMotion: 'reduce' });
  const page = await context.newPage();
  await deterministicStarts(page, game);
  const initial = await start(page, game);
  const steps = solution(game).steps;
  for (const step of steps.slice(0, -1)) {
   const response = await context.request.post(`${gameURL(game, initial.game_id)}/${step.action}`, { data: step.payload });
   if (response.status() !== 200) throw Error('setup mutation failed');
  }
  if (steps.length > 1) { await page.reload(); await page.locator(game.board).waitFor({ state: 'visible' }); }
  const counts = { reads: 0, mutations: 0 };
  page.on('request', (request) => {
   const path = new URL(request.url()).pathname;
   if (request.method() === 'GET' && path === gameURL(game, initial.game_id)) counts.reads++;
   if (request.method() === 'POST' && path.startsWith(`${gameURL(game, initial.game_id)}/`)) counts.mutations++;
  });
  const winning = steps.at(-1);
  let committed;
  await page.route(`**${gameURL(game, initial.game_id)}/${winning.action}`, async (route) => {
   const response = await route.fetch();
   if (response.status() !== 200) throw Error('winning mutation did not commit');
   committed = await response.json();
   await route.fulfill({ status: 503, json: {} });
  }, { times: 1 });
  await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({ status: 503, json: {} }), { times: 1 });
  await act(page, game, winning);
  const verify = page.getByRole('button', { name: 'Verifică jocul', exact: true });
  await verify.waitFor({ state: 'visible' });
  const storage = () => page.evaluate(([key, gameKey]) => ({ pointer: localStorage.getItem(key), played: JSON.parse(localStorage.getItem('cat_wordgame_scores_v1') || '{}')[gameKey]?.played ?? 0 }), [activeKey(game), game.key]);
  const before = await storage();
  const other = await context.newPage();
  await other.goto('/');
  await other.evaluate((key) => localStorage.removeItem(key), activeKey(game));
  const removed = await storage();
  await verify.click();
  await page.getByRole('button', { name: 'Încarcă jocul curent', exact: true }).waitFor({ state: 'visible' });
  const after = await storage();
  await page.screenshot({ path: `${outputDir}/${game.key}-presence-final-null-pointer-retry.png`, fullPage: true });
  const observation = { game: game.key, before, removed, after, counts, committedWon: committed.won, committedScore: committed.score, changedControlVisible: await page.getByRole('button', { name: 'Încarcă jocul curent', exact: true }).count(), resultVisible: await page.getByRole('button', { name: 'Copiază rezultatul', exact: true }).count() > 0 };
  assert.deepEqual(after, { pointer: null, played: 0 });
  assert.deepEqual(counts, { reads: 1, mutations: 1 });
  assert.equal(observation.resultVisible, false);
  assert.equal(observation.changedControlVisible, 1);
  observations.push(observation);
  console.log(JSON.stringify(observation));
  await context.close();
 }
} finally { await browser.close(); }
const afterInputs = {};
for (const [path, before] of Object.entries(inputs)) afterInputs[path] = { before, after: await hash(path) };
const allInputsStable = Object.values(afterInputs).every((v) => v.before === v.after);
const evidence = { afterInputs, allInputsStable, capturedAt: new Date().toISOString(), root, scenario: 'Lost committed winning POST; first GET fails; other tab removes saved pointer; manual verification', inputs, observations };
await writeFile(`${outputDir}/presence-final-null-pointer-retry.json`, JSON.stringify(evidence, null, 2));
console.log(`Evidence: ${outputDir}/presence-final-null-pointer-retry.json`);
