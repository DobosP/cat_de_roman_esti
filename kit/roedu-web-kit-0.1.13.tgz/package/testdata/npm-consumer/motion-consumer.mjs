import { animate } from 'motion/mini';
import { spring } from 'motion';
import { animateHeight, springs } from '@roedu/ui/motion';

// Retain both real callers in the browser bundle; no animation runs at build time.
document.addEventListener('roedu-motion-package-probe', () => {
  const element = document.createElement('div');
  document.body.append(element);
  const direct = animate(element, { opacity: [0, 1] }, { type: spring, ...springs.gentle });
  const core = animateHeight(element, 0, 10, springs.gentle);
  direct.complete(); core.complete(); element.remove();
});
