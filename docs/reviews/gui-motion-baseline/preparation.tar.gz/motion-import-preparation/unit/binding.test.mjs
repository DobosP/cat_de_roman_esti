import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync,writeFileSync,mkdirSync,existsSync,mkdtempSync} from "node:fs";
import {resolve,join} from "node:path";
import {spawnSync} from "node:child_process";
import {digest,BASELINE_SHA,parseLaunch,rejectAmbient,validateBinding,validateReceipt,caseId,assertChildSuccess,verifyFrozenRows,assertWebAssets,assertRuntimeOrigin} from "../policy.mjs";
import {ROOT,reserveRun,runProcessSafely,verifyOriginalSeal,gitBoundFrozen,collectAssets,packageClosure} from "../io.mjs";
const profiles=JSON.parse(readFileSync(join(ROOT,"profiles.json")));
const H="a".repeat(64),J="b".repeat(64),S="1".repeat(40),TREE="2".repeat(40);
function binding(profile="target-acceptance"){
 const diagnostic=profile==="baseline-diagnostic",inventory=profiles[profile].inventory;
 const assets={"assets/app.js":J,"assets/app.css":H};
 const assetDigest=digest(assets);
 const head=diagnostic?BASELINE_SHA:S;
 return{schema_version:1,status:"READY_FOR_REVIEWED_RUN",profile,inventory,
  app:{base_url:"http://127.0.0.1:9001/",ui:diagnostic?null:"preact"},
  source:{head,tree:TREE,dirty:false,build_source_sha:head,build_source_tree:TREE},
  harness:{files_sha256:H,case_inventory_sha256:digest(inventory)},
  build:{assets,entry_scripts:["assets/app.js"],assets_sha256:assetDigest,frozen_assets_sha256:diagnostic?assetDigest:H,
   frozen_js_sha256:[H],frozen_entry_js_sha256:[H],source_reproduced:!diagnostic,
   receipt:diagnostic?null:{status:"PASS",source_sha:head,source_tree:TREE,assets_sha256:assetDigest,image_digest:"sha256:"+J,toolchain_digest:"sha256:"+H,versions_lock_sha256:H}},
  node:{executable:"/unit/node",version:"v26.10.0",expected_version:"v26.10.0",executable_sha256:H},
  browser:{package_root:"/unit/playwright",package_closure_sha256:H,core_version:diagnostic?"1.62.1":"1.63.0",cli_version:diagnostic?"1.62.1":"1.63.0",test_version:diagnostic?"1.62.1":"1.63.0",
   actual_version:"Google Chrome for Testing 153.0.8010.12",expected_version:"Google Chrome for Testing 153.0.8010.12",
   scope:diagnostic?"historical-preview-mismatch":"reviewed-pinned-triple",revision:"1243",package_revision:diagnostic?"1234":"1243",package_browser_version:"153.0.8010.12"},
  runtime:{container_id:"c".repeat(64),live:{container_id:"c".repeat(64),image_digest:"sha256:"+J,running:true,ports:{"8080/tcp":[{HostPort:"9001",HostIp:"127.0.0.1"}]},network_ips:[],app_resolved_ip:null},image_digest:diagnostic?null:"sha256:"+J,receipt:diagnostic?null:{status:"PASS",image_digest:"sha256:"+J,source_sha:head,
   assets_sha256:assetDigest,base_url:"http://127.0.0.1:9001/",valid_until:new Date(Date.now()+60000).toISOString()}},
  core_tag:diagnostic?null:"core-v1.0",toolchain_digest:"sha256:"+H,versions_lock_sha256:H,source_mutants_executed:false,unit_fixture:true};
}
function syntheticReceipt(b=binding()){
 const start=Date.now(),descriptor={binding:b,run_id:"fresh-unit-run",started_at:start,config_file:"/unit/playwright.config.mjs",argv:[b.node.executable,b.browser.package_root+"/cli.js","test","-c","/unit/playwright.config.mjs"]};
 descriptor.descriptor_sha256=digest(descriptor);
 const suites=b.inventory.map(c=>{
  const e={run_id:descriptor.run_id,descriptor_sha256:descriptor.descriptor_sha256,profile:b.profile,case_id:caseId(c),source_head:b.source.head,source_tree:b.source.tree,
   build_assets_sha256:b.build.assets_sha256,image_digest:b.runtime.image_digest,browser_version:b.browser.actual_version,ui:b.app.ui,
   argv:descriptor.argv,html_script_entries:["assets/app.js"],html_script_origins:[new URL(b.app.base_url).origin],package_closure_sha256:H,node_executable_sha256:H,
   effective_config:{grep:[{source:".*",flags:""}],grepInvert:null,projectGrep:[{source:".*",flags:""}],projectGrepInvert:null,updateSnapshots:"none",forbidOnly:true,retries:0,repeatEach:1,shard:null},
   reduced:c.project==="reduce",selection:"complete-inventory-no-filters",served_assets:[{path:"assets/app.js",sha256:J,origin:new URL(b.app.base_url).origin}],source_mutants_executed:false};
  return{file:c.file,title:c.file.split("/").at(-1),specs:[{file:c.file,title:c.title,ok:true,tests:[{
   projectName:c.project,expectedStatus:"passed",status:"expected",annotations:[],results:[{status:"passed",retry:0,attachments:[{name:"binding-evidence",parsed:e}]}]}]}]};
 });
 const report={config:{version:b.browser.cli_version,configFile:descriptor.config_file,updateSnapshots:"none",rootDir:ROOT,forbidOnly:true,shard:null,maxFailures:0,workers:1,
  projects:[{name:"motion-on",retries:0,repeatEach:1},{name:"reduce",retries:0,repeatEach:1}]},
  stats:{startTime:new Date(start).toISOString(),expected:b.inventory.length,unexpected:0,skipped:0,flaky:0},errors:[],suites};
 const runtime={child:{status:0,signal:null,error:null},reportMtimeMs:start,finishedAt:start+100};
 return{b,descriptor,report,runtime};
}
const result=x=>x.report.suites[0].specs[0].tests[0].results[0];
const witness=x=>result(x).attachments[0].parsed;
const validate=x=>validateReceipt(x.report,x.descriptor,x.runtime);
test("synthetic target policy-positive fixture is a subgate model, not a browser run",()=>{
 const x=syntheticReceipt();assert.equal(validateBinding(x.b,structuredClone(x.b),"target-acceptance"),true);
 const v=validate(x);assert.equal(v.case_count,48);assert.equal(v.formal_gate,false);assert.equal(v.scope,"motion-subgate-evidence-only");
});
test("synthetic complete diagnostic receipt never becomes target acceptance",()=>{
 const x=syntheticReceipt(binding("baseline-diagnostic"));validateBinding(x.b,structuredClone(x.b),"baseline-diagnostic");
 assert.equal(validate(x).scope,"diagnostic-only");assert.throws(()=>validateBinding(x.b,structuredClone(x.b),"target-acceptance"),/profile/);
});
test("launch parser rejects missing profile and every extra/filter argument",()=>{
 const path=resolve(ROOT,"templates/target-binding.example.json");
 assert.throws(()=>parseLaunch([]));
 for(const extra of ["--grep","--project","--shard","--last-failed","--update-snapshots","--repeat-each","--list","--only-changed"]){
  assert.throws(()=>parseLaunch(["target-acceptance",path,H,extra]));
 }
 assert.throws(()=>parseLaunch(["unknown",path,H]));assert.throws(()=>parseLaunch(["target-acceptance","relative.json",H]));
 assert.throws(()=>parseLaunch(["target-acceptance",path,"bad"]));
});
test("ambient URL/filter/preload overrides fail closed using names only",()=>{
 for(const name of ["MOTION_BASE_URL","PW_TEST_GREP","PLAYWRIGHT_JSON_OUTPUT_NAME","NODE_OPTIONS","NODE_PATH","IMPORT_DESCRIPTOR","npm_config_node_options"]){
  assert.throws(()=>rejectAmbient({[name]:"synthetic-value"}),/ambient/);
 }
 rejectAmbient({PATH:"public-test-path",LANG:"C.UTF-8"});
});
const badBindings=[
 ["frozen HEAD",b=>{b.source.head=BASELINE_SHA;b.source.build_source_sha=BASELINE_SHA;b.build.receipt.source_sha=BASELINE_SHA;b.runtime.receipt.source_sha=BASELINE_SHA;}],
 ["dirty source",b=>b.source.dirty=true],
 ["stale build SHA",b=>b.build.receipt.source_sha="3".repeat(40)],
 ["stale build tree",b=>b.source.build_source_tree="3".repeat(40)],
 ["wrong source/build asset digest",b=>b.build.receipt.assets_sha256=H],
 ["wrong image",b=>b.runtime.receipt.image_digest="sha256:"+H],
 ["expired runtime proof",b=>b.runtime.receipt.valid_until="2000-01-01T00:00:00Z"],
 ["wrong runtime URL",b=>b.runtime.receipt.base_url="http://127.0.0.1:9002/"],
 ["wrong browser revision",b=>b.browser.package_revision="1234"],
 ["wrong browser binary version",b=>b.browser.package_browser_version="151.0.0.0"],
 ["CLI/test mismatch",b=>b.browser.test_version="1.62.1"],
 ["unreviewed triple",b=>b.browser.scope="historical-preview-mismatch"],
 ["missing core pin",b=>b.core_tag=null],
 ["wrong UI marker",b=>b.app.ui="legacy"],
 ["frozen asset digest",b=>b.build.assets_sha256=b.build.frozen_assets_sha256],
 ["frozen entry JS",b=>b.build.frozen_js_sha256=[J]],
 ["false mutant execution",b=>b.source_mutants_executed=true],
 ["leakage test smuggled into target",b=>{b.inventory[0]={...b.inventory[0],title:"CHARACTERIZATION leakage"};b.harness.case_inventory_sha256=digest(b.inventory);}],
 ["external app origin",b=>b.app.base_url="https://example.invalid/"],
 ["pending binding",b=>b.status="NOT_YET_QUALIFIED"]
];
for(const [name,mutate]of badBindings)test("binding rejects "+name,()=>{
 const b=structuredClone(binding());mutate(b);assert.throws(()=>validateBinding(b,structuredClone(b),"target-acceptance"));
});
test("actual state substitution cannot pass a reviewed binding",()=>{
 const b=binding(),actual=structuredClone(b);actual.source.head="3".repeat(40);
 assert.throws(()=>validateBinding(b,actual,"target-acceptance"),/binding drift/);
});
const badReceipts=[
 ["count-preserving dummy case",x=>{x.report.suites[0].specs[0].title="dummy";}],
 ["duplicate case while preserving count",x=>{x.report.suites[1]=structuredClone(x.report.suites[0]);}],
 ["missing required case",x=>x.report.suites.pop()],
 ["skip",x=>x.report.suites[0].specs[0].tests[0].expectedStatus="skipped"],
 ["retry-success",x=>result(x).retry=1],
 ["extra execution",x=>x.report.suites[0].specs[0].tests[0].results.push(structuredClone(result(x)))],
 ["disabled forbidOnly",x=>x.report.config.forbidOnly=false],
 ["shard",x=>x.report.config.shard={current:1,total:2}],
 ["project filter",x=>x.report.config.projects.pop()],
 ["configured repeat",x=>x.report.config.projects[0].repeatEach=2],
 ["configured retry",x=>x.report.config.projects[0].retries=1],
 ["wrong aggregate",x=>x.report.stats.expected++],
 ["hidden top-level error",x=>x.report.errors=[{message:"synthetic error"}]],
 ["stale mtime",x=>x.runtime.reportMtimeMs=x.descriptor.started_at-1],
 ["stale run timestamp",x=>x.report.stats.startTime="2000-01-01T00:00:00Z"],
 ["wrong run ID",x=>witness(x).run_id="old-run"],
 ["wrong descriptor",x=>witness(x).descriptor_sha256=J],
 ["wrong profile",x=>witness(x).profile="baseline-diagnostic"],
 ["wrong source witness",x=>witness(x).source_head=BASELINE_SHA],
 ["wrong image witness",x=>witness(x).image_digest="sha256:"+H],
 ["wrong served asset",x=>witness(x).served_assets[0].sha256=H],
 ["missing entry script",x=>witness(x).served_assets=[]],
 ["missing binding witness",x=>result(x).attachments=[]],
 ["false media label",x=>witness(x).reduced=!witness(x).reduced],
 ["filtered witness",x=>witness(x).selection="grep"],
 ["invented mutant kills",x=>witness(x).source_mutants_executed=true]
];
for(const [name,mutate]of badReceipts)test("receipt rejects "+name,()=>{
 const x=syntheticReceipt();mutate(x);assert.throws(()=>validate(x));
});
test("fake killed/errored/null-status child cannot reuse a stale passing receipt",()=>{
 const folder=mkdtempSync(join(ROOT,"runtime-tmp/fake-process-"));
 const stale=join(folder,"playwright.json");writeFileSync(stale,JSON.stringify(syntheticReceipt().report));
 for(const child of [{status:null,signal:"SIGKILL",error:null},{status:null,signal:null,error:null},{status:null,signal:null,error:Error("spawn failed")},{status:1,signal:null,error:null},{status:0,signal:"SIGTERM",error:null}]){
  let readOld=false;
  assert.throws(()=>{runProcessSafely("not-executed",[],{},()=>child);readOld=true;JSON.parse(readFileSync(stale));});
  assert.equal(readOld,false,"must fail before any stale receipt can be read");
  const x=syntheticReceipt();x.runtime.child=child;assert.throws(()=>validate(x));
 }
 assert.ok(existsSync(stale),"prior evidence preserved");
});
test("exclusive fresh run allocation refuses reused receipt directories",()=>{
 const root=mkdtempSync(join(ROOT,"runtime-tmp/reserve-")),r=reserveRun(root,"fresh");
 writeFileSync(r.report,"old");assert.throws(()=>reserveRun(root,"fresh"));
 assert.equal(readFileSync(r.report,"utf8"),"old","no old history deleted");
 const next=reserveRun(root,"next");assert.equal(existsSync(next.report),false);
});
test("jointly altering copy and local manifest still fails canonical Git binding",()=>{
 const canonical=[{path:"frontend/src/scores.ts",sha256:H}],manifest=[{path:"frontend/src/scores.ts",sha256:J}];
 assert.throws(()=>verifyFrozenRows(canonical,manifest,{"frontend/src/scores.ts":J}));
 assert.throws(()=>verifyFrozenRows(canonical,[...canonical,...canonical],{"frontend/src/scores.ts":H}));
 assert.throws(()=>verifyFrozenRows(canonical,[{path:"../escape",sha256:H}],{"../escape":H}));
 verifyFrozenRows(canonical,canonical,{"frontend/src/scores.ts":H});
});
test("preserved original bytes and canonical 110-file Git pin verify read-only",()=>{
 assert.equal(verifyOriginalSeal().pass,true);assert.equal(gitBoundFrozen().length,110);
});
test("actual launcher refuses filtered arguments without spawning browser",()=>{
 const child=spawnSync(process.execPath,[join(ROOT,"launch.mjs"),"target-acceptance",join(ROOT,"templates/target-binding.example.json"),H,"--grep","anything"],{encoding:"utf8"});
 assert.equal(child.status,1);assert.match(child.stderr,/FAIL CLOSED/);
});

test("receipt rejects a mutated descriptor even if witnesses are relabeled",()=>{
 const x=syntheticReceipt();x.descriptor.run_id="tampered";for(const suite of x.report.suites)for(const spec of suite.specs)for(const t of spec.tests)t.results[0].attachments[0].parsed.run_id="tampered";
 assert.throws(()=>validate(x),/descriptor integrity/);
});

test("extra legacy HTML script and imported frozen SPA entry are rejected",()=>{
 const x=syntheticReceipt();witness(x).html_script_entries.push("assets/legacy.js");assert.throws(()=>validate(x),/extra or wrong/);
 const y=syntheticReceipt();y.b.build.assets["assets/bridge.js"]=H;witness(y).served_assets.push({path:"assets/bridge.js",sha256:H});
 assert.throws(()=>validate(y));
 assert.throws(()=>assertWebAssets({"assets/app.js":J,"assets/bridge.js":H},["assets/app.js"],[H],[{path:"assets/app.js",sha256:J},{path:"assets/bridge.js",sha256:H}],["assets/app.js"]),/frozen SPA entry/);
});
test("asset referenced only via manifest assets is bound",()=>{
 const root=mkdtempSync(join(ROOT,"runtime-tmp/build-assets-"));mkdirSync(join(root,".vite"));mkdirSync(join(root,"assets"));
 writeFileSync(join(root,"index.html"),"<html></html>");writeFileSync(join(root,"assets/app.js"),"export default 1;");writeFileSync(join(root,"assets/font.woff2"),"public font fixture");
 writeFileSync(join(root,".vite/manifest.json"),JSON.stringify({"index.html":{file:"assets/app.js",isEntry:true,assets:["assets/font.woff2"]}}));
 assert.ok(collectAssets(root).assets["assets/font.woff2"]);
});
test("live image or port substitution is rejected independently of attestation",()=>{
 const b=binding();b.runtime.live.image_digest="sha256:"+H;assert.throws(()=>assertRuntimeOrigin(b.runtime,b.app),/image/);
 const other=binding();other.runtime.live.ports["8080/tcp"][0].HostPort="9002";assert.throws(()=>assertRuntimeOrigin(other.runtime,other.app),/port/);
});
test("loaded dependency closure drift is detected",()=>{
 const root=mkdtempSync(join(ROOT,"runtime-tmp/package-"));mkdirSync(join(root,"lib"));writeFileSync(join(root,"lib/loaded.js"),"export default 1;");
 const first=digest(packageClosure(root));writeFileSync(join(root,"lib/loaded.js"),"export default 2;");assert.notEqual(digest(packageClosure(root)),first);
 const b=binding(),actual=structuredClone(b);actual.browser.package_closure_sha256=J;assert.throws(()=>validateBinding(b,actual,"target-acceptance"),/binding drift/);
});
test("count-preserving effective filter and snapshot updates are rejected",()=>{
 for(const change of [e=>e.effective_config.grep=[{source:"TARGET|intrusul|perechi|anonymous",flags:""}],e=>e.effective_config.grepInvert="impossible-to-match",e=>e.effective_config.updateSnapshots="all"]){
  const x=syntheticReceipt();change(witness(x));assert.throws(()=>validate(x),/effective filtering/);
 }
 const x=syntheticReceipt();x.report.config.updateSnapshots="all";assert.throws(()=>validate(x),/snapshot update/);
});
test("explicit count-preserving CLI filter cannot become a no-filter descriptor",()=>{
 const x=syntheticReceipt();x.descriptor.argv.push("--grep",".*");const raw={...x.descriptor};delete raw.descriptor_sha256;x.descriptor.descriptor_sha256=digest(raw);
 for(const suite of x.report.suites)for(const spec of suite.specs)for(const t of spec.tests){const e=t.results[0].attachments[0].parsed;e.descriptor_sha256=x.descriptor.descriptor_sha256;e.argv=x.descriptor.argv;}
 assert.throws(()=>validate(x),/exact unfiltered CLI/);
});
test("future report timestamp and wrong reported runner version are rejected",()=>{
 const x=syntheticReceipt();x.report.stats.startTime=new Date(x.runtime.finishedAt+1).toISOString();assert.throws(()=>validate(x),/after completion/);
 const y=syntheticReceipt();y.report.config.version="1.62.1";assert.throws(()=>validate(y),/runner version/);
});

test("cross-origin script with expected pathname cannot borrow a genuine local preload",()=>{
 const x=syntheticReceipt();witness(x).html_script_origins=["http://127.0.0.1:9002"];assert.throws(()=>validate(x),/cross-origin executable/);
 const y=syntheticReceipt();witness(y).served_assets[0].origin="http://127.0.0.1:9002";assert.throws(()=>validate(y),/cross-origin fetched/);
});
