# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: conexiuni-action-recovery.spec.mjs >> a lost first clue is restored once, resumes exactly, and retains 100 points
- Location: e2e/conexiuni-action-recovery.spec.mjs:119:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Joc sincronizat. Poți continua.', { exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Joc sincronizat. Poți continua.', { exact: true }) with timeout 10000ms
  - waiting for getByText('Joc sincronizat. Poți continua.', { exact: true })

```

```yaml
- button "Ieși la lista de jocuri": Ieși
- strong: Conexiuni
- group "Starea jocului": DIFICULTATE Ușor GREȘELI 1 rămase
- group: Reguli și ajutor
- status:
  - text: ACUM
  - strong: Alege 4 care merg împreună
  - text: Caută o categorie comună.
- img "1 greșeală disponibilă"
- button "Verifică" [disabled]
- status: Joc sincronizat. Poți continua.
- status: "Un grup ramas are eticheta: L_ Ș___ D_ L_ B___."
- button "Sârma de rufe"
- button "Cauciucurile de iarnă"
- button "Revelionul la televizor"
- button "Sărbători în familie"
- button "Masa în familie"
- button "Vitrina cu bibelouri"
- button "Borcanele de zacuscă"
- button "Rude"
- button "Asociația de proprietari"
- button "Covor"
- button "Interfonul"
- button "lift"
- button "Întreținerea"
- button "Mileurile croșetate"
- button "Carpeta de pe perete"
- button "Bicicleta Pegas"
- button "Indiciu · 1 rămas"
- button "Amestecă"
- button "Golește" [disabled]
- status
```

# Test source

```ts
  24  |   const counts = { reads: 0, mutations: 0 };
  25  |   page.on("request", (request) => {
  26  |     const path = new URL(request.url()).pathname;
  27  |     if (request.method() === "GET" && path === gameURL(game, id)) counts.reads += 1;
  28  |     if (request.method() === "POST" && path.startsWith(`${gameURL(game, id)}/`)) counts.mutations += 1;
  29  |   });
  30  |   return counts;
  31  | }
  32  | 
  33  | function responseFor(page, id, action, method = "POST") {
  34  |   const path = action ? `${gameURL(game, id)}/${action}` : gameURL(game, id);
  35  |   return page.waitForResponse((response) =>
  36  |     response.request().method() === method && new URL(response.url()).pathname === path);
  37  | }
  38  | 
  39  | async function choose(page, step) {
  40  |   const clear = page.getByRole("button", { name: "Golește", exact: true });
  41  |   if (await clear.isEnabled()) await clear.click();
  42  |   for (const label of step.labels) {
  43  |     await page.locator(game.board).getByRole("button", { name: label, exact: true }).click();
  44  |   }
  45  | }
  46  | 
  47  | async function guess(page, id, step) {
  48  |   await choose(page, step);
  49  |   const response = responseFor(page, id, "guess");
  50  |   await page.getByRole("button", { name: "Verifică", exact: true }).click();
  51  |   return response;
  52  | }
  53  | 
  54  | async function askClue(page, id) {
  55  |   const response = responseFor(page, id, "clue");
  56  |   await clueButton(page).click();
  57  |   return response;
  58  | }
  59  | 
  60  | async function prepare(page, request, { mistakes = 0, solved = 0 } = {}) {
  61  |   const initial = await start(page, game);
  62  |   for (let index = 0; index < mistakes; index += 1) {
  63  |     expect((await request.post(`${gameURL(game, initial.game_id)}/guess`, { data: wrong(index).payload })).status()).toBe(200);
  64  |   }
  65  |   for (const step of steps().slice(0, solved)) {
  66  |     expect((await request.post(`${gameURL(game, initial.game_id)}/guess`, { data: step.payload })).status()).toBe(200);
  67  |   }
  68  |   if (mistakes || solved) {
  69  |     await page.reload();
  70  |     await expect(page.locator(`${game.board} button`)).toHaveCount(16 - solved * 4);
  71  |     await expect(page.locator(".connections-lives")).toHaveAttribute("aria-label", `${4 - mistakes} ${mistakes === 3 ? "greșeală disponibilă" : "greșeli disponibile"}`);
  72  |   }
  73  |   return initial;
  74  | }
  75  | 
  76  | async function loseCommittedResponse(page, id, action) {
  77  |   let committed;
  78  |   await page.route(`**${gameURL(game, id)}/${action}`, async (route) => {
  79  |     const response = await route.fetch();
  80  |     expect(response.status()).toBe(200);
  81  |     committed = await response.json();
  82  |     await route.fulfill({ status: 503, contentType: "application/json", body: "{}" });
  83  |   }, { times: 1 });
  84  |   return () => committed;
  85  | }
  86  | 
  87  | async function newerRound(request) {
  88  |   const response = await request.post("/api/wordgames/conexiuni/games?seed=39&difficulty=usor");
  89  |   expect(response.status()).toBe(200);
  90  |   return response.json();
  91  | }
  92  | 
  93  | async function saveFromOtherTab(context, id) {
  94  |   const other = await context.newPage();
  95  |   await other.goto("/");
  96  |   await other.evaluate(([key, value]) => localStorage.setItem(key, value), [activeKey(game), id]);
  97  |   return other;
  98  | }
  99  | 
  100 | async function holdRecovery(page, id, missing = false) {
  101 |   let entered;
  102 |   let release;
  103 |   const requested = new Promise((resolve) => { entered = resolve; });
  104 |   const held = new Promise((resolve) => { release = resolve; });
  105 |   await page.route(`**${gameURL(game, id)}`, async (route) => {
  106 |     const response = await route.fetch();
  107 |     entered();
  108 |     await held;
  109 |     if (missing) await route.fulfill({ status: 404, contentType: "application/json", body: "{}" });
  110 |     else await route.fulfill({ response });
  111 |   }, { times: 1 });
  112 |   return { requested, release };
  113 | }
  114 | 
  115 | test.beforeEach(async ({ page }) => {
  116 |   await deterministicStarts(page, game);
  117 | });
  118 | 
  119 | test("a lost first clue is restored once, resumes exactly, and retains 100 points", async ({ page, request }) => {
  120 |   const initial = await prepare(page, request, { mistakes: 3 });
  121 |   const counts = traffic(page, initial.game_id);
  122 |   const committed = await loseCommittedResponse(page, initial.game_id, "clue");
  123 |   expect((await askClue(page, initial.game_id)).status()).toBe(503);
> 124 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Joc sincronizat. Poți continua." })).toBeVisible();
      |                                                                                    ^ Error: expect(locator).toBeVisible() failed
  125 |   await expect(clueButton(page)).toContainText("1 rămas");
  126 |   const server = await (await request.get(gameURL(game, initial.game_id))).json();
  127 |   expect(server.clues_used).toBe(1);
  128 |   expect(server.clues).toEqual(committed().clues);
  129 |   expect(server.solution).toBeUndefined();
  130 |   expect(server.solved).toEqual([]);
  131 |   await expect(page.getByText(server.clues[0].message, { exact: false })).toHaveCount(1);
  132 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  133 |   await page.locator(".connections-feedback").scrollIntoViewIfNeeded();
  134 |   await expect(page.locator(".connections-feedback")).toHaveCSS("opacity", "1");
  135 |   await page.screenshot({ path: test.info().outputPath("recovered-clue.png") });
  136 |   await page.reload();
  137 |   await expect(clueButton(page)).toContainText("1 rămas");
  138 |   await expect(page.getByText(server.clues[0].message, { exact: false })).toHaveCount(1);
  139 |   for (const step of steps()) expect((await guess(page, initial.game_id, step)).status()).toBe(200);
  140 |   await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeVisible();
  141 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).score).toBe(150);
  142 |   await expect.poll(() => played(page)).toBe(1);
  143 |   expect(counts.mutations).toBe(5);
  144 | });
  145 | 
  146 | test("a lost solved group removes only its four earned tiles and leaves answers private", async ({ page, request }) => {
  147 |   const initial = await prepare(page, request);
  148 |   const counts = traffic(page, initial.game_id);
  149 |   const committed = await loseCommittedResponse(page, initial.game_id, "guess");
  150 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(503);
  151 |   await expect(page.locator(`${game.board} button`)).toHaveCount(12);
  152 |   await expect(page.locator(`${game.board} [aria-pressed=true]`)).toHaveCount(0);
  153 |   await expect(page.getByText(committed().category.label, { exact: true })).toBeVisible();
  154 |   const server = await (await request.get(gameURL(game, initial.game_id))).json();
  155 |   expect(server.solved_count).toBe(1);
  156 |   expect(server.solved).toEqual(committed().solved);
  157 |   expect(server.solution).toBeUndefined();
  158 |   expect(server.one_away).toBeUndefined();
  159 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  160 |   expect(await played(page)).toBe(0);
  161 | });
  162 | 
  163 | for (const lost of [false, true]) {
  164 |   test(`a lost committed ${lost ? "loss" : "win"} adopts the terminal score exactly once`, async ({ page, request }) => {
  165 |     const initial = await prepare(page, request, lost ? { mistakes: 3 } : { solved: 3 });
  166 |     const counts = traffic(page, initial.game_id);
  167 |     const committed = await loseCommittedResponse(page, initial.game_id, "guess");
  168 |     expect((await guess(page, initial.game_id, lost ? wrong(3) : steps()[3])).status()).toBe(503);
  169 |     await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeVisible();
  170 |     await expect(page.getByText(lost ? "Ai rămas fără vieți." : "Ai găsit toate grupurile!", { exact: true })).toBeVisible();
  171 |     await expect.poll(() => played(page)).toBe(1);
  172 |     await expect.poll(() => remembered(page)).toBeNull();
  173 |     const server = await (await request.get(gameURL(game, initial.game_id))).json();
  174 |     expect(server.won).toBe(!lost);
  175 |     expect(server.lost).toBe(lost);
  176 |     expect(server.score).toBe(lost ? 0 : 1000);
  177 |     expect(server.score).toBe(committed().score);
  178 |     expect(server.solution).toHaveLength(4);
  179 |     expect(counts).toEqual({ reads: 1, mutations: 1 });
  180 |     await expect(page.getByText(lost ? "Ai rămas fără vieți." : "Ai găsit toate grupurile!", { exact: true }).locator("../..")).toHaveCSS("opacity", "1");
  181 |     await page.screenshot({ path: test.info().outputPath(`recovered-${lost ? "loss" : "win"}.png`), fullPage: true });
  182 |     await page.reload();
  183 |     await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  184 |     expect(await played(page)).toBe(1);
  185 |   });
  186 | }
  187 | 
  188 | test("failed verification persists, locks every board action, and retries by GET only", async ({ page, request }) => {
  189 |   await page.clock.install();
  190 |   const initial = await prepare(page, request, { mistakes: 3 });
  191 |   const counts = traffic(page, initial.game_id);
  192 |   await loseCommittedResponse(page, initial.game_id, "clue");
  193 |   await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({
  194 |     status: 503, contentType: "application/json", body: "{}",
  195 |   }), { times: 1 });
  196 |   expect((await askClue(page, initial.game_id)).status()).toBe(503);
  197 |   await expect(verify(page)).toBeEnabled();
  198 |   for (const button of await page.locator(`${game.board} button`).all()) await expect(button).toBeDisabled();
  199 |   for (const name of ["Verifică", "Amestecă", "Golește"]) {
  200 |     await expect(page.getByRole("button", { name, exact: true })).toBeDisabled();
  201 |   }
  202 |   await expect(clueButton(page)).toBeDisabled();
  203 |   await page.keyboard.press("Enter");
  204 |   await page.clock.fastForward(4000);
  205 |   await expect(verify(page)).toBeVisible();
  206 |   await page.locator(".connections-sync-recovery").scrollIntoViewIfNeeded();
  207 |   await expect(page.locator(".connections-sync-recovery")).toBeInViewport();
  208 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  209 |   expect(await remembered(page)).toBe(initial.game_id);
  210 |   await page.screenshot({ path: test.info().outputPath("read-only-recovery.png") });
  211 |   const response = responseFor(page, initial.game_id, "", "GET");
  212 |   await verify(page).click();
  213 |   expect((await response).status()).toBe(200);
  214 |   await expect(verify(page)).toHaveCount(0);
  215 |   await expect(clueButton(page)).toBeEnabled();
  216 |   await expect(clueButton(page)).toContainText("1 rămas");
  217 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).clues_used).toBe(1);
  218 |   expect(counts).toEqual({ reads: 2, mutations: 1 });
  219 | });
  220 | 
  221 | test("precommit failure preserves a valid selection and earned clue without replay", async ({ page, request }) => {
  222 |   const initial = await prepare(page, request, { mistakes: 2 });
  223 |   expect((await askClue(page, initial.game_id)).status()).toBe(200);
  224 |   const before = await (await request.get(gameURL(game, initial.game_id))).json();
```