import assert from "node:assert/strict";
import {test} from "../test-api.mjs";
import {installSynthetic} from "../fixtures.mjs";
import {ready,snapshot,depart,assertLocked,evidence,sampleExit} from "../contracts.mjs";
test.beforeEach(async({page})=>page.emulateMedia({reducedMotion:"reduce"}));
for(const game of ["intrusul","perechi"]){
 test(game+": reduce skips transform interpolation while opacity exits and controls lock",async({page,context})=>{
  const f=await installSynthetic(context,game);await ready(page,f);
  const present=await snapshot(page,game);assert.equal(present.reduced,true);
  const leaving=await depart(page,game);assertLocked(leaving);
  const samples=await sampleExit(page,game);
  await evidence(test,page,f,{present,leaving,samples});
  assert.equal(new Set(samples.map(s=>s.transform)).size,1,"reduced transforms must not interpolate during opacity interval");
  assert.ok(samples.every(s=>s.mounted&&s.opacity>0&&s.opacity<1),"sampled opacity interval must retain old board");
  assert.ok(samples.at(-1).opacity<samples[0].opacity,"opacity must progress during reduced exit");
 });
}
