import { chromium } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/node_modules/playwright/index.mjs';
import { writeFileSync, readFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const root='/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity';
const out='/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/derived-recovery';
const browser=await chromium.launch({headless:true});
const records=[];
const sha=(p)=>createHash('sha256').update(readFileSync(`${root}/${p}`)).digest('hex');
const pins=Object.fromEntries(['frontend/src/screens/Intrusul.tsx','frontend/src/screens/Perechi.tsx','frontend/src/gameActionRecovery.mjs','cat_de_roman_esti/web/static/.vite/manifest.json','cat_de_roman_esti/web/static/index.html'].map(p=>[p,sha(p)]));
for(const game of ['intrusul','perechi']) {
 const fixture=JSON.parse(execFileSync('/home/dobo/work/cat_de_roman_esti/.venv/bin/python',[`${root}/frontend/e2e/solutions.py`,game],{cwd:root,env:{...process.env,PYTHONPATH:root},encoding:'utf8'}));
 for(const scenario of ['lost-practice','lost-hint','lost-win','lost-loss','failed-read','late-mutation-pointer','late-read-pointer','late-404-pointer','wrong-get-id','unmount','owned-404']) {
  const context=await browser.newContext({baseURL:'http://127.0.0.1:8188',viewport:{width:390,height:844},reducedMotion:'reduce'});
  const page=await context.newPage(); const api=context.request; const events=[]; let initial; let foreign;
  try {
   await page.route(`**/api/wordgames/${game}/games?*`,r=>{const u=new URL(r.request().url());u.searchParams.set('seed','38');return r.continue({url:u.toString()});});
   await page.goto(`/${game}`); const created=page.waitForResponse(r=>r.request().method()==='POST'&&new URL(r.url()).pathname===`/api/wordgames/${game}/games`);
   await page.getByRole('button',{name:/^Joacă(?: →)?$/}).click(); initial=await (await created).json(); const url=`/api/wordgames/${game}/games/${initial.game_id}`;
   const post=async(step)=>{const r=await api.post(`${url}/${step.action}`,{data:step.payload});return r.json();};
   const bad=game==='intrusul'?initial.tiles.filter(t=>t.id!==fixture.steps[0].payload.id).map(t=>({action:'guess',labels:[t.label],payload:{id:t.id}})):[...fixture.steps[0].payload.ids.flatMap(a=>fixture.steps[1].payload.ids.map(b=>[a,b])),[fixture.steps[0].payload.ids[0],fixture.steps[2].payload.ids[0]],[fixture.steps[0].payload.ids[1],fixture.steps[2].payload.ids[0]]].map(ids=>({action:'match',payload:{ids},labels:ids.map(id=>initial.tiles.find(t=>t.id===id).label)}));
   let step=fixture.practice;
   if(scenario==='lost-hint'||scenario==='failed-read') {for(const s of bad.slice(0,game==='intrusul'?1:2))await post(s);step={action:'hint'};}
   if(scenario==='lost-win'||scenario.startsWith('late-')||scenario==='unmount') {for(const s of fixture.steps.slice(0,-1)) await post(s);step=fixture.steps.at(-1);}
   if(scenario==='lost-loss') {for(const s of bad.slice(0,initial.remaining_mistakes-1))await post(s);step=bad[initial.remaining_mistakes-1];}
   await page.reload();await page.locator(`.${game}-grid`).waitFor();
   page.on('response',async r=>{if(new URL(r.url()).pathname.startsWith(url)){let body;try{body=await r.json();}catch{body=null;}events.push({method:r.request().method(),path:new URL(r.url()).pathname,status:r.status(),body});}});
   let committed;let release;let entered;const held=new Promise(r=>release=r);const requested=new Promise(r=>entered=r);
   await page.route(`**${url}/${step.action}`,async route=>{const r=await route.fetch();committed=await r.json();if(scenario==='late-mutation-pointer'||scenario==='unmount'){entered();await held;await route.fulfill({response:r});}else await route.fulfill({status:503,json:{}});},{times:1});
   if(scenario==='failed-read'||scenario==='owned-404')await page.route(`**${url}`,r=>r.fulfill({status:scenario==='owned-404'?404:503,json:{}}),{times:1});
   if(scenario==='wrong-get-id')await page.route(`**${url}`,async route=>{const r=await route.fetch();await route.fulfill({json:{...await r.json(),game_id:'another-response-id'}});},{times:1});
   if(scenario==='late-read-pointer'||scenario==='late-404-pointer')await page.route(`**${url}`,async route=>{const r=await route.fetch();entered();await held;if(scenario==='late-404-pointer')await route.fulfill({status:404,json:{}});else await route.fulfill({response:r});},{times:1});
   const act=async()=>{if(step.action==='hint') await page.getByRole('button',{name:game==='intrusul'?'💡 Arată indiciul':'💡 Arată o pereche',exact:true}).click();else for(const label of step.labels)await page.locator(`.${game}-grid`).getByRole('button',{name:label,exact:true}).click();};
   const action=act();
   if(scenario.startsWith('late-')){await requested;foreign=await (await api.post(`/api/wordgames/${game}/games?seed=39&starter=1`)).json();const tab=await context.newPage();await tab.goto('/');await tab.evaluate(([key,id])=>localStorage.setItem(key,id),[`cat_active_game_v1_${game}`,foreign.game_id]);release();}
   if(scenario==='unmount'){await requested;await page.getByRole('button',{name:'Ieși la lista de jocuri'}).click();release();}
   await action; await page.waitForTimeout(800);
   const server=await (await api.get(url)).json();
   const observation={game,scenario,initial,committed,server,foreign:foreign?.game_id,events,ui:{feedback:await page.locator(`.${game}-feedback`).allTextContents(),retry:await page.getByRole('button',{name:'Verifică jocul',exact:true}).count(),loadCurrent:await page.getByRole('button',{name:'Încarcă jocul curent',exact:true}).count(),enabledTiles:await page.locator(`.${game}-grid button:not(:disabled)`).count(),results:await page.getByRole('button',{name:'Copiază rezultatul'}).count(),intro:await page.getByRole('button',{name:/^Joacă(?: →)?$/}).count(),storage:await page.evaluate((game)=>({saved:localStorage.getItem(`cat_active_game_v1_${game}`),played:JSON.parse(localStorage.getItem('cat_wordgame_scores_v1')||'{}')[game]?.played??0}),game)}};
   await page.screenshot({path:`${out}/candidate-${game}-${scenario}.png`,fullPage:true});records.push(observation);console.log(JSON.stringify({game,scenario,ui:observation.ui,won:server.won,lost:server.lost,hints:server.hints_used}));
  } catch(error){records.push({game,scenario,error:String(error)});console.log(JSON.stringify({game,scenario,error:String(error)}));}
  finally {await context.close();writeFileSync(`${out}/candidate.json`,JSON.stringify({baseline:'e2e03638b90fc9248c33f70eedaa8c9c5fbd87ad',variant:'candidate worktree built static',pins,records},null,2)+'\n');}
 }
}
await browser.close();
