import sys,pathlib,hashlib
sys.path.insert(0,r'C:/Users/Paul Work/AppData/Local/hermes/hermes-agent/venv/Lib/site-packages')
p=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7/probe/native-docs-windows-r3.py')
b=p.read_bytes()
if hashlib.sha256(b).hexdigest()!='73502f5b0ed9fbe40d34f258e793b22dc709b93d77562755422364c22663d8ee':raise RuntimeError('guard raw bytes drift')
exec(compile(b,str(p),'exec'),{'__name__':'__main__','__file__':str(p)})
