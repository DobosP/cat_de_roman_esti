import ctypes,hashlib,json,os,pathlib,queue,shutil,subprocess,sys,threading,time,datetime
spec_path=pathlib.Path(sys.argv[1]);spec=json.loads(spec_path.read_text(encoding="utf-8"));run=pathlib.Path(spec["windows_run"])
assert not run.exists(),"fresh campaign output exists"
run.mkdir();(run/"tmp").mkdir();cancel=run/"cancel"
root=pathlib.Path(spec["windows_R"]); scratch=pathlib.Path(spec["windows_S"])
GiB=1024**3
class MEM(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","totalPage","availablePage","totalVirtual","availableVirtual","extra"]]
class PMC(ctypes.Structure):
 _fields_=[("cb",ctypes.c_ulong),("faults",ctypes.c_ulong)]+[(x,ctypes.c_size_t) for x in ["peakWS","WS","peakPaged","paged","peakNonpaged","nonpaged","pagefile","peakPagefile"]]
kernel=ctypes.WinDLL("kernel32",use_last_error=True);psapi=ctypes.WinDLL("psapi",use_last_error=True)
kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
kernel.CloseHandle.argtypes=[ctypes.c_void_p];psapi.GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.POINTER(PMC),ctypes.c_ulong]
def host_rss(pid,required=True):
 h=kernel.OpenProcess(0x410,False,pid)
 if not h:
  if not required: return 0
  raise RuntimeError("host RSS process unavailable")
 try:
  m=PMC();m.cb=ctypes.sizeof(m);assert psapi.GetProcessMemoryInfo(h,ctypes.byref(m),m.cb)
  return m.WS
 finally: kernel.CloseHandle(h)
def available():
 m=MEM();m.length=ctypes.sizeof(m);assert kernel.GlobalMemoryStatusEx(ctypes.byref(m));return m.available
def count():return sum(p.stat().st_size for tree in (root,scratch) for p in tree.rglob("*") if p.is_file())
def hashfile(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def pins():
 for path,digest in spec["windows_protected"].items():assert hashfile(path)==digest,path
def publish(v):
 p=run/"state.json";tmp=run/"state.part";tmp.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode("utf-8"));os.replace(tmp,p)
baseline=spec["full_R_S_baseline"];peak=0;completed=[];carrier=None;states=[]
assert spec["started_epoch"]<=time.time()<spec["deadline_epoch"]-195
assert shutil.disk_usage(root).free>=17*GiB and available()>=spec["memory_floor"]
assert count()-baseline<=spec["growth_cap"];pins()
state={"kind":"running","started_epoch":spec["started_epoch"],"deadline_epoch":spec["deadline_epoch"],"baseline":baseline,"completed":completed,"rss_scope":"Windows Python controller + native exec PowerShell launcher + owned WSL carrier + Linux supervisor/owned Go process group; Codex source workers excluded."};publish(state)
try:
 for index,step in enumerate(spec["steps"]):
  pins();assert time.time()<spec["deadline_epoch"]-195;assert not pathlib.Path(step["windows_output"]).exists()
  events=queue.Queue(); complete=None;latest=0;last_count=0
  carrier=subprocess.Popen(["wsl.exe","--exec","/usr/bin/python3.14",spec["linux_guard"],spec["linux_spec"],str(index)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding="utf-8")
  def read(owned_carrier=carrier):
   try:
    for line in owned_carrier.stdout: events.put(json.loads(line))
   except BaseException as exc: events.put({"kind":"failed","error":"telemetry reader: "+repr(exc)})
  reader=threading.Thread(target=read);reader.start()
  with (run/(step["name"]+".telemetry.jsonl")).open("w",encoding="utf-8",newline="\n") as stream:
   while True:
    while True:
     try: event=events.get_nowait()
     except queue.Empty: break
     stream.write(json.dumps(event,separators=(",",":"))+"\n");stream.flush()
     if event["kind"]=="sample":latest=event["rss"]
     elif event["kind"]=="complete":complete=event
     elif event["kind"]=="failed":raise RuntimeError(event["error"])
    total=latest+host_rss(os.getpid())+host_rss(spec["host_launcher_pid"])+host_rss(carrier.pid,False)
    peak=max(peak,total)
    assert total<=spec["rss_cap"] and available()>=spec["memory_floor"],"parent-inclusive RSS or host memory guard"
    assert time.time()<spec["deadline_epoch"]-180,"metadata reserve guard"
    if time.monotonic()-last_count>=2:
     assert shutil.disk_usage(root).free>=16*GiB and count()-baseline<=spec["growth_cap"],"wholeR/S disk/growth guard";last_count=time.monotonic()
    if carrier.poll() is not None and not reader.is_alive() and events.empty():break
    time.sleep(.25)
  reader.join(timeout=3);assert not reader.is_alive();assert carrier.wait()==0 and complete and complete["group_absent"]
  stderr=carrier.stderr.read();(run/(step["name"]+".controller.stderr.log")).write_bytes(stderr.encode("utf-8"))
  pins();data=json.loads(pathlib.Path(step["windows_output"]).read_text(encoding="utf-8"));expected=spec["candidate_sha256"]
  assert data["candidate_sha256"]==expected
  if index==0:
   assert data["kind"]=="quick-content-catalog-v1" and len(data["authored"])==85
   assert {x["role"]:x["reviewer"] for x in data["reviews"]}==spec["reviewer_ids"]
   assert {x["role"]:x["sha256"] for x in data["reviews"]}==spec["review_hashes"]
   assert data["excluded"]==[]
   assert {x["id"] for x in data["authored"]}=={x["id"] for x in json.loads(pathlib.Path(spec["windows_candidate"]).read_text(encoding="utf-8"))["boards"]}
  else:
   assert data["kind"]=="quick-content-live-audit-v1" and data["passed"] is True and data["native_audit_version"]==1
   assert data["catalog_sha256"]==hashfile(spec["steps"][0]["windows_output"])
   assert data["core_boards_preserved"] is True and data["requests"]==460
   expected_ids={x["id"] for x in json.loads(pathlib.Path(spec["windows_candidate"]).read_text(encoding="utf-8"))["boards"]}
   assert len(data["replays"])==85 and {x["id"] for x in data["replays"]}==expected_ids
   assert all(x["hidden_answers_preserved"] is True and x["terminal_get_preserved"] is True and x["score"]==1000 for x in data["replays"])
   assert isinstance(data["runtime_sources"],list) and len({x["path"] for x in data["runtime_sources"]})==len(data["runtime_sources"])==110
   assert isinstance(data["source_bindings"],dict) and len(data["source_bindings"])==9
   expected_runtime=spec["runtime_bindings"]
   assert {x["path"]:x["sha256"] for x in data["runtime_sources"]}==expected_runtime
   assert data["source_bindings"]==spec["source_bindings"]
  completed.append({"step":step["name"],"output_sha256":hashfile(step["windows_output"]),"native_peak":complete["native_peak"]})
  carrier=None;state.update({"completed":completed,"parent_inclusive_peak":peak,"whole_R_S_bytes":count()});publish(state)
 assert time.time()<spec["deadline_epoch"]-180
 state.update({"kind":"passed","finished_epoch":time.time(),"parent_inclusive_peak":peak,"final_growth":count()-baseline,"all_protected_exact":True});publish(state)
 print(json.dumps({"kind":"PASS","completed":len(completed),"parent_inclusive_peak":peak,"growth":state["final_growth"]}))
except BaseException as exc:
 cancel.write_text("cancel",encoding="utf-8")
 if carrier is not None and carrier.poll() is None:
  try:carrier.wait(timeout=12)
  except subprocess.TimeoutExpired:
   carrier.terminate();carrier.wait(timeout=5)
 state.update({"kind":"failed","error":repr(exc),"finished_epoch":time.time(),"parent_inclusive_peak":peak,"completed":completed});publish(state)
 print(json.dumps({"kind":"FAILED","error":repr(exc),"completed":len(completed)}));raise
