import { test, expect } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates/frontend/node_modules/@playwright/test/index.mjs';
import { writeFileSync } from 'node:fs';
import {games,gameURL,deterministicStarts,start,act,solution} from './baseline-gamehelpers.mjs';
const game=games[0];
for (const kind of ['combine','reset','hint','win']) test(`baseline lost ${kind}`,async({page,request})=>{
 await deterministicStarts(page,game); const initial=await start(page,game); const id=initial.game_id;
 const steps=solution(game).steps;
 if(kind==='reset'||kind==='win') for(const step of steps.slice(0,kind==='reset'?1:-1)) await request.post(`${gameURL(game,id)}/combine`,{data:step.payload});
 if(kind==='hint') {
  outer: for(let a=0;a<initial.inventory.length;a++) for(let b=a+1;b<initial.inventory.length;b++) {
   const r=await (await request.post(`${gameURL(game,id)}/combine`,{data:{a:initial.inventory[a].id,b:initial.inventory[b].id}})).json();
   if(r.hint_available) break outer;
  }
 }
 if(kind!=='combine') { await page.reload(); await expect(page.locator(game.board)).toBeVisible(); }
 const before=await (await request.get(gameURL(game,id))).json(); let committed; const counts={reads:0,mutations:0};
 page.on('request',r=>{const path=new URL(r.url()).pathname;if(r.method()==='GET'&&path===gameURL(game,id))counts.reads++;if(r.method()==='POST'&&path.startsWith(gameURL(game,id)+'/'))counts.mutations++;});
 const action=kind==='win'?'combine':kind;
 await page.route(`**${gameURL(game,id)}/${action}`,async route=>{const r=await route.fetch();expect(r.status()).toBe(200);committed=await r.json();await route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({detail:'Răspuns pierdut.'})});},{times:1});
 if(action==='combine') await act(page,game,kind==='win'?steps.at(-1):steps[0]);
 else await page.getByRole('button',{name:action==='hint'?'💡 Indiciu':/Reia același joc/}).click();
 await expect(page.getByText(action==='reset'?'Nu am putut reseta (503).':'Răspuns pierdut.',{exact:true})).toBeVisible();
 const after=await (await request.get(gameURL(game,id))).json();
 expect(counts).toEqual({reads:0,mutations:1});
 if(kind==='combine') {expect(after.discovered_count).toBeGreaterThan(before.discovered_count); for(const d of committed.discovered)await expect(page.locator(game.board).getByRole('button',{name:new RegExp('^'+d.label+'(?:,|$)')})).toHaveCount(0);}
 if(kind==='reset') {expect(after.moves).toBe(0);expect(before.moves).toBe(1);}
 if(kind==='hint') {expect(after.hints_used).toBe(1);expect(after.hint).toBeUndefined();expect(after.hint_output).toBeUndefined();expect(after.earned_hint).toBeUndefined();await expect(page.getByText(committed.message,{exact:true})).toHaveCount(0);}
 if(kind==='win') {expect(after.won).toBe(true);await expect(page.getByRole('button',{name:'Copiază rezultatul'})).toHaveCount(0);}
 await expect(page.locator('.screen')).toHaveCSS('opacity','1');
 await page.screenshot({path:test.info().outputPath(`baseline-${kind}.png`),fullPage:true});
 writeFileSync(test.info().outputPath(`baseline-${kind}.json`),JSON.stringify({kind,before,committed,after,counts,body:await page.locator('body').innerText()},null,2)+'\n');
});
