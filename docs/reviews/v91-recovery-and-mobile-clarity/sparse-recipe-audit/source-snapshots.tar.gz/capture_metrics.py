from __future__ import annotations

import gzip
import hashlib
import json
import os
import time
from collections import Counter
from pathlib import Path
from statistics import median

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'cat_de_roman_esti.web.settings')
import django
django.setup()

from cat_de_roman_esti.wordgames import alchimie as A
from cat_de_roman_esti.wordgames.packs import CuratedItem, get_pack
from tests.test_alchimie_sparse_recipes import (
    _projection_row, approved_projections, v87_projection_snapshot,
)
from tests.content_history import before_v88_pack

ROOT = Path.cwd()
OUT = Path('/home/dobo/work/_temp/feat__v91-recovery-and-mobile-clarity/sparse-recipe-audit')
REVIEW = ROOT / 'docs/reviews/v91-recovery-and-mobile-clarity/content'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def metrics(projections):
    rows, minima, weak, openings = [], [], [], Counter()
    for item, projection in projections:
        rows.append(_projection_row(item, projection))
        for index, route in enumerate(projection.routes):
            quality = A._route_quality(route)
            minima.append(quality[0])
            if quality[0] < A.PREFERRED_RECIPE_STRENGTH:
                assert index == 0
                weak.append(item.id)
        openings[A._projected_opening_pair_count(item.payload['seeds'], projection.recipes)] += 1
    return {
        'boards': len(rows), 'rows_sha256': digest(rows),
        'recipes': sum(len(row['recipes']) for row in rows),
        'two_result_recipes': sum(len(recipe) == 4 for row in rows for recipe in row['recipes']),
        'routes': dict(Counter(row['routes'] for row in rows)),
        'opening_counts': dict(openings), 'route_minima': minima,
        'minimum_selected_strength': min(minima), 'median_selected_strength': median(minima),
        'weak_fallbacks': weak,
    }


start = time.perf_counter()
current, elapsed = approved_projections.__wrapped__()
current_metrics = metrics(current)
historical_rows, historical_minima = v87_projection_snapshot.__wrapped__()
pack = json.loads((ROOT / 'cat_de_roman_esti/fixtures/games_pack.json').read_bytes())
historical_pack = before_v88_pack(pack)
historical_by_id = {row['id']: row for row in historical_rows}
proposal = json.loads((REVIEW / 'replacement-proposal.json').read_bytes())
old = proposal['before']
old_item = CuratedItem(old['id'], 'alchimie', old['category'], old['difficulty'],
                       old['source'], old['status'],
                       {key: old[key] for key in ('seeds', 'target', 'target_depth')})
A._build_recipe_projection_cached.cache_clear()
old_projection = A._build_recipe_projection(old['seeds'], old['target'], old['category'])
assert old_projection is not None
assert _projection_row(old_item, old_projection) == historical_by_id[old['id']]
previous = [(old_item, old_projection) if item.id == old['id'] else (item, projection)
            for item, projection in current]
previous_metrics = metrics(previous)
current_rows = [_projection_row(item, projection) for item, projection in current]
previous_rows = [_projection_row(item, projection) for item, projection in previous]
assert [row for row in previous_rows if row['id'] != 'al_gastronomie_107'] == historical_rows

archive_checks = {}
for filename, projections in [('all-83-books-before.json.gz', previous),
                              ('all-83-books-candidate.json.gz', current)]:
    raw = json.loads(gzip.decompress((REVIEW / filename).read_bytes()))
    archived_rows = []
    for item, projection in projections:
        archived = raw[item.id]
        archived_rows.append({'id': item.id, 'par': archived['par'], 'routes': len(archived['routes']),
                              'recipes': [[*step['pair'], *step['outputs']]
                                          for step in archived['recipes']]})
    actual = [_projection_row(item, projection) for item, projection in projections]
    assert archived_rows == actual
    archive_checks[filename] = {'approved_boards_match': len(actual), 'rows_sha256': digest(actual)}

historical_seed_by_id = {row['id']: row['seeds'] for row in historical_pack['alchimie']}
historical_openings = Counter(A._projected_opening_pair_count(
    historical_seed_by_id[row['id']],
    {tuple(step[:2]): tuple(step[2:]) for step in row['recipes']},
) for row in historical_rows)
historical_metrics = {
    'boards': len(historical_rows), 'rows_sha256': digest(historical_rows),
    'recipes': sum(len(row['recipes']) for row in historical_rows),
    'two_result_recipes': sum(len(step) == 4 for row in historical_rows for step in row['recipes']),
    'routes': dict(Counter(row['routes'] for row in historical_rows)),
    'opening_counts': dict(historical_openings),
    'minimum_selected_strength': min(historical_minima),
    'median_selected_strength': median(historical_minima),
}
report = {
    'date': '2026-09-09', 'kind': 'cold-approved-alchimie-expectation-audit',
    'runtime_unchanged': hashlib.sha256((ROOT/'cat_de_roman_esti/wordgames/alchimie.py').read_bytes()).hexdigest()
        == proposal['source_bindings']['cat_de_roman_esti/wordgames/alchimie.py'],
    'current_projection_elapsed_seconds': elapsed,
    'capture_elapsed_seconds': time.perf_counter()-start,
    'v87': historical_metrics, 'v90_before_reviewed_revision': previous_metrics,
    'v91_current': current_metrics,
    'sport_before': next(row for row in previous_rows if row['id'] == old['id']),
    'sport_after': next(row for row in current_rows if row['id'] == old['id']),
    'changed_projection_ids': [old['id'] for old,new in zip(previous_rows,current_rows,strict=True)
                               if old != new],
    'archived_review_comparisons': archive_checks,
}
(OUT/'metrics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key: {k:v for k,v in value.items() if k != 'route_minima'}
                  if key in ('v87','v90_before_reviewed_revision','v91_current') else value
                  for key,value in report.items()},ensure_ascii=False,indent=2))
