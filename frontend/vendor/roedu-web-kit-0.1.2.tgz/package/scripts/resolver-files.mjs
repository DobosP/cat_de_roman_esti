import * as fs from 'node:fs';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import assert from 'node:assert/strict';
export const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
export const json=value=>Buffer.from(JSON.stringify(value,null,2)+'\n');
export function sourceFile(root,relative) {
  assert.ok(typeof relative==='string'&&relative&&!path.isAbsolute(relative)&&!/[\\:\x00-\x1f\x7f]/.test(relative)&&relative.split('/').every(p=>p&&p!=='.'&&p!=='..'),'Literal resolver source path required');
  let file=root;
  for(const [index,part] of relative.split('/').entries()) {
    file=path.join(file,part);const stat=fs.lstatSync(file);
    assert.ok(!stat.isSymbolicLink()&&(index===relative.split('/').length-1?stat.isFile():stat.isDirectory()),`Resolver source is not regular: ${relative}`);
  }
  return file;
}
export function planner(root) {
  const inputs=new Map(),writes=new Map();
  const read=relative=>{const file=sourceFile(root,relative),bytes=fs.readFileSync(file),mode=fs.statSync(file).mode&0o777;const previous=inputs.get(relative);assert.ok(!previous||previous.bytes.equals(bytes),`Resolver input changed: ${relative}`);inputs.set(relative,{bytes,mode});return bytes;};
  const put=(relative,bytes)=>{if(!inputs.has(relative))read(relative);writes.set(relative,Buffer.from(bytes));};
  const validate=()=>{for(const [relative,input] of inputs){assert.ok(fs.readFileSync(sourceFile(root,relative)).equals(input.bytes)&&(fs.statSync(sourceFile(root,relative)).mode&0o777)===input.mode,`Resolver input changed before publication: ${relative}`);}};
  const commit=()=>{
    validate();const done=[];
    try {
      for(const [relative,bytes] of writes){const input=inputs.get(relative);if(bytes.equals(input.bytes))continue;const file=sourceFile(root,relative),temporary=file+'.resolver-'+randomUUID()+'.tmp';
        try{fs.writeFileSync(temporary,bytes,{flag:'wx',mode:input.mode});fs.chmodSync(temporary,input.mode);assert.ok(fs.readFileSync(file).equals(input.bytes),'Source changed during resolver publication');fs.renameSync(temporary,file);done.push(relative);}finally{fs.rmSync(temporary,{force:true});}
      }
    }catch(error){for(const relative of done.reverse()){const file=sourceFile(root,relative);assert.ok(fs.readFileSync(file).equals(writes.get(relative)),`Cannot roll back concurrently changed source: ${relative}`);fs.writeFileSync(file,inputs.get(relative).bytes);fs.chmodSync(file,inputs.get(relative).mode);}throw error;}
    return done;
  };
  return {read,put,validate,commit,inputs,writes};
}
