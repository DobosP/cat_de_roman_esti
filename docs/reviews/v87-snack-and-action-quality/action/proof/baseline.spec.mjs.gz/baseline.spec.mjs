import {test, expect} from "/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v87-snack-and-action-quality/frontend/node_modules/@playwright/test/index.mjs";
import {games, activeKey, gameURL, deterministicStarts, solution, start, act} from "/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v87-snack-and-action-quality/frontend/e2e/games.mjs";
import {writeFileSync} from "node:fs";
const game=games.find((item)=>item.key==="contexto");
const input=(page)=>page.getByRole("textbox",{name:"Concept de ghicit"});
const out="/home/dobo/work/_temp/feat__v87-snack-and-action-quality/action/proof";
test("baseline loses a committed win and cannot recover by retrying the answer", async({page,request})=>{
 await deterministicStarts(page,game); const created=await start(page,game);const answer=solution(game).steps.at(-1);
 let committed;
 await page.route(`**${gameURL(game,created.game_id)}/guess`,async(route)=>{
  const result=await route.fetch();expect(result.status()).toBe(200);committed=await result.json();
  await route.fulfill({status:503,contentType:"application/json",body:'{"detail":"Upstream response lost."}'});
 },{times:1});
 expect((await act(page,game,answer)).status()).toBe(503);
 await expect(input(page)).toBeEnabled();expect(committed.won).toBe(true);
 const authoritative=await(await request.get(gameURL(game,created.game_id))).json();expect(authoritative.won).toBe(true);
 await expect(page.getByRole("button",{name:"Copiază rezultatul"})).toHaveCount(0);
 const retried=await act(page,game,answer);expect(retried.status()).toBe(400);
 await expect(input(page)).toBeEnabled();await expect(page.getByRole("button",{name:"Copiază rezultatul"})).toHaveCount(0);
 const pointer=await page.evaluate((key)=>localStorage.getItem(key),activeKey(game));expect(pointer).toBe(created.game_id);
 const played=await page.evaluate(()=>JSON.parse(localStorage.getItem("cat_wordgame_scores_v1")||"{}").contexto?.played??0);expect(played).toBe(0);
 writeFileSync(`${out}/lost-win.json`,JSON.stringify({server_won:true,server_score:authoritative.score,client_result_visible:false,repeat_status:400,client_input_still_enabled:true,saved_pointer_retained:true,local_played:played},null,2)+"\n");
 await page.screenshot({path:`${out}/lost-win.png`});
});
test("baseline charges another clue when the committed first clue response is lost",async({page,request})=>{
 await deterministicStarts(page,game);const created=await start(page,game);
 const answer=solution(game).steps.at(-1).payload.text.toLowerCase();
 for(const text of ["fotbal","stilou","București","măr"].filter((text)=>text.toLowerCase()!==answer).slice(0,3)){
  const result=await act(page,game,{action:"guess",payload:{text}});expect((await result.json()).won).toBe(false);
 }
 let committed;
 await page.route(`**${gameURL(game,created.game_id)}/clue`,async(route)=>{
  const result=await route.fetch();expect(result.status()).toBe(200);committed=await result.json();
  await route.fulfill({status:503,contentType:"application/json",body:'{"detail":"Upstream response lost."}'});
 },{times:1});
 let response=page.waitForResponse((r)=>new URL(r.url()).pathname.endsWith('/clue'));
 await page.getByRole("button",{name:"Indiciu",exact:true}).click();expect((await response).status()).toBe(503);
 await expect(input(page)).toBeEnabled();expect(committed.clues_used).toBe(1);
 response=page.waitForResponse((r)=>new URL(r.url()).pathname.endsWith('/clue'));
 await page.getByRole("button",{name:"Indiciu",exact:true}).click();expect((await response).status()).toBe(200);
 const authoritative=await(await request.get(gameURL(game,created.game_id))).json();expect(authoritative.clues_used).toBe(2);
 writeFileSync(`${out}/lost-clue.json`,JSON.stringify({first_clue_committed:true,first_response_lost:true,clues_after_first:1,clues_after_natural_retry:authoritative.clues_used},null,2)+"\n");
});
