import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {resolve} from "node:path";
import {descriptor,binding} from "./descriptor.mjs";
import {caseId} from "./policy.mjs";
const api=await import("file://"+binding.browser.package_root+"/test.mjs");
export const {expect,defineConfig}=api;
export const test=api.test.extend({
 _strictWitness:[async({page,browser},use,info)=>{
  const assets=new Map(),pending=[],htmlEntries=[],originViolations=[];
  const appOrigin=new URL(binding.app.base_url).origin;
  await page.route("**/*",async route=>{
   const req=route.request(),url=new URL(req.url());
   if(["script","stylesheet","font"].includes(req.resourceType())&&url.origin!==appOrigin){originViolations.push(req.url());return route.abort("blockedbyclient");}
   return route.fallback();
  });
  const reduced=info.project.name==="reduce";
  await page.emulateMedia({reducedMotion:reduced?"reduce":"no-preference"});
  const observe=async response=>{
   const url=new URL(response.url());
   if(url.origin!==appOrigin){if(["script","stylesheet","font"].includes(response.request().resourceType()))throw Error("cross-origin frontend response");return;}
   const path=url.pathname.slice(1);
   if(!Object.hasOwn(binding.build.assets,path)){assert.ok(!/\.(?:[cm]?js|css|woff2?)$/.test(path)&&!path.startsWith("assets/"),"unexpected frontend asset "+path);return;}
   const bytes=await response.body();
   const sha=createHash("sha256").update(bytes).digest("hex");
   assert.equal(sha,binding.build.assets[path],"served asset bytes differ: "+path);
   if(binding.profile==="target-acceptance"&&/\.[cm]?js$/.test(path))assert.ok(!binding.build.frozen_entry_js_sha256.includes(sha),"frozen SPA entry loaded through bootstrap");
   assets.set(path,{path,sha256:sha,origin:url.origin});
  };
  page.on("response",response=>pending.push(observe(response)));
  const nativeGoto=page.goto.bind(page),nativeBack=page.goBack.bind(page);
  const witnessPage=async()=>{
   const ui=await page.locator("html").getAttribute("data-ui");
   assert.equal(ui,binding.app.ui,"actual app UI identity mismatch");
   const preference=await page.evaluate(()=>matchMedia("(prefers-reduced-motion: reduce)").matches);
   assert.equal(preference,reduced,"actual browser media mismatch");
   const scriptUrls=await page.locator('script[src]').evaluateAll(nodes=>nodes.map(n=>n.src));
   const origins=scriptUrls.map(u=>new URL(u).origin);assert.ok(origins.every(o=>o===appOrigin),"cross-origin script even with matching pathname");
   const scripts=scriptUrls.map(u=>new URL(u).pathname.slice(1));
   assert.deepEqual([...scripts].sort(),[...binding.build.entry_scripts].sort(),"extra/wrong HTML script entries");
   const inline=await page.locator("script:not([src])").evaluateAll(nodes=>nodes.filter(n=>!["application/json","application/ld+json","speculationrules"].includes(n.type)).length);
   assert.equal(inline,0,"unbound executable inline script");
   htmlEntries.push({url:page.url(),ui,scripts,origins,scriptUrls});
  };
  page.goto=async(...args)=>{const response=await nativeGoto(...args);await witnessPage();return response;};
  page.goBack=async(...args)=>{const response=await nativeBack(...args);await witnessPage();return response;};
  await use();
  await Promise.all(pending);assert.deepEqual(originViolations,[],"cross-origin script/style/font request");
  assert.ok(htmlEntries.length>0,"no observed app document");
  for(const entry of binding.build.entry_scripts)assert.ok(assets.has(entry),"bound entry was not actually fetched");
  assert.ok(Array.isArray(info.titlePath),"complete Playwright title path required");
  const id=caseId({project:info.project.name,file:resolve(info.file),title:info.titlePath.slice(1).join(" › ")});
  const actualVersion=browser.version();
  assert.ok(binding.browser.actual_version.includes(actualVersion),"launched browser version differs from preflight binary");
  await info.attach("binding-evidence",{body:JSON.stringify({
   run_id:descriptor.run_id,descriptor_sha256:descriptor.descriptor_sha256,profile:binding.profile,case_id:id,
   source_head:binding.source.head,source_tree:binding.source.tree,build_assets_sha256:binding.build.assets_sha256,
   browser_version:binding.browser.actual_version,image_digest:binding.runtime.image_digest,ui:binding.app.ui,
   reduced:await page.evaluate(()=>matchMedia("(prefers-reduced-motion: reduce)").matches),
   selection:"complete-inventory-no-filters",served_assets:[...assets.values()],htmlEntries,
   argv:descriptor.argv,html_script_entries:htmlEntries[0].scripts,html_script_origins:htmlEntries[0].origins,
   effective_config:{grep:(Array.isArray(info.config.grep)?info.config.grep:[info.config.grep]).map(r=>({source:r.source,flags:r.flags})),grepInvert:info.config.grepInvert?String(info.config.grepInvert):null,
    projectGrep:(Array.isArray(info.project.grep)?info.project.grep:[info.project.grep]).map(r=>({source:r.source,flags:r.flags})),projectGrepInvert:info.project.grepInvert?String(info.project.grepInvert):null,
    updateSnapshots:info.config.updateSnapshots,forbidOnly:info.config.forbidOnly,retries:info.project.retries,repeatEach:info.project.repeatEach,shard:info.config.shard},
   package_closure_sha256:binding.browser.package_closure_sha256,node_executable_sha256:binding.node.executable_sha256,
   source_mutants_executed:false,formal_gate:false
  }),contentType:"application/json"});
 },{auto:true}]
});
