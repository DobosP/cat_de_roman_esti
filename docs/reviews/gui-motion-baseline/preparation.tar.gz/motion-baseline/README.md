Valid until: S1 is dispatched at a settled app base or these tests are imported into the reviewed pinned runner — then recapture and treat this preview as history.

# Scratch React motion baseline

Authorized S1 M0 preparation only. No consumer implementation, formal gate, app dependency/ADR change, branch/worktree operation, content edit, deployment or real account/data access.

Frozen pin: bb99e81333b497ac90fc78e231d88d51367538db. frozen-source.json records SHA256 and size for 110 public tracked files copied with git show: frontend source, committed React assets and five config/reference files. verify-frozen.mjs checks every byte. The preview serves the committed bundle at that pin; a fresh source-to-build reproduction was not run.

Authority: roedu-ui plan commit 954088c9179412206ba97cd0e026c25737ccee85, pack/03-session1-cat.md:467–471 mandates framework-neutral Presence tests against React, explicit no-preference, leaving-click inactivity and no second record/upload. Lines311–334 cover cancellation and reduced motion. Parent added retained-screen witnesses, storage/receipt assertions and held replies.

## Result

Final attempt08: 29/29 passed, zero skips/flakes/retries. All evidence is PROVISIONAL, formal_gate=false. See summary.json and results/attempt-08.json.

Motion-on: 18 cases. Reduce: 11 cases. Actual media preference is applied and checked rather than inferred from a project label. No native/content/PG/full-app gate, CSP, axe, screenshot parity, vitals or real-device claim is made.

## Executable files

- tests/presence.spec.mjs: idle Intrusul/Perechi exit guards. Establish enabled board/eligible hint; preselect a Perechi tile; use native activation on retained nodes without locator stability waits; assert locked controls, no selection/API/storage change and sampled motion-on interpolation.
- tests/owned.spec.mjs: present completion controls; held terminal/hint/503 replies cancelled during mounted exit; no late clue/recovery/result or extra recovery GET; pointer retained; resume records once; anonymous local recording. Runs in both modes.
- tests/replay.spec.mjs: a retained terminal replay button cannot create a game or record/upload again.
- tests/reduced.spec.mjs: actual reduce preference, locked controls and no transform interpolation over five frames while opacity advances.
- tests/characterization.spec.mjs: temporary frozen-React Conexiuni gap observations, separate from target contracts. Do not import the leakage expectation as an approved migration target.
- tests/sensitivity.spec.mjs: executed DOM/request/storage perturbations rejected by the same assertion helpers.
- contracts.mjs: framework-neutral DOM/storage/HTTP assertions; no React/Framer internals.
- fixtures.mjs: wholly synthetic same-origin API trap, per-game action/payload validation, response-body completion ledger, synthetic consented/anonymous account modes and bounded native-storage observations.
- server.mjs: isolated loopback static preview; any escaped API is rejected. This is not the Go server.
- run-preview.mjs: frozen-byte verification, focused matrix and explicit runner provenance.
- prepare-source-mutants.mjs / mutants/manifest.json: six source variant scaffolds, uncompiled and browser-unexecuted.
- results/: preserved attempt receipts and synthetic preview evidence.

Run from this folder with the verified host Node:

    /home/dobo/.vite-plus/js_runtime/node/24.21.0/bin/node verify-frozen.mjs
    /home/dobo/.vite-plus/js_runtime/node/24.21.0/bin/node run-preview.mjs fresh-preview-label

All outputs and TMPDIR stay here. The local server/browser command may require the scoped tool escalation used for these previews. No dependency install/download is needed.

For an already-running reviewed gate app, config supports MOTION_BASE_URL. test-api.mjs defaults to the gate's @playwright/test; this preview alone supplies MOTION_PLAYWRIGHT_TEST_MODULE. Final M0 must use the reviewed Go app/pinned runner and rerun at the settled base. Import into the repository remains unauthorized until S1 dispatch.

## What avoids false passes

The outer Clasament link bypasses screen-owned exit handlers, which already invalidate ownership and could hide missing Presence cleanup. Leaving assertions require the original board/screen to remain connected. Detached-node or timing errors are failures.

Held network requests reach response-body completion/failure before client-continuation assertions. Hint/503 checks continue through detachment. New clue, recovery UI, terminal result or recovery GET is forbidden. Preexisting feedback may finish its earlier disappearance; that is different from adopting a new reply.

Records are checked through played/recent, private receipt IDs, saved pointer and upload count. Empty startup prevents full-sync noise. Consented synthetic positive controls prove one browser upload to the mocked endpoint; anonymous cases verify local rows/receipts directly. Post-completion checks establish stability, not proof that a resize reran an effect.

Only synthetic contexts instrument Storage.prototype.setItem: the original native write/return/error behavior is preserved; at most32 observations record synthetic completion time, receipt IDs and original-screen connection. Conexiuni's score write is observed while that original screen is connected, even though a win removes the tile grid. No application module or score algorithm changes.

Current API functions expose no action AbortSignal. This establishes logical cancellation/no adoption, not physical fetch abortion. The future transport requirement needs separate evidence.

## Observed current Conexiuni gap

Both frozen-pin characterizations passed: a leaving board accepted selection/guess; a held terminal response released during departure recorded one local row/receipt and one synthetic score upload. The native storage observer proved the original screen was connected at write time. These are current-behavior findings, not approved target behavior, source fixes or migration parity.

## Motion and mutation limits

M0 Presence/replay explicitly use no-preference. Owned tests explicitly verify each project's preference. Reduced cases sample five mounted opacity frames: transform stays constant while opacity decreases. Frozen React may jump immediately to a static exit transform under reduce; demanding an identity matrix would misstate that baseline. Motion-on controls require varying transform samples.

Executed controls prove oracle sensitivity:
1. Enable a leaving tile in the browser DOM; the lock assertion rejects it.
2. Inject valid synthetic mutation/upload requests; the traffic assertion rejects the delta.
3. Inject synthetic local record metadata; the storage assertion rejects the delta.

They do not prove source-mutant kills. For each of Intrusul/Perechi, scaffolds provide isolated actions-lock removal, isolated exit-invalidation removal and combined always-present removal. None was built/executed; source-build dependencies are absent. Frozen API/asyncControl/scores files stay byte-identical.

## Provisional provenance and preserved failures

Host Node24.21.0; cached Playwright1.62.1; cached headless-shell revision1243, Chrome for Testing153.0.8010.12. The package expects a different browser revision. This is neither the planned Playwright1.63.0 triple nor the reviewed core toolchain.

Failed preview receipts are preserved:
- Attempt01: Chromium Unix socket path exceeded the assigned long TMPDIR; cached headless shell avoided it without leaving scratch.
- Attempt03: wrong detachment selector and unverified reduce preference; replaced with captured-element detachment and explicit media verification.
- Attempt04: identity-transform expectation was wrong for frozen React; frame sampling now verifies no interpolation.
- Attempt05: collection outlasted exit; sampling moved into immediate activation; attempt06 reran both idle cases.
- Attempt07: exact feedback text confused preexisting fade-out with adoption; corrected checks allow old text/disappearance and additionally forbid new recovery/result UI.
- Attempt08: final complete 29-case matrix passed with zero skips/retries.

summary.json is the authoritative local result ledger; all attempts remain visible. No failed or preview result is called a formal gate.

## Parent handoff

Parent settles content/base/ADR ownership and finishes reviewed core/bootstrap, then sends pinned core/adapted S1 prompt. Reverify source/build association and rerun this harness under M0's final runner. Keep Conexiuni characterization separate from target Presence assertions. Compile/execute the source variants there before claiming source sensitivity. No consumer migration was begun.
