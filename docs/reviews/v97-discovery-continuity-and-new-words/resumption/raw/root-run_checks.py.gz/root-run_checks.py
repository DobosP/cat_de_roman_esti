import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path("/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v97-discovery-continuity-and-new-words")
OUT=Path("/home/dobo/work/_temp/feat__v97-discovery-continuity-and-new-words/resumption-2026-09-22")
PY312="/home/dobo/work/cat_de_roman_esti/.venv/bin/python"
PY314="/home/dobo/work/_temp/feat__v97-discovery-continuity-and-new-words/integration/venv314/bin/python"
env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),PYTHONDONTWRITEBYTECODE="1",CAT_ACCOUNTS_ENABLED="0",CAT_DEBUG="0",ROEDU_API_URL="",ROEDU_API_KEY="")
env["PATH"]="/home/dobo/work/cat_de_roman_esti/.venv/bin:/home/dobo/.vite-plus/bin:"+env["PATH"]
mode=sys.argv[1]
if mode.startswith("backend"):
 py=PY314 if mode.endswith("314") else PY312
 jobs=[(mode,[py,"-m","pytest","-q","-o","addopts="],ROOT,{}),(mode.replace("backend","accounts"),[py,"-m","pytest","-q","-o","addopts=","tests/accounts"],ROOT,{"CAT_ACCOUNTS_ENABLED":"1","CAT_DEBUG":"1"})]
elif mode=="frontend":
 jobs=[(name,["npm",*args],ROOT/"frontend",{}) for name,args in [("frontend-native-final",["test"]),("frontend-lint",["run","lint"]),("frontend-typecheck",["run","typecheck"]),("frontend-build",["run","build"]),("frontend-bundle",["run","check:bundle"])]]
elif mode=="browser":
 jobs=[("browser",["npm","run","test:e2e","--","--workers=2"],ROOT/"frontend",{"CDR_E2E_PORT":"8187","CDR_E2E_OUTPUT_DIR":str(OUT/"browser-results")})]
else:raise SystemExit(mode)
for name,cmd,cwd,extra in jobs:
 log=OUT/(name+".log");assert not log.exists(),name
 print("START",name,flush=True);start=time.monotonic()
 with log.open("w") as h:
  p=subprocess.Popen(cmd,cwd=cwd,env=env|extra,stdout=h,stderr=subprocess.STDOUT)
  while True:
   try:rc=p.wait(timeout=30);break
   except subprocess.TimeoutExpired:print("RUNNING",name,round(time.monotonic()-start,1),log.stat().st_size,flush=True)
 b=log.read_bytes();r={"command":cmd,"cwd":str(cwd),"exit_code":rc,"elapsed_seconds":round(time.monotonic()-start,2),"log_sha256":hashlib.sha256(b).hexdigest(),"tail":b.decode(errors="replace").splitlines()[-10:]}
 log.with_suffix(".json").write_text(json.dumps(r,ensure_ascii=False,indent=2)+"\n");print("END",name,rc,r["elapsed_seconds"],flush=True)
 if rc:raise SystemExit(rc)
