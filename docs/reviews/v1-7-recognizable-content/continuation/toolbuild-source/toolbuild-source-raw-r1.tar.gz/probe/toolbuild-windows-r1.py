import stat,ctypes,hashlib,json,os,pathlib,queue,shutil,subprocess,sys,threading,time,datetime,signal
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"): raise RuntimeError("optimized Python refused")
stopping=False
def interrupted(signum,frame):
 global stopping
 stopping=True
signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
spec_path=pathlib.Path(sys.argv[1]);expected_spec=sys.argv[2]
spec_bytes=spec_path.read_bytes()
if hashlib.sha256(spec_bytes).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")
spec=json.loads(spec_bytes.decode("utf-8"));run=pathlib.Path(spec["windows_run"])
assert not run.exists(),"fresh campaign output exists"
run.mkdir();(run/"tmp").mkdir();cancel=run/"cancel"
root=pathlib.Path(spec["windows_R"]); scratch=pathlib.Path(spec["windows_S"])
GiB=1024**3
mono_deadline=time.monotonic()+spec["deadline_epoch"]-time.time()
if spec["deadline_epoch"]-spec["started_epoch"]!=1200: raise RuntimeError("campaign duration drift")
class MEM(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ["total","available","totalPage","availablePage","totalVirtual","availableVirtual","extra"]]
class PMC(ctypes.Structure):
 _fields_=[("cb",ctypes.c_ulong),("faults",ctypes.c_ulong)]+[(x,ctypes.c_size_t) for x in ["peakWS","WS","peakPaged","paged","peakNonpaged","nonpaged","pagefile","peakPagefile"]]
kernel=ctypes.WinDLL("kernel32",use_last_error=True);psapi=ctypes.WinDLL("psapi",use_last_error=True)
kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
kernel.CloseHandle.argtypes=[ctypes.c_void_p];psapi.GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.POINTER(PMC),ctypes.c_ulong]
def host_rss(pid,required=True):
 h=kernel.OpenProcess(0x410,False,pid)
 if not h:
  if not required: return 0
  raise RuntimeError("host RSS process unavailable")
 try:
  m=PMC();m.cb=ctypes.sizeof(m);assert psapi.GetProcessMemoryInfo(h,ctypes.byref(m),m.cb)
  return m.WS
 finally: kernel.CloseHandle(h)
def carrier_rss():
 try: return host_rss(carrier.pid)
 except (RuntimeError,AssertionError):
  if carrier.poll() is not None: return 0
  raise
def available():
 m=MEM();m.length=ctypes.sizeof(m);assert kernel.GlobalMemoryStatusEx(ctypes.byref(m));return m.available
def count():
 total=0;pending=[root,scratch]
 while pending:
  directory=pending.pop()
  with os.scandir(directory) as entries:
   for entry in entries:
    info=entry.stat(follow_symlinks=False)
    if getattr(info,"st_file_attributes",0)&0x400 or stat.S_ISLNK(info.st_mode): raise RuntimeError("owned reparse input refused: "+entry.path)
    if stat.S_ISDIR(info.st_mode): pending.append(pathlib.Path(entry.path))
    elif stat.S_ISREG(info.st_mode): total+=info.st_size
    else: raise RuntimeError("owned nonregular input refused: "+entry.path)
 return total
def hashfile(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def pins(after=False):
 assert hashfile(spec_path)==expected_spec,"spec SHA drift"
 for path,digest in spec["windows_protected"].items():assert hashfile(path)==digest,path
 names=set();pending=[pathlib.Path(spec["windows_stage"])]
 while pending:
  directory=pending.pop()
  with os.scandir(directory) as entries:
   for entry in entries:
    info=entry.stat(follow_symlinks=False)
    if getattr(info,"st_file_attributes",0)&0x400 or stat.S_ISLNK(info.st_mode):raise RuntimeError("stage reparse input refused: "+entry.path)
    if stat.S_ISDIR(info.st_mode):pending.append(pathlib.Path(entry.path))
    elif stat.S_ISREG(info.st_mode):names.add(str(pathlib.Path(entry.path).relative_to(spec["windows_stage"])).replace("\\","/"))
    else:raise RuntimeError("stage nonregular refused: "+entry.path)
 assert names==set(spec["stage_files"]),"full stage namespace drift"
 assert not (pathlib.Path(spec["windows_stage"])/".cat-content-ops.lock").exists(),"operator lock present"
 target=pathlib.Path(spec["windows_target"])
 assert target==pathlib.Path(spec["windows_stage"])/"cat_de_roman_esti/fixtures/quick_games_v92.json"
 assert hashfile(target)==(spec["target_after_sha256"] if after else spec["target_before_sha256"]),"Quick target pin drift"
MAX_STATE=65536
STATE_RESERVE=MAX_STATE*2+4096
def publish(v,failed=False):
 b=(json.dumps(v,ensure_ascii=False,indent=2)+"\n").encode("utf-8")
 assert len(b)<=MAX_STATE,"state publication size guard"
 assert count()-spec["full_R_S_baseline"]+STATE_RESERVE<=spec["growth_cap"],"reserved publication growth guard"
 assert shutil.disk_usage(root).free-STATE_RESERVE>=16*GiB,"reserved publication disk guard"
 assert available()>=spec["memory_floor"],"publication memory guard"
 reserve=0 if failed else 180
 assert time.time()<spec["deadline_epoch"]-reserve and time.monotonic()<mono_deadline-reserve,"publication deadline guard"
 p=run/"state.json";tmp=run/"state.part";tmp.write_bytes(b);os.replace(tmp,p)
 assert count()-spec["full_R_S_baseline"]<=spec["growth_cap"],"post-publication growth guard"
 assert shutil.disk_usage(root).free>=16*GiB and available()>=spec["memory_floor"],"post-publication resource guard"
 assert time.time()<spec["deadline_epoch"]-reserve and time.monotonic()<mono_deadline-reserve,"post-publication deadline guard"
baseline=spec["full_R_S_baseline"];peak=0;completed=[];carrier=None;events=None;cleanup_status="no child launched"
def resources(reserve=180,disk_floor=16*GiB):
 assert not stopping,"cooperative signal"
 assert time.time()<spec["deadline_epoch"]-reserve and time.monotonic()<mono_deadline-reserve,"immutable metadata reserve guard"
 assert shutil.disk_usage(root).free>=disk_floor and (disk_floor>16*GiB or shutil.disk_usage(root).free-STATE_RESERVE>=disk_floor) and available()>=spec["memory_floor"],"disk/memory/metadata reserve guard"
 measured=count();assert measured-baseline+STATE_RESERVE<=spec["growth_cap"],"whole R/S growth/metadata reserve guard"
 assert not stopping,"cooperative signal after resource count"
 return measured
state={"kind":"running","started_epoch":spec["started_epoch"],"deadline_epoch":spec["deadline_epoch"],"baseline":baseline,"completed":completed,"rss_scope":"Windows Python controller + native exec PowerShell launcher + owned WSL carrier + Linux supervisor/owned Go process group; Codex source workers excluded."}
try:
 assert spec["started_epoch"]<=time.time()
 resources(195,17*GiB);pins();resources(195,17*GiB);publish(state);resources(195)
 for index,step in enumerate(spec["steps"]):
  pins();resources(195);assert pathlib.Path(step["windows_output"]).parent==pathlib.Path(spec["windows_build_root"])/"tools" and not pathlib.Path(step["windows_output"]).exists(),"fresh owned output"
  assert spec["target_before_sha256"]==spec["target_after_sha256"],"build cannot mutate Quick target"
  events=queue.Queue(); complete=None;latest=0;last_count=0
  cleanup_status="owned Linux launch unconfirmed"
  state.update({"cleanup":cleanup_status,"pending_step":step["name"]});publish(state);pins();resources(195)
  carrier=subprocess.Popen(["wsl.exe","--exec","/usr/bin/python3.14",spec["linux_guard"],spec["linux_spec"],expected_spec,str(index)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding="utf-8")
  def read(owned_carrier=carrier):
   try:
    for line in owned_carrier.stdout: events.put(json.loads(line))
   except BaseException as exc: events.put({"kind":"failed","error":"telemetry reader: "+repr(exc)})
  cleanup_status="owned Linux group unconfirmed";reader=threading.Thread(target=read);reader.start()
  with (run/(step["name"]+".telemetry.jsonl")).open("w",encoding="utf-8",newline="\n") as stream:
   while True:
    assert not stopping,"cooperative signal"
    while True:
     try: event=events.get_nowait()
     except queue.Empty: break
     stream.write(json.dumps(event,separators=(",",":"))+"\n");stream.flush()
     if event["kind"]=="sample":latest=event["rss"]
     elif event["kind"]=="complete":complete=event
     elif event["kind"]=="failed":raise RuntimeError(event["error"])
    total=latest+host_rss(os.getpid())+host_rss(spec["host_launcher_pid"])+carrier_rss()
    peak=max(peak,total)
    assert total<=spec["rss_cap"] and available()>=spec["memory_floor"],"parent-inclusive RSS or host memory guard"
    assert time.time()<spec["deadline_epoch"]-180 and time.monotonic()<mono_deadline-180,"metadata reserve guard"
    if time.monotonic()-last_count>=2:
     assert shutil.disk_usage(root).free>=16*GiB and count()-baseline<=spec["growth_cap"],"wholeR/S disk/growth guard";last_count=time.monotonic()
    if carrier.poll() is not None and not reader.is_alive() and events.empty():break
    time.sleep(.25)
  reader.join(timeout=3);assert not reader.is_alive();assert carrier.wait()==0 and complete and complete["group_absent"]
  cleanup_status="owned Linux group confirmed absent"
  stderr=carrier.stderr.read();(run/(step["name"]+".controller.stderr.log")).write_bytes(stderr.encode("utf-8"))
  pins(after=True);output=pathlib.Path(step["windows_output"]);assert output.is_file() and output.read_bytes()[:4]==b"\x7fELF","fresh Linux ELF output"
  data=json.loads(pathlib.Path(spec["windows_target"]).read_text(encoding="utf-8"))
  assert hashfile(spec["windows_target"])==spec["target_after_sha256"]
  assert data["kind"]=="quick-content-catalog-v1" and data["candidate_sha256"]==spec["candidate_sha256"]
  assert len(data["authored"])==85 and data["excluded"]==[]
  assert {x["role"]:x["reviewer"] for x in data["reviews"]}==spec["reviewer_ids"]
  assert {x["role"]:x["sha256"] for x in data["reviews"]}==spec["review_hashes"]
  resources();pins(after=True)
  completed.append({"step":step["name"],"output_sha256":hashfile(step["windows_output"]),"native_peak":complete["native_peak"]})
  carrier=None;state.update({"completed":completed,"parent_inclusive_peak":peak,"whole_R_S_bytes":resources(),"cleanup":cleanup_status});publish(state);resources();pins(after=True)
 resources();pins(after=True)
 state.update({"kind":"passed","finished_epoch":time.time(),"parent_inclusive_peak":peak,"final_growth":count()-baseline,"all_non_target_protected_exact":True,"full_stage_namespace_exact":True,"target_before_sha256":spec["target_before_sha256"],"target_after_sha256":spec["target_after_sha256"],"scope":"Two fresh pure-Go operator tool builds only; immutable complete stage, current Quick and all protected inputs; no operator/audit/installed V1.7 qualification.","cleanup":cleanup_status});publish(state);resources();pins(after=True);resources()
 assert not stopping,"cooperative signal before PASS"
 print(json.dumps({"kind":"PASS","completed":len(completed),"parent_inclusive_peak":peak,"growth":state["final_growth"]}))
except BaseException as exc:
 cancel.write_text("cancel",encoding="utf-8")
 if carrier is not None and carrier.poll() is None:
  try:carrier.wait(timeout=12)
  except subprocess.TimeoutExpired:
   carrier.terminate();carrier.wait(timeout=5)
 if events is not None:
  while not events.empty():
   event=events.get_nowait()
   if event.get("group_absent") is True:cleanup_status="owned Linux group confirmed absent"
 state.update({"cleanup":cleanup_status,"kind":"failed","error":repr(exc),"finished_epoch":time.time(),"parent_inclusive_peak":peak,"completed":completed})
 try:publish(state,failed=True)
 except BaseException as publication_error:state["failed_publication_error"]=repr(publication_error)
 print(json.dumps({"kind":"FAILED","error":repr(exc),"completed":len(completed),"cleanup":cleanup_status,"failed_publication_error":state.get("failed_publication_error")}));raise

