import { chromium } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v89-feedback-and-conexiuni-recovery/frontend/node_modules/playwright/index.mjs';
import { spawn, execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
const root='/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v89-feedback-and-conexiuni-recovery';
const dir='/home/dobo/work/_temp/feat__v89-feedback-and-conexiuni-recovery/conex-action';
const py='/home/dobo/work/cat_de_roman_esti/.venv/bin/python';
const env={...process.env,PYTHONPATH:root,CAT_ACCOUNTS_ENABLED:'0',CAT_DEBUG:'1',ROEDU_API_URL:'',ROEDU_API_KEY:''};
const fixture=JSON.parse(execFileSync(py,[`${root}/frontend/e2e/solutions.py`,'conexiuni'],{cwd:root,env,encoding:'utf8'}));
const server=spawn(py,['-m','cat_de_roman_esti.web','--host','127.0.0.1','--port','8188','--log-level','warning'],{cwd:root,env,stdio:'ignore'});
let browser;
try {
  for(let i=0;i<120;i++) { try { if((await fetch('http://127.0.0.1:8188/api/health')).ok)break; } catch {} await new Promise(r=>setTimeout(r,250)); }
  browser=await chromium.launch();
  const result={baseline:'b614bfe735a27b9703025420daf603118f6a7f74', cases:[]};
  for (const kind of ['clue','group','win','loss']) {
    const ctx=await browser.newContext({baseURL:'http://127.0.0.1:8188',locale:'ro-RO',reducedMotion:'reduce'});
    const page=await ctx.newPage();
    const initial=await (await ctx.request.post('/api/wordgames/conexiuni/games?seed=38&difficulty=usor')).json();
    const url=`/api/wordgames/conexiuni/games/${initial.game_id}`;
    if(kind==='clue'||kind==='loss') for(let j=0;j<3;j++) { const ids=fixture.steps.map(s=>s.payload.ids[j]); const r=await ctx.request.post(`${url}/guess`,{data:{ids}}); if(r.status()!==200)throw Error('setup guess'); }
    if(kind==='win')for(const s of fixture.steps.slice(0,3)) await ctx.request.post(`${url}/guess`,{data:s.payload});
    await page.goto('/');await page.evaluate(id=>localStorage.setItem('cat_active_game_v1_conexiuni',id),initial.game_id);await page.goto('/conexiuni');await page.locator('.connections-grid').waitFor();
    let reads=0,posts=0, committed;
    page.on('request',r=>{if(new URL(r.url()).pathname===url&&r.method()==='GET')reads++;if(new URL(r.url()).pathname.startsWith(`${url}/`)&&r.method()==='POST')posts++;});
    const action=kind==='clue'?'clue':'guess';
    await page.route(`**${url}/${action}`,async route=>{const res=await route.fetch();committed=await res.json();await route.fulfill({status:503,contentType:'application/json',body:'{"detail":"Lost after commit"}'});},{times:1});
    async function clickGuess(step) {for(const label of step.labels)await page.locator('.connections-grid').getByRole('button',{name:label,exact:true}).click();await page.getByRole('button',{name:'Verifică',exact:true}).click();}
    if(kind==='clue') await page.getByRole('button',{name:/^Indiciu/}).click();
    else if(kind==='loss') await clickGuess({labels:fixture.steps.map(s=>s.labels[3])});
    else await clickGuess(fixture.steps[kind==='win'?3:0]);
    await page.getByText('Lost after commit',{exact:true}).waitFor();
    const serverAfter=await (await ctx.request.get(url)).json();
    const observed={kind,serverAfter,reads,posts,renderedTiles:await page.locator('.connections-grid button').count(),renderedClueMessages:await page.locator('.connections-feedback').count(),resultVisible:await page.getByRole('button',{name:'Copiază rezultatul'}).count(),played:await page.evaluate(()=>JSON.parse(localStorage.getItem('cat_wordgame_scores_v1')||'{}').conexiuni?.played??0),committed};
    await page.screenshot({path:`${dir}/baseline-lost-${kind}.png`,fullPage:true});
    if(kind==='clue') {await page.getByRole('button',{name:/^Indiciu/}).click();await page.getByRole('button',{name:'Indicii folosite'}).waitFor();observed.afterExplicitRetry=await(await ctx.request.get(url)).json();for(const s of fixture.steps)await ctx.request.post(`${url}/guess`,{data:s.payload});observed.actualFinal=await(await ctx.request.get(url)).json();observed.expectedScoreWithOneClue=150;}
    result.cases.push(observed);await ctx.close();
  }
  writeFileSync(`${dir}/baseline-proof.json`,JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result.cases.map(({kind,reads,posts,renderedTiles,renderedClueMessages,resultVisible,played,serverAfter,actualFinal})=>({kind,reads,posts,renderedTiles,renderedClueMessages,resultVisible,played,server:{won:serverAfter.won,lost:serverAfter.lost,solved_count:serverAfter.solved_count,clues_used:serverAfter.clues_used,score:serverAfter.score},actualFinalScore:actualFinal?.score})),null,2));
} finally {await browser?.close();server.kill('SIGTERM');}
