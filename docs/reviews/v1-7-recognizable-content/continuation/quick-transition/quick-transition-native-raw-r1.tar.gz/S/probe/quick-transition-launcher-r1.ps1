$ErrorActionPreference = 'Stop'
$phaseResult = & 'C:/Users/Paul Work/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe' -X utf8 -B 'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/probe/quick-transition-admit-r2.py' $PID '2c11246d93f400840f12cdc38c48b5ce40acf40a3bca24068023d676aad3a897'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Output $phaseResult
$phaseAdmission = [System.IO.File]::ReadAllText('C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/quick-transition-native-admission-r1.json') | ConvertFrom-Json
$frozenSpecSHA = $phaseAdmission.spec_sha256
$phaseMarker = 'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/probe/quick-transition-dispatch-r1.txt'
while (-not (Test-Path -LiteralPath $phaseMarker) -and [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000.0 -lt $phaseAdmission.deadline_epoch-195) { Start-Sleep -Milliseconds 200 }
if (-not (Test-Path -LiteralPath $phaseMarker)) { throw 'No independent exact-spec dispatch marker before immutable launch cutoff; no native operator launched.' }
if ([System.IO.File]::ReadAllText($phaseMarker).Trim() -ne $frozenSpecSHA) { throw 'External marker/spec SHA mismatch; no native operator launched.' }
if ((Get-FileHash -LiteralPath 'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/probe/quick-transition-native-spec-r1.json' -Algorithm SHA256).Hash.ToLowerInvariant() -ne $frozenSpecSHA) { throw 'Frozen spec drift; no native operator launched.' }
& 'C:/Users/Paul Work/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe' -X utf8 -B 'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/probe/quick-transition-windows-r3.py' 'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/probe/quick-transition-native-spec-r1.json' $frozenSpecSHA
$phaseExit = $LASTEXITCODE
exit $phaseExit
