# RO-EDU core monorepo

Last verified: 2026-10-08 — core-v1.4 parser-alias candidate source reviewed; actual qualification pending.

Candidate @roedu/ui 1.0.4 / @roedu/web-kit 0.1.4 correct the approved parser alias; released core-v1.3 remains immutable.
[ADR-0014](docs/adr/0014-historical-data-and-docker-companions.md) records it; core-v1.2 remains immutable.
The [ADR ledger](docs/adr/README.md) records architecture and policy.

## Current state

Core-v1.3 is qualified and atomically published at immutable source `95aec25308cdf1731ef0225e617d9e6bdcd7b00a`, tree
`207e985ef1ee0a5ec49159d4baf480459ceb1aedfb229bd2d11071fe2addf232`.
Annotated tag object: `68d8d0b95d66473e4443b44a960a400a455231cb`.
Clean unit passed 28 plus only pg-live/no-dsn; fresh full passed 41 with zero skips/retries,
16 HTTP Chromium cases once, six exact PNGs and zero CSP/axe violations.
Fresh A/B and owning-tag builds passed 5 each; all seven outputs were byte-identical.
Owning Git Go exports A/B matched 41 full-mode files/55,206 bytes. The real canonical
five-file bundle passed 12 actual parser/sync/npm/Go commands, vet/race 11 packages/66 tests
and repeat no drift; 37 byte/mode artifact rows were independently verified in source/mirror.
[Release evidence](docs/reviews/gui-core-v13/README.md) binds archives and physical keepers.
Scope is Linux/local desktop Chromium and disposable PG, not Cat/device/production qualification.

Core-v1.2 remains immutable at `9e0a88e33d44ba7ce9e84ead890c897b36d41dd4`, tag object
`b5e1c817608e79411595da7f46618475e92acc13`: unit 28 + PG skip, worker/parent full 41,
16 cases/six PNGs/CSP+axe zero, builds 5/seven equal outputs/ten actual consumer packs.
Its canonical 41-file/55,202-byte Go archive and 11-package/66-test proof retain scope
in [v1.2 evidence](docs/reviews/gui-core-v12/README.md); none is overwritten by v1.3.

Earlier core-v1.0/v1.1 remain immutable; v1.1 source 9acd440 passed unit 27 + PG skip,
full/parent full 40 checks, 16 cases, six PNGs, zero CSP/axe/skips/retries. Lab 432 ms LCP/40 ms INP
and the compiler-cache correction retain their scope in [WORKLOG](WORKLOG.md) and [ADR-0008](docs/adr/0008-release-artifacts-exclude-compiler-state.md).

Paul directly resumed Linux implementation on 2026-10-08; the [living handoff](docs/GUI_MIGRATION_HANDOFF.md)
supersedes the historical pause/source-only Windows transfer. Five verified layers are applied:
38 Cat source paths (including 15 accepted style files), 2 eager accounting paths, 9 Cat/2 core docs and 6 Node alignment paths.
Original 16 fixtures/78 assertions, the exact 30-file legacy freeze and sealed packets retain their earlier scope.
The CORE_REQ3 correction in [ADR-0010](docs/adr/0010-configured-consumer-version-resolution.md) is released;
adoption requires the clean idle owner sequence; d0e6c7c unit 28 + PG skip/full 41, six screenshots/185/231 bindings retain that historical scope.

The sealed Windows81 core-v1.2 preparation is source-accepted and applied in the native
owning task worktree. [ADR-0012](docs/adr/0012-go-archive-budget-closure.md) records
the narrow budget Go archive closure and real parser/extracted-module regression.
[ADR-0013](docs/adr/0013-confined-declaration-preparation.md) records confined
pre-emission declaration regeneration, compatible with ADR-0008's postbuild stage.
Private bundle admission and Go planning preserve public exports and failure order;
their parity/refusal checks passed actual native qualification. The
[owning integration ExecPlan](docs/execplans/core-integration.md) records exact
selected-source provenance, current Linux checks and evidence retention.
At core-v1.2, final clean unit verified 292 artifact hashes/21 declaration safety cases;
each full verified 337 artifact hashes. Its actual owning Git Go exports A/B
reproduced 41 files/55,202-byte TGZ, SHA256
`f499198a0b229b6b04488344724f5ba8873c6e1bd8da64096b76cc371f228bb4`.
Cat's original 114,086-byte gzip entry still exceeds 40,960; M0/M1 remain unqualified.
Its physical Samsung Chrome/Internet checkpoint remains UNMET. Active UI adoption,
production and S0b templ migration remain pending.
[ADR-0011](docs/adr/0011-original-runtime-budget-qualification-order.md) corrects
preliminary acceptance ordering while keeping the budget red, the real device
checkpoint and the green M2 requirement before S0b unchanged.

Paul's accepted startup calculation includes entry/static JS/CSS plus immediately mounted AccountBar,
counted once; decision: `cat_de_roman_esti/docs/adr/0185-accepted-eager-startup-bundle-accounting.md`.
Owning branch `fix/gui-cat-prerequisites-linux`; latest GEN result `dc379835`, source `6d4abaa16e853497f6981a53f843aef9e38201d6`, dirty tree
`677c741cebb91ff157a2bfb1be0a69362f05678b8211b78b82c25b0b8abe1927`.
Earlier bundle 11/native TypeScript 7/API consumer 2/selection-key 3 passes retain their captured scope.
Latest startup 125,166 exceeds 122,880 by 2,286; lint 70 is before equivalence repair.
Native race refused CGO_ENABLED=0 before tests; 12 format differences were retained. New fixes are source-only;
normalized 900/canonical unit/full/image/CSP/device remain pending. No adoption or KIT_BUMP is earned.
Frontend 120KiB JS/CSS and canonical 40,960/30,720-byte JS remain distinct, unchanged and unqualified here.

The Cat-only sealed staged-UI contract and confined same-repo Go audits from
[ADR-0009](docs/adr/0009-corrective-release-and-staged-sdk.md) remain enforced.
Staged UI is pending; M2 requires actual active installation proof. Bootstrap
uses the bound current descriptor and host-private result checks. The
[core ExecPlan](docs/execplans/core-v1.md) preserves S0a history; the
[consumer resolver ExecPlan](docs/execplans/consumer-resolution.md) records the
current fix. [PROGRAM](docs/PROGRAM.md) retains the release and consumer gates.

## Source and interfaces

| Area | Path | Surface |
| --- | --- | --- |
| Tokens | src/tokens/ | DTCG input, generated CSS/app themes, TS and Go constants |
| Layered CSS | src/css/ | reset, tokens, base, components, utilities, app |
| Components | src/preact/ | CSP-safe and keyboard accessible Preact components |
| Behaviors | src/behaviors/ | light-DOM elements, invoker and island protocol |
| Motion | src/motion/ | Presence, springs, Confetti and mini playback controls |
| Network/storage | src/net/, src/storage/ | same-origin CSRF and registered keys |
| Go delivery | web-kit/ | assets, static, csp, island, health, golden, routes, engine |
| Sample | web-kit/sample/ | three stress modules, Pongo2 and compiled templ pages |
| Gate | scripts/gate.sh | pinned Linux execution and bound evidence |
| Templates | web-kit/templates/ | shared gate files, repo hooks and CI reference |

## Consumption

Consumers select only committed kit/CORE_TAG and adopt through the owner
staging/sync/trust sequence. The [consumer notes](CONSUMER_NOTES.md) list every
breaking API/style change and the exact kit protocol. Import components from
@roedu/ui/preact, CSS from @roedu/ui/styles.css and one generated theme.
Reading comfort requires a self-paced surface and rejects timed/psychometric use.
Preact island adapters render into a stable owned child, then dispose it on abort.

## Verification and documentation

Published UI1.0.3/web-kit0.1.3/Go identities bind immutable 95aec253; v1.2 still binds 9e0a88e.
This later documentation HEAD is not either qualified archive source. README is packaged:
repacking changed metadata would change archive bytes; a subsequent product release
must bump affected package versions rather than replace these published archives.
An authored parser-alias successor ([ADR-0015](docs/adr/0015-approved-parser-alias.md)) is NOT RUN.
Parent owns qualification and the next versioned release; published core-v1.3 stays immutable.
Cat/device/production, parent-owned captures and earlier receipts retain their scopes.

Every product build/test runs through the pinned native wrapper. Full adds real
PostgreSQL, an image-built app, all registered-page nonce checks, axe/vitals,
journeys and exact committed screenshot comparisons. Full permits no skips.
The [testing guide](docs/agent-testing.md) describes commands and evidence.
Requests and resolutions are append-only in [GATE_REQUESTS.md](GATE_REQUESTS.md).
Source maps: [agent map](docs/agent-map.md), [architecture](docs/architecture.md),
[theming](docs/theming.md), [tokens](docs/design-tokens.md),
[consumer guide](docs/consuming-web-react.md) and [LLM guides](docs/llm/README.md).
The original React 0.3.1 verification remains historical in [WORKLOG.md](WORKLOG.md).
