import ast,copy,hashlib,json,pathlib,stat,tempfile,re,sys,unittest
sys.dont_write_bytecode=True
S=pathlib.Path(sys.argv.pop(1));W=S/'probe/native-authcore-tests-windows-r2.py'
nodes=[n for n in ast.parse(W.read_text()).body if (isinstance(n,ast.FunctionDef) and n.name in ('verify_test_output','verify_compiled_input')) or (isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('TOP_TESTS','SUB_TESTS'))]
E={'pathlib':pathlib,'re':re,'json':json,'hashlib':hashlib,'filemode':stat};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(W),'exec'),E)
TOP=E['TOP_TESTS'];ALL=TOP+E['SUB_TESTS']
def validbody():return ('\n'.join(['=== RUN   '+x for x in ALL]+['--- PASS: '+x+' (0.00s)' for x in ALL]+['PASS'])+'\n').encode()
class OutputCases(unittest.TestCase):
 def test_full15_list(self):E['verify_test_output']('authcore-case-list',('\n'.join(TOP)+'\n').encode())
 def test_missing_case(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-case-list',('\n'.join(TOP[:-1])+'\n').encode())
 def test_duplicate_list(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-case-list',('\n'.join(TOP[:-1]+[TOP[0]])+'\n').encode())
 def test_extra_list(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-case-list',('\n'.join(TOP+['TestExtra'])+'\n').encode())
 def test_full28_execution(self):E['verify_test_output']('authcore-race-tests',validbody())
 def test_missing_pass(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',validbody().replace(('--- PASS: '+ALL[-1]+' (0.00s)\n').encode(),b''))
 def test_missing_run(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',validbody().replace(('=== RUN   '+ALL[-1]+'\n').encode(),b''))
 def test_duplicate_run(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',('=== RUN   '+ALL[0]+'\n').encode()+validbody())
 def test_skip(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',validbody().replace(b'--- PASS:',b'--- SKIP:',1))
 def test_fail(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',validbody().replace(b'--- PASS:',b'--- FAIL:',1))
 def test_race_text(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',b'WARNING: DATA RACE\n'+validbody())
 def test_missing_terminal_pass(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',validbody()[:-5])
 def test_truncated_line(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',validbody()[:-1])
 def test_duplicate_final_pass(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',validbody()+b'PASS\n')
 def test_bad_utf8(self):
  with self.assertRaises(UnicodeDecodeError):E['verify_test_output']('authcore-case-list',b'\xff\n')
 def test_bytecap(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-race-tests',b'X'*(1024**2+1))
 def test_empty_vet(self):E['verify_test_output']('authcore-vet',b'')
 def test_nonempty_vet(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('authcore-vet',b'warning\n')
 def test_unknown_step(self):
  with self.assertRaises(RuntimeError):E['verify_test_output']('unknown',b'')
class CompiledCases(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=S/'probe');self.root=pathlib.Path(self.tmp.name)
  self.state=json.loads((S/'native-authcore-race-compile-r2/run/state.json').read_text());self.outer=json.loads((S/'native-authcore-race-compile-r2/run/outer-tool-result-r1.json').read_text());self.spec=json.loads((S/'probe/native-authcore-tests-template-r2.json').read_text())
  h=bytearray(64);h[:6]=b'\x7fELF\x02\x01';h[16:18]=(2).to_bytes(2,'little');h[18:20]=(62).to_bytes(2,'little');p=self.root/'binary';p.write_bytes(h)
  self.spec.update(windows_artifact=str(p),windows_compile_state=str(self.root/'state'),windows_compile_outer=str(self.root/'outer'),artifact_bytes=64,artifact_sha256=hashlib.sha256(h).hexdigest())
  self.state['completed'][0].update(artifact_bytes=64,artifact_sha256=self.spec['artifact_sha256'])
 def tearDown(self):self.tmp.cleanup()
 def sync(self):
  p=pathlib.Path(self.spec['windows_compile_state']);p.write_text(json.dumps(self.state));self.spec['compile_state_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();self.outer['state_sha256']=self.spec['compile_state_sha256'];p=pathlib.Path(self.spec['windows_compile_outer']);p.write_text(json.dumps(self.outer));self.spec['compile_outer_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();E['spec']=self.spec
 def test_valid_controlled_compile(self):self.sync();E['verify_compiled_input']('windows')
 def test_failed_compile_same_binary(self):
  self.state['kind']='failed';self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_missing_post(self):
  self.state['full_readset_checks'].pop();self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_incomplete_readset(self):
  self.state['full_readset_checks'][1]['protected_files']-=1;self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_expired_compile_boundary(self):
  self.state['finished_epoch']=self.state['deadline_epoch']-180;self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_uncertain_group(self):
  self.state['cleanup']='unconfirmed';self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_false_protection(self):
  self.state['all_non_target_protected_exact']=False;self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_prior_caps(self):
  self.state['parent_inclusive_peak']=self.spec['rss_cap']+1;self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_outer_exit_nonzero(self):
  self.outer['exit_code']=1;self.sync()
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_binary_mutation(self):
  self.sync();pathlib.Path(self.spec['windows_artifact']).write_bytes(b'drift')
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
 def test_hashpin_drift(self):
  self.sync();self.spec['compile_state_sha256']='0'*64
  with self.assertRaises(RuntimeError):E['verify_compiled_input']('windows')
if __name__=='__main__':unittest.main(verbosity=1)
