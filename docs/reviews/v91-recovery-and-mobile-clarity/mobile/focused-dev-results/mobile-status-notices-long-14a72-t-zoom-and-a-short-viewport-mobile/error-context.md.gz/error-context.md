# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile-status-notices.spec.mjs >> long Romanian status stays readable with text zoom and a short viewport
- Location: frontend/e2e/mobile-status-notices.spec.mjs:115:1

# Error details

```
Error: long-labels-200-percent: screen width

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 320
Received:    350
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - generic:
    - status
  - generic [ref=e8]:
    - generic [ref=e9]:
      - generic [ref=e10]:
        - button "Ieși la lista de jocuri" [ref=e11] [cursor=pointer]:
          - generic [aria-hidden] [ref=e12]: ←
          - text: Ieși
        - strong [ref=e13]: Lanțul Cuvintelor Românești
      - group "Starea jocului" [ref=e15]:
        - generic "Dificultate" [ref=e16]:
          - generic [ref=e17]: Mod
          - generic [ref=e18]: Personalități și viața de zi cu zi în România
        - generic [ref=e19]:
          - generic [ref=e20]: Categorie
          - generic [ref=e21]: Sport
        - generic [ref=e22]:
          - generic [ref=e23]: Combinații
          - generic [ref=e24]: "0"
        - generic [ref=e25]:
          - generic [ref=e26]: Descoperite
          - generic [ref=e27]: "0"
    - group [ref=e28]:
      - generic "Reguli și ajutor" [ref=e29] [cursor=pointer]
    - generic [ref=e31]:
      - generic [ref=e32]: ȚINTA DE FĂURIT
      - generic [ref=e33]:
        - generic [aria-hidden] [ref=e34]: ◎
        - heading "Liga Campionilor la handbal" [level=2] [ref=e35]
      - paragraph [ref=e36]: Competiția europeană majoră de club în care Cristina Neagu a strălucit.
    - generic [ref=e37]:
      - generic [aria-hidden] [ref=e38]: 👆
      - generic [ref=e39]:
        - generic [ref=e40]: ACUM
        - strong [ref=e41]: Alege două concepte
        - generic [ref=e42]: Pornește din inventar.
      - generic [ref=e43]: 0/2
    - generic [ref=e44]:
      - generic [ref=e45]:
        - generic [ref=e46]: alege…
        - generic [aria-hidden] [ref=e47]: +
        - generic [ref=e48]: alege…
      - button "Combină cele două concepte selectate" [disabled] [ref=e50]: ⚗ Combină
    - region "Inventar" [ref=e51]:
      - generic [ref=e52]:
        - generic [ref=e53]: INVENTAR · 3 ÎN JOC
        - generic [ref=e54]:
          - generic [ref=e55]: ● pereche gata
          - generic [ref=e56]: 3 puse deoparte
      - group "Filtrează inventarul" [ref=e57]:
        - button "Recente 3" [ref=e58] [cursor=pointer]
        - button "Utile 3" [pressed] [ref=e59] [cursor=pointer]
        - button "Toate 6" [ref=e60] [cursor=pointer]
      - searchbox "Caută în toate conceptele descoperite" [ref=e61]
      - generic [ref=e62]:
        - button "Washington Bullets, gata pentru o combinație utilă" [ref=e63] [cursor=pointer]:
          - generic [aria-hidden] [ref=e64]: ●
          - text: Washington Bullets
        - button "Cristina Neagu, gata pentru o combinație utilă" [ref=e65] [cursor=pointer]:
          - generic [aria-hidden] [ref=e66]: ●
          - text: Cristina Neagu
        - button "Tricolorii, gata pentru o combinație utilă" [ref=e67] [cursor=pointer]:
          - generic [aria-hidden] [ref=e68]: ●
          - text: Tricolorii
    - generic [ref=e69]:
      - button "↻ Reia același joc" [ref=e70] [cursor=pointer]
      - button "⚗ Alt joc" [ref=e71] [cursor=pointer]
      - button "⚙ Schimbă opțiunile" [ref=e72] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import { games, deterministicStarts, start, solve, solution, tabTo } from "./games.mjs";
  3   | 
  4   | async function settle(page) {
  5   |   await page.evaluate(async () => {
  6   |     await globalThis.document.fonts.ready;
  7   |     await Promise.all(globalThis.document.getAnimations().filter((animation) =>
  8   |       Number.isFinite(animation.effect?.getComputedTiming().endTime),
  9   |     ).map((animation) => animation.finished.catch(() => {})));
  10  |   });
  11  | }
  12  | 
  13  | async function layout(page, testInfo, state) {
  14  |   await settle(page);
  15  |   const metrics = await page.evaluate(() => {
  16  |     const rect = (element) => {
  17  |       if (!element) return null;
  18  |       const box = element.getBoundingClientRect();
  19  |       return { left: box.left, top: box.top, right: box.right, bottom: box.bottom,
  20  |         width: box.width, height: box.height };
  21  |     };
  22  |     const header = globalThis.document.querySelector(".game-shell-header");
  23  |     const hud = header.querySelector(".hud");
  24  |     const scroller = globalThis.document.querySelector(".screen-pad");
  25  |     return {
  26  |       width: globalThis.innerWidth,
  27  |       pageWidth: globalThis.document.documentElement.scrollWidth,
  28  |       scrollWidth: scroller.scrollWidth,
  29  |       clientWidth: scroller.clientWidth,
  30  |       header: rect(header),
  31  |       title: rect(header.querySelector(".game-shell-title")),
  32  |       hud: rect(hud),
  33  |       hudScrollWidth: hud?.scrollWidth,
  34  |       badges: hud ? [...hud.children].map((child) => ({ text: child.textContent, ...rect(child) })) : [],
  35  |       notices: [...globalThis.document.querySelectorAll(".roedu-toast")].map(rect),
  36  |       content: rect(globalThis.document.querySelector(".app-content")),
  37  |     };
  38  |   });
  39  |   await testInfo.attach(`${state}-geometry`, {
  40  |     body: JSON.stringify(metrics, null, 2), contentType: "application/json",
  41  |   });
  42  |   expect(metrics.pageWidth, `${state}: page width`).toBeLessThanOrEqual(metrics.width);
> 43  |   expect(metrics.scrollWidth, `${state}: screen width`).toBeLessThanOrEqual(metrics.clientWidth);
      |                                                         ^ Error: long-labels-200-percent: screen width
  44  |   if (metrics.hud) {
  45  |     expect(metrics.title.width, `${state}: visible game title`).toBeGreaterThan(2);
  46  |     expect(metrics.title.right).toBeLessThanOrEqual(metrics.width);
  47  |     expect(metrics.hudScrollWidth, `${state}: all counters fit without scrolling`)
  48  |       .toBeLessThanOrEqual(Math.ceil(metrics.hud.width));
  49  |     for (const badge of metrics.badges) {
  50  |       expect(badge.left, `${state}: ${badge.text}`).toBeGreaterThanOrEqual(metrics.header.left);
  51  |       expect(badge.right, `${state}: ${badge.text}`).toBeLessThanOrEqual(metrics.header.right);
  52  |       expect(badge.bottom, `${state}: ${badge.text}`).toBeLessThanOrEqual(metrics.header.bottom);
  53  |     }
  54  |   }
  55  |   for (const notice of metrics.notices) {
  56  |     expect(notice.bottom, `${state}: notice leaves the screen unobstructed`)
  57  |       .toBeLessThanOrEqual(metrics.content.top);
  58  |   }
  59  | }
  60  | 
  61  | for (const game of games) {
  62  |   test(`${game.key} keeps its status and notices visible through resume and result`, async ({ page }, testInfo) => {
  63  |     test.setTimeout(120_000);
  64  |     const widths = testInfo.project.name === "mobile" ? [320, 390] : [1280];
  65  |     await deterministicStarts(page, game);
  66  |     for (const width of widths) {
  67  |       await page.setViewportSize({ width, height: 850 });
  68  |       await page.goto(game.path);
  69  |       await page.evaluate(() => localStorage.clear());
  70  |       await page.reload();
  71  |       await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  72  |       await layout(page, testInfo, `${width}-intro`);
  73  |       await start(page, game);
  74  |       await layout(page, testInfo, `${width}-live`);
  75  |       await page.reload();
  76  |       await expect(page.locator(game.board)).toBeVisible();
  77  |       await expect(page.getByText(/^Joc reluat\./)).toBeVisible();
  78  |       await layout(page, testInfo, `${width}-resume`);
  79  |       await testInfo.attach(`${width}-resume`, { body: await page.screenshot(), contentType: "image/png" });
  80  |       const exit = page.getByRole("button", { name: "Ieși la lista de jocuri" });
  81  |       await tabTo(page, exit);
  82  |       await expect(exit).toBeFocused();
  83  |       await page.locator(".screen-pad").evaluate((element) => { element.scrollTop = element.scrollHeight; });
  84  |       await layout(page, testInfo, `${width}-scrolled`);
  85  |       if (width <= 640) {
  86  |         const sticky = page.locator(".connections-coach-stack, .contexto-sticky-controls, .alchemy-bench, .word-hop-input");
  87  |         for (const control of await sticky.all()) {
  88  |           const top = (await control.boundingBox()).y;
  89  |           const header = await page.locator(".game-shell-header").boundingBox();
  90  |           expect(top, "secondary sticky controls stay below the wrapped header")
  91  |             .toBeGreaterThanOrEqual(header.y + header.height);
  92  |         }
  93  |       }
  94  |       await solve(page, game, solution(game).steps);
  95  |       await layout(page, testInfo, `${width}-finished`);
  96  |       // Exercise the real copy failure feedback without relying on host clipboard permissions.
  97  |       await page.evaluate(() => {
  98  |         Object.defineProperty(globalThis.navigator, "clipboard", {
  99  |           configurable: true, value: { writeText: async () => { throw new Error("Clipboard unavailable in test"); } },
  100 |         });
  101 |         globalThis.document.execCommand = () => false;
  102 |       });
  103 |       await page.getByRole("button", { name: "Copiază rezultatul" }).click();
  104 |       const failure = page.getByRole("button", { name: /Nu am putut copia\./ });
  105 |       await expect(failure).toBeVisible();
  106 |       await layout(page, testInfo, `${width}-copy-failed`);
  107 |       await failure.focus();
  108 |       await page.keyboard.press("Space");
  109 |       await expect(failure).toHaveCount(0);
  110 |       await expect(page.getByRole("button", { name: /^Încă (?:unul|un lanț) →$/ })).toBeEnabled();
  111 |     }
  112 |   });
  113 | }
  114 | 
  115 | test("long Romanian status stays readable with text zoom and a short viewport", async ({ page }, testInfo) => {
  116 |   const game = games[0];
  117 |   await page.setViewportSize({ width: 320, height: 850 });
  118 |   await deterministicStarts(page, game);
  119 |   await start(page, game);
  120 |   // Presentation stress only: no game state or network response is changed.
  121 |   await page.evaluate(() => {
  122 |     globalThis.document.documentElement.style.fontSize = "200%";
  123 |     globalThis.document.querySelector(".stat-badge-value").textContent = "Personalități și viața de zi cu zi în România";
  124 |     globalThis.document.querySelector(".game-shell-title").textContent = "Lanțul Cuvintelor Românești";
  125 |   });
  126 |   await layout(page, testInfo, "long-labels-200-percent");
  127 |   await testInfo.attach("long-labels-200-percent", { body: await page.screenshot(), contentType: "image/png" });
  128 |   await page.setViewportSize({ width: 320, height: 480 });
  129 |   await page.getByRole("searchbox", { name: "Caută în toate conceptele descoperite" }).focus();
  130 |   await expect(page.getByRole("searchbox", { name: "Caută în toate conceptele descoperite" })).toBeInViewport();
  131 |   await layout(page, testInfo, "short-viewport-focused-input");
  132 |   await testInfo.attach("short-viewport-focused-input", { body: await page.screenshot(), contentType: "image/png" });
  133 | });
  134 | 
```