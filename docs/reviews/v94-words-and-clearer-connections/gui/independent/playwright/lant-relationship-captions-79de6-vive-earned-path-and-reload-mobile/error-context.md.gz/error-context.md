# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: lant-relationship-captions.spec.mjs >> lt_geografie_239 route 3: meaningful choices survive earned path and reload
- Location: e2e/lant-relationship-captions.spec.mjs:73:5

# Error details

```
Error: expect(received).toMatch(expected)

Expected pattern: /oraș|regiune|salină|chei|revoluționar|răscoală|munți/
Received string:  "obiective din zona Turda"
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - generic:
    - status
  - generic [ref=e8]:
    - generic [ref=e9]:
      - generic [ref=e10]:
        - button "Ieși la lista de jocuri" [ref=e11] [cursor=pointer]:
          - generic [aria-hidden] [ref=e12]: ←
          - text: Ieși
        - strong [ref=e13]: Lanțul Cuvintelor
      - group "Starea jocului" [ref=e15]:
        - generic "Mutări făcute" [ref=e16]:
          - generic [ref=e17]: MUTĂRI
          - generic [ref=e18]: 2 mutări
    - region "Poziția și ținta" [ref=e19]:
      - generic [ref=e20]:
        - generic [ref=e21]: EȘTI ACUM LA
        - generic [ref=e22]: Cheile Turzii
      - generic [aria-hidden] [ref=e23]: →
      - generic [ref=e24]:
        - generic [ref=e25]: ȚINTĂ
        - strong [ref=e26]: Munții Apuseni
      - paragraph [ref=e27]: Grupa montana din Carpatii Occidentali, cunoscuta pentru pesteri si Tara Motilor.
    - region [ref=e28]:
      - strong [ref=e30]: Atinge următorul cuvânt
      - generic [ref=e31]:
        - 'button "Salt la Cheile Bicazului: legătură directă" [active] [ref=e32] [cursor=pointer]':
          - strong [ref=e33]: Cheile Bicazului
          - generic [ref=e34]: legătură directă
        - 'button "Salt la Munții Apuseni: chei și munții din care fac parte" [ref=e35] [cursor=pointer]':
          - strong [ref=e36]: Munții Apuseni
          - generic [ref=e37]: chei și munții din care fac parte
        - 'button "Salt la stâncă: legătură directă" [ref=e38] [cursor=pointer]':
          - strong [ref=e39]: stâncă
          - generic [ref=e40]: legătură directă
    - status [ref=e41]:
      - generic [aria-hidden] [ref=e42]: ↗
      - strong [ref=e43]: Mai aproape de țintă.
    - status [ref=e44]
    - generic [ref=e45]:
      - generic [ref=e46]:
        - textbox "Următorul concept" [ref=e47]:
          - /placeholder: Sau scrie alt concept…
        - button "Salt" [disabled] [ref=e48]
      - generic [ref=e49]:
        - button "Înapoi" [ref=e50] [cursor=pointer]: ↶ Înapoi
        - button "💡 Indiciu" [ref=e51] [cursor=pointer]
    - group [ref=e52]:
      - generic "⋯ Opțiuni de joc" [ref=e53] [cursor=pointer]
```

# Test source

```ts
  1   | import { execFileSync } from "node:child_process";
  2   | import { fileURLToPath } from "node:url";
  3   | import { test, expect } from "@playwright/test";
  4   | import { games, gameURL, start, tabTo } from "./games.mjs";
  5   | 
  6   | const game = games.find(({ key }) => key === "lant");
  7   | const root = fileURLToPath(new URL("../../", import.meta.url));
  8   | const helper = fileURLToPath(new URL("./lant_caption_seeds.py", import.meta.url));
  9   | const cases = [
  10  |   { id: "lt_geografie_239", nouns: /oraș|regiune|salină|chei|revoluționar|răscoală|munți/ },
  11  |   { id: "lt_literatura_240", nouns: /poet|scriitor|revistă|societate|academie|fondator|postum/ },
  12  |   { id: "lt_gastronomie_241", nouns: /ciorbă|perișoare|sarmale|orez|carne|umplutură/ },
  13  | ].map((item) => ({
  14  |   ...item,
  15  |   journey: JSON.parse(execFileSync("python3", [helper, item.id], {
  16  |     cwd: root, env: { ...process.env, PYTHONPATH: root }, encoding: "utf8",
  17  |   })),
  18  | }));
  19  | 
  20  | const responseFor = (page, id, action) => page.waitForResponse((response) =>
  21  |   response.request().method() === "POST" &&
  22  |   new URL(response.url()).pathname === `${gameURL(game, id)}/${action}`);
  23  | 
  24  | async function begin(page, item) {
  25  |   if (test.info().project.name === "mobile") {
  26  |     await page.setViewportSize({ width: 320, height: 900 });
  27  |     await page.addInitScript(() => {
  28  |       globalThis.document.addEventListener("DOMContentLoaded", () => {
  29  |         globalThis.document.documentElement.style.fontSize = "200%";
  30  |       });
  31  |     });
  32  |   }
  33  |   await page.route("**/api/wordgames/lant/games?*", async (route) => {
  34  |     const url = new URL(route.request().url());
  35  |     for (const [name, value] of Object.entries(item.journey.query)) {
  36  |       url.searchParams.set(name, String(value));
  37  |     }
  38  |     await route.continue({ url: url.toString() });
  39  |   });
  40  |   const state = await start(page, game, { keyboard: true });
  41  |   expect(state.start.id).toBe(item.journey.start.id);
  42  |   expect(state.target.id).toBe(item.journey.target.id);
  43  |   return state;
  44  | }
  45  | 
  46  | function meaningful(caption, nouns) {
> 47  |   expect(caption).toMatch(nouns);
      |                   ^ Error: expect(received).toMatch(expected)
  48  |   expect(caption).not.toMatch(/^legătură(?: directă)?$/i);
  49  | }
  50  | 
  51  | async function fits(page) {
  52  |   const layout = await page.locator(".lant-choice-grid button, .lant-hint-panel, .breadcrumb-trail, .lant-trail-step, .lant-trail-relation, .lant-trail-step .chip")
  53  |     .evaluateAll((elements) => ({
  54  |       width: globalThis.document.documentElement.clientWidth,
  55  |       scroll: globalThis.document.documentElement.scrollWidth,
  56  |       visible: elements.filter((element) => element.getClientRects().length).map((element) => ({
  57  |         left: element.getBoundingClientRect().left,
  58  |         right: element.getBoundingClientRect().right,
  59  |         width: element.clientWidth,
  60  |         scroll: element.scrollWidth,
  61  |       })),
  62  |     }));
  63  |   expect(layout.scroll).toBeLessThanOrEqual(layout.width + 1);
  64  |   for (const element of layout.visible) {
  65  |     expect(element.left).toBeGreaterThanOrEqual(-1);
  66  |     expect(element.right).toBeLessThanOrEqual(layout.width + 1);
  67  |     expect(element.scroll).toBeLessThanOrEqual(element.width + 1);
  68  |   }
  69  | }
  70  | 
  71  | for (const item of cases) {
  72  |   for (const [index, route] of item.journey.routes.entries()) {
  73  |     test(`${item.id} route ${index + 1}: meaningful choices survive earned path and reload`, async ({ page, request }) => {
  74  |       let state = await begin(page, item);
  75  |       const id = state.game_id;
  76  |       const firstHops = new Set(item.journey.routes.map((path) => path[1].label));
  77  |       const usefulChoices = state.choices.filter((choice) => firstHops.has(choice.label));
  78  |       expect(usefulChoices.length).toBeGreaterThanOrEqual(2);
  79  |       for (const choice of usefulChoices) {
  80  |         meaningful(choice.relation, item.nouns);
  81  |         await expect(page.getByRole("button", { name: `Salt la ${choice.label}: ${choice.relation}`, exact: true }))
  82  |           .toContainText(choice.relation);
  83  |       }
  84  |       await fits(page);
  85  |       if (index === 0) await page.screenshot({ path: test.info().outputPath("choices.png"), fullPage: true });
  86  |       for (const next of route.slice(1)) {
  87  |         const response = responseFor(page, id, "move");
  88  |         const choice = page.locator(".lant-choice-grid button").filter({
  89  |           has: page.locator("strong", { hasText: new RegExp(`^${next.label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`) }),
  90  |         });
  91  |         if (await choice.count()) {
  92  |           await tabTo(page, choice);
  93  |           await page.keyboard.press("Space");
  94  |         } else {
  95  |           const input = page.getByRole("textbox", { name: "Următorul concept" });
  96  |           await tabTo(page, input);
  97  |           await input.fill(next.label);
  98  |           await input.press("Enter");
  99  |         }
  100 |         state = await (await response).json();
  101 |         expect(state.ok).toBe(true);
  102 |         expect(state.current.id).toBe(next.id);
  103 |         meaningful(state.path.at(-1).relation, item.nouns);
  104 |       }
  105 |       expect(state.won).toBe(true);
  106 |       let mutations = 0;
  107 |       page.on("request", (request) => {
  108 |         if (request.method() === "POST" && new URL(request.url()).pathname.startsWith(`${gameURL(game, id)}/`)) mutations += 1;
  109 |       });
  110 |       const saved = await (await request.get(gameURL(game, id))).json();
  111 |       expect(saved.path).toEqual(state.path);
  112 |       await page.reload();
  113 |       await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toBeVisible();
  114 |       const options = page.locator(".game-options > summary");
  115 |       await tabTo(page, options);
  116 |       await page.keyboard.press("Space");
  117 |       const path = page.getByRole("group", { name: "Traseul parcurs" });
  118 |       for (const step of saved.path.slice(1)) await expect(path).toContainText(step.relation);
  119 |       expect(mutations).toBe(0);
  120 |       await fits(page);
  121 |       if (index === 0) await page.screenshot({ path: test.info().outputPath("earned-path.png"), fullPage: true });
  122 |       await test.info().attach("earned-captions", {
  123 |         body: JSON.stringify({ seed: item.journey.query, path: saved.path }, null, 2), contentType: "application/json",
  124 |       });
  125 |     });
  126 |   }
  127 | 
  128 |   test(`${item.id}: noun-bearing hints persist without taking a hop`, async ({ page, request }) => {
  129 |     const initial = await begin(page, item);
  130 |     const id = initial.game_id;
  131 |     async function ask() {
  132 |       const response = responseFor(page, id, "hint");
  133 |       const button = page.getByRole("button", { name: /💡 (?:Indiciu|Mai clar)/ });
  134 |       await tabTo(page, button);
  135 |       await page.keyboard.press("Space");
  136 |       return (await response).json();
  137 |     }
  138 |     const direction = await ask();
  139 |     expect(direction.stage).toBe("direction");
  140 |     meaningful(direction.relation, item.nouns);
  141 |     await expect(page.locator(".lant-hint-panel")).toContainText(direction.relation);
  142 |     await page.reload();
  143 |     await expect(page.locator(".lant-hint-panel")).toContainText(direction.relation);
  144 |     const saved = await (await request.get(gameURL(game, id))).json();
  145 |     expect(saved.moves).toBe(0);
  146 |     expect(saved.earned_hint).toEqual(direction);
  147 |     const alternatives = await ask();
```