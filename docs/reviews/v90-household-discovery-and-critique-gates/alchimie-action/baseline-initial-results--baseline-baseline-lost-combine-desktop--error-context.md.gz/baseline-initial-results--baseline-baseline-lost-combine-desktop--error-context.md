# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: baseline.spec.mjs >> baseline lost combine
- Location: ../../../_temp/feat__v90-household-discovery-and-critique-gates/alchimie/baseline.spec.mjs:5:54

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Combinație respinsă (503).', { exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Combinație respinsă (503).', { exact: true }) with timeout 10000ms
  - waiting for getByText('Combinație respinsă (503).', { exact: true })

```

```yaml
- button "Ieși la lista de jocuri": Ieși
- strong: Alchimie
- group "Starea jocului": Mod Ușor Categorie Sport Combinații 0 Descoperite 0
- group: Reguli și ajutor
- text: ȚINTA DE FĂURIT
- heading "Liga Campionilor la handbal" [level=2]
- paragraph: Competiția europeană majoră de club în care Cristina Neagu a strălucit.
- text: ACUM
- strong: Pereche gata
- text: Apasă Combină. 2/2
- button "Scoate Cristina Neagu din alambic": Cristina Neagu
- button "Scoate Washington Bullets din alambic": Washington Bullets
- button "Golește"
- button "Combină cele două concepte selectate": ⚗ Combină
- region "Inventar":
  - text: INVENTAR · 3 ÎN JOC pereche gata 3 puse deoparte
  - group "Filtrează inventarul":
    - button "Recente 3"
    - button "Utile 3"
    - button "Toate 6" [pressed]
  - searchbox "Caută în toate conceptele descoperite"
  - button "Washington Bullets, gata pentru o combinație utilă" [pressed]: Washington Bullets
  - button "Medalie, pus deoparte" [disabled]: Medalie
  - button "Recordul la 100 m liber din 2022, pus deoparte" [disabled]: Recordul la 100 m liber din 2022
  - button "Cristina Neagu, gata pentru o combinație utilă" [pressed]: Cristina Neagu
  - button "Bazin olimpic, pus deoparte" [disabled]: Bazin olimpic
  - button "Tricolorii, gata pentru o combinație utilă": Tricolorii
- button "↻ Reia același joc"
- button "⚗ Alt joc"
- button "⚙ Schimbă opțiunile"
- status
```

# Test source

```ts
  1  | import { test, expect } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates/frontend/node_modules/@playwright/test/index.mjs';
  2  | import { writeFileSync } from 'node:fs';
  3  | import {games,gameURL,deterministicStarts,start,act,solution} from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates/frontend/e2e/games.mjs';
  4  | const game=games[0];
  5  | for (const kind of ['combine','reset','hint','win']) test(`baseline lost ${kind}`,async({page,request})=>{
  6  |  await deterministicStarts(page,game); const initial=await start(page,game); const id=initial.game_id;
  7  |  const steps=solution(game).steps;
  8  |  if(kind==='reset'||kind==='win') for(const step of steps.slice(0,kind==='reset'?1:-1)) await request.post(`${gameURL(game,id)}/combine`,{data:step.payload});
  9  |  if(kind==='hint') {
  10 |   outer: for(let a=0;a<initial.inventory.length;a++) for(let b=a+1;b<initial.inventory.length;b++) {
  11 |    const r=await (await request.post(`${gameURL(game,id)}/combine`,{data:{a:initial.inventory[a].id,b:initial.inventory[b].id}})).json();
  12 |    if(r.hint_available) break outer;
  13 |   }
  14 |  }
  15 |  if(kind!=='combine') { await page.reload(); await expect(page.locator(game.board)).toBeVisible(); }
  16 |  const before=await (await request.get(gameURL(game,id))).json(); let committed; const counts={reads:0,mutations:0};
  17 |  page.on('request',r=>{const path=new URL(r.url()).pathname;if(r.method()==='GET'&&path===gameURL(game,id))counts.reads++;if(r.method()==='POST'&&path.startsWith(gameURL(game,id)+'/'))counts.mutations++;});
  18 |  const action=kind==='win'?'combine':kind;
  19 |  await page.route(`**${gameURL(game,id)}/${action}`,async route=>{const r=await route.fetch();expect(r.status()).toBe(200);committed=await r.json();await route.fulfill({status:503,contentType:'application/json',body:'{}'});},{times:1});
  20 |  if(action==='combine') await act(page,game,kind==='win'?steps.at(-1):steps[0]);
  21 |  else await page.getByRole('button',{name:action==='hint'?'💡 Indiciu':/Reia același joc/}).click();
> 22 |  await expect(page.getByText(action==='combine'?'Combinație respinsă (503).':action==='hint'?'Niciun indiciu (503).':'Nu am putut reseta (503).',{exact:true})).toBeVisible();
     |                                                                                                                                                                 ^ Error: expect(locator).toBeVisible() failed
  23 |  const after=await (await request.get(gameURL(game,id))).json();
  24 |  expect(counts).toEqual({reads:0,mutations:1});
  25 |  if(kind==='combine') {expect(after.discovered_count).toBeGreaterThan(before.discovered_count); for(const d of committed.discovered)await expect(page.locator(game.board).getByRole('button',{name:new RegExp('^'+d.label+'(?:,|$)')})).toHaveCount(0);}
  26 |  if(kind==='reset') {expect(after.moves).toBe(0);expect(before.moves).toBe(1);}
  27 |  if(kind==='hint') {expect(after.hints_used).toBe(1);expect(after.hint).toBeUndefined();expect(after.hint_output).toBeUndefined();expect(after.earned_hint).toBeUndefined();await expect(page.getByText(committed.message,{exact:true})).toHaveCount(0);}
  28 |  if(kind==='win') {expect(after.won).toBe(true);await expect(page.getByRole('button',{name:'Copiază rezultatul'})).toHaveCount(0);}
  29 |  await expect(page.locator('.screen')).toHaveCSS('opacity','1');
  30 |  await page.screenshot({path:test.info().outputPath(`baseline-${kind}.png`),fullPage:true});
  31 |  writeFileSync(test.info().outputPath(`baseline-${kind}.json`),JSON.stringify({kind,before,committed,after,counts,body:await page.locator('body').innerText()},null,2)+'\n');
  32 | });
  33 | 
```