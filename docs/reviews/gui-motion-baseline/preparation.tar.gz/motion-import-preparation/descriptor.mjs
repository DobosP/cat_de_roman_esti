import {readFileSync} from "node:fs";
import assert from "node:assert/strict";
import {digest} from "./policy.mjs";
export const path=process.env.IMPORT_DESCRIPTOR;
assert.ok(path,"strict launcher descriptor required; direct/filtered Playwright invocation is forbidden");
export const descriptor=JSON.parse(readFileSync(path,"utf8"));
const unsigned={...descriptor};delete unsigned.descriptor_sha256;
assert.equal(digest(unsigned),descriptor.descriptor_sha256,"run descriptor drift");
export const binding=descriptor.binding;
