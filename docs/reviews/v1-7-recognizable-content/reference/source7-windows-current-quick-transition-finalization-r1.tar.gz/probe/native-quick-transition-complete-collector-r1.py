import pathlib,json,hashlib,io,tarfile,time,datetime,stat,os,shutil,ctypes
S=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7');P=S/'probe';O=S/'source7-current-quick-transition-r1';spec=json.loads((P/'native-quick-transition-spec-r1.json').read_bytes())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def put(p,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return hashlib.sha256(b).hexdigest()
reviews={'kind':'root transcription of actual independent transition judgments','factual':{'reviewer':'/root/qualification_ledger','verdict':'ACCEPT_ACTUAL_ISOLATED_QUICK_TRANSITION_ONLY','frozen_utc':'2026-10-09T15:44:31Z','fresh1265protected_readback':True,'fullI1200namespace_modes_and1199others_verified':True,'OS_absence_scope':'read recordednativecleanup; independent live OS absence is parent/quality, not personally rerun'},'quality':{'reviewer':'/root/continuation_audit','verdict':'ACCEPT_ACTUAL_ISOLATED_QUICK_TRANSITION_EVIDENCE_ONLY','frozen_utc':'2026-10-09T15:45:07Z','fresh1265protected_readback':True,'independent_Windows_Linux_modes_and_owner_absence':True,'recorded_fresh_full4root_total':3196119961,'recorded_growth':5163618,'recorded_disk_free_bytes':19908456448,'recorded_Windows_available_bytes':27481206784,'recorded_Linux_available_kB':55765460},'bound_state_sha256':'8329994bd45a0c26bc75d14ce4cb7e86d17cfaf2878e840ac83408e9e0b6c738','scope':'isolated scratch target transition only; old1c6audit/finals now pretransition; no installedaudit/Source7/V1.7 qualification'}
put(S/'native-quick-transition-reviews-r1.json',reviews)
source=dict(spec['source_bindings']);source['quick_games_v92.json']=spec['new_target_sha256'];I=pathlib.Path(spec['windows_stage'])
for name,h in source.items():
 p=I/('docs/CRITIQUE_RUBRIC.md' if name=='rubric' else 'cat_de_roman_esti/fixtures/'+name);b=p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n');assert hashlib.sha256(b).hexdigest()==h
for name,h in spec['runtime_bindings'].items():assert sha(I/name)==h
put(S/'native-quick-transition-post-bindings-r1.json',{'kind':'root actual-byte-posttransition-bindings-not-gameplay-audit','runtime131':spec['runtime_bindings'],'source9':source,'root_raw_readback_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_gameplay_not_rerun':True,'next_runtime_change_expected':'only current contentbuild/build.go Quick pin among131 runtime rows; frozenSource6 tests untouched'})
names=['quick-transition-source-evidence-r1.tar.gz','quick-transition-source-evidence-r1.json','probe/native-quick-transition-spec-r1.json','native-quick-transition-actual-admission-r1.json','probe/native-quick-transition-dispatch-approval-r1.json','native-quick-transition-actual-results-r1.json','native-quick-transition-owner-closure-r1.json','native-quick-transition-outer-observation-r1.json','native-quick-transition-post-I1200-r1.json','native-quick-transition-post-bindings-r1.json','native-quick-transition-reviews-r1.json','probe/native-quick-transition-actual-collector-r1.py','source7-current-quick-reviews/factual-r1.json','source7-current-quick-reviews/quality-r1.json','source7-candidate-1200/native/quick/candidate.json','source7-candidate-1200/go-backend/internal/contentrails/sources/authored-v7.json','source7-current-quick-transition-r1/quick_games_v92.before.json','source7-current-quick-transition-r1/quick_games_v92.after.json','source7-current-quick-transition-r1/inverse-before-r1.json']
names+=['source7-current-quick-transition-r1/run/'+n for n in ['state.json','quick-transition.stdout.log','quick-transition.stderr.log','quick-transition.controller.stderr.log','quick-transition.telemetry.jsonl']]
assert time.time()<spec['deadline_epoch'] and len(set(names))==len(names)
archive=S/'native-quick-transition-complete-evidence-r1.tar.gz'
with archive.open('xb') as out:
 with tarfile.open(fileobj=out,mode='w:gz') as tf:
  for name in names:
   p=S/name;st=p.lstat();assert stat.S_ISREG(st.st_mode) and not stat.S_ISLNK(st.st_mode) and not getattr(st,'st_file_attributes',0)&0x400;b=p.read_bytes();t=tarfile.TarInfo(name);t.mode=0o600;t.size=len(b);tf.addfile(t,io.BytesIO(b))
assert archive.stat().st_size<=8<<20
rows=[]
with tarfile.open(archive,'r:gz') as tf:
 assert tf.getnames()==names
 for t in tf:
  assert t.isreg() and not pathlib.PurePosixPath(t.name).is_absolute() and '..' not in pathlib.PurePosixPath(t.name).parts
  b=tf.extractfile(t).read();assert b==(S/t.name).read_bytes();rows.append(dict(path=t.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
def count(root):
 pending=[root];total=files=dirs=0
 while pending:
  p=pending.pop();a=p.lstat();assert stat.S_ISDIR(a.st_mode) and not stat.S_ISLNK(a.st_mode) and not getattr(a,'st_file_attributes',0)&0x400;dirs+=1
  with os.scandir(p) as es:
   for e in es:
    st=e.stat(follow_symlinks=False);assert not stat.S_ISLNK(st.st_mode) and not getattr(st,'st_file_attributes',0)&0x400
    if stat.S_ISDIR(st.st_mode):pending.append(pathlib.Path(e.path))
    else:assert stat.S_ISREG(st.st_mode);total+=st.st_size;files+=1
  b=p.lstat();assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino)
 return dict(bytes=total,files=files,dirs=dirs)
counts={p:count(pathlib.Path(p)) for p in spec['accounting_roots']};total=sum(x['bytes'] for x in counts.values());G=1<<30
class M(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ['total','available','tp','ap','tv','av','extra']]
m=M();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
assert total-spec['full_R_S_baseline']+(1<<20)<=G and shutil.disk_usage(I).free-(1<<20)>=16*G and m.available>=16*G and time.time()<spec['deadline_epoch']
receipt={'kind':'complete-isolated-Quick-transition-portable-evidence-v1','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':rows,'all_member_root_readback':True,'closed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_deadline_epoch':spec['deadline_epoch'],'original_full_owned_baseline':spec['full_R_S_baseline'],'current_full4root_counts':counts,'growth_before_manifest':total-spec['full_R_S_baseline'],'final_metadata_reserve_bytes':1<<20,'source_metadata_RSS':'unmeasured','current_Windows_available_bytes':m.available,'current_disk_free_bytes':shutil.disk_usage(I).free,'owner_active':False,'scope':'actual isolated scratch Quick update accepted; freshinstalledaudit/producer/pins/authority/Source7/fullversiongates remain','qualified_binary_not_duplicated':'e702 already preserved in committed20member745bcc2f buildarchive; originalI1200 base5d0ae406 plus exactbefore/after sufficient forforward/inverse'}
put(S/'native-quick-transition-complete-evidence-r1.json',receipt)
print(json.dumps({'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(rows),'manifest_sha256':sha(S/'native-quick-transition-complete-evidence-r1.json'),'closed_utc':receipt['closed_utc'],'growth_before_manifest':receipt['growth_before_manifest']}))
