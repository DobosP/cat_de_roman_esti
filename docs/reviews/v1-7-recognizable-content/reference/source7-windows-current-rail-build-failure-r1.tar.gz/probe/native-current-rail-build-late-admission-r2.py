from pathlib import Path
import ctypes,hashlib,json,os,shutil,stat,sys,time
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"):raise RuntimeError("optimized publisher refused")
S=Path("C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7")
R=Path("C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-7")
old=Path("C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7-qualification/toolbuild-r1")
roots=[R,S,old/"gocache",old/"gomodcache"]
def count(root):
 if not root.is_dir() or root.is_symlink() or str(root.resolve(strict=True))!=str(root):raise RuntimeError("canonical accounting root")
 n=0;pending=[root]
 while pending:
  p=pending.pop();st=p.lstat()
  if not stat.S_ISDIR(st.st_mode) or stat.S_ISLNK(st.st_mode) or getattr(st,"st_file_attributes",0)&0x400:raise RuntimeError("ordinary accounting directory")
  with os.scandir(p) as entries:
   for e in entries:
    q=Path(e.path);st=q.lstat()
    if stat.S_ISLNK(st.st_mode) or getattr(st,"st_file_attributes",0)&0x400:raise RuntimeError("link/reparse accounting")
    if stat.S_ISDIR(st.st_mode):pending.append(q)
    elif stat.S_ISREG(st.st_mode):n+=st.st_size
    else:raise RuntimeError("nonregular accounting")
 return n
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def exclusive(p,v):
 b=(json.dumps(v,indent=2,sort_keys=True)+"\n").encode()
 with p.open("xb") as f:f.write(b)
 return hashlib.sha256(b).hexdigest()
t=S/"probe/native-current-rail-build-template-r2.json";blob=t.read_bytes()
if hashlib.sha256(blob).hexdigest()!="a88e3a95f5c42d06b386ce7a7d71a66001a0e47a79312bfc19dcc10997cb46f1":raise RuntimeError("template drift")
if len(sys.argv)!=3 or len(sys.argv[2])!=64 or any(c not in "0123456789abcdef" for c in sys.argv[2]):raise RuntimeError("one external frozen source-boundary hash required")
closure_path=S/"current-rail-build-source-boundary-r1.json"
if digest(closure_path)!=sys.argv[2]:raise RuntimeError("source boundary drift")
closure=json.loads(closure_path.read_bytes())
if closure["native_ran"] or closure["owner_active"]:raise RuntimeError("source-only boundary")
a=closure["admission"]
if not a["started_epoch"]<closure["recorded_unix"]<a["deadline_epoch"]:raise RuntimeError("boundary metadata deadline")
for role,identity in [("factual","/root/qualification_ledger"),("quality","/root/continuation_audit")]:
 row=closure[role]
 if row["reviewer"]!=identity or row["verdict"]!={"factual":"ACCEPT_SOURCE_ONLY","quality":"ACCEPT_CURRENT_RAIL_BUILD_SOURCE_ONLY"}[role]:raise RuntimeError("source review absent")
 from datetime import datetime
 if datetime.fromisoformat(row["frozen_utc"].replace("Z","+00:00")).timestamp()>=a["substantive_cutoff_epoch"]:raise RuntimeError("source review late")
for key,path in [("windows_r1","native-current-rail-build-windows-r1.py"),("linux_r1","native-current-rail-build-linux-r1.py"),("template_r2","native-current-rail-build-template-r2.json"),("controls_r1","native-current-rail-build-controls-r1.py")]:
 if digest(S/"probe"/path)!=closure["accepted_hashes"][key]:raise RuntimeError("accepted method drift")
spec=json.loads(blob)
if set(["started_epoch","deadline_epoch","full_R_S_baseline","host_launcher_pid"])&set(spec):raise RuntimeError("template contains clocks")
if len(sys.argv)!=3 or not sys.argv[1].isdigit() or int(sys.argv[1])<=0:raise RuntimeError("one actual held launcher PID")
actual_spec=Path(spec["windows_spec"]);record_path=S/"native-current-rail-build-actual-admission-r1.json"
if actual_spec.exists() or record_path.exists() or Path(spec["windows_run"]).exists():raise RuntimeError("fresh single admission/output")
if any(Path(spec["windows_build_cache"]).iterdir()):raise RuntimeError("fresh empty build module cache required")
if Path(spec["windows_artifact"]).exists():raise RuntimeError("fresh build binary required")
class M(ctypes.Structure):
 _fields_=[("length",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ("total","available","tp","ap","tv","av","extra")]
m=M();m.length=ctypes.sizeof(m)
if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise RuntimeError("memory unavailable")
disk=shutil.disk_usage(R).free;measures={str(p):count(p) for p in roots}
baseline=1793580496
if json.loads((S/"SDK-recovery-admission-r1.json").read_bytes())["baseline_total"]!=baseline:raise RuntimeError("original growth anchor drift")
actual=sum(measures.values())
if disk<17*(1<<30) or m.available<16*(1<<30):raise RuntimeError("native start resource floor")
if actual-baseline+(16<<20)>1<<30:raise RuntimeError("combined source/native growth with publication headroom")
start=time.time()
spec.update(started_epoch=start,deadline_epoch=start+1200,full_R_S_baseline=baseline,host_launcher_pid=int(sys.argv[1]))
pin=exclusive(actual_spec,spec)
record={"schema":"current-rail-offline-build-actual-admission-v1","valid_until":"immutable deadline or guard failure; then history","spec_sha256":pin,"spec":str(actual_spec),"started_epoch":start,"substantive_cutoff_epoch":start+1020,"deadline_epoch":start+1200,"disk_free_bytes":disk,"available_physical_bytes":m.available,"current_full_owned_roots":measures,"current_total":actual,"conservative_growth_anchor":baseline,"growth_before_native":actual-baseline,"host_launcher_pid":int(sys.argv[1]),"only_late_fields":["started_epoch","deadline_epoch","full_R_S_baseline","host_launcher_pid"],"source_boundary_sha256":digest(closure_path),"publisher_sha256":digest(Path(__file__)),"immutable_inputs_exclusive_no_concurrent_writers":True,"prior_native_acquisition":"accepted completed exact-five acquisition; prior source-only rejected build scope draft and withdrawn missing-prehash finding preserved","actual_dispatch":"WITHHELD until independent exact actual admission review; parent shell held","scope":"ONE fixed offline CGO1 current content-rail build through two immutable file proxies; trusted OS compiler headers/config/plugins/libraries/loader boundary; no tool invocation/audit/adoption/full-release acceptance","failed_clock_reset":False,"source_RSS":"unmeasured"}
ap=exclusive(record_path,record)
print(json.dumps({"spec_sha256":pin,"admission_sha256":ap,"spec":str(actual_spec),"started_epoch":start,"deadline_epoch":start+1200,"launcher_pid":int(sys.argv[1]),"disk":disk,"memory":m.available,"growth_anchor":baseline,"current_growth":actual-baseline}))
