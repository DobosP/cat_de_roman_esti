from pathlib import Path
import hashlib,json,ast
R=Path('/home/dobo/work/_worktrees/cat_de_roman_esti/codex__content-v1-7');S=Path('/home/dobo/work/_temp/codex__content-v1-7');D=R/'docs/reviews/v1-7-recognizable-content';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=D/'methods/ordinary_leafa_http_r1.go.txt';s=a.read_text()
s=s.replace('v1-7-ordinary-leafa-baseline-r1','v1-7-ordinary-leafa-baseline-r2').replace('ordinary-leafa-baseline-r1.json','ordinary-leafa-baseline-r2.json')
s=s.replace('status,clue:=request("earned_clue","POST",base+"/clue",nil,true)\n  if status!=200 || clue["clue_kind"]!="category" || number(clue["clues_used"])!=1 || number(clue["attempts"])!=3 {t.Fatalf("earnedclue failed%v",clue)}\n  getState("after_clue_get",base,clue)',r'''cluesUsed:=0
  if current["clue_available"]==true {
   if current["next_clue_kind"]!="warmer" {t.Fatal("explicit Societate category must offer warmer, notcategory")}
   status,clue:=request("earned_warmer_clue","POST",base+"/clue",nil,true)
   if status!=200 || clue["clue_kind"]!="warmer" || number(clue["clues_used"])!=1 || number(clue["attempts"])!=3 || clue["won"]!=false || !reflect.DeepEqual(clue["guesses"],current["guesses"]) {t.Fatalf("earnedwarmer failed%v",clue)}
   word,ok:=clue["word"].(map[string]any);if !ok {t.Fatal("warmer clue word missing")}
   label,ok:=word["label"].(string);if !ok || label=="" || label==c.Labels[target] {t.Fatal("warmer clue exposedtarget/emptylabel")}
   best:=int(^uint(0)>>1);for _,value:=range guesses {g:=value.(map[string]any);if number(g["rank"])<best {best=number(g["rank"])}}
   if number(word["rank"])<=1 || number(word["rank"])>=best {t.Fatal("warmer clue rank mustbe safe and better than publicbest")}
   obs["earned_clue"]=clue;getState("after_clue_get",base,clue);cluesUsed=1
  }else {
   if _,ok:=current["next_clue_kind"];ok {t.Fatal("unavailable clue must omit nextkind")}
   status,refusal:=request("unavailable_warmer_clue","POST",base+"/clue",nil,true)
   if status!=400 {t.Fatal("unavailable warmer clue refusalstatus")}
   obs["clue_refusal"]=refusal;getState("after_clue_refusal_get",base,current)
  }
  expectedScore:=max(50,1000-60*3-120*cluesUsed)''')
s=s.replace('number(terminal["clues_used"])!=1 || number(terminal["score"])!=700','number(terminal["clues_used"])!=cluesUsed || number(terminal["score"])!=expectedScore').replace('terminal exactfourattempt/oneclue700drift','terminal exactfourattempt/actualclue/score drift')
s=s.replace('+"\\n4 încercări\\nindiciu x1"','+"\\n4 încercări"\n  if cluesUsed>0 {wantedShare+="\\nindiciu x1"}')
s=s.replace('finalScore!=700','finalScore!=expectedScore').replace('obs["final_clues_used"]=1;obs["final_score"]=700','obs["final_clues_used"]=cluesUsed;obs["final_score"]=expectedScore')
p=D/'methods/ordinary_leafa_http_r2.go.txt';p.write_text(s)
w=(D/'methods/ordinary_leafa_compile_lifecycle_r1.py.txt').read_text().replace('ordinary_leafa_http_r1.go.txt','ordinary_leafa_http_r2.go.txt').replace('v17_ordinary_leafa_probe_test.go','v17_ordinary_leafa_probe_r2_test.go').replace('ordinary-leafa-baseline-r1.test','ordinary-leafa-baseline-r2.test').replace('ordinary-leafa-compile-lifecycle-r1.json','ordinary-leafa-compile-lifecycle-r2.json').replace('v1-7-temporary-leafa-compile-lifecycle-r1','v1-7-temporary-leafa-compile-lifecycle-r2').replace(sha(a),sha(p))
q=D/'methods/ordinary_leafa_compile_lifecycle_r2.py.txt';q.write_text(w);ast.parse(w);(S/'probe/ordinary_leafa_compile_lifecycle_r2.py').write_text(w)
plan=json.load(open(D/'ordinary-leafa-baseline-method-proposal-r1.json'))
plan.update({'schema':'v1-7-ordinary-leafa-baseline-method-r2','method_sha256':sha(p),'method_path':str(p.relative_to(R)),'compile_lifecycle_sha256':sha(q),'compile_lifecycle_path':str(q.relative_to(R)),'compile_lifecycle_scratch':str(S/'probe/ordinary_leafa_compile_lifecycle_r2.py'),'r1_preserved':{'proposal_sha256':sha(D/'ordinary-leafa-baseline-method-proposal-r1.json'),'method_sha256':sha(a),'compile_lifecycle_sha256':sha(D/'methods/ordinary_leafa_compile_lifecycle_r1.py.txt'),'native_execution':False,'reason':'Independent review found explicit category already revealed, so category-clue/700-only contract was incorrect. R2 follows actual warmer availability or preserves unavailable refusal and nocharge; no selector/rule change.'}})
plan['case']['normal_terminal_contract']='3unique nonwinning guesses; current warmer availability is observed. If offered, safe rank>1/better-than-best warmer clue and oneclue700; if unavailable,400refusal/nocharge and zeroclue820. Exact fourattempt share/Get/Progress. Unexpected existing wins retained separately and hold hypothesis.'
for step in plan['commands_before_admission_template']:
 step['argv']=[x.replace('ordinary_leafa_compile_lifecycle_r1.py','ordinary_leafa_compile_lifecycle_r2.py').replace('ordinary-leafa-baseline-r1.test','ordinary-leafa-baseline-r2.test') for x in step['argv']]
plan['environment']['V17_LEAFA_REPORT']=str(S/'probe/ordinary-leafa-baseline-r2.json')
v=D/'ordinary-leafa-baseline-method-proposal-r2.json';v.write_text(json.dumps(plan,sort_keys=True,ensure_ascii=False,indent=2)+'\n')
for x in [p,q,v]:print(x.name,sha(x))
