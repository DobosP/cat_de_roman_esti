import { defineConfig } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates/frontend/node_modules/@playwright/test/index.mjs';
import config from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v90-household-discovery-and-critique-gates/frontend/playwright.config.mjs';
export default defineConfig({ ...config, testDir: '.', testMatch: 'repeated-verification.spec.mjs', outputDir: './results' });
