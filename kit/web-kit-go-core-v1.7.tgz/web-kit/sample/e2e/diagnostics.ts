import { test } from '@playwright/test';
import { createHash } from 'node:crypto';
import {mkdirSync,writeFileSync} from 'node:fs';
const observations=new WeakMap();
test.beforeEach(async({page,request})=>{
  const response=await request.get(new URL('/__gate/csp',process.env.GATE_APP_URL!).href);const data={console:[],errors:[],network:[],server_before:await response.json()};observations.set(page,data);
  page.on('pageerror',error=>data.errors.push({message:error.message,stack:error.stack}));
  page.on('console',message=>{if(['error','warning'].includes(message.type()))data.console.push({type:message.type(),text:message.text().replace(/nonce-[A-Za-z0-9+/_=-]+/g,'nonce-[redacted]')});});
  page.on('requestfailed',request=>data.network.push({url:request.url(),failure:request.failure()}));
  page.on('response',response=>{if(response.status()>=400||response.url().includes('/api/hovercard'))data.network.push({url:response.url(),status:response.status()});});
  await page.addInitScript(()=>{window.__roeduIslandFailures=[];window.__roeduCSPEvents=[];document.addEventListener('island:failed',event=>window.__roeduIslandFailures.push({key:event.detail.key,error:String(event.detail.error)}));document.addEventListener('securitypolicyviolation',event=>{const prefix=event.sample?.split('|')[0].trim()??'';const sink=/^(HTML[A-Za-z]*Element|Element|Document|Range|DOMParser) [A-Za-z][A-Za-z0-9]*$/.test(prefix)&&prefix.length<=80?prefix:'unknown';window.__roeduCSPEvents.push({directive:event.effectiveDirective,sink,disposition:event.disposition,line:event.lineNumber,column:event.columnNumber});});});
});
test.afterEach(async({page,request},info)=>{
  const response=await request.get(new URL('/__gate/csp',process.env.GATE_APP_URL!).href);const server_after=await response.json();
  const id=createHash('sha256').update(info.titlePath.join(':')).digest('hex').slice(0,16);
  const data={schema:1,sha:process.env.GATE_SHA,tree_sha256:process.env.GATE_TREE_SHA256,title:info.title,status:info.status,server_after,csp:await page.evaluate(()=>window.__roeduCSPEvents??[]).catch(()=>[]),...observations.get(page),cards:await page.evaluate(()=>[...document.querySelectorAll('roedu-hovercard')].map(element=>({defined:!!customElements.get('roedu-hovercard'),role:element.getAttribute('role'),hidden:element.hidden,state:element.dataset.state,open:element.matches(':popover-open'),text:element.textContent,rect:element.getBoundingClientRect().toJSON()}))).catch(()=>[]),islands:await page.evaluate(()=>window.__roeduIslandFailures??[]).catch(()=>[]),urls:await page.evaluate(()=>[...document.querySelectorAll('script[src],link[href]')].map(element=>({tag:element.tagName,url:element.src??element.href,rel:element.rel,nonce_set:!!element.nonce}))).catch(()=>[])};
  mkdirSync('.gate/full/diagnostics',{recursive:true});const body=JSON.stringify(data,null,2);writeFileSync(`.gate/full/diagnostics/${id}.json`,body+'\n');await info.attach('actual browser diagnostics',{body:Buffer.from(body),contentType:'application/json'});
});
