"""Actual-root Python-only WSL R5 lifecycle fixture with complete SDK root; no application execution.
Usage: qualified_python check_runner_signal_r4_r2.py NEW_DIRECTORY_UNDER_OWN_PROBE [active|finalization]
Work has24seconds; six further seconds are reserved for owned cleanup/reporting.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
sys.dont_write_bytecode=True
import time

R = Path('/mnt/c/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-6')
S = Path('/mnt/c/Users/Paul Work/personal_repos/_temp/codex__content-v1-6')
D = R / 'docs/reviews/v1-6-everyday-inputs'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def info(pid):
    try:
        fields = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
        return {'pid': pid, 'state': fields[0], 'pgid': int(fields[2]),
                'sid': int(fields[3]), 'start_ticks': int(fields[19])}
    except (OSError, ValueError, IndexError):
        return None

def live(pid):
    value = info(pid)
    return value is not None and value['state'] not in ('Z', 'X')

def main():
    started = time.monotonic()
    work_deadline, hard_deadline = started + 24, started + 30
    directory = Path(sys.argv[1]).resolve()
    if not directory.is_relative_to(S / 'probe') or directory == S / 'probe':
        raise ValueError('check directory must be inside owned probe')
    directory.mkdir(mode=0o700)
    runner = S / 'probe/run_worktree_lane_wsl_r9.py'
    lane = 'r4-r2-signal-' + hashlib.sha256(str(directory).encode()).hexdigest()[:16]
    state_path = S / 'probe' / (lane + '-r4-r2-state.json')
    result_path = D / (lane + '-result.json')
    marker, never = directory / 'owned-processes.json', directory / 'must-not-run.txt'
    child_source = directory / 'child.py'
    child_source.write_text("""import json,os,pathlib,signal,subprocess,sys,time
marker=pathlib.Path(sys.argv[1])
grand=subprocess.Popen([sys.executable,"-c","import time; time.sleep(60)"])
def identity(pid):
 f=pathlib.Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
 return {'pid':pid,'pgid':int(f[2]),'sid':int(f[3]),'start_ticks':int(f[19])}
def stopped(signum,frame):
 try:
  grand.terminate()
  grand.wait(timeout=1)
 except ProcessLookupError:
  pass
 finally:
  raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stopped)
signal.signal(signal.SIGINT,stopped)
marker.write_text(json.dumps({'child':identity(os.getpid()),'grandchild':identity(grand.pid)}))
while True: time.sleep(.1)
""")
    protected = directory / 'immutable-input.txt'
    protected.write_text('R4 owned lifecycle fixture\n')
    expected = {str(p): sha(p) for p in (protected, child_source, runner)}
    current = datetime.datetime.now(datetime.timezone.utc)
    manifest = {'schema': 'v1-6-r4-python-only-signal-fixture', 'lane': lane,
                'runner_sha256': sha(runner), 'checked_at_utc': current.isoformat(),
                'deadline_utc': (current + datetime.timedelta(minutes=20)).isoformat(),
                'inputs': expected, 'unchanged': expected, 'scratch_bindings': {}, 'expected_after': {},
                'additional_measure_dirs': [str(S / 'tools')], 'environment': {'PYTHONDONTWRITEBYTECODE': '1'},
                'limits': {'RSS_bytes': 2 * 2**30, 'incremental_bytes': 2**30,
                           'start_disk_floor_bytes': 17 * 2**30,
                           'remaining_disk_memory_floor_bytes': 16 * 2**30,
                           'GOMAXPROCS': 2, 'build_jobs': 2, 'metadata_reserve_seconds': 180},
                'commands': [
                    {'name': 'successful-fixture-prefix', 'argv': [sys.executable, '-c', 'pass']},
                    {'name': 'owned-python-child-and-grandchild', 'argv': [sys.executable, str(child_source), str(marker)]},
                    {'name': 'forbidden-after-failure', 'argv': [sys.executable, '-c',
                     'from pathlib import Path; Path(' + repr(str(never)) + ').write_text("bad")']},
                ]}
    manifest_path = directory / 'admission.json'
    manifest_path.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
    guard = ownership = failure = None
    fallback_cleanup = False
    observations = {}
    def remaining():
        left = work_deadline - time.monotonic()
        if left <= 0:
            raise TimeoutError('fixture work budget exhausted')
        return left
    try:
        guard = subprocess.Popen([sys.executable, str(runner), str(manifest_path), '0'],
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        output, _ = guard.communicate(timeout=remaining())
        if guard.returncode != 0:
            raise AssertionError('fixture prefix refused: ' + output.decode(errors='replace'))
        initial = json.loads(state_path.read_bytes())
        assert initial['status'] == 'ready' and initial['next_index'] == 1 and len(initial['steps']) == 1
        prefix = initial['steps'][0]
        guard = subprocess.Popen([sys.executable, str(runner), str(manifest_path), '1'],
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        while True:
            remaining()
            try:
                ownership = json.loads(marker.read_bytes())
                pending = json.loads(state_path.read_bytes())
                if pending['pending']['phase'] == 'monitoring' and pending['pending']['pid'] == ownership['child']['pid']:
                    break
            except (OSError, ValueError, TypeError, KeyError):
                pass
            if guard.poll() is not None:
                raise AssertionError('guard ended before owned marker/ownership state')
            time.sleep(.05)
        assert ownership['child']['pgid'] == ownership['child']['pid']
        assert ownership['grandchild']['pgid'] == ownership['child']['pid']
        guard.stdout.close()
        os.kill(guard.pid, signal.SIGTERM)
        guard.wait(timeout=min(7, remaining()))
        assert guard.returncode != 0
        final = json.loads(state_path.read_bytes())
        result = json.loads(result_path.read_bytes())
        assert final['status'] == 'failed' and result['status'] == 'failed'
        assert final['steps'][0] == prefix and result['steps'][0]['status'] == 'passed'
        assert final['original_start_size'] == initial['original_start_size']
        assert final['deadline_utc'] == initial['deadline_utc'] == manifest['deadline_utc']
        assert final['campaign_started_at_utc'] == initial['campaign_started_at_utc']
        stopped = result['steps'][1]
        assert stopped['received_signal'] == signal.SIGTERM and stopped['status'] == 'failed'
        assert stopped['cleanup']['remaining_live_members'] == [] and stopped['cleanup']['error'] is None
        assert all(stopped['pre_checks'].values()) and all(stopped['post_checks'].values())
        assert not live(ownership['child']['pid']) and not live(ownership['grandchild']['pid'])
        failed_state_hash = sha(state_path)
        for index in (2, 0):
            refusal = subprocess.run([sys.executable, str(runner), str(manifest_path), str(index)],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=remaining())
            assert refusal.returncode != 0 and sha(state_path) == failed_state_hash
        assert not never.exists() and all(sha(p) == h for p, h in expected.items())
        observations = {'successful_prefix_preserved': True, 'baseline_deadline_start_preserved': True,
                        'closed_stdout_durable_failed_receipt': True, 'SIGTERM_only_guard_pid': True,
                        'owned_child_and_grandchild_not_live': True, 'failed_resume_reset_refused': True,
                        'input_hashes_exact': True, 'runner_result_sha256': sha(result_path)}
    except BaseException as exc:
        failure = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        if guard is not None and guard.poll() is None:
            fallback_cleanup = True
            guard.terminate()
            try:
                guard.wait(timeout=max(.1, min(5, hard_deadline - time.monotonic())))
            except subprocess.TimeoutExpired:
                guard.kill()
                guard.wait(timeout=.2)
        if ownership is not None:
            pgid = ownership['child']['pgid']
            proven = False
            for expected_owner in ownership.values():
                actual = info(expected_owner['pid'])
                if actual is not None and actual['start_ticks'] == expected_owner['start_ticks'] and actual['pgid'] == pgid and actual['sid'] == pgid:
                    proven = True
            if proven and any(live(value['pid']) for value in ownership.values()):
                fallback_cleanup = True
                os.killpg(pgid, signal.SIGTERM)
                while time.monotonic() < hard_deadline - 1 and any(live(value['pid']) for value in ownership.values()):
                    time.sleep(.05)
                if any(live(value['pid']) for value in ownership.values()):
                    os.killpg(pgid, signal.SIGKILL)
        result = {'schema': 'v1-6-r4-python-only-signal-check', 'runner_sha256': sha(runner),
                  'elapsed_seconds': time.monotonic() - started, 'budget_seconds': 30,
                  'failure': failure, 'fallback_cleanup_needed': fallback_cleanup,
                  'observations': observations, 'native_Go_or_application_executions': 0,
                  'no_foreign_process_signalled': True, 'SIGKILL_hostloss_guarantee': False}
        result['passed'] = failure is None and not fallback_cleanup and result['elapsed_seconds'] <= 30
        (directory / 'check-result.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    return 0 if result['passed'] else 1


def finalization_check():
    # A separately bounded Python-only fixture. The wrapper injects SIGINT only
    # at log hashing and returns the original digest; application data is absent.
    import importlib.util
    start = time.monotonic()
    deadline = start + 30
    directory = Path(sys.argv[1]).resolve()
    if not directory.is_relative_to(S / 'probe') or directory == S / 'probe':
        raise ValueError('owned probe directory required')
    directory.mkdir(mode=0o700)
    runner = S / 'probe/run_worktree_lane_wsl_r9.py'
    spec = importlib.util.spec_from_file_location('r4r2_guard_fixture', runner)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Controlled boundary values exercise the exact predicate used by the real
    # supervisor, without allocating1GiB or altering real resource thresholds.
    allowance = module.PUBLICATION_ALLOWANCE
    cap = module.GIB
    assert module.publication_guard(cap-allowance, 16*cap+allowance, 16*cap, 1024, False) is None
    assert module.publication_guard(cap-allowance+1, 16*cap+allowance, 16*cap, 1024, False)
    assert module.publication_guard(0, 16*cap+allowance-1, 16*cap, 1024, False)
    assert module.publication_guard(0, 17*cap, 16*cap, module.MAX_PUBLICATION_ENCODING+1, False)
    lane = 'r4-r2-finalize-' + hashlib.sha256(str(directory).encode()).hexdigest()[:16]
    manifest_path = directory / 'admission.json'
    marker = directory / 'late-signal.json'
    wrapper = directory / 'inject_late_signal.py'
    wrapper.write_text("""import importlib.util,json,os,pathlib,signal,sys
sys.dont_write_bytecode=True
runner=pathlib.Path(sys.argv[1]); admission=sys.argv[2]; marker=pathlib.Path(sys.argv[3])
spec=importlib.util.spec_from_file_location('owned_guard',runner)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
real=m.digest;fired=False
def observed(path):
 global fired
 if pathlib.Path(path).suffix=='.log' and not fired:
  fired=True
  marker.write_text(json.dumps({'phase':'log-hashing','signal':int(signal.SIGINT),'pid':os.getpid()}))
  os.kill(os.getpid(),signal.SIGINT)
 return real(path)
m.digest=observed
signal.signal(signal.SIGTERM,m.on_signal);signal.signal(signal.SIGINT,m.on_signal)
sys.argv=[str(runner),admission,'0']
raise SystemExit(m.main())
""")
    current = datetime.datetime.now(datetime.timezone.utc)
    protected = {str(runner): sha(runner), str(wrapper): sha(wrapper)}
    manifest = {'lane':lane,'runner_sha256':sha(runner),'checked_at_utc':current.isoformat(),
                'deadline_utc':(current+datetime.timedelta(minutes=20)).isoformat(),
                'inputs':protected,'unchanged':protected,'scratch_bindings':{},'expected_after':{},
                'additional_measure_dirs':[str(S/'tools')],'environment':{'PYTHONDONTWRITEBYTECODE':'1'},
                'limits':{'RSS_bytes':2*cap,'incremental_bytes':cap,'start_disk_floor_bytes':17*cap,
                          'remaining_disk_memory_floor_bytes':16*cap,'GOMAXPROCS':2,'build_jobs':2,
                          'metadata_reserve_seconds':180},
                'commands':[{'name':'tiny-child-before-late-signal','argv':[sys.executable,'-c','pass']}]}
    manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    guard = None
    failure = None
    try:
        guard = subprocess.Popen([sys.executable,str(wrapper),str(runner),str(manifest_path),str(marker)],
                                 stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        guard.wait(timeout=max(.1,deadline-time.monotonic()-6))
        assert guard.returncode != 0 and marker.exists()
        state=json.loads((S/'probe'/(lane+'-r4-r2-state.json')).read_bytes())
        result=json.loads((D/(lane+'-result.json')).read_bytes())
        row=result['steps'][0]
        assert state['status']==result['status']=='failed'
        assert row['exit_code']==0 and row['received_signal']==signal.SIGINT
        assert row['guard'] and row['status']=='failed'
        assert all(row['pre_checks'].values()) and all(row['post_checks'].values())
        assert all(sha(p)==h for p,h in protected.items())
        assert row['publication_accounting']['atomic_temporaries_and_final_outputs_included']
        assert row['publication_accounting']['reserved_publication_bytes_inside_limits']==allowance
    except BaseException as exc:
        failure={'type':type(exc).__name__,'message':str(exc)}
    finally:
        if guard is not None and guard.poll() is None:
            guard.terminate()
            try: guard.wait(timeout=max(.1,min(5,deadline-time.monotonic())))
            except subprocess.TimeoutExpired:
                guard.kill();guard.wait(timeout=.2)
        report={'schema':'v1-6-r4-r2-finalization-fixture','failure':failure,
                'elapsed_seconds':time.monotonic()-start,'budget_seconds':30,
                'controlled_predicate_boundary_checks':True,
                'controlled_log_digest_signal_injection':True,
                'manifest_hash_parse':'production source uses one buffer; no fixture manifest substitution',
                'native_application_executions':0,'runner_sha256':sha(runner)}
        report['passed']=failure is None and report['elapsed_seconds']<=30
        (directory/'check-result.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    return 0 if report['passed'] else 1

if __name__ == '__main__':
    mode = sys.argv[2] if len(sys.argv) > 2 else 'active'
    if mode not in ('active', 'finalization'):
        raise ValueError('mode must be active or finalization')
    raise SystemExit(finalization_check() if mode == 'finalization' else main())
