# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: conexiuni-action-recovery.spec.mjs >> a confirmed duplicate remains blocked after failed verification and manual read
- Location: e2e/conexiuni-action-recovery.spec.mjs:342:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Aproape: 3 din 4. Schimbă o piesă.', { exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Aproape: 3 din 4. Schimbă o piesă.', { exact: true }) with timeout 10000ms
  - waiting for getByText('Aproape: 3 din 4. Schimbă o piesă.', { exact: true })

```

```yaml
- button "Ieși la lista de jocuri": Ieși
- strong: Conexiuni
- group "Starea jocului": DIFICULTATE Ușor GREȘELI 3 rămase
- group: Reguli și ajutor
- status:
  - text: ACUM
  - strong: Schimbă o piesă
  - text: Aceeași combinație a fost deja verificată.
- text: 4/4
- img "3 greșeli disponibile"
- button "Schimbă o piesă" [disabled]
- status: "Aproape: 3 din 4. Schimbă o piesă."
- button "Sârma de rufe"
- button "Cauciucurile de iarnă"
- button "Revelionul la televizor"
- button "Sărbători în familie"
- button "Masa în familie"
- button "Vitrina cu bibelouri"
- button "Borcanele de zacuscă"
- button "Rude"
- button "Asociația de proprietari"
- button "Covor"
- button "Interfonul" [pressed]
- button "lift" [pressed]
- button "Întreținerea" [pressed]
- button "Mileurile croșetate"
- button "Carpeta de pe perete" [pressed]
- button "Bicicleta Pegas"
- button "Indiciu · încă 1 greșeală" [disabled]
- button "Amestecă"
- button "Golește"
- text: Enter = verifică · Esc = golește
- status
```

# Test source

```ts
  245 |     const newer = await newerRound(request);
  246 |     await loseCommittedResponse(page, initial.game_id, "guess");
  247 |     const held = await holdRecovery(page, initial.game_id, missing);
  248 |     expect((await guess(page, initial.game_id, steps()[3])).status()).toBe(503);
  249 |     await held.requested;
  250 |     const other = await saveFromOtherTab(context, newer.game_id);
  251 |     held.release();
  252 |     await expect(currentGame(page)).toBeEnabled();
  253 |     await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toHaveCount(0);
  254 |     expect(await remembered(page)).toBe(newer.game_id);
  255 |     expect(await played(page)).toBe(0);
  256 |     const loaded = responseFor(page, newer.game_id, "", "GET");
  257 |     await currentGame(page).click();
  258 |     expect((await loaded).status()).toBe(200);
  259 |     await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  260 |     expect(await remembered(page)).toBe(newer.game_id);
  261 |     expect(await played(page)).toBe(0);
  262 |     await other.close();
  263 |   });
  264 | }
  265 | 
  266 | test("leaving during recovery preserves its pointer and stale completion cannot change a new screen", async ({ page, context, request }) => {
  267 |   const initial = await prepare(page, request, { solved: 3 });
  268 |   await loseCommittedResponse(page, initial.game_id, "guess");
  269 |   const held = await holdRecovery(page, initial.game_id);
  270 |   expect((await guess(page, initial.game_id, steps()[3])).status()).toBe(503);
  271 |   await held.requested;
  272 |   await page.getByRole("button", { name: "Ieși la lista de jocuri", exact: true }).click();
  273 |   await expect(page.getByRole("button", { name: /^Joacă Conexiuni —/ })).toBeVisible();
  274 |   expect(await remembered(page)).toBe(initial.game_id);
  275 |   const newer = await newerRound(request);
  276 |   const other = await saveFromOtherTab(context, newer.game_id);
  277 |   const loaded = responseFor(page, newer.game_id, "", "GET");
  278 |   await page.getByRole("button", { name: /^Joacă Conexiuni —/ }).click();
  279 |   expect((await loaded).status()).toBe(200);
  280 |   const oldCompleted = responseFor(page, initial.game_id, "", "GET");
  281 |   held.release();
  282 |   await oldCompleted;
  283 |   await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  284 |   await expect(page.getByRole("button", { name: "Copiază rezultatul" })).toHaveCount(0);
  285 |   expect(await remembered(page)).toBe(newer.game_id);
  286 |   expect(await played(page)).toBe(0);
  287 |   await other.close();
  288 | });
  289 | 
  290 | test("an already different saved pointer pauses before any old-round mutation", async ({ page, context, request }) => {
  291 |   const initial = await prepare(page, request);
  292 |   const newer = await newerRound(request);
  293 |   const other = await saveFromOtherTab(context, newer.game_id);
  294 |   const counts = traffic(page, initial.game_id);
  295 |   await choose(page, steps()[0]);
  296 |   await page.getByRole("button", { name: "Verifică", exact: true }).click();
  297 |   await expect(currentGame(page)).toBeEnabled();
  298 |   expect(counts).toEqual({ reads: 0, mutations: 0 });
  299 |   expect(await (await request.get(gameURL(game, initial.game_id))).json()).toEqual(initial);
  300 |   expect(await remembered(page)).toBe(newer.game_id);
  301 |   await currentGame(page).click();
  302 |   await expect(page.locator(`${game.board} button`)).toHaveCount(16);
  303 |   expect(await played(page)).toBe(0);
  304 |   await other.close();
  305 | });
  306 | 
  307 | test("a verified missing owned session returns to setup and conditionally clears its pointer", async ({ page, request }) => {
  308 |   const initial = await prepare(page, request);
  309 |   const counts = traffic(page, initial.game_id);
  310 |   for (const suffix of ["/guess", ""]) {
  311 |     await page.route(`**${gameURL(game, initial.game_id)}${suffix}`, (route) => route.fulfill({
  312 |       status: 404, contentType: "application/json", body: "{}",
  313 |     }), { times: 1 });
  314 |   }
  315 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(404);
  316 |   await expect(page.getByRole("button", { name: /^Joacă(?: →)?$/ })).toBeEnabled();
  317 |   expect(await remembered(page)).toBeNull();
  318 |   expect(await played(page)).toBe(0);
  319 |   expect(counts).toEqual({ reads: 1, mutations: 1 });
  320 | });
  321 | 
  322 | test("lost one-away feedback stays neutral and confirmed duplicate feedback still requires a change", async ({ page, request }) => {
  323 |   const initial = await prepare(page, request);
  324 |   const counts = traffic(page, initial.game_id);
  325 |   const committed = await loseCommittedResponse(page, initial.game_id, "guess");
  326 |   expect((await guess(page, initial.game_id, solution(game).practice)).status()).toBe(503);
  327 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Joc sincronizat. Poți continua." })).toBeVisible();
  328 |   expect(committed().one_away).toBe(true);
  329 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toHaveCount(0);
  330 |   const duplicate = responseFor(page, initial.game_id, "guess");
  331 |   await page.getByRole("button", { name: "Verifică", exact: true }).click();
  332 |   expect((await duplicate).status()).toBe(409);
  333 |   await expect(page.getByRole("button", { name: "Schimbă o piesă", exact: true })).toBeDisabled();
  334 |   await expect(page.locator(`${game.board} [aria-pressed=true]`)).toHaveCount(4);
  335 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toHaveCount(0);
  336 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).mistakes).toBe(1);
  337 |   expect(counts).toEqual({ reads: 2, mutations: 2 });
  338 |   expect((await guess(page, initial.game_id, steps()[0])).status()).toBe(200);
  339 |   await expect(page.locator(`${game.board} button`)).toHaveCount(12);
  340 | });
  341 | 
  342 | test("a confirmed duplicate remains blocked after failed verification and manual read", async ({ page, request }) => {
  343 |   const initial = await prepare(page, request);
  344 |   expect((await guess(page, initial.game_id, solution(game).practice)).status()).toBe(200);
> 345 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toBeVisible();
      |                                                                                       ^ Error: expect(locator).toBeVisible() failed
  346 |   const counts = traffic(page, initial.game_id);
  347 |   await page.route(`**${gameURL(game, initial.game_id)}`, (route) => route.fulfill({
  348 |     status: 503, contentType: "application/json", body: "{}",
  349 |   }), { times: 1 });
  350 |   expect((await guess(page, initial.game_id, solution(game).practice)).status()).toBe(409);
  351 |   await expect(verify(page)).toBeEnabled();
  352 |   await verify(page).click();
  353 |   await expect(verify(page)).toHaveCount(0);
  354 |   await expect(page.getByRole("button", { name: "Schimbă o piesă", exact: true })).toBeDisabled();
  355 |   await expect(page.locator(`${game.board} [aria-pressed=true]`)).toHaveCount(4);
  356 |   await expect(page.locator(".connections-feedback [role=status]").filter({ hasText: "Aproape: 3 din 4. Schimbă o piesă." })).toHaveCount(0);
  357 |   expect((await (await request.get(gameURL(game, initial.game_id))).json()).mistakes).toBe(1);
  358 |   expect(counts).toEqual({ reads: 2, mutations: 1 });
  359 | });
  360 | 
```