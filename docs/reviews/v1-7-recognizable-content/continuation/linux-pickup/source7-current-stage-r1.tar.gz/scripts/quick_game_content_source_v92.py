"""V92 authored additions for Intrusul and Perechi.

This is editorial source, not a served fixture. The root build rail emits a bound
candidate file and requires two complete independent reviews before any package
catalog write. Original V38 boards and shared KG records remain unedited.

Perechi mixes practical associations and familiar Romanian culture in the broad
``viata_de_roman`` shelf. No pair is reused across these twenty authored boards.
"""

from __future__ import annotations

from copy import deepcopy

BOARDS = (
    {
        "id": "iq92_rail",
        "game": "intrusul",
        "source_id": "aq92_intrusul_rail",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_transport_rail_tren",
                "n_v24_transport_rail_tramvai",
                "n_v24_transport_rail_metrou",
            ],
            "intruder": "n_v24_transport_personal_bicicleta",
            "group_label": "Mijloace de transport care circulă pe șine",
        },
        "sources": [
            "https://dexonline.ro/definitie/tren",
            "https://dexonline.ro/definitie/tramvai",
            "https://dexonline.ro/definitie/metrou",
            "https://dexonline.ro/definitie/biciclet%C4%83",
        ],
        "rationale": "Predicat explicit: Mijloace de transport care circulă pe șine. "
        "Trio: Tren, Tramvai, Metrou. Bicicletă nu satisface "
        "predicatul. Vocabular familiar, fără informații de "
        "actualitate.",
    },
    {
        "id": "iq92_precipitation",
        "game": "intrusul",
        "source_id": "aq92_intrusul_precipitation",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_weather_precipitation_ploaie",
                "n_v24_weather_precipitation_zapada",
                "n_v24_weather_precipitation_grindina",
            ],
            "intruder": "n_v33_forest_animal_lup",
            "group_label": "Forme de precipitații",
        },
        "sources": [
            "https://dexonline.ro/definitie/ploaie",
            "https://dexonline.ro/definitie/z%C4%83pad%C4%83",
            "https://dexonline.ro/definitie/grindin%C4%83",
            "https://dexonline.ro/definitie/lup",
        ],
        "rationale": "Predicat explicit: Forme de precipitații. Trio: Ploaie, "
        "Zăpadă, Grindină. Lup nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_face",
        "game": "intrusul",
        "source_id": "aq92_intrusul_face",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v32_body_face_obraz",
                "n_v32_body_face_pleoapa",
                "n_v32_body_face_spranceana",
            ],
            "intruder": "n_v31_body_lower_genunchi",
            "group_label": "Părți ale feței",
        },
        "sources": [
            "https://dexonline.ro/definitie/obraz",
            "https://dexonline.ro/definitie/pleoap%C4%83",
            "https://dexonline.ro/definitie/spr%C3%A2ncean%C4%83",
            "https://dexonline.ro/definitie/genunchi",
        ],
        "rationale": "Predicat explicit: Părți ale feței. Trio: Obraz, Pleoapă, "
        "Sprânceană. Genunchi nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_leg",
        "game": "intrusul",
        "source_id": "aq92_intrusul_leg",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v31_body_lower_coapsa",
                "n_v31_body_lower_gamba",
                "n_v31_body_lower_glezna",
            ],
            "intruder": "n_v24_body_face_nas",
            "group_label": "Părți ale membrului inferior",
        },
        "sources": [
            "https://dexonline.ro/definitie/coaps%C4%83",
            "https://dexonline.ro/definitie/gamb%C4%83",
            "https://dexonline.ro/definitie/glezn%C4%83",
            "https://dexonline.ro/definitie/nas",
        ],
        "rationale": "Predicat explicit: Părți ale membrului inferior. Trio: Coapsă, "
        "Gambă, Gleznă. Nas nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_plant",
        "game": "intrusul",
        "source_id": "aq92_intrusul_plant",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_nature_plant_parts_radacina",
                "n_v24_nature_plant_parts_ramura",
                "n_v4sti_frunza",
            ],
            "intruder": "n_v28_nature_material_piatra",
            "group_label": "Părți ale unei plante",
        },
        "sources": [
            "https://dexonline.ro/definitie/r%C4%83d%C4%83cin%C4%83",
            "https://dexonline.ro/definitie/ramur%C4%83",
            "https://dexonline.ro/definitie/frunz%C4%83",
            "https://dexonline.ro/definitie/piatr%C4%83",
        ],
        "rationale": "Predicat explicit: Părți ale unei plante. Trio: Rădăcină, "
        "Ramură, frunză. Piatră nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_seating",
        "game": "intrusul",
        "source_id": "aq92_intrusul_seating",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_home_seating_canapea",
                "n_v24_home_seating_fotoliu",
                "n_v88_home_taburet",
            ],
            "intruder": "n_v33_bathroom_fixture_robinet",
            "group_label": "Mobilier pe care te așezi",
        },
        "sources": [
            "https://dexonline.ro/definitie/canapea",
            "https://dexonline.ro/definitie/fotoliu",
            "https://dexonline.ro/definitie/taburet",
            "https://dexonline.ro/definitie/robinet",
        ],
        "rationale": "Predicat explicit: Mobilier pe care te așezi. Trio: Canapea, "
        "Fotoliu, Taburet. Robinet nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_workshop",
        "game": "intrusul",
        "source_id": "aq92_intrusul_workshop",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v32_workshop_hand_ciocan",
                "n_v32_workshop_hand_cleste",
                "n_v32_workshop_cut_fierastrau",
            ],
            "intruder": "n_v31_hygiene_oral_periuta_dinti",
            "group_label": "Unelte manuale de atelier",
        },
        "sources": [
            "https://dexonline.ro/definitie/ciocan",
            "https://dexonline.ro/definitie/cle%C8%99te",
            "https://dexonline.ro/definitie/fier%C4%83str%C4%83u",
            "https://dexonline.ro/definitie/periu%C8%9B%C4%83",
        ],
        "rationale": "Predicat explicit: Unelte manuale de atelier. Trio: Ciocan, "
        "Clește, Fierăstrău. Periuță de dinți nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_cheese",
        "game": "intrusul",
        "source_id": "aq92_intrusul_cheese",
        "category": "gastronomie",
        "difficulty": "usor",
        "payload": {
            "members": ["n_gas_telemea", "n_gas_urda", "n_v42gas_branza_burduf"],
            "intruder": "n_v24_food_summer_fruit_caisa",
            "group_label": "Sortimente de brânză",
        },
        "sources": [
            "https://dexonline.ro/definitie/telemea",
            "https://dexonline.ro/definitie/urd%C4%83",
            "https://dexonline.ro/definitie/br%C3%A2nz%C4%83",
            "https://dexonline.ro/definitie/cais%C4%83",
        ],
        "rationale": "Predicat explicit: Sortimente de brânză. Trio: Telemea, Urdă, "
        "Brânză de burduf. Caisă nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_pastries",
        "game": "intrusul",
        "source_id": "aq92_intrusul_pastries",
        "category": "gastronomie",
        "difficulty": "usor",
        "payload": {
            "members": ["n_v18gas_amandina", "n_v21gas_ecler", "n_v21gas_savarina"],
            "intruder": "n_gas_mustar",
            "group_label": "Prăjituri din cofetărie",
        },
        "sources": [
            "https://dexonline.ro/definitie/amandin%C4%83",
            "https://dexonline.ro/definitie/ecler",
            "https://dexonline.ro/definitie/savarin%C4%83",
            "https://dexonline.ro/definitie/mu%C8%99tar",
        ],
        "rationale": "Predicat explicit: Prăjituri din cofetărie. Trio: Amandină, "
        "Ecler, Savarină. Muștar nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_geometry",
        "game": "intrusul",
        "source_id": "aq92_intrusul_geometry",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": ["n_v88_school_compas", "n_v88_school_echer", "n_v88_school_raportor"],
            "intruder": "n_v31_cleaning_floor_mop",
            "group_label": "Instrumente din trusa de geometrie",
        },
        "sources": [
            "https://dexonline.ro/definitie/compas",
            "https://dexonline.ro/definitie/echer",
            "https://dexonline.ro/definitie/raportor",
            "https://dexonline.ro/definitie/mop",
        ],
        "rationale": "Predicat explicit: Instrumente din trusa de geometrie. Trio: "
        "Compas, Echer, Raportor. Mop nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_bathroom",
        "game": "intrusul",
        "source_id": "aq92_intrusul_bathroom",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v33_bathroom_fixture_chiuveta",
                "n_v33_bathroom_fixture_cada_baie",
                "n_v33_bathroom_fixture_robinet",
            ],
            "intruder": "n_v24_time_day_ceas",
            "group_label": "Obiecte sanitare racordate la apă",
        },
        "sources": [
            "https://dexonline.ro/definitie/chiuvet%C4%83",
            "https://dexonline.ro/definitie/cad%C4%83",
            "https://dexonline.ro/definitie/robinet",
            "https://dexonline.ro/definitie/ceas",
        ],
        "rationale": "Predicat explicit: Obiecte sanitare racordate la apă. Trio: "
        "Chiuvetă, Cadă de baie, Robinet. Ceas nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_floor_cleaning",
        "game": "intrusul",
        "source_id": "aq92_intrusul_floor_cleaning",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v31_cleaning_floor_mop",
                "n_v88_cleaning_matura",
                "n_v31_cleaning_floor_aspirator",
            ],
            "intruder": "n_v24_school_supplies_stilou",
            "group_label": "Obiecte folosite la curățarea podelei",
        },
        "sources": [
            "https://dexonline.ro/definitie/mop",
            "https://dexonline.ro/definitie/m%C4%83tur%C4%83",
            "https://dexonline.ro/definitie/aspirator",
            "https://dexonline.ro/definitie/stilou",
        ],
        "rationale": "Predicat explicit: Obiecte folosite la curățarea podelei. "
        "Trio: Mop, Mătură, Aspirator. Stilou nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_gardening",
        "game": "intrusul",
        "source_id": "aq92_intrusul_gardening",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v32_garden_soil_lopata",
                "n_v32_garden_soil_grebla",
                "n_v32_garden_water_stropitoare",
            ],
            "intruder": "n_v31_hygiene_oral_pasta_dinti",
            "group_label": "Unelte folosite în grădină",
        },
        "sources": [
            "https://dexonline.ro/definitie/lopat%C4%83",
            "https://dexonline.ro/definitie/grebl%C4%83",
            "https://dexonline.ro/definitie/stropitoare",
            "https://dexonline.ro/definitie/past%C4%83",
        ],
        "rationale": "Predicat explicit: Unelte folosite în grădină. Trio: Lopată, "
        "Greblă, Stropitoare. Pastă de dinți nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_forest_animals",
        "game": "intrusul",
        "source_id": "aq92_intrusul_forest_animals",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v33_forest_animal_urs",
                "n_v33_forest_animal_vulpe",
                "n_v33_forest_animal_veverita",
            ],
            "intruder": "n_v30_animal_farm_oaie",
            "group_label": "Animale sălbatice din pădurile României",
        },
        "sources": [
            "https://dexonline.ro/definitie/urs",
            "https://dexonline.ro/definitie/vulpe",
            "https://dexonline.ro/definitie/veveri%C8%9B%C4%83",
            "https://dexonline.ro/definitie/oaie",
        ],
        "rationale": "Predicat explicit: Animale sălbatice din pădurile României. "
        "Trio: Urs, Vulpe, Veveriță. Oaie nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_farm_animals",
        "game": "intrusul",
        "source_id": "aq92_intrusul_farm_animals",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v30_animal_farm_vaca",
                "n_v30_animal_farm_cal",
                "n_v30_animal_farm_capra",
            ],
            "intruder": "n_v33_forest_animal_lup",
            "group_label": "Animale domestice crescute în gospodărie",
        },
        "sources": [
            "https://dexonline.ro/definitie/vac%C4%83",
            "https://dexonline.ro/definitie/cal",
            "https://dexonline.ro/definitie/capr%C4%83",
            "https://dexonline.ro/definitie/lup",
        ],
        "rationale": "Predicat explicit: Animale domestice crescute în gospodărie. "
        "Trio: Vacă, Cal, Capră. Lup nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_orchard",
        "game": "intrusul",
        "source_id": "aq92_intrusul_orchard",
        "category": "gastronomie",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_food_orchard_mar",
                "n_v24_food_orchard_para",
                "n_v24_food_orchard_pruna",
            ],
            "intruder": "n_v24_food_salad_veg_morcov",
            "group_label": "Fructe care cresc în livadă",
        },
        "sources": [
            "https://dexonline.ro/definitie/m%C4%83r",
            "https://dexonline.ro/definitie/par%C4%83",
            "https://dexonline.ro/definitie/prun%C4%83",
            "https://dexonline.ro/definitie/morcov",
        ],
        "rationale": "Predicat explicit: Fructe care cresc în livadă. Trio: Măr, "
        "Pară, Prună. Morcov nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_duration",
        "game": "intrusul",
        "source_id": "aq92_intrusul_duration",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": ["n_v29_time_units_secunda", "n_v29_time_units_minut", "n_v24_time_day_ora"],
            "intruder": "n_v24_school_supplies_rigla",
            "group_label": "Unități pentru măsurarea duratei",
        },
        "sources": [
            "https://dexonline.ro/definitie/secund%C4%83",
            "https://dexonline.ro/definitie/minut",
            "https://dexonline.ro/definitie/or%C4%83",
            "https://dexonline.ro/definitie/rigl%C4%83",
        ],
        "rationale": "Predicat explicit: Unități pentru măsurarea duratei. Trio: "
        "Secundă, Minut, Oră. Riglă nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_storage",
        "game": "intrusul",
        "source_id": "aq92_intrusul_storage",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_home_storage_dulap",
                "n_v24_home_storage_raft",
                "n_v24_home_storage_comoda_sertare",
            ],
            "intruder": "n_v31_hygiene_hair_sampon",
            "group_label": "Obiecte pentru depozitarea lucrurilor",
        },
        "sources": [
            "https://dexonline.ro/definitie/dulap",
            "https://dexonline.ro/definitie/raft",
            "https://dexonline.ro/definitie/comod%C4%83",
            "https://dexonline.ro/definitie/%C8%99ampon",
        ],
        "rationale": "Predicat explicit: Obiecte pentru depozitarea lucrurilor. "
        "Trio: Dulap, Raft, Comodă cu sertare. Șampon nu satisface "
        "predicatul. Vocabular familiar, fără informații de "
        "actualitate.",
    },
    {
        "id": "iq92_cereals",
        "game": "intrusul",
        "source_id": "aq92_intrusul_cereals",
        "category": "gastronomie",
        "difficulty": "usor",
        "payload": {
            "members": ["n_v84_food_grau", "n_v84_food_orz", "n_v84_food_ovaz"],
            "intruder": "n_v85_food_vanilie",
            "group_label": "Cereale",
        },
        "sources": [
            "https://dexonline.ro/definitie/gr%C3%A2u",
            "https://dexonline.ro/definitie/orz",
            "https://dexonline.ro/definitie/ov%C4%83z",
            "https://dexonline.ro/definitie/vanilie",
        ],
        "rationale": "Predicat explicit: Cereale. Trio: Grâu, Orz, Ovăz. Vanilie nu "
        "satisface predicatul. Vocabular familiar, fără informații de "
        "actualitate.",
    },
    {
        "id": "iq92_nuts",
        "game": "intrusul",
        "source_id": "aq92_intrusul_nuts",
        "category": "gastronomie",
        "difficulty": "usor",
        "payload": {
            "members": ["n_v81_food_pantry_nuca", "n_v85_food_alune_padure", "n_v85_food_migdale"],
            "intruder": "n_v85_food_cacao",
            "group_label": "Miezuri comestibile în coajă tare",
        },
        "sources": [
            "https://dexonline.ro/definitie/nuc%C4%83",
            "https://dexonline.ro/definitie/alun%C4%83",
            "https://dexonline.ro/definitie/migdale",
            "https://dexonline.ro/definitie/cacao",
        ],
        "rationale": "Predicat explicit: Miezuri comestibile în coajă tare. Trio: "
        "Nucă, Alune de pădure, Migdale. Cacao nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_clothing",
        "game": "intrusul",
        "source_id": "aq92_intrusul_clothing",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v30_clothing_everyday_pantaloni",
                "n_v30_clothing_everyday_rochie",
                "n_v30_clothing_everyday_fusta",
            ],
            "intruder": "n_v31_hygiene_hair_pieptene",
            "group_label": "Articole de îmbrăcăminte",
        },
        "sources": [
            "https://dexonline.ro/definitie/pantaloni",
            "https://dexonline.ro/definitie/rochie",
            "https://dexonline.ro/definitie/fust%C4%83",
            "https://dexonline.ro/definitie/pieptene",
        ],
        "rationale": "Predicat explicit: Articole de îmbrăcăminte. Trio: Pantaloni, "
        "Rochie, Fustă. Pieptene nu satisface predicatul. Vocabular "
        "familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_textiles",
        "game": "intrusul",
        "source_id": "aq92_intrusul_textiles",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_home_textiles_patura",
                "n_v24_home_textiles_cearsaf",
                "n_v24_home_textiles_covor",
            ],
            "intruder": "n_v32_workshop_hand_ciocan",
            "group_label": "Textile pentru casă",
        },
        "sources": [
            "https://dexonline.ro/definitie/p%C4%83tur%C4%83",
            "https://dexonline.ro/definitie/cear%C8%99af",
            "https://dexonline.ro/definitie/covor",
            "https://dexonline.ro/definitie/ciocan",
        ],
        "rationale": "Predicat explicit: Textile pentru casă. Trio: Pătură, Cearșaf, "
        "Covor. Ciocan nu satisface predicatul. Vocabular familiar, "
        "fără informații de actualitate.",
    },
    {
        "id": "iq92_building",
        "game": "intrusul",
        "source_id": "aq92_intrusul_building",
        "category": "viata_de_roman",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_home_structure_acoperis",
                "n_v24_home_structure_perete",
                "n_v24_home_structure_tavan",
            ],
            "intruder": "n_v24_transport_personal_motocicleta",
            "group_label": "Părți ale construcției unei case",
        },
        "sources": [
            "https://dexonline.ro/definitie/acoperi%C8%99",
            "https://dexonline.ro/definitie/perete",
            "https://dexonline.ro/definitie/tavan",
            "https://dexonline.ro/definitie/motociclet%C4%83",
        ],
        "rationale": "Predicat explicit: Părți ale construcției unei case. Trio: "
        "Acoperiș, Perete, Tavan. Motocicletă nu satisface predicatul. "
        "Vocabular familiar, fără informații de actualitate.",
    },
    {
        "id": "iq92_emotions",
        "game": "intrusul",
        "source_id": "aq92_intrusul_emotions",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": [
                "n_v24_feeling_difficult_tristete",
                "n_v24_feeling_difficult_frica",
                "n_v24_feeling_difficult_furie",
            ],
            "intruder": "n_v24_feeling_needs_foame",
            "group_label": "Emoții",
        },
        "sources": [
            "https://dexonline.ro/definitie/triste%C8%9Be",
            "https://dexonline.ro/definitie/fric%C4%83",
            "https://dexonline.ro/definitie/furie",
            "https://dexonline.ro/definitie/foame",
        ],
        "rationale": "Predicat explicit: Emoții. Trio: Tristețe, Frică, Furie. Foame "
        "nu satisface predicatul. Vocabular familiar, fără informații "
        "de actualitate.",
    },
    {
        "id": "iq92_sky",
        "game": "intrusul",
        "source_id": "aq92_intrusul_sky",
        "category": "stiinta",
        "difficulty": "usor",
        "payload": {
            "members": ["n_v24_nature_sky_soare", "n_v24_nature_sky_luna", "n_v24_nature_sky_stea"],
            "intruder": "n_v24_food_salad_veg_morcov",
            "group_label": "Corpuri cerești",
        },
        "sources": [
            "https://dexonline.ro/definitie/soare",
            "https://dexonline.ro/definitie/lun%C4%83",
            "https://dexonline.ro/definitie/stea",
            "https://dexonline.ro/definitie/morcov",
        ],
        "rationale": "Predicat explicit: Corpuri cerești. Trio: Soare, Lună, Stea. "
        "Morcov nu satisface predicatul. Vocabular familiar, fără "
        "informații de actualitate.",
    },
    {
        "id": "pq92_associations_01",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_01",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v86_food_frisca", "n_v88_food_smantana_dulce"],
                    "group_label": "Spuma și ingredientul din care o bați",
                },
                {
                    "members": ["n_v31_hygiene_bath_sapun", "n_v31_hygiene_bath_prosop"],
                    "group_label": "Te speli, apoi te usuci",
                },
                {
                    "members": ["n_v24_home_bed_pat", "n_v24_home_bed_saltea"],
                    "group_label": "Mobilier pentru dormit și suportul pe care te întinzi",
                },
                {
                    "members": ["n_v84_food_drojdie", "n_v4gas_paine"],
                    "group_label": "Agent de dospire și produs de panificație",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/fri%C8%99c%C4%83",
            "https://dexonline.ro/definitie/s%C4%83pun",
            "https://dexonline.ro/definitie/prosop",
            "https://dexonline.ro/definitie/pat",
            "https://dexonline.ro/definitie/saltea",
            "https://dexonline.ro/definitie/drojdie",
            "https://dexonline.ro/definitie/p%C3%A2ine",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Frișcă ↔ Smântână dulce pentru frișcă; Săpun "
        "↔ Prosop; Pat ↔ Saltea; Drojdie ↔ Pâine. Fiecare pereche "
        "păstrează o explicație proprie; nicio pereche intenționată nu "
        "este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_02",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_02",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v17fil_garcea", "n_ftv_mugur_mihaescu"],
                    "group_label": "Personaj și actorul care îl interpretează",
                },
                {
                    "members": ["n_v24_time_day_ceas", "n_v24_time_day_ora"],
                    "group_label": "Instrument și unitatea pe care o indică",
                },
                {
                    "members": [
                        "n_v32_garden_container_ghiveci_flori",
                        "n_v32_garden_water_stropitoare",
                    ],
                    "group_label": "Vasul plantei și unealta cu care o uzi",
                },
                {
                    "members": ["n_v33_forest_animal_caprioara", "n_v33_forest_animal_cerb"],
                    "group_label": "Animale sălbatice din familia cervidelor",
                },
            ]
        },
        "sources": [
            "https://www.kanald.ro/avere-mugur-mihaescu-ce-venituri-are-actorul-care-i-a-dat-viata-personajului-garcea-20173461",
            "https://dexonline.ro/definitie/ceas",
            "https://dexonline.ro/definitie/or%C4%83",
            "https://dexonline.ro/definitie/ghiveci",
            "https://dexonline.ro/definitie/stropitoare",
            "https://dexonline.ro/definitie/c%C4%83prioar%C4%83",
            "https://dexonline.ro/definitie/cerb",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Garcea ↔ Mugur Mihăescu; Ceas ↔ Oră; Ghiveci "
        "de flori ↔ Stropitoare; Căprioară ↔ Cerb. Fiecare pereche "
        "păstrează o explicație proprie; nicio pereche intenționată nu "
        "este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_03",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_03",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_spt_david_popovici", "n_v2spo_inot_sportiv"],
                    "group_label": "Sportiv și disciplina sa",
                },
                {
                    "members": ["n_v33_electric_light_bec", "n_v33_electric_control_intrerupator"],
                    "group_label": "Sursa de lumină și comanda ei",
                },
                {
                    "members": ["n_v24_transport_rail_tren", "n_v24_transport_terminals_gara"],
                    "group_label": "Mijloc de transport și locul de îmbarcare",
                },
                {
                    "members": ["n_ion_luca_caragiale", "n_o_scrisoare_pierduta"],
                    "group_label": "Dramaturg și comedie",
                },
            ]
        },
        "sources": [
            "https://www.cosr.ro/public/sportive/popovici-david",
            "https://dexonline.ro/definitie/bec",
            "https://dexonline.ro/definitie/%C3%AEntrerup%C4%83tor",
            "https://dexonline.ro/definitie/tren",
            "https://dexonline.ro/definitie/gar%C4%83",
            "https://ro.wikisource.org/wiki/O_scrisoare_pierdut%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: David Popovici ↔ Înot sportiv; Bec ↔ "
        "Întrerupător de lumină; Tren ↔ Gară; I.L. Caragiale ↔ O "
        "scrisoare pierdută. Fiecare pereche păstrează o explicație "
        "proprie; nicio pereche intenționată nu este refolosită în "
        "această extensie.",
    },
    {
        "id": "pq92_associations_04",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_04",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v4gas_sare", "n_v84_food_saramura"],
                    "group_label": "Substanță și soluția ei în apă",
                },
                {
                    "members": [
                        "n_v24_people_grandparents_bunica",
                        "n_v24_people_grandparents_bunic",
                    ],
                    "group_label": "Părinții părinților",
                },
                {
                    "members": ["n_v30_kitchen_utensil_furculita", "n_v30_kitchen_utensil_lingura"],
                    "group_label": "Tacâmuri",
                },
                {
                    "members": ["n_constantin_brancusi", "n_v20art_domnisoara_pogany"],
                    "group_label": "Sculptor și sculptură",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/sare",
            "https://dexonline.ro/definitie/saramur%C4%83",
            "https://dexonline.ro/definitie/bunic%C4%83",
            "https://dexonline.ro/definitie/bunic",
            "https://dexonline.ro/definitie/furculi%C8%9B%C4%83",
            "https://dexonline.ro/definitie/lingur%C4%83",
            "https://cimec.ro/patrimoniu-mobil/portalul-brancusi/",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Sare ↔ Saramură; Bunică ↔ Bunic; Furculiță ↔ "
        "Lingură; Constantin Brâncuși ↔ Domnișoara Pogany. Fiecare "
        "pereche păstrează o explicație proprie; nicio pereche "
        "intenționată nu este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_05",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_05",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_mihai_eminescu", "n_v21lit_floare_albastra"],
                    "group_label": "Poet și poezie",
                },
                {"members": ["n_gas_telemea", "n_gas_urda"], "group_label": "Sortimente de brânză"},
                {
                    "members": ["n_v32_body_face_pleoapa", "n_v32_body_face_spranceana"],
                    "group_label": "Părți ale feței din jurul ochiului",
                },
                {
                    "members": ["n_v24_food_pantry_faina", "n_v84_food_aluat"],
                    "group_label": "Ingredient de bază și amestecul obținut",
                },
            ]
        },
        "sources": [
            "https://ro.wikisource.org/wiki/Floare_albastr%C4%83",
            "https://dexonline.ro/definitie/telemea",
            "https://dexonline.ro/definitie/urd%C4%83",
            "https://dexonline.ro/definitie/pleoap%C4%83",
            "https://dexonline.ro/definitie/spr%C3%A2ncean%C4%83",
            "https://dexonline.ro/definitie/f%C4%83in%C4%83",
            "https://dexonline.ro/definitie/aluat",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Mihai Eminescu ↔ Floare albastră; Telemea ↔ "
        "Urdă; Pleoapă ↔ Sprânceană; Făină ↔ Aluat. Fiecare pereche "
        "păstrează o explicație proprie; nicio pereche intenționată nu "
        "este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_06",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_06",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v24_people_relatives_frate", "n_v24_people_relatives_sora"],
                    "group_label": "Copii care au părinți comuni",
                },
                {
                    "members": [
                        "n_v24_transport_personal_bicicleta",
                        "n_v24_transport_personal_motocicleta",
                    ],
                    "group_label": "Vehicule cu două roți",
                },
                {
                    "members": ["n_v32_workshop_hand_ciocan", "n_v32_workshop_fastener_cui"],
                    "group_label": "Unealta cu care bați elementul de fixare",
                },
                {
                    "members": ["n_v24_weather_air_nor", "n_v24_weather_precipitation_ploaie"],
                    "group_label": "Precipitația cade din nori",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/frate",
            "https://dexonline.ro/definitie/sor%C4%83",
            "https://dexonline.ro/definitie/biciclet%C4%83",
            "https://dexonline.ro/definitie/motociclet%C4%83",
            "https://dexonline.ro/definitie/ciocan",
            "https://dexonline.ro/definitie/cui",
            "https://dexonline.ro/definitie/nor",
            "https://dexonline.ro/definitie/ploaie",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Frate ↔ Soră; Bicicletă ↔ Motocicletă; "
        "Ciocan ↔ Cui; Nor ↔ Ploaie. Fiecare pereche păstrează o "
        "explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_07",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_07",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v31_body_lower_calcai", "n_v31_body_lower_glezna"],
                    "group_label": "Părți învecinate ale piciorului",
                },
                {
                    "members": ["n_v24_home_seating_canapea", "n_v24_home_seating_fotoliu"],
                    "group_label": "Mobilier tapițat pentru șezut",
                },
                {
                    "members": ["n_ftv_bobita", "n_v19fil_mihai_bobonete"],
                    "group_label": "Personaj și actorul care îl interpretează",
                },
                {
                    "members": ["n_v24_food_orchard_mar", "n_v24_food_orchard_para"],
                    "group_label": "Fructe de livadă",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/c%C4%83lc%C3%A2i",
            "https://dexonline.ro/definitie/glezn%C4%83",
            "https://dexonline.ro/definitie/canapea",
            "https://dexonline.ro/definitie/fotoliu",
            "https://femeiaalege.protv.ro/stiri/bobita-din-las-fierbinti-te-face-sa-mori-de-ras-si-in-viata-reala-vezi-un-interviu-exclusiv-cu-mihai-bobonete.html",
            "https://dexonline.ro/definitie/m%C4%83r",
            "https://dexonline.ro/definitie/par%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Călcâi ↔ Gleznă; Canapea ↔ Fotoliu; Bobiță ↔ "
        "Mihai Bobonete; Măr ↔ Pară. Fiecare pereche păstrează o "
        "explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_08",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_08",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v29_time_calendar", "n_v4ist_an"],
                    "group_label": "Instrument de organizare și intervalul pe care îl cuprinde",
                },
                {
                    "members": [
                        "n_v24_people_relationships_sot",
                        "n_v24_people_relationships_sotie",
                    ],
                    "group_label": "Parteneri de căsătorie",
                },
                {
                    "members": ["n_simona_halep", "n_spt_simona_wimbledon_2019"],
                    "group_label": "Sportivă și turneu câștigat",
                },
                {"members": ["n_v84_food_orz", "n_v84_food_ovaz"], "group_label": "Cereale"},
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/calendar",
            "https://dexonline.ro/definitie/an",
            "https://dexonline.ro/definitie/so%C8%9B",
            "https://dexonline.ro/definitie/so%C8%9Bie",
            "https://www.wtatennis.com/news/1446826/i-wanted-this-badly-simona-halep-stuns-serena-williams-for-wimbledon-2019-title",
            "https://dexonline.ro/definitie/orz",
            "https://dexonline.ro/definitie/ov%C4%83z",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Calendar ↔ An; Soț ↔ Soție; Simona Halep ↔ "
        "Wimbledon 2019; Orz ↔ Ovăz. Fiecare pereche păstrează o "
        "explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_09",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_09",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": [
                        "n_v33_bathroom_fixture_chiuveta",
                        "n_v33_bathroom_fixture_robinet",
                    ],
                    "group_label": "Vas sanitar și sursa lui de apă",
                },
                {
                    "members": ["n_v3lit_carte", "n_v24_action_language_a_citi"],
                    "group_label": "Obiectul și acțiunea obișnuită",
                },
                {
                    "members": ["n_v24_weather_storm_fulger", "n_v24_weather_storm_tunet"],
                    "group_label": "Lumina și sunetul descărcării electrice",
                },
                {
                    "members": [
                        "n_v31_hygiene_oral_periuta_dinti",
                        "n_v31_hygiene_oral_pasta_dinti",
                    ],
                    "group_label": "Se folosesc împreună pentru curățarea dinților",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/chiuvet%C4%83",
            "https://dexonline.ro/definitie/robinet",
            "https://dexonline.ro/definitie/carte",
            "https://dexonline.ro/definitie/citi",
            "https://dexonline.ro/definitie/fulger",
            "https://dexonline.ro/definitie/tunet",
            "https://dexonline.ro/definitie/periu%C8%9B%C4%83",
            "https://dexonline.ro/definitie/past%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Chiuvetă ↔ Robinet; Carte ↔ a citi; Fulger ↔ "
        "Tunet; Periuță de dinți ↔ Pastă de dinți. Fiecare pereche "
        "păstrează o explicație proprie; nicio pereche intenționată nu "
        "este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_10",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_10",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": [
                        "n_v24_weather_precipitation_ploaie",
                        "n_v24_weather_precipitation_zapada",
                    ],
                    "group_label": "Forme de precipitații",
                },
                {
                    "members": ["n_v84_food_grau", "n_v84_food_gris"],
                    "group_label": "Cereală și produs obținut prin măcinare",
                },
                {
                    "members": ["n_v30_clothing_everyday_fusta", "n_v30_clothing_everyday_rochie"],
                    "group_label": "Articole de îmbrăcăminte",
                },
                {
                    "members": ["n_v81_food_pantry_nuca", "n_v85_food_migdale"],
                    "group_label": "Miezuri comestibile în coajă tare",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/ploaie",
            "https://dexonline.ro/definitie/z%C4%83pad%C4%83",
            "https://dexonline.ro/definitie/gr%C3%A2u",
            "https://dexonline.ro/definitie/gri%C8%99",
            "https://dexonline.ro/definitie/fust%C4%83",
            "https://dexonline.ro/definitie/rochie",
            "https://dexonline.ro/definitie/nuc%C4%83",
            "https://dexonline.ro/definitie/migdale",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Ploaie ↔ Zăpadă; Grâu ↔ Griș; Fustă ↔ "
        "Rochie; Nucă ↔ Migdale. Fiecare pereche păstrează o explicație "
        "proprie; nicio pereche intenționată nu este refolosită în "
        "această extensie.",
    },
    {
        "id": "pq92_associations_11",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_11",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v24_school_supplies_rigla", "n_v88_school_echer"],
                    "group_label": "Instrumente pentru trasarea liniilor",
                },
                {
                    "members": ["n_v30_clothing_footwear_pantof", "n_v30_clothing_footwear_soseta"],
                    "group_label": "Se poartă împreună în picioare",
                },
                {
                    "members": ["n_v24_home_bed_pat", "n_v24_home_bed_perna"],
                    "group_label": "Mobilier și sprijin pentru cap în timpul somnului",
                },
                {
                    "members": ["n_ion_creanga", "n_v23lit_capra_cu_trei_iezi"],
                    "group_label": "Scriitor și poveste",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/rigl%C4%83",
            "https://dexonline.ro/definitie/echer",
            "https://dexonline.ro/definitie/pantof",
            "https://dexonline.ro/definitie/%C8%99oset%C4%83",
            "https://dexonline.ro/definitie/pat",
            "https://dexonline.ro/definitie/pern%C4%83",
            "https://ro.wikisource.org/wiki/Capra_cu_trei_iezi",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Riglă ↔ Echer; Pantof ↔ Șosetă; Pat ↔ Pernă; "
        "Ion Creangă ↔ Capra cu trei iezi. Fiecare pereche păstrează o "
        "explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_12",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_12",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v24_people_parents_mama", "n_v24_people_parents_tata"],
                    "group_label": "Părinții",
                },
                {
                    "members": ["n_v33_electric_outlet_priza", "n_v33_electric_plug_stecher"],
                    "group_label": "Piese care se conectează pentru alimentare electrică",
                },
                {
                    "members": ["n_ciprian_porumbescu", "n_v20art_balada_porumbescu"],
                    "group_label": "Compozitor și lucrare muzicală",
                },
                {
                    "members": ["n_v29_time_units_minut", "n_v29_time_units_secunda"],
                    "group_label": "Un minut are șaizeci de secunde",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/mam%C4%83",
            "https://dexonline.ro/definitie/tat%C4%83",
            "https://dexonline.ro/definitie/priz%C4%83",
            "https://dexonline.ro/definitie/%C8%99techer",
            "https://muzeulbucovinei.ro/mnb/obiective-culturale/muzeul-memorial-ciprian-porumbescu",
            "https://dexonline.ro/definitie/minut",
            "https://dexonline.ro/definitie/secund%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Mamă ↔ Tată; Priză electrică ↔ Ștecher; "
        "Ciprian Porumbescu ↔ Balada pentru vioară; Minut ↔ Secundă. "
        "Fiecare pereche păstrează o explicație proprie; nicio pereche "
        "intenționată nu este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_13",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_13",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v24_home_storage_dulap", "n_v24_home_storage_raft"],
                    "group_label": "Spații pentru depozitare",
                },
                {
                    "members": ["n_v31_hygiene_hair_pieptene", "n_v31_hygiene_hair_sampon"],
                    "group_label": "Obiecte folosite pentru îngrijirea părului",
                },
                {
                    "members": ["n_v32_garden_water_stropitoare", "n_v4gas_apa"],
                    "group_label": "Unealtă și lichidul pentru udarea plantelor",
                },
                {
                    "members": ["n_v3gas_clatite", "n_v17gas_dulceata"],
                    "group_label": "Desert și umplutură dulce",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/dulap",
            "https://dexonline.ro/definitie/raft",
            "https://dexonline.ro/definitie/pieptene",
            "https://dexonline.ro/definitie/%C8%99ampon",
            "https://dexonline.ro/definitie/stropitoare",
            "https://dexonline.ro/definitie/ap%C4%83",
            "https://dexonline.ro/definitie/cl%C4%83tite",
            "https://dexonline.ro/definitie/dulcea%C8%9B%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Dulap ↔ Raft; Pieptene ↔ Șampon; Stropitoare "
        "↔ Apă; Clătite ↔ Dulceață. Fiecare pereche păstrează o "
        "explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_14",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_14",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v29_kitchen_table_cutit", "n_v4gas_paine"],
                    "group_label": "Unealtă și alimentul pe care îl taie",
                },
                {
                    "members": ["n_ioan_slavici", "n_moara_cu_noroc"],
                    "group_label": "Scriitor și nuvelă",
                },
                {
                    "members": ["n_spt_cristina_neagu", "n_v3spo_handbal"],
                    "group_label": "Sportivă și disciplina sa",
                },
                {
                    "members": ["n_v85_food_cacao", "n_v85_food_ciocolata"],
                    "group_label": "Ingredient de bază și produsul făcut din el",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/cu%C8%9Bit",
            "https://dexonline.ro/definitie/p%C3%A2ine",
            "https://ro.wikisource.org/wiki/Moara_cu_noroc",
            "https://www.ihf.info/media-center/news/unstoppable-8-says-farewell-was-my-calling",
            "https://dexonline.ro/definitie/cacao",
            "https://dexonline.ro/definitie/ciocolat%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Cuțit ↔ Pâine; Ioan Slavici ↔ Moara cu "
        "noroc; Cristina Neagu ↔ Handbal; Cacao ↔ Ciocolată. Fiecare "
        "pereche păstrează o explicație proprie; nicio pereche "
        "intenționată nu este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_15",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_15",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v24_home_appliances_aragaz", "n_v30_kitchen_cookware_tigaie"],
                    "group_label": "Sursa de căldură și vasul pentru prăjit",
                },
                {
                    "members": ["n_gas_sarmale", "n_v2lim_varza"],
                    "group_label": "Preparat și frunzele folosite la învelire",
                },
                {
                    "members": ["n_henri_coanda", "n_efectul_coanda"],
                    "group_label": "Inventator și fenomenul care îi poartă numele",
                },
                {
                    "members": ["n_v31_cleaning_floor_aspirator", "n_v90_household_praf"],
                    "group_label": "Aparatul și murdăria pe care o îndepărtează",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/aragaz",
            "https://dexonline.ro/definitie/tigaie",
            "https://dexonline.ro/definitie/sarmale",
            "https://dexonline.ro/definitie/varz%C4%83",
            "https://acad.ro/acad_membri/membri/Coanda_Henri.html",
            "https://dexonline.ro/definitie/aspirator",
            "https://dexonline.ro/definitie/praf",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Aragaz ↔ Tigaie; Sarmale ↔ Varză; Henri "
        "Coandă ↔ Efectul Coandă; Aspirator ↔ Praf. Fiecare pereche "
        "păstrează o explicație proprie; nicio pereche intenționată nu "
        "este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_16",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_16",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_gas_mamaliga", "n_v84_food_malai"],
                    "group_label": "Preparat și ingredientul său de bază",
                },
                {
                    "members": ["n_v31_body_lower_gamba", "n_v31_body_lower_genunchi"],
                    "group_label": "Părți învecinate ale piciorului",
                },
                {
                    "members": ["n_gas_mujdei", "n_v4gas_usturoi"],
                    "group_label": "Sos și ingredientul care îi dă gustul",
                },
                {
                    "members": ["n_ftv_florin_piersic", "n_v17fil_margelatu"],
                    "group_label": "Actor și personaj",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/m%C4%83m%C4%83lig%C4%83",
            "https://dexonline.ro/definitie/m%C4%83lai",
            "https://dexonline.ro/definitie/gamb%C4%83",
            "https://dexonline.ro/definitie/genunchi",
            "https://dexonline.ro/definitie/mujdei",
            "https://dexonline.ro/definitie/usturoi",
            "https://tvr1.tvr.ro/florin-piersic--90-de-ani-de-poveste-alaturi-de-unul-dintre-cei-mai-iubi--i-actori-din-istoria-teatrului---i-filmului-romanesc_54062.html",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Mămăligă ↔ Mălai; Gambă ↔ Genunchi; Mujdei ↔ "
        "Usturoi; Florin Piersic ↔ Mărgelatu. Fiecare pereche păstrează "
        "o explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_17",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_17",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v4lit_biblioteca", "n_v3lit_carte"],
                    "group_label": "Locul de păstrare și împrumut al cărților",
                },
                {
                    "members": ["n_v30_kitchen_drink_cana", "n_v24_food_snack_ceai"],
                    "group_label": "Băutură și vasul din care o bei",
                },
                {
                    "members": ["n_v32_workshop_hand_surubelnita", "n_v32_workshop_fastener_surub"],
                    "group_label": "Unealta care rotește elementul de fixare",
                },
                {
                    "members": ["n_v84_food_cuptor", "n_v84_food_tava_copt"],
                    "group_label": "Sursa de căldură și vasul folosit la copt",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/bibliotec%C4%83",
            "https://dexonline.ro/definitie/carte",
            "https://dexonline.ro/definitie/can%C4%83",
            "https://dexonline.ro/definitie/ceai",
            "https://dexonline.ro/definitie/%C8%99urubelni%C8%9B%C4%83",
            "https://dexonline.ro/definitie/%C8%99urub",
            "https://dexonline.ro/definitie/cuptor",
            "https://dexonline.ro/definitie/tav%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Bibliotecă ↔ Carte; Cană ↔ Ceai; Șurubelniță "
        "↔ Șurub; Cuptor de bucătărie ↔ Tavă de copt. Fiecare pereche "
        "păstrează o explicație proprie; nicio pereche intenționată nu "
        "este refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_18",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_18",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v24_school_writing_caiet", "n_v24_school_writing_pix"],
                    "group_label": "Suport și instrument pentru scris",
                },
                {
                    "members": ["n_v88_cleaning_matura", "n_v31_cleaning_floor_faras"],
                    "group_label": "Se folosesc împreună la măturat",
                },
                {
                    "members": ["n_george_enescu", "n_rapsodia_romana"],
                    "group_label": "Compozitor și lucrare muzicală",
                },
                {
                    "members": ["n_v18gas_amandina", "n_v21gas_ecler"],
                    "group_label": "Prăjituri de cofetărie",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/caiet",
            "https://dexonline.ro/definitie/pix",
            "https://dexonline.ro/definitie/m%C4%83tur%C4%83",
            "https://dexonline.ro/definitie/f%C4%83ra%C8%99",
            "https://www.georgeenescu.ro/prime-auditii_doc_31_110-ani-de-la-prima-auditie-absoluta-a-celor-doua-rapsodii-romane-de-george-enescu-23-februarie-1903-ateneul-roman-sub-bagheta-compozitorului_pg_0.htm",
            "https://dexonline.ro/definitie/amandin%C4%83",
            "https://dexonline.ro/definitie/ecler",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Caiet ↔ Pix; Mătură ↔ Făraș; George Enescu ↔ "
        "Rapsodia Română; Amandină ↔ Ecler. Fiecare pereche păstrează o "
        "explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_19",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_19",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v24_school_writing_creion", "n_v24_school_supplies_radiera"],
                    "group_label": "Instrument de scris și obiectul care îi șterge urma",
                },
                {
                    "members": ["n_v31_cleaning_floor_mop", "n_v31_cleaning_water_galeata"],
                    "group_label": "Se folosesc împreună la spălarea podelei",
                },
                {
                    "members": ["n_gas_mustar", "n_gas_mici"],
                    "group_label": "Condiment și preparatul lângă care este servit",
                },
                {
                    "members": ["n_v24_home_surfaces_fereastra", "n_v24_home_surfaces_oglinda"],
                    "group_label": "Obiecte casnice care conțin sticlă",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/creion",
            "https://dexonline.ro/definitie/radier%C4%83",
            "https://dexonline.ro/definitie/mop",
            "https://dexonline.ro/definitie/g%C4%83leat%C4%83",
            "https://dexonline.ro/definitie/mu%C8%99tar",
            "https://dexonline.ro/definitie/mici",
            "https://dexonline.ro/definitie/fereastr%C4%83",
            "https://dexonline.ro/definitie/oglind%C4%83",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Creion ↔ Radieră; Mop ↔ Găleată; Muștar ↔ "
        "Mici; Fereastră ↔ Oglindă. Fiecare pereche păstrează o "
        "explicație proprie; nicio pereche intenționată nu este "
        "refolosită în această extensie.",
    },
    {
        "id": "pq92_associations_20",
        "game": "perechi",
        "source_id": "aq92_perechi_associations_20",
        "category": "viata_de_roman",
        "difficulty": "normal",
        "payload": {
            "pairs": [
                {
                    "members": ["n_v29_kitchen_table_pahar", "n_v4gas_apa"],
                    "group_label": "Băutură și vasul din care o bei",
                },
                {
                    "members": ["n_emil_racovita", "n_speologie"],
                    "group_label": "Cercetător și domeniul explorării peșterilor",
                },
                {
                    "members": [
                        "n_v24_nature_plant_parts_radacina",
                        "n_v24_nature_plant_parts_ramura",
                    ],
                    "group_label": "Părți ale unei plante",
                },
                {
                    "members": ["n_nadia_comaneci", "n_spt_nadia_zecele_perfect"],
                    "group_label": "Sportivă și performanță istorică",
                },
            ]
        },
        "sources": [
            "https://dexonline.ro/definitie/pahar",
            "https://dexonline.ro/definitie/ap%C4%83",
            "https://www.iser.ro/ro/index.html",
            "https://dexonline.ro/definitie/r%C4%83d%C4%83cin%C4%83",
            "https://dexonline.ro/definitie/ramur%C4%83",
            "https://www.cosr.ro/news/anul-nadia-2026-lansat-oficial",
        ],
        "rationale": "Patru asocieri independente din vocabularul cotidian și "
        "cultura generală: Pahar ↔ Apă; Emil Racoviță ↔ Speologie; "
        "Rădăcină ↔ Ramură; Nadia Comăneci ↔ Primul 10 perfect. Fiecare "
        "pereche păstrează o explicație proprie; nicio pereche "
        "intenționată nu este refolosită în această extensie.",
    },
)


def candidate_boards() -> list[dict]:
    """Return independent copies for candidate generation and integrity checks."""
    return deepcopy(list(BOARDS))


# Session02: six independently reviewed everyday boards.
BOARDS += ({'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'intrusul',
  'id': 'iq92_session02_school_tools',
  'payload': {'group_label': 'Rechizite folosite la școală',
              'intruder': 'n_v30_kitchen_drink_cana',
              'members': ['n_v24_school_supplies_stilou',
                          'n_v24_school_supplies_radiera',
                          'n_v24_school_supplies_rigla']},
  'rationale': 'Trei rechizite cu funcții diferite împart o categorie exactă; cana este un vas, '
               'chiar dacă poate fi folosită într-o școală. Niciun membru nu depinde de o '
               'descriere ascunsă.',
  'source_id': 'aq92_session02_intrusul_school_tools',
  'sources': ['https://dexonline.ro/definitie/stilou',
              'https://dexonline.ro/definitie/radier%C4%83',
              'https://dexonline.ro/definitie/rigl%C4%83',
              'https://dexonline.ro/definitie/can%C4%83']},
 {'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'intrusul',
  'id': 'iq92_session02_kitchen_vessels',
  'payload': {'group_label': 'Vase folosite în bucătărie',
              'intruder': 'n_v29_kitchen_table_cutit',
              'members': ['n_v30_kitchen_cookware_tigaie',
                          'n_v30_kitchen_cookware_oala',
                          'n_v30_kitchen_table_castron']},
  'rationale': 'Toate cele patru obiecte țin de bucătărie, dar doar cele trei vase pot conține '
               'alimente. Cuțitul este o unealtă de tăiere, ceea ce oferă un intrus tematic și '
               'corect.',
  'source_id': 'aq92_session02_intrusul_kitchen_vessels',
  'sources': ['https://dexonline.ro/definitie/tigaie',
              'https://dexonline.ro/definitie/oal%C4%83',
              'https://dexonline.ro/definitie/castron',
              'https://dexonline.ro/definitie/cu%C8%9Bit']},
 {'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'intrusul',
  'id': 'iq92_session02_road_vehicles',
  'payload': {'group_label': 'Autovehicule care circulă pe șosea',
              'intruder': 'n_v24_transport_rail_tren',
              'members': ['n_v24_transport_road_camion',
                          'n_v24_transport_road_microbuz',
                          'n_v24_transport_road_duba']},
  'rationale': 'Toate sunt mijloace de transport motorizate. Distincția exactă este șosea față '
               'de șine; numărul de pasageri sau transportul de marfă nu determină soluția.',
  'source_id': 'aq92_session02_intrusul_road_vehicles',
  'sources': ['https://dexonline.ro/definitie/camion',
              'https://dexonline.ro/definitie/microbuz',
              'https://dexonline.ro/definitie/dub%C4%83',
              'https://dexonline.ro/definitie/tren']},
 {'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'perechi',
  'id': 'pq92_session02_everyday_01',
  'payload': {'pairs': [{'group_label': 'Pasăre domestică și produsul ei',
                         'members': ['n_v29_animal_farm_gaina', 'n_v4gas_ou']},
                        {'group_label': 'Corp de iluminat și sursa sa de lumină',
                         'members': ['n_v24_home_appliances_lampa', 'n_v33_electric_light_bec']},
                        {'group_label': 'Preparat lichid și tacâmul potrivit',
                         'members': ['n_v4gas_supa', 'n_v30_kitchen_utensil_lingura']},
                        {'group_label': 'Infrastructură de transport și vehiculul deservit',
                         'members': ['n_v24_transport_terminals_aeroport', 'n_v2sti_avion']}]},
  'rationale': 'Patru relații distincte din viața de zi cu zi: Găină — Ou (pasăre domestică și '
               'produsul ei); Lampă — Bec (corp de iluminat și sursa sa de lumină); Supă — '
               'Lingură (preparat lichid și tacâmul potrivit); Aeroport — Avion (infrastructură '
               'de transport și vehiculul deservit). Fiecare pereche este nouă în Perechi; nu '
               'există muchii concurente puternice pe tablă.',
  'source_id': 'aq92_session02_perechi_everyday_01',
  'sources': ['https://dexonline.ro/definitie/g%C4%83in%C4%83',
              'https://dexonline.ro/definitie/ou',
              'https://dexonline.ro/definitie/lamp%C4%83',
              'https://dexonline.ro/definitie/bec',
              'https://dexonline.ro/definitie/sup%C4%83',
              'https://dexonline.ro/definitie/lingur%C4%83',
              'https://dexonline.ro/definitie/aeroport',
              'https://dexonline.ro/definitie/avion']},
 {'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'perechi',
  'id': 'pq92_session02_everyday_02',
  'payload': {'pairs': [{'group_label': 'Parte a corpului și obiect pentru curățarea ei',
                         'members': ['n_v28_body_mouth_dinte',
                                     'n_v31_hygiene_oral_periuta_dinti']},
                        {'group_label': 'Unealtă de curățat și suprafața curățată',
                         'members': ['n_v31_cleaning_floor_mop', 'n_v24_home_surfaces_podea']},
                        {'group_label': 'Plantă lemnoasă și partea ei subterană',
                         'members': ['n_v4sti_copac', 'n_v24_nature_plant_parts_radacina']},
                        {'group_label': 'Activitate și locul unde o faci',
                         'members': ['n_v29_routine_shopping_cumparaturi', 'n_v4soc_magazin']}]},
  'rationale': 'Patru relații distincte din viața de zi cu zi: Dinte — Periuță de dinți (parte a '
               'corpului și obiect pentru curățarea ei); Mop — Podea (unealtă de curățat și '
               'suprafața curățată); copac — Rădăcină (plantă lemnoasă și partea ei subterană); '
               'Cumpărături — magazin (activitate și locul unde o faci). Fiecare pereche este '
               'nouă în Perechi; nu există muchii concurente puternice pe tablă.',
  'source_id': 'aq92_session02_perechi_everyday_02',
  'sources': ['https://dexonline.ro/definitie/dinte',
              'https://dexonline.ro/definitie/periu%C8%9B%C4%83%20de%20din%C8%9Bi',
              'https://dexonline.ro/definitie/mop',
              'https://dexonline.ro/definitie/podea',
              'https://dexonline.ro/definitie/copac',
              'https://dexonline.ro/definitie/r%C4%83d%C4%83cin%C4%83',
              'https://dexonline.ro/definitie/cump%C4%83r%C4%83turi',
              'https://dexonline.ro/definitie/magazin']},
 {'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'perechi',
  'id': 'pq92_session02_everyday_03',
  'payload': {'pairs': [{'group_label': 'Loc de educație și activitatea sa centrală',
                         'members': ['n_v3soc_scoala', 'n_v24_action_routine_a_invata']},
                        {'group_label': 'Legumă și animal asociat cu ea',
                         'members': ['n_v24_food_salad_veg_morcov', 'n_v30_animal_field_iepure']},
                        {'group_label': 'Instrument și unitate de timp măsurată',
                         'members': ['n_v24_time_day_ceas', 'n_v29_time_units_minut']},
                        {'group_label': 'Floare și recipient pentru planta ei',
                         'members': ['n_v4sti_floare', 'n_v32_garden_container_ghiveci_flori']}]},
  'rationale': 'Patru relații distincte din viața de zi cu zi: Școală — A învăța (loc de '
               'educație și activitatea sa centrală); Morcov — Iepure (legumă și animal asociat '
               'cu ea); Ceas — Minut (instrument și unitate de timp măsurată); floare — Ghiveci '
               'de flori (floare și recipient pentru planta ei). Fiecare pereche este nouă în '
               'Perechi; nu există muchii concurente puternice pe tablă.',
  'source_id': 'aq92_session02_perechi_everyday_03',
  'sources': ['https://dexonline.ro/definitie/%C8%99coal%C4%83',
              'https://dexonline.ro/definitie/%C3%AEnv%C4%83%C8%9Ba',
              'https://dexonline.ro/definitie/morcov',
              'https://dexonline.ro/definitie/iepure',
              'https://dexonline.ro/definitie/ceas',
              'https://dexonline.ro/definitie/minut',
              'https://dexonline.ro/definitie/floare',
              'https://dexonline.ro/definitie/ghiveci%20de%20flori']})


# Session 03: fresh everyday and cultural vocabulary.
BOARDS += (
    ({'category': 'viata_de_roman',
      'difficulty': 'usor',
      'game': 'intrusul',
      'id': 'iq92_s03_electric_connections',
      'payload': {'group_label': 'Piese pentru conectarea aparatelor la curent electric',
                  'intruder': 'n_v33_bathroom_fixture_robinet',
                  'members': ['n_v33_electric_plug_stecher',
                              'n_v33_electric_extension_prelungitor',
                              'n_v33_electric_wire_cablu']},
      'rationale': 'Ștecherul, prelungitorul electric și cablul electric realizează '
                   'alimentarea electrică; robinetul reglează curgerea unui fluid. Patru '
                   'obiecte familiare din casă, cu o diferență funcțională precisă. Toate '
                   'trei legăturile interioare sunt puternice; intrusul nu are legături '
                   'native cu trio-ul.',
      'source_id': 'aq92_intrusul_s03_electric_connections',
      'sources': ['https://dexonline.ro/definitie/%C8%99techer',
                  'https://dexonline.ro/definitie/prelungitor',
                  'https://dexonline.ro/definitie/cablu',
                  'https://dexonline.ro/definitie/robinet']},
     {'category': 'stiinta',
      'difficulty': 'usor',
      'game': 'intrusul',
      'id': 'iq92_s03_bodily_needs',
      'payload': {'group_label': 'Stări care semnalează nevoi fiziologice',
                  'intruder': 'n_v28_feeling_social_rusine',
                  'members': ['n_v24_feeling_needs_foame',
                              'n_v24_feeling_needs_sete',
                              'n_v24_feeling_needs_oboseala']},
      'rationale': 'Foamea, setea și oboseala indică nevoi de hrană, apă sau odihnă; rușinea '
                   'este un sentiment social. Se folosesc sensurile cotidiene, nu expresii '
                   'figurate. Toate cuvintele numesc stări, astfel încât intrusul nu se '
                   'găsește printr-o simplă diferență de tip. Trio nou; numai Foame apare în '
                   'vechiul board despre emoții.',
      'source_id': 'aq92_intrusul_s03_bodily_needs',
      'sources': ['https://dexonline.ro/definitie/foame',
                  'https://dexonline.ro/definitie/sete',
                  'https://dexonline.ro/definitie/oboseal%C4%83',
                  'https://dexonline.ro/definitie/ru%C8%99ine']},
     {'category': 'viata_de_roman',
      'difficulty': 'usor',
      'game': 'intrusul',
      'id': 'iq92_s03_family_relations',
      'payload': {'group_label': 'Termeni care numesc rude',
                  'intruder': 'n_v29_people_coleg',
                  'members': ['n_v24_people_grandparents_bunica',
                              'n_v24_people_grandparents_bunic',
                              'n_v24_people_grandparents_matusa']},
      'rationale': 'Bunică, bunic și mătușă numesc relații de rudenie; coleg numește o '
                   'relație de școală sau de muncă. Patru relații interpersonale ușor de '
                   'recunoscut, fără opoziție om/obiect. Predicatul privește sensurile '
                   'cuvintelor: faptul că o anumită rudă poate fi și coleg nu schimbă '
                   'definiția termenului coleg. Trio nerefolosit.',
      'source_id': 'aq92_intrusul_s03_family_relations',
      'sources': ['https://dexonline.ro/definitie/bunic%C4%83',
                  'https://dexonline.ro/definitie/bunic',
                  'https://dexonline.ro/definitie/m%C4%83tu%C8%99%C4%83',
                  'https://dexonline.ro/definitie/coleg']},
     {'category': 'viata_de_roman',
      'difficulty': 'normal',
      'game': 'perechi',
      'id': 'pq92_s03_associations_01',
      'payload': {'pairs': [{'group_label': 'Organul vederii și funcția lui',
                             'members': ['n_v4sti_ochi', 'n_v24_action_senses_a_vedea']},
                            {'group_label': 'Camera de dormit și mobila pentru somn',
                             'members': ['n_v24_home_rooms_dormitor', 'n_v24_home_bed_pat']},
                            {'group_label': 'Produs și ustensilă folosite împreună la spălat '
                                            'vase',
                             'members': ['n_v31_cleaning_supply_detergent',
                                         'n_v31_cleaning_dishes_burete_vase']},
                            {'group_label': 'Parteneri celebri în scenete comice',
                             'members': ['n_v20fil_stela_popescu',
                                         'n_v20fil_alexandru_arsinel']}]},
      'rationale': 'Corectare față de schița neaprobată: înlocuiește perechea deja instalată '
                   'în sesiunea 02. Detergentul se folosește pe buretele de vase; niciun alt '
                   'cuvânt de pe tablă nu numește o ustensilă de curățat. Celelalte trei '
                   'relații sunt organul vederii și funcția lui; camera de dormit și mobila '
                   'pentru somn; parteneri celebri în scenete comice. Toate cele patru '
                   'perechi sunt noi în inventarul curent, cu o singură soluție de asociere '
                   'și fără muchii încrucișate puternice.',
      'source_id': 'aq92_perechi_s03_associations_01',
      'sources': ['https://dexonline.ro/definitie/detergent',
                  'https://dexonline.ro/definitie/burete%20de%20vase',
                  'https://dexonline.ro/definitie/ochi',
                  'https://dexonline.ro/intrare/dormitor/17553',
                  'https://dexonline.ro/definitie/pat',
                  'https://www.romania-actualitati.ro/interviuri/stela-popescu-am-fost-si-voi-fi-o-optimista-id44871.html']},
     {'category': 'viata_de_roman',
      'difficulty': 'normal',
      'game': 'perechi',
      'id': 'pq92_s03_associations_02',
      'payload': {'pairs': [{'group_label': 'Organul auzului și funcția lui',
                             'members': ['n_v4sti_ureche', 'n_v24_action_senses_a_auzi']},
                            {'group_label': 'Conductor izolat și dispozitivul electric care '
                                            'îl include',
                             'members': ['n_v33_electric_wire_cablu',
                                         'n_v33_electric_extension_prelungitor']},
                            {'group_label': 'Navă și locul de acostare',
                             'members': ['n_v28_transport_water_vapor', 'n_v2soc_port']},
                            {'group_label': 'Poezie și autorul ei',
                             'members': ['n_v20lit_scrisoarea_iii', 'n_mihai_eminescu']}]},
      'rationale': 'Corectare față de schița neaprobată: înlocuiește perechea deja instalată '
                   'în sesiunea 02. Cablul electric este o componentă a unui prelungitor cu '
                   'fir; perechea numește partea și dispozitivul complet. Celelalte trei '
                   'relații sunt organul auzului și funcția lui; navă și locul de acostare; '
                   'poezie și autorul ei. Toate cele patru perechi sunt noi în inventarul '
                   'curent, cu o singură soluție de asociere și fără muchii încrucișate '
                   'puternice.',
      'source_id': 'aq92_perechi_s03_associations_02',
      'sources': ['https://dexonline.ro/definitie/cablu%20electric',
                  'https://dexonline.ro/definitie/prelungitor%20electric',
                  'https://dexonline.ro/definitie/ureche',
                  'https://dexonline.ro/definitie/vapor',
                  'https://dexonline.ro/definitie/port',
                  'https://ro.wikisource.org/wiki/Scrisoarea_III']},
     {'category': 'viata_de_roman',
      'difficulty': 'normal',
      'game': 'perechi',
      'id': 'pq92_s03_associations_03',
      'payload': {'pairs': [{'group_label': 'Fenomen optic și culorile sale',
                             'members': ['n_v28_nature_weather_curcubeu', 'n_v4art_culoare']},
                            {'group_label': 'Calendarul arată zilele anului',
                             'members': ['n_v29_time_calendar', 'n_v24_time_day_zi']},
                            {'group_label': 'Castel și orașul în care se află',
                             'members': ['n_v20ist_castelul_peles', 'n_geox_sinaia']},
                            {'group_label': 'Ingredient de bază și preparat din aluat dospit',
                             'members': ['n_v24_food_pantry_faina', 'n_gas_cozonac']}]},
      'rationale': 'Culorile curcubeului, zilele calendarului, Peleșul din Sinaia și făina '
                   'pentru cozonac dau patru asocieri din domenii diferite. Calendarul nu '
                   'este tratat drept instrument meteo, iar Culoare trimite la spectrul '
                   'curcubeului. Ingredientul nu concurează cu alt preparat de pe board. '
                   'Toate patru perechile sunt noi în Perechi, fără vreo legătură '
                   'încrucișată nativă.',
      'source_id': 'aq92_perechi_s03_associations_03',
      'sources': ['https://dexonline.ro/definitie/curcubeu',
                  'https://dexonline.ro/definitie/calendar',
                  'https://peles.ro/ro/',
                  'https://dexonline.ro/definitie/cozonac']})
)


# V93: fresh everyday words, pending independent candidate and final live-audit reviews.
BOARDS += ({'id': 'iq92_v93_transport_stops',
  'game': 'intrusul',
  'source_id': 'aq92_v93_intrusul_transport_stops',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_transport_terminals_gara',
                          'n_v24_transport_terminals_aeroport',
                          'n_v24_transport_terminals_statie'],
              'intruder': 'n_v28_transport_water_vapor',
              'group_label': 'Locuri de oprire pentru mijloacele de transport'},
  'sources': ['https://dexonline.ro/definitie/gar%C4%83',
              'https://dexonline.ro/definitie/aeroport',
              'https://dexonline.ro/definitie/sta%C8%9Bie',
              'https://dexonline.ro/definitie/vapor'],
  'rationale': 'Gara, aeroportul și stația sunt locuri amenajate unde sosesc sau opresc '
               'mijloacele de transport. Vaporul este el însuși un mijloc de transport. Toate '
               'cuvintele aparțin temei călătoriei; soluția depinde de rol, nu de domeniu. Stație '
               'este folosit în sensul cotidian de stație de transport.'},
 {'id': 'iq92_v93_food_actions',
  'game': 'intrusul',
  'source_id': 'aq92_v93_intrusul_food_actions',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_action_food_a_manca',
                          'n_v24_action_food_a_bea',
                          'n_v24_action_food_a_gati'],
              'intruder': 'n_v24_action_language_a_citi',
              'group_label': 'Acțiuni de preparare sau consum al hranei și băuturilor'},
  'sources': ['https://dexonline.ro/definitie/m%C3%A2nca',
              'https://dexonline.ro/definitie/bea',
              'https://dexonline.ro/definitie/g%C4%83ti',
              'https://dexonline.ro/definitie/citi'],
  'rationale': 'Mâncatul și băutul înseamnă consum, iar gătitul pregătirea hranei. Cititul '
               'înseamnă descifrarea unui text. Toate cele patru opțiuni sunt verbe uzuale; '
               'faptul că se poate citi o rețetă nu transformă sensul verbului în preparare sau '
               'consum. A bea are aici sensul neutru, de a consuma un lichid.'},
 {'id': 'iq92_v93_weather',
  'game': 'intrusul',
  'source_id': 'aq92_v93_intrusul_weather',
  'category': 'stiinta',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_weather_air_vant',
                          'n_v24_weather_air_nor',
                          'n_v24_weather_air_ceata'],
              'intruder': 'n_v29_time_daily_noapte',
              'group_label': 'Fenomene atmosferice'},
  'sources': ['https://dexonline.ro/definitie/v%C3%A2nt',
              'https://dexonline.ro/definitie/nor',
              'https://dexonline.ro/definitie/cea%C8%9B%C4%83',
              'https://dexonline.ro/definitie/noapte'],
  'rationale': 'Vântul, norul și ceața descriu starea atmosferei. Noaptea este un interval al '
               'zilei, care poate avea oricare dintre aceste condiții meteo. Nu este nevoie de '
               'definiții științifice ascunse; diferența este vremea față de momentul zilei.'},
 {'id': 'iq92_v93_fruits',
  'game': 'intrusul',
  'source_id': 'aq92_v93_intrusul_fruits',
  'category': 'gastronomie',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_food_imported_fruit_banana',
                          'n_v24_food_imported_fruit_portocala',
                          'n_v24_food_imported_fruit_lamaie'],
              'intruder': 'n_v24_food_salad_veg_morcov',
              'group_label': 'Fructe comestibile'},
  'sources': ['https://dexonline.ro/definitie/banan%C4%83',
              'https://dexonline.ro/definitie/portocal%C4%83',
              'https://dexonline.ro/definitie/l%C4%83m%C3%A2ie',
              'https://dexonline.ro/definitie/morcov'],
  'rationale': 'Banana, portocala și lămâia sunt fructe; morcovul consumat este o rădăcină. Toate '
               'patru sunt alimente vegetale familiare. Predicatul nu pretinde că banana este '
               'citrică și nu depinde de dulceața alimentului.'},
 {'id': 'pq92_v93_everyday_01',
  'game': 'perechi',
  'source_id': 'aq92_v93_perechi_everyday_01',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_food_small_fruit_strugure', 'n_v85_food_stafide'],
                         'group_label': 'Fruct și boabele lui uscate'},
                        {'members': ['n_v24_nature_world_pamant', 'n_v32_garden_soil_lopata'],
                         'group_label': 'Material și unealta folosită la mutarea lui'},
                        {'members': ['n_v29_city_street_trotuar', 'n_v4geo_strada'],
                         'group_label': 'Cale publică și partea ei pentru pietoni'},
                        {'members': ['n_v29_body_upper_gat', 'n_v24_body_face_cap'],
                         'group_label': 'Partea corpului care susține capul'}]},
  'sources': ['https://dexonline.ro/definitie/stafid%C4%83',
              'https://dexonline.ro/definitie/lopat%C4%83',
              'https://dexonline.ro/definitie/trotuar',
              'https://dexonline.ro/definitie/g%C3%A2t'],
  'rationale': 'Patru relații cotidiene distincte: Strugure — Stafide (fruct și boabele lui '
               'uscate); Pământ — Lopată (material și unealta folosită la mutarea lui); Trotuar — '
               'stradă (cale publică și partea ei pentru pietoni); Gât — Cap (partea corpului '
               'care susține capul). Fiecare pereche este nouă în catalogul Perechi. Nu există '
               'muchii native încrucișate între perechi; vocabularul este familiar și sensurile '
               'sunt cele concrete, uzuale.'},
 {'id': 'pq92_v93_everyday_02',
  'game': 'perechi',
  'source_id': 'aq92_v93_perechi_everyday_02',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_food_snack_biscuit', 'n_v90_food_firimitura'],
                         'group_label': 'Produs sfărâmicios și un fragment desprins din el'},
                        {'members': ['n_v24_home_seating_scaun', 'n_v88_home_taburet'],
                         'group_label': 'Mobilier pentru șezut și varianta fără spătar'},
                        {'members': ['n_v28_time_calendar_saptamana', 'n_v29_time_weekly_weekend'],
                         'group_label': 'Perioadă calendaristică și sfârșitul ei'},
                        {'members': ['n_v2gas_ciorba', 'n_v30_kitchen_table_castron'],
                         'group_label': 'Preparat lichid și vasul în care se servește'}]},
  'sources': ['https://dexonline.ro/definitie/firimitur%C4%83',
              'https://dexonline.ro/definitie/taburet',
              'https://dexonline.ro/definitie/weekend',
              'https://dexonline.ro/definitie/castron'],
  'rationale': 'Patru relații cotidiene distincte: Biscuit — Firimitură (produs sfărâmicios și un '
               'fragment desprins din el); Scaun — Taburet (mobilier pentru șezut și varianta '
               'fără spătar); Săptămână — Weekend (perioadă calendaristică și sfârșitul ei); '
               'Ciorbă — Castron (preparat lichid și vasul în care se servește). Fiecare pereche '
               'este nouă în catalogul Perechi. Nu există muchii native încrucișate între '
               'perechi; vocabularul este familiar și sensurile sunt cele concrete, uzuale.'},
 {'id': 'pq92_v93_everyday_03',
  'game': 'perechi',
  'source_id': 'aq92_v93_perechi_everyday_03',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v29_time_daily_noapte', 'n_v24_action_routine_a_dormi'],
                         'group_label': 'Moment obișnuit pentru somn și activitatea lui'},
                        {'members': ['n_v24_home_appliances_frigider', 'n_v86_kitchen_congelator'],
                         'group_label': 'Aparate care păstrează alimentele la rece'},
                        {'members': ['n_v24_body_face_gura', 'n_v32_body_face_buza'],
                         'group_label': 'Orificiu al feței și marginea lui cărnoasă'},
                        {'members': ['n_v29_clothing_everyday_haina', 'n_v90_textile_scama'],
                         'group_label': 'Obiect textil și o fibră desprinsă din el'}]},
  'sources': ['https://dexonline.ro/definitie/dormi',
              'https://dexonline.ro/definitie/congelator',
              'https://dexonline.ro/definitie/buz%C4%83',
              'https://dexonline.ro/definitie/scam%C4%83',
              'https://support.electrolux.ro/support-articles/article/cum-se-pstreaz-alimentele-in-frigider-i-congelator'],
  'rationale': 'Patru relații cotidiene distincte: Noapte — A dormi (moment obișnuit pentru somn '
               'și activitatea lui); Frigider — Congelator (aparate care păstrează alimentele la '
               'rece); Gură — Buză (orificiu al feței și marginea lui cărnoasă); Haină — Scamă '
               '(obiect textil și o fibră desprinsă din el). Fiecare pereche este nouă în '
               'catalogul Perechi. Nu există muchii native încrucișate între perechi; vocabularul '
               'este familiar și sensurile sunt cele concrete, uzuale.'},
 {'id': 'pq92_v93_everyday_04',
  'game': 'perechi',
  'source_id': 'aq92_v93_perechi_everyday_04',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_home_outdoor_gradina', 'n_v32_garden_soil_grebla'],
                         'group_label': 'Loc cultivat și unealtă pentru adunat frunze'},
                        {'members': ['n_v24_home_textiles_covor',
                                     'n_v31_cleaning_floor_aspirator'],
                         'group_label': 'Obiect textil pentru podea și aparatul care îl curăță'},
                        {'members': ['n_v24_people_parents_mama', 'n_v24_people_parents_bebelus'],
                         'group_label': 'Părinte și copilul aflat la începutul vieții'},
                        {'members': ['n_v33_forest_animal_lup', 'n_v4geo_padure'],
                         'group_label': 'Animal sălbatic și un habitat al lui'}]},
  'sources': ['https://dexonline.ro/definitie/grebl%C4%83',
              'https://dexonline.ro/definitie/aspirator',
              'https://dexonline.ro/definitie/bebelu%C8%99',
              'https://dexonline.ro/definitie/lup',
              'https://www.gardena.com/ro/produse/sol-teren/combisystem/grebla-de-mana-combisystem/967093801.html',
              'https://www.electrolux.ro/vacuums-home-comfort/vacuum-cleaners/vacuum-cleaners/',
              'https://wwf.ro/ce-facem/specii/lupul/'],
  'rationale': 'Patru relații cotidiene distincte: Grădină — Greblă (loc cultivat și unealtă '
               'pentru adunat frunze); Covor — Aspirator (obiect textil pentru podea și aparatul '
               'care îl curăță); Mamă — Bebeluș (părinte și copilul aflat la începutul vieții); '
               'Lup — pădure (animal sălbatic și un habitat al lui). Fiecare pereche este nouă în '
               'catalogul Perechi. Nu există muchii native încrucișate între perechi; vocabularul '
               'este familiar și sensurile sunt cele concrete, uzuale.'})


# V94: fresh everyday words, pending independent candidate and final live-audit reviews.
BOARDS += ({'id': 'iq92_v94_sleep',
  'game': 'intrusul',
  'source_id': 'aq92_v94_intrusul_sleep',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_home_bed_pat', 'n_v24_home_bed_saltea', 'n_v24_home_bed_perna'],
              'intruder': 'n_v24_home_seating_scaun',
              'group_label': 'Obiecte destinate somnului'},
  'sources': ['https://dexonline.ro/definitie/pat',
              'https://dexonline.ro/definitie/saltea',
              'https://dexonline.ro/definitie/pern%C4%83',
              'https://dexonline.ro/definitie/scaun'],
  'rationale': 'Patul, salteaua și perna alcătuiesc locul obișnuit pentru dormit. Scaunul este '
               'mobilier pentru șezut; faptul că cineva poate ațipi pe un scaun nu îi schimbă '
               'destinația obișnuită.'},
 {'id': 'iq92_v94_milling',
  'game': 'intrusul',
  'source_id': 'aq92_v94_intrusul_milling',
  'category': 'gastronomie',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_food_pantry_faina', 'n_v84_food_malai', 'n_v84_food_gris'],
              'intruder': 'n_v84_food_drojdie',
              'group_label': 'Produse obținute prin măcinarea cerealelor'},
  'sources': ['https://dexonline.ro/definitie/f%C4%83in%C4%83',
              'https://dexonline.ro/definitie/m%C4%83lai',
              'https://dexonline.ro/definitie/gri%C8%99',
              'https://dexonline.ro/definitie/drojdie'],
  'rationale': 'Făina, mălaiul și grișul sunt produse de măcinare a cerealelor. Drojdia este un '
               'agent biologic de fermentare, nu cereale măcinate. Toate cele patru sunt '
               'ingrediente familiare de bucătărie.'},
 {'id': 'iq92_v94_rooms',
  'game': 'intrusul',
  'source_id': 'aq92_v94_intrusul_rooms',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_home_rooms_camera',
                          'n_v24_home_rooms_sufragerie',
                          'n_v24_home_rooms_dormitor'],
              'intruder': 'n_v24_home_outdoor_curte',
              'group_label': 'Încăperi din interiorul unei locuințe'},
  'sources': ['https://dexonline.ro/definitie/camer%C4%83',
              'https://dexonline.ro/definitie/sufragerie',
              'https://dexonline.ro/definitie/dormitor',
              'https://dexonline.ro/definitie/curte'],
  'rationale': 'Camera, sufrageria și dormitorul denumesc încăperi interioare. Curtea este un '
               'teren exterior din jurul locuinței. Sufragerie poate desemna camera de zi sau de '
               'luat masa: ambele sensuri satisfac exact acest predicat; nu este nevoie de un '
               'sens ascuns.'},
 {'id': 'iq92_v94_writing',
  'game': 'intrusul',
  'source_id': 'aq92_v94_intrusul_writing',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_school_writing_caiet',
                          'n_v24_school_writing_creion',
                          'n_v24_school_writing_pix'],
              'intruder': 'n_v24_school_assessment_examen',
              'group_label': 'Rechizite folosite pentru scris'},
  'sources': ['https://dexonline.ro/definitie/caiet',
              'https://dexonline.ro/definitie/creion',
              'https://dexonline.ro/definitie/pix',
              'https://dexonline.ro/definitie/examen',
              'https://dexonline.ro/definitie/rechizite'],
  'rationale': 'Caietul, creionul și pixul sunt obiecte de papetărie folosite pentru scris. '
               'Examenul este o verificare a cunoștințelor, nu un obiect de papetărie, chiar dacă '
               'unele examene sunt scrise.'},
 {'id': 'pq92_v94_everyday_01',
  'game': 'perechi',
  'source_id': 'aq92_v94_perechi_everyday_01',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_school_writing_caiet',
                                     'n_v24_school_assessment_tema_acasa'],
                         'group_label': 'Sarcină școlară și suportul pe care se scrie'},
                        {'members': ['n_v24_feeling_needs_oboseala',
                                     'n_v24_action_routine_a_dormi'],
                         'group_label': 'Stare de epuizare și odihna care o alină'},
                        {'members': ['n_v32_workshop_fastener_cui', 'n_v32_workshop_hand_cleste'],
                         'group_label': 'Piesă de fixare și unealta cu care poate fi scoasă'},
                        {'members': ['n_v24_food_pantry_ulei',
                                     'n_v85_food_seminte_floarea_soarelui'],
                         'group_label': 'Produs alimentar și semințele din care se extrage'}]},
  'sources': ['https://dexonline.ro/definitie/caiet',
              'https://dexonline.ro/definitie/oboseal%C4%83',
              'https://dexonline.ro/definitie/cle%C8%99te',
              'https://dexonline.ro/definitie/ulei',
              'https://dexonline.ro/definitie/floarea-soarelui'],
  'rationale': 'Patru relații cotidiene distincte: Caiet — Temă pentru acasă (sarcină școlară și '
               'suportul pe care se scrie); Oboseală — A dormi (stare de epuizare și odihna care '
               'o alină); Cui — Clește (piesă de fixare și unealta cu care poate fi scoasă); Ulei '
               '— Semințe de floarea-soarelui (produs alimentar și semințele din care se '
               'extrage). Fiecare pereche este nouă în catalogul Perechi. Nu există muchii native '
               'încrucișate între perechi; vocabularul este familiar și sensurile sunt cele '
               'concrete, uzuale.'},
 {'id': 'pq92_v94_everyday_02',
  'game': 'perechi',
  'source_id': 'aq92_v94_perechi_everyday_02',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v32_body_face_frunte', 'n_v32_body_face_spranceana'],
                         'group_label': 'Partea feței și arcul de peri de la baza ei'},
                        {'members': ['n_v88_kitchen_cratita', 'n_v24_home_appliances_aragaz'],
                         'group_label': 'Vas de gătit și aparatul pe care se încălzește'},
                        {'members': ['n_v30_animal_farm_capra', 'n_v24_nature_plant_parts_iarba'],
                         'group_label': 'Animal erbivor și o hrană a lui'},
                        {'members': ['n_v28_time_calendar_luna_calendaristica',
                                     'n_v29_time_calendar'],
                         'group_label': 'Unitate a anului și instrumentul care o arată'}]},
  'sources': ['https://dexonline.ro/definitie/frunte',
              'https://dexonline.ro/definitie/crati%C8%9B%C4%83',
              'https://dexonline.ro/definitie/capr%C4%83',
              'https://dexonline.ro/definitie/calendar',
              'https://dexonline.ro/definitie/spr%C3%A2ncean%C4%83',
              'https://dexonline.ro/definitie/iarb%C4%83'],
  'rationale': 'Patru relații cotidiene distincte: Frunte — Sprânceană (partea feței și arcul de '
               'peri de la baza ei); Cratiță — Aragaz (vas de gătit și aparatul pe care se '
               'încălzește); Capră — Iarbă (animal erbivor și o hrană a lui); Lună calendaristică '
               '— Calendar (unitate a anului și instrumentul care o arată). Fiecare pereche este '
               'nouă în catalogul Perechi. Nu există muchii native încrucișate între perechi; '
               'vocabularul este familiar și sensurile sunt cele concrete, uzuale.'},
 {'id': 'pq92_v94_everyday_03',
  'game': 'perechi',
  'source_id': 'aq92_v94_perechi_everyday_03',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_action_home_a_deschide',
                                     'n_v24_action_home_a_inchide'],
                         'group_label': 'Acțiuni cu sensuri opuse'},
                        {'members': ['n_v86_food_crema_vanilie', 'n_v87_food_cremsnit'],
                         'group_label': 'Umplutură și prăjitura care o conține'},
                        {'members': ['n_v30_kitchen_table_farfurie',
                                     'n_v31_cleaning_dishes_burete_vase'],
                         'group_label': 'Obiect de veselă și obiectul cu care se spală'},
                        {'members': ['n_v24_body_limbs_mana', 'n_v24_body_limbs_deget'],
                         'group_label': 'Parte a corpului și unul dintre segmentele ei '
                                        'terminale'}]},
  'sources': ['https://dexonline.ro/definitie/%C3%AEnchide',
              'https://dexonline.ro/definitie/crem%C8%99nit',
              'https://dexonline.ro/definitie/burete',
              'https://dexonline.ro/definitie/deget',
              'https://www.oetker.ro/retete/r/crema-de-vanilie-pentru-cremsnit-crema-fiarta',
              'https://dexonline.ro/definitie/farfurie'],
  'rationale': 'Patru relații cotidiene distincte: A deschide — A închide (acțiuni cu sensuri '
               'opuse); Cremă de vanilie — Cremșnit (umplutură și prăjitura care o conține); '
               'Farfurie — Burete de vase (obiect de veselă și obiectul cu care se spală); Mână — '
               'Deget (parte a corpului și unul dintre segmentele ei terminale). Fiecare pereche '
               'este nouă în catalogul Perechi. Nu există muchii native încrucișate între '
               'perechi; vocabularul este familiar și sensurile sunt cele concrete, uzuale.'},
 {'id': 'pq92_v94_everyday_04',
  'game': 'perechi',
  'source_id': 'aq92_v94_perechi_everyday_04',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_body_face_gura', 'n_v24_action_senses_a_vorbi'],
                         'group_label': 'Organ al articulării și acțiunea de a rosti cuvinte'},
                        {'members': ['n_v24_food_pantry_zahar', 'n_v86_food_zahar_pudra'],
                         'group_label': 'Ingredient dulce și forma lui fin măcinată'},
                        {'members': ['n_v4gas_lapte', 'n_v84_food_zer'],
                         'group_label': 'Materia primă și lichidul separat la închegarea ei'},
                        {'members': ['n_v32_garden_water_furtun',
                                     'n_v32_garden_water_stropitoare'],
                         'group_label': 'Obiecte folosite la udarea plantelor'}]},
  'sources': ['https://dexonline.ro/definitie/vorbi',
              'https://dexonline.ro/definitie/zah%C4%83r',
              'https://dexonline.ro/definitie/zer',
              'https://dexonline.ro/definitie/stropitoare',
              'https://dexonline.ro/definitie/gur%C4%83',
              'https://dexonline.ro/definitie/pudr%C4%83',
              'https://dexonline.ro/definitie/furtun'],
  'rationale': 'Patru relații cotidiene distincte: Gură — A vorbi (organ al articulării și '
               'acțiunea de a rosti cuvinte); Zahăr — Zahăr pudră (ingredient dulce și forma lui '
               'fin măcinată); Lapte — Zer (materia primă și lichidul separat la închegarea ei); '
               'Furtun de grădină — Stropitoare (obiecte folosite la udarea plantelor). Fiecare '
               'pereche este nouă în catalogul Perechi. Nu există muchii native încrucișate între '
               'perechi; vocabularul este familiar și sensurile sunt cele concrete, uzuale.'})


# V95: fresh functional associations; independent reviews gate installation.
BOARDS += ({'id': 'iq92_v95_workshop',
  'game': 'intrusul',
  'source_id': 'aq92_v95_intrusul_workshop',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v32_workshop_hand_ciocan',
                          'n_v32_workshop_hand_cleste',
                          'n_v32_workshop_hand_surubelnita'],
              'intruder': 'n_v31_cleaning_dishes_burete_vase',
              'group_label': 'Unelte de atelier'},
  'sources': ['https://dexonline.ro/definitie/ciocan',
              'https://dexonline.ro/definitie/cle%C8%99te',
              'https://dexonline.ro/definitie/%C8%99urubelni%C8%9B%C4%83',
              'https://dexonline.ro/definitie/burete%20de%20vase'],
  'rationale': 'Ciocanul, cleștele și șurubelnița sunt unelte de atelier folosite la lucrul cu '
               'piese. Buretele de vase este un obiect de curățenie, nu o unealtă de atelier; '
               'folosirea lui incidentală pentru a șterge o masă de lucru nu îi schimbă funcția '
               'obișnuită.'},
 {'id': 'iq92_v95_body',
  'game': 'intrusul',
  'source_id': 'aq92_v95_intrusul_body',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v24_body_limbs_mana',
                          'n_v24_body_limbs_deget',
                          'n_v24_body_limbs_picior'],
              'intruder': 'n_v29_clothing_everyday_camasa',
              'group_label': 'Părți ale corpului'},
  'sources': ['https://dexonline.ro/definitie/m%C3%A2n%C4%83',
              'https://dexonline.ro/definitie/deget',
              'https://dexonline.ro/definitie/picior',
              'https://dexonline.ro/definitie/c%C4%83ma%C8%99%C4%83'],
  'rationale': 'Mâna, degetul și piciorul sunt părți ale corpului. Cămașa este un obiect '
               'vestimentar purtat pe corp. Nu sunt numite toate membre: degetul este parte a '
               'unui membru, iar predicatul mai larg este intenționat.'},
 {'id': 'iq92_v95_tableware',
  'game': 'intrusul',
  'source_id': 'aq92_v95_intrusul_tableware',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v30_kitchen_table_farfurie',
                          'n_v30_kitchen_table_castron',
                          'n_v30_kitchen_drink_cana'],
              'intruder': 'n_v31_cleaning_water_galeata',
              'group_label': 'Vase folosite la masă'},
  'sources': ['https://dexonline.ro/definitie/farfurie',
              'https://dexonline.ro/definitie/castron',
              'https://dexonline.ro/definitie/can%C4%83',
              'https://dexonline.ro/definitie/g%C4%83leat%C4%83',
              'https://dexonline.ro/definitie/vesel%C4%83'],
  'rationale': 'Farfuria, castronul și cana sunt vase din care se servește în mod obișnuit '
               'mâncare sau băutură la masă. Găleata este un recipient pentru transport sau lucru '
               'gospodăresc, nu veselă de masă. Toate sunt recipiente, astfel că forma de vas nu '
               'rezolvă singură alegerea.'},
 {'id': 'iq92_v95_floor_cleaning',
  'game': 'intrusul',
  'source_id': 'aq92_v95_intrusul_floor_cleaning',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'members': ['n_v31_cleaning_water_galeata',
                          'n_v31_cleaning_floor_mop',
                          'n_v31_cleaning_supply_detergent'],
              'intruder': 'n_v24_home_appliances_lampa',
              'group_label': 'Folosite la spălarea podelei'},
  'sources': ['https://dexonline.ro/definitie/g%C4%83leat%C4%83',
              'https://dexonline.ro/definitie/mop',
              'https://dexonline.ro/definitie/detergent',
              'https://dexonline.ro/definitie/lamp%C4%83',
              'https://www.viledaromania.ro/turbo',
              'https://s1.kaercher-media.com/documents/datasheets/cleaningagents/ro_RO/0.011-319.0_PI_ro_RO.pdf'],
  'rationale': 'Găleata ține apa, mopul spală, iar detergentul curăță în spălarea obișnuită a '
               'podelei. Lampa luminează încăperea și nu este un mijloc de spălare. Eticheta '
               'numește aceeași utilizare pentru obiecte și produs; nu pretinde că toate sunt '
               'unelte ori că detergentul este obligatoriu la orice mop.'},
 {'id': 'pq92_v95_everyday_01',
  'game': 'perechi',
  'source_id': 'aq92_v95_perechi_everyday_01',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_feeling_needs_sete', 'n_v4gas_apa'],
                         'group_label': 'Nevoie de a bea și lichidul care o potolește'},
                        {'members': ['n_v32_garden_transport_roaba', 'n_v24_home_outdoor_gradina'],
                         'group_label': 'Mijloc de transport și locul unde poate căra pământ'},
                        {'members': ['n_v24_school_supplies_stilou', 'n_v23via_ghiozdan'],
                         'group_label': 'Instrument de scris și geanta școlară în care se poate '
                                        'păstra'},
                        {'members': ['n_v24_people_descendants_fiu',
                                     'n_v24_people_descendants_fiica'],
                         'group_label': 'Termeni pentru copilul băiat și copilul fată'}]},
  'sources': ['https://dexonline.ro/definitie/sete',
              'https://dexonline.ro/definitie/ap%C4%83',
              'https://dexonline.ro/definitie/roab%C4%83',
              'https://dexonline.ro/definitie/gr%C4%83din%C4%83',
              'https://dexonline.ro/definitie/stilou',
              'https://dexonline.ro/definitie/ghiozdan',
              'https://dexonline.ro/definitie/fiu',
              'https://dexonline.ro/definitie/fiic%C4%83'],
  'rationale': 'Patru asocieri cotidiene distincte: Sete — Apă; Roabă — Grădină; Stilou — '
               'Ghiozdan; Fiu — Fiică. Setea nu se potolește cu roaba sau cu ghiozdanul. Apa '
               'poate uda grădina, dar schimbul lasă Sete fără partener. Fiu/Fiică sunt termenii '
               'de rudenie, fără a afirma că cei doi au aceiași părinți. Roaba este un mijloc de '
               'transport în grădină, nu o unealtă care sapă.'},
 {'id': 'pq92_v95_everyday_02',
  'game': 'perechi',
  'source_id': 'aq92_v95_perechi_everyday_02',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_feeling_needs_foame', 'n_v4gas_mancare'],
                         'group_label': 'Nevoie de a mânca și ceea ce o potolește'},
                        {'members': ['n_v32_workshop_cut_fierastrau', 'n_v4sti_copac'],
                         'group_label': 'Unealtă de tăiat și arborele ale cărui ramuri le poate '
                                        'tăia'},
                        {'members': ['n_v29_animal_pets_caine', 'n_v24_home_outdoor_curte'],
                         'group_label': 'Animal de pază și un spațiu pe care îl poate păzi'},
                        {'members': ['n_v24_home_textiles_patura', 'n_v24_home_textiles_cearsaf'],
                         'group_label': 'Obiecte textile folosite la așternutul patului'}]},
  'sources': ['https://dexonline.ro/definitie/foame',
              'https://dexonline.ro/definitie/m%C3%A2ncare',
              'https://dexonline.ro/definitie/fier%C4%83str%C4%83u',
              'https://dexonline.ro/definitie/copac',
              'https://dexonline.ro/definitie/c%C3%A2ine',
              'https://dexonline.ro/definitie/curte',
              'https://dexonline.ro/definitie/p%C4%83tur%C4%83',
              'https://dexonline.ro/definitie/cear%C8%99af',
              'https://www.gardena.com/ro/produse/copac-arbust-ingrijire/ferastraie-ferastrau-de-gradina',
              'https://dexonline.ro/definitie/c%C3%A2ine/definitii'],
  'rationale': 'Patru asocieri cotidiene distincte: Foame — Mâncare; Fierăstrău — copac; Câine — '
               'Curte; Pătură — Cearșaf. Câinele poate mânca, dar Foame ar rămâne fără partener '
               'dacă Mâncare ar fi cuplată cu animalul. Fierăstrăul taie ramurile copacului; '
               'curtea este un spațiu, nu material de tăiat. Pătura și cearșaful au folosirea '
               'comună de așternut, nu aceeași poziție pe pat. Nu se afirmă că orice câine '
               'locuiește în curte.'},
 {'id': 'pq92_v95_everyday_03',
  'game': 'perechi',
  'source_id': 'aq92_v95_perechi_everyday_03',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_body_limbs_picior', 'n_v31_body_lower_glezna'],
                         'group_label': 'Membru inferior și regiunea articulației sale de jos'},
                        {'members': ['n_v24_nature_sky_soare', 'n_v24_nature_sky_stea'],
                         'group_label': 'Astrul nostru și tipul de corp ceresc căruia îi '
                                        'aparține'},
                        {'members': ['n_v24_action_language_a_scrie',
                                     'n_v24_school_writing_caiet'],
                         'group_label': 'Acțiune și suportul cu foi pe care se poate face'},
                        {'members': ['n_v30_clothing_outer_geaca', 'n_v24_home_storage_dulap'],
                         'group_label': 'Haină de exterior și mobilierul în care se poate '
                                        'păstra'}]},
  'sources': ['https://dexonline.ro/definitie/picior',
              'https://dexonline.ro/definitie/glezn%C4%83',
              'https://dexonline.ro/definitie/soare',
              'https://dexonline.ro/definitie/stea',
              'https://dexonline.ro/definitie/scrie',
              'https://dexonline.ro/definitie/caiet',
              'https://dexonline.ro/definitie/geac%C4%83',
              'https://dexonline.ro/definitie/dulap',
              'https://science.nasa.gov/sun/facts/'],
  'rationale': 'Patru asocieri cotidiene distincte: Picior — Gleznă; Soare — Stea; A scrie — '
               'Caiet; Geacă — Dulap. Soarele este o stea; nu se confundă Luna cu o stea. Picior '
               'este membrul inferior în sensul românesc obișnuit, nu doar laba piciorului. '
               'Scrisul pe alte materiale și depozitarea altor obiecte nu produc o a doua '
               'împărțire a celor opt cuvinte.'},
 {'id': 'pq92_v95_everyday_04',
  'game': 'perechi',
  'source_id': 'aq92_v95_perechi_everyday_04',
  'category': 'viata_de_roman',
  'difficulty': 'usor',
  'payload': {'pairs': [{'members': ['n_v24_nature_sky_luna', 'n_v29_time_daily_noapte'],
                         'group_label': 'Astru și perioada cu care este asociat pe cer'},
                        {'members': ['n_v24_food_breakfast_unt', 'n_v18gas_salam_de_biscuiti'],
                         'group_label': 'Ingredient și desertul în care se folosește'},
                        {'members': ['n_v24_food_imported_fruit_lamaie',
                                     'n_v24_food_imported_fruit_portocala'],
                         'group_label': 'Fructe din grupa citricelor'},
                        {'members': ['n_v28_body_mouth_dinte', 'n_v31_hygiene_oral_pasta_dinti'],
                         'group_label': 'Parte a danturii și produsul folosit la curățarea ei'}]},
  'sources': ['https://dexonline.ro/definitie/lun%C4%83',
              'https://dexonline.ro/definitie/noapte',
              'https://dexonline.ro/definitie/unt',
              'https://dexonline.ro/definitie/salam%20de%20biscui%C8%9Bi',
              'https://dexonline.ro/definitie/l%C4%83m%C3%A2ie',
              'https://dexonline.ro/definitie/portocal%C4%83',
              'https://dexonline.ro/definitie/dinte',
              'https://dexonline.ro/definitie/past%C4%83%20de%20din%C8%9Bi',
              'https://astro-urseanu.ro/ghidul-vizitatorului/',
              'https://jamilacuisine.ro/salam-de-biscuiti-facut-in-casa-reteta-video/',
              'https://dexonline.ro/definitie/citrice'],
  'rationale': 'Patru asocieri cotidiene distincte: Lună — Noapte; Unt — Salam de biscuiți; '
               'Lămâie — Portocală; Dinte — Pastă de dinți. Luna poate fi vizibilă și ziua; '
               'eticheta exprimă asocierea familiară cu noaptea, fără exclusivitate sau '
               'promisiunea vizibilității în fiecare noapte. Untul este documentat în varianta '
               'obișnuită de salam de biscuiți, fără pretenția că orice variantă conține lactate. '
               'Cele două citrice rămân perechea distinctă; nu sunt ingrediente obligatorii ale '
               'desertului.'})

# V96: atmospheric phenomena and four familiar natural-world associations.
BOARDS += ({'category': 'stiinta',
  'difficulty': 'usor',
  'game': 'intrusul',
  'id': 'iq92_v96_weather',
  'payload': {'group_label': 'Fenomene produse în atmosferă',
              'intruder': 'n_v24_nature_sky_luna',
              'members': ['n_v24_weather_storm_furtuna',
                          'n_v24_weather_storm_fulger',
                          'n_v24_weather_storm_tunet']},
  'rationale': 'Furtuna, fulgerul și tunetul sunt fenomene atmosferice; Luna este un corp '
               'ceresc. Eticheta nu spune că fiecare furtună produce tunete sau că Luna este '
               'invizibilă ziua.',
  'source_id': 'aq92_v96_intrusul_weather',
  'sources': ['https://www.weather.gov/safety/lightning-science-thunder',
              'https://forecast.weather.gov/glossary.php?word=lightning',
              'https://science.nasa.gov/moon/facts/']},
 {'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'perechi',
  'id': 'pq92_v96_nature_everyday',
  'payload': {'pairs': [{'group_label': 'Parte a plantei și ramificația pe care poate crește',
                         'members': ['n_v4sti_frunza', 'n_v24_nature_plant_parts_ramura']},
                        {'group_label': 'Animale domestice ținute frecvent pentru companie',
                         'members': ['n_v29_animal_pets_caine', 'n_v29_animal_pets_pisica']},
                        {'group_label': 'Aliment și categoria de alimente căreia îi aparține',
                         'members': ['n_v24_food_imported_fruit_banana', 'n_v4gas_fruct']},
                        {'group_label': 'Cereală și produsul obținut prin măcinarea boabelor',
                         'members': ['n_v84_food_grau', 'n_v24_food_pantry_faina']}]},
  'rationale': 'Frunză–Ramură, Câine–Pisică, Banană–Fruct și Grâu–Făină au relații obișnuite '
               'distincte. Bananele și grâul provin din plante, dar nu pot înlocui perechea '
               'grâu–făină fără să lase un partener nepotrivit. Nu se afirmă că banana crește '
               'într-un copac sau că orice făină este din grâu.',
  'source_id': 'aq92_v96_perechi_nature_everyday',
  'sources': ['https://dexonline.ro/definitie/frunz%C4%83',
              'https://dexonline.ro/definitie/ramur%C4%83',
              'https://dexonline.ro/definitie/c%C3%A2ine',
              'https://dexonline.ro/definitie/pisic%C4%83',
              'https://dexonline.ro/definitie/banan%C4%83',
              'https://dexonline.ro/definitie/f%C4%83in%C4%83']})

# V97: ordinary kinship terms and separate home, rail and school associations.
BOARDS += ({'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'intrusul',
  'id': 'iq92_v97_relatives',
  'payload': {'group_label': 'Denumiri de rude',
              'intruder': 'n_v2via_vecini',
              'members': ['n_v24_people_relatives_frate',
                          'n_v24_people_relatives_sora',
                          'n_v24_people_relatives_unchi']},
  'rationale': 'Frate, soră și unchi denumesc relații de rudenie. Vecin numește apropierea '
               'locuinței, nu rudenia. O rudă poate locui alături, dar acest fapt nu '
               'transformă termenul vecin într-o denumire de rudă. Sunt folosite sensurile '
               'obișnuite ale identităților native, nu sensurile figurate sau religioase.',
  'source_id': 'aq92_v97_intrusul_relatives',
  'sources': ['https://dexonline.ro/definitie/frate',
              'https://dexonline.ro/definitie/sor%C4%83',
              'https://dexonline.ro/definitie/unchi',
              'https://dexonline.ro/definitie/vecin']},
 {'category': 'viata_de_roman',
  'difficulty': 'usor',
  'game': 'perechi',
  'id': 'pq92_v97_home_and_city',
  'payload': {'pairs': [{'group_label': 'Elemente care delimitează o cameră',
                         'members': ['n_v24_home_structure_perete',
                                     'n_v24_home_structure_tavan']},
                        {'group_label': 'Mijloace de transport urban pe șine',
                         'members': ['n_v24_transport_rail_metrou',
                                     'n_v24_transport_rail_tramvai']},
                        {'group_label': 'Acțiune și încăperea destinată preparării hranei',
                         'members': ['n_v24_action_food_a_gati', 'n_v4gas_bucatarie']},
                        {'group_label': 'Evaluare școlară și unitate de studiu',
                         'members': ['n_v24_school_assessment_examen',
                                     'n_v24_school_classroom_lectie']}]},
  'rationale': 'Patru asocieri concrete: Perete–Tavan, Metrou–Tramvai, A găti–Bucătărie și '
               'Examen–Lecție. Lecțiile oferă conținut de învățat pentru o evaluare, fără a '
               'afirma că orice lecție este urmată de examen. Cele două vehicule sunt '
               'singurele mijloace de transport de pe tablă, iar peretele și tavanul sunt '
               'singurele elemente de construcție. Încăperea pentru gătit se leagă de acțiunea '
               'de preparare a hranei, nu de sensul reflexiv al împodobirii. Cuvintele '
               'denumesc sensurile obișnuite, nu toate sensurile figurate.',
  'source_id': 'aq92_v97_perechi_home_and_city',
  'sources': ['https://dexonline.ro/definitie/perete/definitii',
              'https://dexonline.ro/definitie/tavan',
              'https://dexonline.ro/definitie/metrou',
              'https://dexonline.ro/definitie/tramvai',
              'https://dexonline.ro/definitie/g%C4%83ti/definitii',
              'https://dexonline.ro/definitie/buc%C4%83t%C4%83rie',
              'https://dexonline.ro/definitie/examen',
              'https://dexonline.ro/definitie/lec%C8%9Bie']})
