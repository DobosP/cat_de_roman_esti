import test from 'node:test';
import assert from 'node:assert/strict';
import { motionExternal, assertLibraryMotion, assertConsumerMotion } from './motion-boundary.mjs';

test('Motion boundary matches only the package and its subpaths', () => {
  for (const name of ['motion', 'motion/mini', 'motion/react']) assert.equal(motionExternal.test(name), true);
  for (const name of ['motionless', 'motion-dom', 'framer-motion', './motion', '/work/src/motion/core.ts']) assert.equal(motionExternal.test(name), false);
});

test('library requires real external mini/spring imports and refuses embedded engines', () => {
  assertLibraryMotion(['/work/src/motion/core.ts'], ['motion', 'motion/mini', 'preact']);
  for (const name of ['motion', 'motion-dom', 'motion-utils', 'framer-motion']) {
    assert.throws(() => assertLibraryMotion([`/work/node_modules/${name}/dist/index.mjs`], ['motion', 'motion/mini']), /embeds/);
  }
  for (const imports of [[], ['motion'], ['motion/mini'], ['motion', 'motion/mini', 'motion/react']]) {
    assert.throws(() => assertLibraryMotion(['/work/src/motion/core.ts'], imports));
  }
});

function fixture() {
  const entry = '/consumer/motion-consumer.mjs', uiPrefix = '/consumer/node_modules/@roedu/ui/', mini = '/consumer/node_modules/motion/dist/es/mini.mjs', spring = '/consumer/node_modules/motion/dist/es/index.mjs';
  const core = uiPrefix + 'dist/motion.js', implementation = '/consumer/node_modules/motion-dom/dist/es/animation.mjs';
  return { entry, uiPrefix, resolutions: [{ specifier: 'motion', id: spring }, { specifier: 'motion/mini', id: mini }],
    modules: [{ id: entry, imports: [spring, mini, core] }, { id: core, imports: [spring, mini] },
      { id: mini, imports: [implementation] }, { id: spring, imports: [implementation] }, { id: implementation, imports: [] }],
    rendered: [entry, core, implementation] };
}

test('consumer shares both actual resolutions and emits one Motion implementation', () => {
  const result = assertConsumerMotion(fixture()); assert.deepEqual(result.map(row => row.name), ['motion', 'motion-dom']);
});

test('consumer refuses duplicate package roots, unresolved/shared imports and tree-shaken witnesses', () => {
  for (const change of [
    f => { f.modules.push({ id: '/consumer/node_modules/@roedu/ui/node_modules/motion/dist/es/mini.mjs', imports: [] }); },
    f => { f.modules[1].imports = []; }, f => { f.modules[0].imports = []; },
    f => { f.modules[2].external = true; }, f => { f.resolutions[0].id = '/outside/unresolved.mjs'; },
    f => { f.rendered = f.rendered.filter(id => id !== f.entry); },
    f => { f.rendered = f.rendered.filter(id => !id.startsWith(f.uiPrefix)); },
    f => { f.rendered.push(f.rendered.at(-1)); }, f => { f.modules.push(f.modules[0]); },
  ]) { const value = fixture(); change(value); assert.throws(() => assertConsumerMotion(value)); }
});
