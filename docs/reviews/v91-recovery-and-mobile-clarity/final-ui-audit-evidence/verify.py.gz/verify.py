from pathlib import Path
from datetime import datetime, timezone
import base64
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

WT = Path('/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity')
REVIEW = WT / 'docs/reviews/v91-recovery-and-mobile-clarity'
SCRATCH = Path(__file__).resolve().parent
OUT = {'checked_at': datetime.now(timezone.utc).isoformat(), 'errors': []}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def check(value, message):
    if not value:
        OUT['errors'].append(message)

def read_json(path):
    return json.loads(path.read_bytes())

def check_pins(pins, label):
    mismatches = [p for p, digest in pins.items()
                  if not (WT / p).is_file() or sha((WT / p).read_bytes()) != digest]
    check(not mismatches, f'{label}: {mismatches}')
    return {'count': len(pins), 'mismatches': mismatches}

def walk_tests(suites):
    for suite in suites:
        for spec in suite.get('specs', []):
            yield from spec.get('tests', [])
        yield from walk_tests(suite.get('suites', []))

archives = {}
OUT['recovery_archives'] = {}
for stem in ['baseline', 'initial-candidate', 'review-findings', 'third-candidate',
             'independent-final', 'final-candidate']:
    manifest_path = REVIEW / f'derived-recovery/{stem}-manifest.json'
    manifest = read_json(manifest_path)
    path = REVIEW / f'derived-recovery/{stem}-evidence.tar.gz'
    raw = path.read_bytes()
    check(raw[4:8] == bytes(4), f'{stem}: gzip mtime not zero')
    check(sha(raw) == manifest['archive_sha256'], f'{stem}: archive sha')
    decoded = gzip.decompress(raw)
    with tarfile.open(fileobj=io.BytesIO(decoded)) as tar:
        members = [m for m in tar.getmembers() if m.isfile()]
        check(len({m.name for m in members}) == len(members), f'{stem}: duplicate file members')
        entries = {m.name: tar.extractfile(m).read() for m in members}
    check(set(entries) == set(manifest['entries']), f'{stem}: member set')
    for name, expected in manifest['entries'].items():
        check(name in entries, f'{stem}: absent {name}')
        if name in entries:
            check(sha(entries[name]) == expected['sha256'], f'{stem}: member sha {name}')
            check(len(entries[name]) == expected['bytes'], f'{stem}: member size {name}')
    archives[stem] = entries
    OUT['recovery_archives'][stem] = {
        'members': len(entries), 'archive_sha256': sha(raw),
        'decoded_tar_sha256': sha(decoded), 'manifest_sha256': sha(manifest_path.read_bytes()),
        'gzip_mtime': 0,
    }
check(sum(x['members'] for x in OUT['recovery_archives'].values()) == 199, 'recovery total !=199')

baseline = read_json(REVIEW / 'derived-recovery/baseline-manifest.json')
for name, digest in baseline['static_hashes'].items():
    raw = subprocess.check_output(['git', 'show', f"{baseline['baseline_commit']}:{name}"], cwd=WT)
    check(sha(raw) == digest, f'baseline git object: {name}')
OUT['baseline_static_git_pins'] = len(baseline['static_hashes'])

final = read_json(REVIEW / 'derived-recovery/final-candidate-manifest.json')
OUT['final_recovery_pins'] = check_pins(final['inputs'], 'final42')
check(len(final['inputs']) == 42 and not final['changed_frozen_inputs_after_browser_run'], 'final42 receipt')
current_static = {str(p.relative_to(WT)) for p in (WT / 'cat_de_roman_esti/web/static').rglob('*') if p.is_file()}
bound_static = {p for p in final['inputs'] if p.startswith('cat_de_roman_esti/web/static/')}
check(current_static == bound_static, 'final static membership differs')
OUT['current_static_files'] = len(current_static)
browser_log = archives['final-candidate']['presence-browser.log'].decode()
back_log = archives['final-candidate']['presence-back.log'].decode()
check(len(re.findall(r'^\s*✓\s+\d+ ', browser_log, re.M)) == 80, '80 distinct passing log lines')
check('80 passed (4.5m)' in browser_log and final['browser_exit_code'] == 0, '80 browser pass receipt')
check(len(re.findall(r'^\s*✓\s+\d+ ', back_log, re.M)) == 4 and '4 passed (27.9s)' in back_log, '4 Back lines')
check(final['back_first']['exit_code'] == 0, '4 Back exit receipt')
last_run = json.loads(archives['final-candidate']['presence-focused-results/.last-run.json'])
check(last_run == {'status': 'passed', 'failedTests': []}, 'final last-run receipt')
records = json.loads(archives['final-candidate']['presence-candidate.json'])['records']
check(len(records) == 6, 'six final state captures')
captured = []
for row in records:
    ui = row['ui']
    check(ui['enabledTiles'] == 0 and ui['feedback'] == [] and ui['results'] == 0,
          f"final capture readonly/result/feedback: {row['game']} {row['scenario']}")
    check(ui['storage']['played'] == 0, f"final capture score: {row['game']} {row['scenario']}")
    if row['scenario'] == 'failed-read':
        check(ui['retry'] == 1 and row['server']['hints_used'] == 1, 'failed-read clue/cap observation')
    else:
        check(ui['loadCurrent'] == 1 and row['committed']['won'], 'foreign-pointer completion observation')
    captured.append({'game': row['game'], 'scenario': row['scenario'], 'ui': ui})
OUT['recovery_results'] = {'browser_pass_lines': 80, 'back_pass_lines': 4, 'manual_captures': captured,
                           'browser_exit_code': final['browser_exit_code']}

independent = read_json(REVIEW / 'derived-recovery/independent-final-review.json')
OUT['independent_recovery_pins'] = check_pins(independent['inputsAfter'], 'independent39')
check(len(independent['inputsAfter']) == 39 and independent['inputsBefore'] == independent['inputsAfter'], 'independent39 stable')
check(independent['verdict'] == 'accept', 'independent verdict')
independent_raw = archives['independent-final']
for name, digest in independent['artifacts'].items():
    check(sha(independent_raw[name]) == digest, f'independent artifact sha: {name}')
independent_report = json.loads(independent_raw['presence-final-results.json'])
independent_tests = list(walk_tests(independent_report['suites']))
check(len(independent_tests) == 4, 'independent test count')
check(all(len(t['results']) == 1 and t['results'][0]['status'] == 'passed'
          and t['results'][0]['retry'] == 0 for t in independent_tests), 'independent four results')
pointer_cases = independent['pointerRetryCases']
check(len(pointer_cases) == 2, 'independent pointer case count')
for row in pointer_cases:
    check(row['after'] == {'pointer': None, 'played': 0} and row['counts'] == {'reads': 1, 'mutations': 1}
          and row['committedWon'] and row['changedControlVisible'] == 1 and not row['resultVisible'],
          f"independent pointer semantics: {row['game']}")
OUT['independent_results'] = {'back_stats': independent_report['stats'], 'pointer_retry_cases': pointer_cases}

mobile = REVIEW / 'mobile'
mobile_manifest = read_json(mobile / 'manifest.json')
check(len(mobile_manifest['files']) == 255, 'mobile file count')
check(len({v['path'] for v in mobile_manifest['files']}) == 255, 'duplicate mobile entries')
gzip_count = 0
for entry in mobile_manifest['files']:
    raw = (mobile / entry['path']).read_bytes()
    check(len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], f"mobile raw: {entry['path']}")
    decoded = raw
    if entry['gzip_mtime'] is not None:
        gzip_count += 1
        check(raw[4:8] == bytes(4) and entry['gzip_mtime'] == 0, f"mobile gzip mtime: {entry['path']}")
        decoded = gzip.decompress(raw)
    check(len(decoded) == entry['raw_bytes'] and sha(decoded) == entry['raw_sha256'], f"mobile decoded: {entry['path']}")
OUT['mobile_artifacts'] = {'count': 255, 'gzip_payloads': gzip_count,
                           'manifest_sha256': sha((mobile / 'manifest.json').read_bytes())}
source_bindings = read_json(mobile / 'source-bindings.json')
OUT['mobile_shared_source_pins'] = check_pins(source_bindings['candidate_shared_source'], 'mobile shared source')
OUT['installed_toast_pins'] = check_pins(source_bindings['installed_toast_api'], 'unchanged installed Toast API')
built = read_json(mobile / 'built-source-bindings.json')
old_build_differences = [p for p, digest in built.items() if not (WT / p).is_file() or sha((WT / p).read_bytes()) != digest]
check(all(p.startswith('cat_de_roman_esti/web/static/') or p in [
    'frontend/src/screens/Intrusul.tsx', 'frontend/src/screens/Perechi.tsx'] for p in old_build_differences),
    'unexpected old mobile build/source difference')
check(read_json(mobile / 'built-source-recheck.json') == {'mismatches': [], 'files': 85}, 'mobile post-run85 receipt')
OUT['mobile_older_build_differences'] = old_build_differences
report = json.loads(gzip.decompress((mobile / 'focused-built-report.json.gz').read_bytes()))
tests = list(walk_tests(report['suites']))
check(len(tests) == 14 and report['stats']['expected'] == 14 and report['stats']['unexpected'] == 0
      and report['stats']['flaky'] == 0 and report['stats']['skipped'] == 0, 'mobile14 summary')
check(all(len(t['results']) == 1 and t['results'][0]['status'] == 'passed'
          and t['results'][0]['retry'] == 0 for t in tests), 'mobile14 exact result statuses')
attachments = [a for t in tests for result in t['results'] for a in result.get('attachments', []) if 'body' in a]
for attachment in attachments:
    base64.b64decode(attachment['body'], validate=True)
OUT['mobile_results'] = {'stats': report['stats'], 'result_count': len(tests),
                          'valid_embedded_attachment_bodies': len(attachments)}
integration = SCRATCH.parent / 'integration'
OUT['root_rebuild_receipts'] = {}
for name in ['frontend_build', 'frontend_bundle']:
    receipt_path = integration / f'{name}.json'
    receipt = read_json(receipt_path)
    check(receipt['exit_code'] == 0 and sha((integration / f'{name}.log').read_bytes()) == receipt['log_sha256'],
          f'root {name} log/exit receipt')
    OUT['root_rebuild_receipts'][name] = {'receipt_sha256': sha(receipt_path.read_bytes()), **receipt}
check(any('119.08 KiB  total' in line for line in OUT['root_rebuild_receipts']['frontend_bundle']['tail']), 'root bundle119.08')
OUT['limits'] = ['Read-only audit; no browser run or build performed by this auditor.',
                 'Focused evidence only; full integration gates remain owned by root and are not declared passed here.',
                 'Mobile focused evidence uses its earlier build; four shared files and installed Toast inputs remain exact, while final42 pins bind current rebuilt static assets.',
                 'Physical devices, actual keyboard opening, player acceptance and deployment are outside this audit.']
OUT['verdict'] = 'accept' if not OUT['errors'] else 'reject'
OUT['runner_sha256'] = sha(Path(__file__).read_bytes())
(SCRATCH / 'receipt.json').write_text(json.dumps(OUT, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verdict': OUT['verdict'], 'errors': OUT['errors'],
                  'archive_members': sum(x['members'] for x in OUT['recovery_archives'].values()),
                  'mobile_artifacts': 255, 'final_pins': OUT['final_recovery_pins'],
                  'independent_pins': OUT['independent_recovery_pins']}, ensure_ascii=False, indent=2))
raise SystemExit(0 if not OUT['errors'] else 1)
