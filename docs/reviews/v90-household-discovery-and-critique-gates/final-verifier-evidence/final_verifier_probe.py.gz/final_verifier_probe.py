import dataclasses
import gzip
import hashlib
import json
import os
from pathlib import Path

os.environ.update(DJANGO_SETTINGS_MODULE='cat_de_roman_esti.web.settings', CAT_ACCOUNTS_ENABLED='0', CAT_DEBUG='0')
import django
django.setup()
from django.test import Client
from cat_de_roman_esti.wordgames import contexto as C, contexto_projection as P
from cat_de_roman_esti.wordgames.service import get_service, normalize
from scripts import critique_pack as CP
from scripts.build_review_artifact import read_dossiers

root = Path.cwd()
base = root / 'docs/reviews/v90-household-discovery-and-critique-gates'
out = Path('/home/dobo/work/_temp/feat__v90-household-discovery-and-critique-gates/graph-factual')
ids = ['ct_viata_de_roman_355', 'ct_viata_de_roman_356']
paths = [
    'cat_de_roman_esti/fixtures/kg_sample.json', 'cat_de_roman_esti/fixtures/games_pack.json',
    'cat_de_roman_esti/fixtures/derived_catalog_v38.json', 'cat_de_roman_esti/fixtures/board_rankings_v37.json',
    'cat_de_roman_esti/wordgames/service.py', 'cat_de_roman_esti/wordgames/contexto.py',
    'cat_de_roman_esti/wordgames/contexto_feedback.py', 'cat_de_roman_esti/wordgames/contexto_projection.py',
    'cat_de_roman_esti/wordgames/packs.py', 'cat_de_roman_esti/wordgames/derived_catalog.py',
    'scripts/critique_pack.py', 'docs/CRITIQUE_RUBRIC.md',
    *[str((base/'dossiers'/f'{i}.json').relative_to(root)) for i in ids],
    str((base/'author-candidates/graph-proposal.json').relative_to(root)),
]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
bindings = {p: sha(root/p) for p in paths}
dossiers = read_dossiers(base/'dossiers', ids)
svc = get_service()
client = Client()
result = {'scope': 'Independent final verifier, actual applied graph and unpatched Django BFF; explicitly seeded private pending-round sessions, not public selector or human playtest', 'bindings': bindings, 'profiles': [], 'first_guesses': [], 'journeys': []}
pack = json.loads((root/paths[1]).read_text())
kg = json.loads((root/paths[0]).read_text())
proposal = json.loads((base/'author-candidates/graph-proposal.json').read_text())
for wanted in proposal['nodes']:
    matches = [n for n in kg['kg_nodes'] if n['id']==wanted['id']]
    assert len(matches)==1 and all(matches[0][k]==v for k,v in wanted.items())
for wanted in proposal['edges']:
    matches=[e for e in kg['kg_edges'] if e['src_id']==wanted['src'] and e['dst_id']==wanted['dst'] and e['relation']==wanted['relation']]
    assert len(matches)==1 and all(matches[0][k]==v for k,v in wanted.items() if k not in {'src','dst'})
result['applied_proposal_matches']={'nodes':3,'edges':17,'forms':10}

def private(body, tid, label):
    assert not body.get('won')
    def visit(value):
        if isinstance(value, dict):
            assert not set(value)&{'target','target_id','description','route','path'}
            for v in value.values(): visit(v)
        elif isinstance(value, list):
            for v in value: visit(v)
        elif isinstance(value, str):
            assert value != tid and normalize(value) != normalize(label), (tid,value)
    visit(body)

words = ['Praf','prafului','Firimitură','firimituri','Scamă','scame','Mătură','Podea','Mop','Covor','Electricitate','Pâine','Biscuit','Haină','Apă','Casă','Bucătărie','Farfurie','Pământ','Praf de copt','Lapte praf','București','Fotbal','gunoi']
for packid,label,plural,approach in [
    (ids[0], 'Făraș', 'fărașele', 'Mătură'),
    (ids[1], 'Aspirator', 'aspiratoarele', 'Covor'),
]:
    tid = svc.resolve(label)
    incoming = CP.contexto_incoming_ids(svc, tid)
    dossier = dossiers[packid]
    assert len(incoming) == dossier['incoming_neighbor_floor']['count']
    assert sorted(incoming) == sorted(n['id'] for n in dossier['incoming_neighbor_floor']['sample'])
    dist = svc.distances_to(tid)
    session = C._build_session(tid, 'usor', None, category='viata_de_roman', pack_id=packid)
    profile = {'id': packid, 'target':tid, 'label':label, 'review_binding':dossier['review_binding'], 'reachable':len(dist), 'responsive':C._responsive_count(dist), 'good_target':C._is_good_target(dist), 'incoming':[], 'same_target_records':[r['id'] for r in pack['contexto'] if r['target']==tid]}
    assert profile['good_target'] and profile['same_target_records']==[packid]
    for nid in incoming:
        profile['incoming'].append({'id':nid, 'label':svc.label(nid), 'native_distance':dist[nid], 'feedback_anchor':C._feedback_anchor_id(svc,nid,tid), 'feedback':dataclasses.asdict(C._score_feedback(svc,session,nid))})
    result['profiles'].append(profile)
    for word in words:
        if svc.resolve(word)==tid: continue
        gid=C.store.create(C._build_session(tid,'usor',None,category='viata_de_roman',pack_id=packid))
        try:
            response=client.post(f'/api/wordgames/contexto/games/{gid}/guess',{'text':word},content_type='application/json')
            body=response.json()
            assert response.status_code==200,(label,word,response.status_code,body)
            private(body,tid,label)
            result['first_guesses'].append({'target':label,'word':word,'response':body})
        finally: C.store.delete(gid)
    gid=C.store.create(C._build_session(tid,'usor',None,category='viata_de_roman',pack_id=packid))
    url=f'/api/wordgames/contexto/games/{gid}'
    steps=[]
    def call(name,path='',body=None):
        r=client.get(url) if body is None else client.post(url+path,body,content_type='application/json')
        value=r.json();assert r.status_code==200,(name,r.status_code,value)
        steps.append({'name':name,'response':value});return value
    try:
        private(call('initial'),tid,label)
        for word in ['București','Fotbal','Stilou']: private(call(word,'/guess',{'text':word}),tid,label)
        clue=call('earned warmer clue','/clue',{});private(clue,tid,label)
        assert clue['clues_used']==1 and clue['clue_kind']=='warmer'
        private(call(approach,'/guess',{'text':approach}),tid,label)
        dust=call('native dust','/guess',{'text':'Praf'});private(dust,tid,label)
        assert dust['guess']['id']=='n_v90_household_praf' and dust['guess']['rank']>1
        for word in ['praful','prafului']:
            repeated=call(word,'/guess',{'text':word});private(repeated,tid,label)
            assert repeated['attempts']==dust['attempts'] and repeated['guesses']==dust['guesses']
        resumed=call('resume');private(resumed,tid,label)
        assert resumed['guesses']==dust['guesses'] and resumed['clues_used']==1
        won=call('exact plural win','/guess',{'text':plural})
        assert won['won'] and won['guess']['id']==tid and won['guess']['rank']==1
        terminal=call('terminal resume');assert terminal['won'] and terminal['score']==won['score']
        result['journeys'].append({'id':packid,'checks_passed':True,'steps':steps})
    finally: C.store.delete(gid)

assert P.resolve_projection('praf') is None
assert svc.resolve('praf')=='n_v90_household_praf'
assert svc.resolve('Praf de copt')=='n_v87_food_praf_copt'
assert svc.resolve('Lapte praf')=='n_v86_food_lapte_praf'
assert {p:sha(root/p) for p in paths}==bindings
result['first_guess_count']=len(result['first_guesses'])
result['journey_requests']=sum(len(j['steps']) for j in result['journeys'])
result['bindings_unchanged_at_finish']=True
(out/'final-verifier-probes.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for p in result['profiles']:
    print(p['label'],'incoming',len(p['incoming']),'reachable',p['reachable'],'responsive',p['responsive'])
    print([(x['label'],x['native_distance'],x['feedback']) for x in p['incoming']])
    print([(x['word'],x['response'].get('guess',{}).get('rank'),x['response'].get('guess',{}).get('temperature')) for x in result['first_guesses'] if x['target']==p['label']])
print('PASS',result['first_guess_count'],'fresh guesses;',result['journey_requests'],'journey requests; all source/artifact bindings unchanged')
