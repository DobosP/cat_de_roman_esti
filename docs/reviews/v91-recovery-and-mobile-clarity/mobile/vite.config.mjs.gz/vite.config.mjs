import { defineConfig } from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/node_modules/vite/dist/node/index.js';
import react from '/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend/node_modules/@vitejs/plugin-react/dist/index.js';
export default defineConfig({root:'/home/dobo/work/_worktrees/cat_de_roman_esti/feat__v91-recovery-and-mobile-clarity/frontend',plugins:[react()],server:{host:'127.0.0.1',port:8190,strictPort:true,proxy:{'/api':{target:'http://127.0.0.1:8189',changeOrigin:true}}}});
