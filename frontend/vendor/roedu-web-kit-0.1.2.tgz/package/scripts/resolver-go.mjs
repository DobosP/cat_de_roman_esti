import * as fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {normalizeGoRequirements,auditGoModules} from './go-module-audit.mjs';
import {walkRepository} from '../lint/validation-files.mjs';
import {hash,sourceFile} from './resolver-files.mjs';
import {compare} from './resolver-policy.mjs';
const KIT='github.com/DobosP/roedu-ui/web-kit';
const modPath=dir=>dir==='.'?'go.mod':dir+'/go.mod';
export function discoverGo(root,config,plan,native) {
  const {files}=walkRepository(root,config),source=new Set(files),modules=new Map();
  const run=(args,cwd)=>{const child=spawnSync('go',args,{cwd,env:{...process.env,GOTOOLCHAIN:'local',GOWORK:'off',GOENV:'off'},encoding:'utf8',timeout:30000,maxBuffer:4*1024*1024});native.push({command:'go',args,cwd:path.relative(root,cwd)||'.',exit_code:child.status,stdout:child.stdout??'',stderr:child.stderr??'',stdout_sha256:hash(child.stdout??''),stderr_sha256:hash(child.stderr??'')});assert.ok(!child.error&&child.signal===null&&child.status===0,`Native Go resolver command failed: ${child.stderr||child.error?.message||child.status}`);return child.stdout;};
  function visit(dir) {
    if(modules.has(dir))return;const relative=modPath(dir);assert.ok(source.has(relative),`Go replacement is outside audited source: ${relative}`);
    const before=plan.read(relative),data=JSON.parse(run(['mod','edit','-json',sourceFile(root,relative)],path.dirname(sourceFile(root,relative))));
    assert.ok(plan.read(relative).equals(before),'Native Go parser changed source');
    const requirements=normalizeGoRequirements(data.Require??[],relative),replacements=data.Replace??[];
    assert.ok(typeof data.Module?.Path==='string'&&/^\d+\.\d+(?:\.\d+)?$/.test(data.Go),`Native module/Go identity required: ${relative}`);
    const local=new Set(),row={dir,relative,data,requirements,local,source_sha256:hash(before)};modules.set(dir,row);
    const sum=(dir==='.'?'':dir+'/')+'go.sum';if(source.has(sum))plan.read(sum);
    for(const replacement of replacements){assert.ok(replacement.Old&&replacement.New&&!replacement.New.Version,'Remote Go replacements refused');const name=replacement.Old.Path;assert.ok(requirements.some(x=>x.Path===name&&(!replacement.Old.Version||x.Version===replacement.Old.Version)),`Replacement has no requirement: ${name}`);local.add(name);if(name===KIT)continue;
      const literal=replacement.New.Path;assert.ok(typeof literal==='string'&&!path.isAbsolute(literal)&&!/[\\\x00-\x1f\x7f]/.test(literal)&&/^\.\.?\//.test(literal),'Literal same-repo Go replacement required');const absolute=path.resolve(root,dir,literal);assert.ok(absolute.startsWith(root+path.sep),'Go replacement escapes repository');const target=path.relative(root,absolute).split(path.sep).join('/');assert.ok(!target.split('/').some(p=>p.startsWith('.')||['kit','third_party','node_modules','vendor','dist','testdata','fixtures','cache','caches','_temp','_worktrees'].includes(p)),'Go replacement enters excluded source');sourceFile(root,modPath(target));visit(target);assert.equal(modules.get(target).data.Module.Path,name,'Local Go module identity differs');
    }
  }
  for(const dir of config.go_dirs)visit(dir);
  return {modules:[...modules.values()],files,run};
}
export function validateGoBaseline(root,config,lock,go,entries,native) {
  const baselines=new Map(go.modules.map(module=>[module.dir,{source_sha256:module.source_sha256,requirements:module.requirements}]));
  // Source baselines belong to individual native modules, never a last-wins
  // dependency map. Paths, replacements, each source checksum row and frozen
  // kit identity retain the existing auditor's checks. Selected/core floors
  // remain unchanged here and are enforced by metadata selection/write planning.
  const audited=auditGoModules({root,config,files:go.files,entries,lock,resolverInputBaselines:baselines});
  native.push(...audited.commands);
  return audited;
}
export function planGoWrites(root,config,go,entries,plan) {
  const gate=path.join(root,'.gate');if(fs.existsSync(gate))assert.ok(fs.lstatSync(gate).isDirectory()&&!fs.lstatSync(gate).isSymbolicLink(),'Resolver scratch must be regular');else fs.mkdirSync(gate);
  const directory=fs.mkdtempSync(path.join(gate,'resolver-plan-'));
  try {
    for(const [index,module] of go.modules.entries()) {
      const args=[];const runtime=entries.get('go');
      if(runtime){const version=module.data.Go.split('.').length===2?module.data.Go+'.0':module.data.Go;assert.ok(compare(runtime.version,version)>=0,`${module.relative}: higher Go directive refused`);if(runtime.version!==module.data.Go)args.push('-go='+runtime.version);}
      for(const req of module.requirements){if(module.local.has(req.Path))continue;const entry=entries.get(req.Path);if(!entry?.version||entry.kind!=='gomod')continue;assert.ok(compare(entry.version,req.Version)>=0,`${req.Path}: owning Go downgrade`);if(req.Version!==entry.version)args.push(`-require=${req.Path}@${entry.version}`);}
      if(!args.length)continue;const file=path.join(directory,index+'.mod');fs.writeFileSync(file,plan.read(module.relative));go.run(['mod','edit',...args,file],path.join(root,module.dir));plan.put(module.relative,fs.readFileSync(file));
    }
  }finally{fs.rmSync(directory,{recursive:true,force:true});}
}
