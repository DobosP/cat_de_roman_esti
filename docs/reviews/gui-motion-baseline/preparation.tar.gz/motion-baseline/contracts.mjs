import assert from "node:assert/strict";
import {boardFor,activeKey} from "./fixtures.mjs";
export async function poll(read,predicate,message,timeout=3000){
 const end=Date.now()+timeout;let value;
 do{value=await read();if(predicate(value))return value;await new Promise(r=>setTimeout(r,15));}while(Date.now()<end);
 assert.fail(message+"; final="+JSON.stringify(value));
}
export async function snapshot(page,game){
 return page.evaluate(({game,board,key})=>{
  const node=document.querySelector(board),raw=JSON.parse(localStorage.getItem("cat_wordgame_scores_v1")||"{}");
  const rec=raw[game];const receipts=raw._completionReceipts;
  return{mounted:!!node,path:location.pathname,
   tiles:node?[...node.querySelectorAll("button")].map(t=>({label:t.getAttribute("aria-label"),disabled:t.disabled,pressed:t.getAttribute("aria-pressed")})):[],
   hint:[...document.querySelectorAll("button")].filter(b=>b.textContent.includes("Arată indiciul")||b.textContent.includes("Arată o pereche")||b.textContent.includes("Indiciu ·")).map(b=>({disabled:b.disabled,text:b.textContent})),
   feedback:document.querySelector("."+game+"-feedback, .connections-feedback")?.textContent||"",
   active:localStorage.getItem(key),played:rec?.played||0,recent:rec?.recent?.length||0,receipts:receipts?.games?.[game]?.length||0,receiptIds:(receipts?.games?.[game]||[]).map(r=>r.id),
   rawScores:JSON.stringify(raw),transform:node?getComputedStyle(node.closest(".screen")).transform:null,
   opacity:node?getComputedStyle(node.closest(".screen")).opacity:null,reduced:matchMedia("(prefers-reduced-motion: reduce)").matches};
 },{game,board:boardFor(game),key:activeKey(game)});
}
export async function ready(page,fixture){
 await page.goto("/"+fixture.game);
 await poll(()=>snapshot(page,fixture.game),s=>s.mounted&&s.tiles.length>0&&s.tiles.every(t=>!t.disabled)&&s.opacity==="1","idle board never became enabled");
 await page.locator('.account-bar a[href="/clasament"]').waitFor();
 assert.equal(fixture.counts().uploads,0,"empty startup must not upload");
}
export async function depart(page,game){
 await page.evaluate(()=>document.querySelector('.account-bar a[href="/clasament"]').click());
 await poll(()=>snapshot(page,game),s=>s.path==="/clasament"&&s.mounted&&Number(s.opacity)<1,"leaving board did not remain mounted with an opacity exit",250);
 const s=await snapshot(page,game);assert.equal(s.mounted,true,"departure snapshot attached");
 return s;
}
export async function activateLeaving(page,game){
 return page.evaluate(board=>{
  const node=document.querySelector(board);if(!node)throw Error("leaving board detached before activation");
  const buttons=[...node.querySelectorAll("button")];for(const button of buttons)button.click();
  for(const button of document.querySelectorAll("button"))if(/Arată indiciul|Arată o pereche|Indiciu/.test(button.textContent))button.click();
  return{mounted:node.isConnected,buttons:buttons.length};
 },boardFor(game));
}
export async function trigger(page,game,kind="terminal"){
 if(kind==="hint")return page.getByRole("button",{name:game==="intrusul"?/Arată indiciul/:/Arată o pereche/}).click();
 const buttons=page.locator(boardFor(game)+" button");
 if(game==="intrusul")await buttons.first().click();
 else if(game==="perechi"){await buttons.nth(0).click();await buttons.nth(1).click();}
 else{for(let i=0;i<4;i++)await buttons.nth(i).click();await page.getByRole("button",{name:"Verifică",exact:true}).click();}
}
export function assertNoRecord(before,after){
 for(const k of ["played","recent","receipts","rawScores","active"])assert.deepEqual(after[k],before[k],"unexpected record/pointer change "+k);
}
export function assertCounts(before,after){
 assert.deepEqual(after,before,"unexpected API mutation/read/create/upload");
}
export function assertLocked(s){
 assert.equal(s.mounted,true,"old board must remain mounted");
 assert.ok(s.tiles.length>0,"nonempty retained board");
 assert.ok(s.tiles.every(t=>t.disabled),"all leaving tile controls must be disabled");
 assert.ok(s.hint.length>0,"eligible hint required, or no hint guard was exercised");
 assert.ok(s.hint.every(t=>t.disabled),"leaving hint control must be disabled");
}
export async function settledFrames(page){
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
}
export async function recordExactlyOnce(page,fixture,{anonymous=false}={}){
 const s=await poll(()=>snapshot(page,fixture.game),s=>s.played===1&&s.recent===1&&s.receipts===1&&s.active===null,"exactly one completion after present terminal/resume");
 assert.deepEqual(s.receiptIds,[fixture.id],"receipt belongs to completed synthetic round");
 await poll(()=>fixture.counts(),c=>c.uploads===(anonymous?0:1),"synthetic private upload count");
 await page.evaluate(()=>window.dispatchEvent(new Event("resize")));await settledFrames(page);
 const after=await snapshot(page,fixture.game);for(const k of ["played","recent","receipts"])assert.equal(after[k],1,"duplicate local "+k);
 assert.equal(fixture.counts().uploads,anonymous?0:1,"duplicate private score upload");
 return s;
}
export async function evidence(test,page,fixture,extra={}){
 assert.deepEqual(fixture.unexpected,[],"unexpected API/external request");
 await test.info().attach("motion-evidence",{body:JSON.stringify({
  provisional:true,source_commit:"bb99e81333b497ac90fc78e231d88d51367538db",project:test.info().project.name,
  snapshot:await snapshot(page,fixture.game),counts:fixture.counts(),ledger:fixture.ledger,scoreWrites:await page.evaluate(()=>window.__motionWrites),observerError:await page.evaluate(()=>window.__motionObserverError||null),...extra},null,2),contentType:"application/json"});
}

export async function sampleExit(page,game,count=5){
 return page.evaluate(async({board,count})=>{
  const rows=[];for(let i=0;i<count;i++){
   await new Promise(r=>requestAnimationFrame(r));const n=document.querySelector(board);
   if(!n)throw Error("leaving board detached during motion sampling");
   const frame=n.closest(".screen"),style=getComputedStyle(frame);
   rows.push({time:performance.now(),mounted:n.isConnected,transform:style.transform,opacity:Number(style.opacity)});
  }return rows;
 },{board:boardFor(game),count});
}
