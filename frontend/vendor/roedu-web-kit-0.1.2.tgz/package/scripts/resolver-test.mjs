import { readFileSync,writeFileSync,mkdtempSync,mkdirSync,rmSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
const root=process.cwd();
const records=JSON.parse(readFileSync('web-kit/testdata/versions/registry.json'));
// Fixture dates preserve observed day precision; synthetic tag mutation tests fallback.
// Current gen identities below are synthetic protocol inputs, never app qualification.
const base=JSON.parse(readFileSync('versions.lock.json'));
const dir=mkdtempSync('/scratch/_temp/resolver-test-');
try {
  mkdirSync(`${dir}/web-kit`);writeFileSync(`${dir}/package.json`,'{}');writeFileSync(`${dir}/web-kit/package.json`,JSON.stringify({name:'@roedu/web-kit'}));
  const config={role:'core',app:'roedu-ui',npm_dir:'web-kit',vendor_dir:'frontend/vendor',go_dirs:['web-kit']};
  writeFileSync(`${dir}/Taskfile.yml`,"version: '3'\nsilent: true\ntasks:\n  repo:kit-config:\n    cmds:\n      - node --input-type=module -e 'process.stdout.write("+JSON.stringify(JSON.stringify(config))+ ")'\n");
  const env={...process.env,GATE_VERSIONS_RESOLVE:'1',GATE_SHA:'a'.repeat(40),GATE_TREE_SHA256:'b'.repeat(64),TOOLCHAIN_DIGEST:'sha256:'+'c'.repeat(64)};
  const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
  mkdirSync(`${dir}/.gate/gen`,{recursive:true});
  const capture={schema:1,target:'gen',sha:env.GATE_SHA,tree_sha256:env.GATE_TREE_SHA256,toolchain_digest:env.TOOLCHAIN_DIGEST,config,config_sha256:hash(JSON.stringify(config))};
  const bytes=JSON.stringify(capture)+'\n';writeFileSync(`${dir}/.gate/gen/wrapper-kit-config.json`,bytes);
  writeFileSync(`${dir}/.gate/wrapper-current.json`,JSON.stringify({schema:1,invocation:randomUUID(),target:'gen',sha:capture.sha,tree_sha256:capture.tree_sha256,toolchain_digest:capture.toolchain_digest,config_sha256:capture.config_sha256,config_path:'.gate/gen/wrapper-kit-config.json',config_file_sha256:hash(bytes)})+'\n');
  const selected=base.tools.filter(e=>['preact','@babel/core'].includes(e.tool));
  const resolve=(tools,fixture=records)=>{
    writeFileSync(`${dir}/versions.lock.json`,JSON.stringify({...base,tools}));writeFileSync(`${dir}/fixture.json`,JSON.stringify(fixture));
    const out=spawnSync('bash',[path.join(root,'web-kit/scripts/resolve-versions.sh'),'--fixture',`${dir}/fixture.json`],{cwd:dir,env,encoding:'utf8'});return out;
  };
  assert.equal(resolve(selected).status,0,'recorded current stable resolution');
  assert.equal(JSON.parse(readFileSync(`${dir}/versions.lock.json`)).tools.find(x=>x.tool==='@babel/core').version,'7.29.7','approved Babel7 exception');
  const prerelease=structuredClone(records);prerelease['https://registry.npmjs.org/preact']['dist-tags'].latest='11.0.0-rc.4';
  assert.equal(resolve(selected,prerelease).status,0,'non-prerelease fallback');
  const higher=structuredClone(selected);higher[0].version='12.0.0';assert.notEqual(resolve(higher).status,0,'no downgrade');
  const unavailable=structuredClone(records);unavailable['https://registry.npmjs.org/preact'].versions={'11.0.0-rc.4':{}};unavailable['https://registry.npmjs.org/preact']['dist-tags'].latest='11.0.0-rc.4';assert.notEqual(resolve(selected,unavailable).status,0,'prerelease-only refusal');
  console.log('resolver fixtures: observed stable/Babel7, prerelease fallback, downgrade and unavailable stable guards');
}finally{rmSync(dir,{recursive:true,force:true});}
