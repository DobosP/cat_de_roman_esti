import { defineConfig } from 'vite';
import { roeduPreset } from '../vite-preset/index.mjs';
export default defineConfig(roeduPreset({base:'/static/',build:{outDir:'web-kit/sample/embedfs/dist',emptyOutDir:true,rolldownOptions:{input:'src/sample/main.ts'}}}));
