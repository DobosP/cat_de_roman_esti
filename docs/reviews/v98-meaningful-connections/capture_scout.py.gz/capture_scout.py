import hashlib,json,os
from pathlib import Path
os.environ.update(DJANGO_SETTINGS_MODULE="cat_de_roman_esti.web.settings",CAT_ACCOUNTS_ENABLED="0",CAT_DEBUG="0",ROEDU_API_URL="",ROEDU_API_KEY="")
import django
django.setup()
from cat_de_roman_esti.wordgames.service import get_service
from cat_de_roman_esti.wordgames.discovery_world import get_world,MAX_SUPPLIES
from cat_de_roman_esti.wordgames.lant_relations import caption,MAX_CAPTION_LENGTH
from cat_de_roman_esti.wordgames.recipe_extensions import digest,record_snapshot
ROOT=Path.cwd();OUT=ROOT/"docs/reviews/v98-meaningful-connections";svc=get_service();world=get_world()
kg=json.loads((ROOT/"cat_de_roman_esti/fixtures/kg_sample.json").read_bytes());by_edge={e["id"]:e for e in kg["kg_edges"]}
rows=[]
for edge_id,text in [("de8627","înghețată cu aromă de cacao"),("de8710","chec în variantă cu cacao"),("de5087","înghețată în variantă cu lapte"),("de8745","chec servit alături de lapte")]:
 raw=by_edge[edge_id];a,b=raw["src_id"],raw["dst_id"];edge=svc.link(a,b);assert edge.id==edge_id
 snap=record_snapshot(edge);assert caption(svc,a,b)=="legătură directă" and len(text)<=MAX_CAPTION_LENGTH
 rows.append({"edge_snapshot":snap,"edge_snapshot_sha256":digest(snap),"pair":sorted([a,b]),"labels":[svc.label(a),svc.label(b)],"current_caption":caption(svc,a,b),"draft_caption":text,"draft_characters":len(text),"reverse_allowed":svc.link(b,a) is not None,"reverse_caption":caption(svc,b,a),"review_status":"unreviewed"})
recipes=[]
for key,pair,result,needed,pitfall in [
 ("soup-tomato-cream",["alw_food_supa_rosii","n_v20gas_smantana"],"alw_food_supa_crema","A source showing prepared tomato soup becomes a smooth cream soup with fermented cream; a topping alone is insufficient.","Existing soup may contain rice; blending and texture must be substantiated. Fermented cream differs from sweet whipping cream."),
 ("soup-spinach-broth",["alw_food_mancare_spanac","n_v4gas_supa"],"alw_food_supa_crema","A source reusing the already cooked creamy spinach preparation with soup and any required homogenization.","Milk, flour and garlic in the existing preparation cannot disappear. Raw spinach recipes do not substantiate this reuse."),
 ("tart-creamed-spinach",["alw_food_foietaj","alw_food_mancare_spanac"],"alw_food_tarta","A source for the exact creamy cooked spinach preparation in an open puff-pastry tart, including binding and baking.","Raw spinach-and-cheese pie is insufficient; wet cooked filling may require steps that weaken the proposed pair.")]:
  assert all(i in world.concepts for i in [*pair,result]);installed=tuple(sorted(pair)) in world.recipes;assert not installed
  recipes.append({"scout_id":key,"pair":pair,"pair_labels":[world.concepts[i].label for i in pair],"result":result,"result_label":world.concepts[result].label,"pair_already_installed":installed,"concepts_to_add":0,"review_status":"unreviewed","evidence_needed":needed,"pitfall":pitfall})
used=sum(len(t.concept_ids) for t in world.catalog.unlocks)
record={"kind":"v98-unreviewed-caption-and-continuation-scout","baseline_commit":"240c4591f31c1b8bec59fb5680d4e66f5f0788fe","source_sha256":{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ["cat_de_roman_esti/fixtures/kg_sample.json","cat_de_roman_esti/fixtures/alchimie_discovery_world_v92.json","cat_de_roman_esti/wordgames/lant_relations.py","cat_de_roman_esti/wordgames/discovery_world.py"]},"captions":rows,"onward_recipe_research_candidates":recipes,"world":{"concepts":len(world.concepts),"recipes":len(world.recipes),"historical_books":len(world.compatible_versions),"supplies_used":used,"supplies_max":MAX_SUPPLIES,"outgoing_recipe_uses":{n:sum(n in pair for pair in world.recipes) for n in ["alw_food_supa_rosii","alw_food_mancare_spanac"]}},"limits":["No web source check or independent factual/quality approval has occurred for these drafts.","The existing kitchen mixer is a mixing/beating tool, not a blender. A new tool requires reachability/supply design; all96 supply slots are already used.","The five remaining world concept slots are separate from the shared KG vocabulary budget.","Masă in this KG means a meal; do not treat it as furniture."]}
(OUT/"unreviewed-scout.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
print("GREEN scout binding:4 draft captions,5 allowed directions,3 absent reverses,3 unreviewed recipe ideas,0 content writes")
