import {readFileSync,writeFileSync} from "node:fs";
import {spawnSync} from "node:child_process";
import {fileURLToPath} from "node:url";
const root=fileURLToPath(new URL("./",import.meta.url));
const label=process.argv[2]||"preview";
if(!/^[a-z0-9-]{1,48}$/.test(label))throw Error("label must be a short lowercase name");
const moduleRoot="/home/dobo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright";
const browser="/home/dobo/.cache/ms-playwright/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell";
const verified=spawnSync(process.execPath,["verify-frozen.mjs"],{cwd:root,encoding:"utf8"});
if(verified.status!==0)throw Error(verified.stdout+verified.stderr);
const version=JSON.parse(readFileSync(moduleRoot+"/package.json","utf8")).version;
const browserVersion=spawnSync(browser,["--version"],{encoding:"utf8"}).stdout.trim();
const receipt=root+"results/"+label+".json";
const result=spawnSync(process.execPath,[moduleRoot+"/cli.js","test","-c","playwright.config.mjs","--reporter=json","--output","results/"+label+"-artifacts"],{
 cwd:root,encoding:"utf8",maxBuffer:32*1024*1024,
 env:{...process.env,MOTION_PLAYWRIGHT_TEST_MODULE:"file://"+moduleRoot+"/test.mjs",MOTION_CHROMIUM_PATH:browser,
  TMPDIR:root+"runtime-tmp",PLAYWRIGHT_JSON_OUTPUT_NAME:receipt}
});
writeFileSync(root+"results/"+label+".log",result.stdout+result.stderr);
const data=JSON.parse(readFileSync(receipt,"utf8"));
writeFileSync(root+"results/"+label+"-provenance.json",JSON.stringify({
 provisional:true,formal_gate:false,source_commit:"bb99e81333b497ac90fc78e231d88d51367538db",frozen_verification:verified.stdout.trim(),
 node:process.version,node_executable:process.execPath,playwright:version,required_m0_playwright:"1.63.0",
 browser,browserVersion,browser_pair_matches_package:false,real_accounts_or_db:false,api:"synthetic local interceptions",
 exit_code:result.status,stats:data.stats,receipt},null,2)+"\n");
console.log(JSON.stringify({provisional:true,formal_gate:false,exit_code:result.status,stats:data.stats,receipt}));
process.exitCode=result.status||0;
