from pathlib import Path
import hashlib,json,ast
R=Path('/home/dobo/work/_worktrees/cat_de_roman_esti/codex__content-v1-7');S=Path('/home/dobo/work/_temp/codex__content-v1-7');D=R/'docs/reviews/v1-7-recognizable-content';p=D/'methods/ordinary_leafa_http_r1.go.txt'
s=p.read_text().replace('if privacy {for _,key','if privacy && reply["won"]!=true {for _,key').replace('map[string]any{"text":"leafă"},false)','map[string]any{"text":"leafă"},true)').replace('map[string]any{"text":"leafă","confirm":token},false)','map[string]any{"text":"leafă","confirm":token},true)')
s=s.replace('if current["won"]==true {obs["early_terminal"]=current;continue}',r'''if current["won"]==true {
   obs["early_terminal"]=current
   status,recovered:=request("early_terminal_get","GET",base,nil,false);if status!=200 {t.Fatal("earlyterminal GETstatus")};sameState("earlyterminal GET",recovered,current)
   for _,key:=range []string{"target","score","share"}{if !reflect.DeepEqual(recovered[key],current[key]){t.Fatal("earlyterminal recovery drift")}}
   body,ok:=current["target"].(map[string]any);if !ok || body["id"]!=target || body["label"]!=c.Labels[target]{t.Fatal("earlyterminal target mismatch")}
   cid,done,win,score,exists:=s.contexto.Progress(id);if !exists || cid!=curated || !done || !win || score!=number(current["score"]){t.Fatal("earlyterminal Progressdrift")}
   obs["hypothesis_hold"]="existing typed input wins or resolves early; no alias-growth benefit inferred"
   continue
  }''')
p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
wrapper=r'''"""Compile one exact temporary test source, remove it before executing the binary.
No data/content overlay or fixture write. The already-reviewed outer runner owns
this process group; catchable group signals reach the Go compiler and this wrapper.
SIGKILL/host loss cannot promise cleanup: preserve source and stop for inspection.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
R=Path('/home/dobo/work/_worktrees/cat_de_roman_esti/codex__content-v1-7')
S=Path('/home/dobo/work/_temp/codex__content-v1-7')
D=R/'docs/reviews/v1-7-recognizable-content'
SOURCE=D/'methods/ordinary_leafa_http_r1.go.txt'
TEMP=R/'go-backend/internal/httpapi/v17_ordinary_leafa_probe_test.go'
BINARY=S/'probe/ordinary-leafa-baseline-r1.test'
RECEIPT=S/'probe/ordinary-leafa-compile-lifecycle-r1.json'
EXPECTED='METHOD_SHA'
received=None

def on_signal(number,frame):
 global received
 if received is None: received=number

for signum in (signal.SIGTERM,signal.SIGINT):signal.signal(signum,on_signal)
if sys.argv != [str(Path(__file__)), 'build']:raise ValueError('exact build invocation required')
blob=SOURCE.read_bytes()
if hashlib.sha256(blob).hexdigest()!=EXPECTED:raise ValueError('method bytes differ')
if TEMP.exists() or TEMP.is_symlink() or BINARY.exists() or BINARY.is_symlink() or RECEIPT.exists() or RECEIPT.is_symlink():raise ValueError('owned destinations must be absent; no clobber/retry')
identity=None
code=None
cleanup=False
try:
 previous=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGINT})
 try:
  fd=os.open(TEMP,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as output:
   identity=os.fstat(output.fileno())
   output.write(blob);output.flush();os.fsync(output.fileno())
 finally:signal.pthread_sigmask(signal.SIG_SETMASK,previous)
 if received is not None:raise InterruptedError('catchable signal before compiler launch')
 command=[str(S/'tools/go/bin/go'),'-C',str(R/'go-backend'),'test','-c','-race','-o',str(BINARY),'./internal/httpapi']
 code=subprocess.run(command,check=False).returncode
 if code!=0:raise RuntimeError('compiler returned'+str(code))
 if received is not None:raise InterruptedError('catchable signal during compilation')
 if not BINARY.is_file() or BINARY.is_symlink():raise RuntimeError('compiled binary missing/notregular')
finally:
 if identity is not None:
  current=TEMP.lstat()
  if not stat.S_ISREG(current.st_mode) or (current.st_dev,current.st_ino)!=(identity.st_dev,identity.st_ino) or hashlib.sha256(TEMP.read_bytes()).hexdigest()!=EXPECTED:
   raise RuntimeError('temporary source changed: refuse to delete')
  TEMP.unlink();cleanup=True
 receipt={'schema':'v1-7-temporary-leafa-compile-lifecycle-r1','method_sha256':EXPECTED,'temporary_source':str(TEMP),'temporary_source_removed':cleanup,'binary_path':str(BINARY),'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest() if BINARY.is_file() else None,'compiler_exit_code':code,'caught_signal':received,'content_overlay_used':False,'installation_approval':False}
 with RECEIPT.open('x') as out:json.dump(receipt,out,sort_keys=True,indent=2);out.write('\n');out.flush();os.fsync(out.fileno())
'''.replace('METHOD_SHA',sha(p))
q=D/'methods/ordinary_leafa_compile_lifecycle_r1.py.txt';q.write_text(wrapper);ast.parse(wrapper)
# Copy scripts only into own scratch; no native execution is performed.
(S/'probe/ordinary_leafa_compile_lifecycle_r1.py').write_text(wrapper)
base=json.load(open(D/'native-baseline-admission.json'))
plan={'schema':'v1-7-ordinary-leafa-baseline-method-r1','baseline_commit':'b2c471dad743179cb34038560f742c2ede180844','preparation_admission_sha256':sha(D/'ordinary-leafa-method-preparation-admission-r1.json'),'method_sha256':sha(p),'method_path':str(p.relative_to(R)),'compile_lifecycle_sha256':sha(q),'compile_lifecycle_path':str(q.relative_to(R)),'compile_lifecycle_scratch':str(S/'probe/ordinary_leafa_compile_lifecycle_r1.py'),'runner_path':str(S/'probe/run_owned_full_scratch_lane.py'),'runner_sha256':'397686a51c5f03f207cc450fceda8b88623383a83ab2ecb90a884e6167fa91ee','later_primary_access_receipt_sha256':'1859d56a7f49ac7822ac3fc6d9c4cbb2d053f17f92377bd8354d2be8582a6822','prior_method_pins':{str(x.relative_to(R)):sha(x) for x in [R/'docs/reviews/v1-6-everyday-inputs/methods/qualified_input_http_r1.go.txt',R/'docs/reviews/v1-6-everyday-inputs/methods/native_input_baseline_test.go.txt']},'case':{'curated_id':'ct_societate_090','target_id':'n_bnr','owner_id':'n_v4soc_salariu','novel':'leafă','canonical':'Salariu','category':'societate','difficulty':'normal','approved':True,'pilot_eligible':True,'max_picker_draws':128,'seed_range_inclusive':[0,127],'sessions':2,'arms':['alias_first','canonical_first'],'max_requests':80,'extra_nonwinning_labels':['Bani','Impozit'],'observed_not_assumed':['novel unknown/suggestions/confirmation/direct response','canonical rank/distance/closeness/temperature'],'normal_terminal_contract':'3unique nonwinning guesses, earned category clue, attempt4/oneclue/700points; unexpected existing wins retained separately and hold hypothesis'},'write_scope':'D methods/plan and own S only; compile temporarily creates exact exclusive probe test source and deletes it before binary execution. No pool/runtime/fixture/Source7/content-overlay/private-session-injection edits.','protected_inputs':base.get('unchanged',{}),'scratch_bindings':base.get('scratch_bindings',{}),'commands_before_admission_template':[{'name':'qualified-go-version','argv':[str(S/'tools/go/bin/go'),'version']},{'name':'compile-exact-temp-probe-race','argv':['/home/dobo/work/cat_de_roman_esti/.venv/bin/python',str(S/'probe/ordinary_leafa_compile_lifecycle_r1.py'),'build']},{'name':'ordinary-sealed-source6-leafa-baseline','argv':['/usr/bin/env','-u','CAT_KG_FIXTURE','-u','CAT_GAMES_PACK','-u','CAT_BOARD_RANKINGS',str(S/'probe/ordinary-leafa-baseline-r1.test'),'-test.run=^TestV17OrdinaryLeafaBaseline$','-test.timeout=3m','-test.count=1','-test.v']}],'environment':{'V17_LEAFA_ROOT':str(R),'V17_LEAFA_REPORT':str(S/'probe/ordinary-leafa-baseline-r1.json'),'CAT_ALLOWED_HOSTS':'testserver,example.com'},'native_not_executed':True,'independent_method_acceptance_required':True,'separate_fresh_native_admission_required':True,'limits':{'start_disk_floor_bytes':17*2**30,'remaining_disk_memory_floor_bytes':16*2**30,'RSS_bytes':2*2**30,'incremental_bytes':2**30,'GOMAXPROCS':2,'build_jobs':2,'metadata_reserve_seconds':180,'campaign_seconds_max':1200},'measurement_roots':[str(S),str(R)],'additional_measure_dirs':[],'scope_caveats':['In-process HTTP only; no browser/TCP/human fun proof.','Controlled pre-reviewed seed search uses ordinary public-supported category/difficulty filter; no forced curated target.','Source worker RSS unmeasured; no source-memory PASS.','Research baseline is not synonym/raw installation acceptance or Source7 authority.','If fixed case absent in128draws or novel already accepted/earlywins, retain truthful held result without broadening search or inventing approval.']}
(D/'ordinary-leafa-baseline-method-proposal-r1.json').write_text(json.dumps(plan,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
for x in [p,q,D/'ordinary-leafa-baseline-method-proposal-r1.json']:print(x.name,sha(x))
print('protected count',len(plan['protected_inputs']),'scratchcount',len(plan['scratch_bindings']))
