Valid until: the reviewed app base, harness, core pin or binding schema changes — then regenerate reviewed bindings and treat this preparation as history.

# Motion import preparation

Scratch-only preparation is complete. The app, ADRs, content and original motion-baseline directory are untouched.

This package has separate profiles:
- baseline-diagnostic: exactly29 original cases (18 motion-on,11 reduce), including the two frozen Conexiuni leakage observations and three oracle controls. Its result is diagnostic-only.
- target-acceptance: exactly48 future browser cases (25 motion-on,23 reduce). It excludes the leakage/three oracle expectations, retains24 framework-neutral contracts, and adds24 Conexiuni checks. These browser specs are NOT_YET_QUALIFIED and have never run.

The completed original baseline remains29/29 under cached Playwright1.62.1/Chromium revision1243. Its three executed controls prove DOM/request/storage oracle sensitivity. Six source mutation variants remain uncompiled and unexecuted. Nothing here promotes that preview to target or full-gate evidence.

## Concrete artifacts

- profiles.json: exact project + absolute file + complete title inventories.
- original-baseline-seal.json:224 original artifact hashes, including assertions and failed-preview history.
- target/tests/: copied unchanged Intrusul/Perechi assertion files and new Conexiuni negative/positive controls.
- target/conexiuni-model.mjs: private synthetic catalog with native-shaped public live/terminal projections; only unsolved tiles before terminal, response-only fields stripped from GET, group-by-group completion, native mistake/clue score economy.
- target/conexiuni-fixtures.mjs: independent exact mutation/GET holds, explicit committed/precommit503,404 and newer-pointer state.
- target/conexiuni-contracts.mjs: retained-screen, eligible-control, focus, no-adoption and exact authoritative-resume assertions.
- policy.mjs / io.mjs: fail-closed identity, inventory, receipt and file guards.
- launch.mjs / playwright.config.mjs / runner-api.mjs: mandatory profile and fresh-run entry, forbidOnly, actual served assets/media and effective-config witness.
- templates/: incomplete input examples with status NOT_YET_QUALIFIED; no owner ACK, source build or image observation has been invented.
- unit/: executed synthetic adversarial policy/fake-process/model tests and preserved logs.
- preparation.json: actual checks and qualification limits.
- prepared-files.json: import-package hashes.

## New Conexiuni target expectations

Both projects contain present-completion positive control; retained tiles/clear/shuffle/verify/clue locks; guess/body-Enter and independent clue inactivity; held terminal/clue503 cancellation; one fresh authoritative resume; committed-terminal recovery GET cancellation; old404 protection for a newer pointer; committed-clue recovery; stale recovery503; and stale recovery404 with the same pointer.

A held response is bound to its exact ledger row. Successful delivery requires the expected HTTP status; failure is accepted only with explicit net::ERR_ABORTED client-cancellation evidence. Old controls/screens must remain mounted during assertions. New feedback/clue/result/recovery, focus movement, storage writes and extra requests are forbidden. Resume checks nonempty exact remaining tiles/order/lives/solved groups/clues/pointer, then rechecks counters after settling. A held fresh GET prevents an old delayed record being misclassified as legitimate resume completion.

This is a future complete motion subgate for all three routes. It is not a substitute for M0's React baseline, M2's differently scoped pilot, CSP/a11y/native/content/PG qualification or the final full gate. Perechi must also be served by the target shell before this complete profile can pass; filtering it out is forbidden.

## Strict launch contract

The sole accepted command has three inputs:

    node launch.mjs baseline-diagnostic /absolute/reviewed-binding.json <reviewed-sha256>
    node launch.mjs target-acceptance /absolute/reviewed-binding.json <reviewed-sha256>

No project, grep, shard, repeat, last-failed, file, snapshot-update or extra arguments are accepted. Ambient MOTION/IMPORT/PLAYWRIGHT/PW_TEST/preload/npm/Docker overrides are rejected by name. The fixed launcher controls child argv/environment.

Each run gets a new exclusive UUID directory. A preexisting report path is refused/cleared only in that new directory; no original evidence is deleted. Launch error, signal, nonzero or null status fails before receipt reading. Report absence, stale timestamp, wrong nonce/descriptor, missing/extra/duplicate cases, aggregate mismatch, retries/skips/expected failures, filtering, wrong runner/config and snapshot updates all fail. Descriptor integrity is recomputed.

Receipt success means diagnostic-only or motion-subgate-evidence-only, always formal_gate=false. Source-mutant execution remainsfalse. Exit0 alone is insufficient.

## Source, build, runtime and browser binding

Inputs must come from the reviewed pinned gate and match their externally supplied reviewed content digest. Template files are intentionally inadmissible. They describe requirements, not observations.

- Frozen profile: copied110 source/config/static files must match canonical Git objects at bb99e81333b497ac90fc78e231d88d51367538db; changing copy and local manifest together still fails. The original224-file seal is checked. All30 canonical assets and the historical1.62.1/revision1243 scope are bound; source reproduction is explicitlyfalse.
- Target: clean current HEAD/tree and source-set hash; protected API/asyncControl/scores/action ownership bytes; core pin; canonical repository versions.lock.json; current reviewed build receipt with source/tree/assets/toolchain/version hashes. Frozen assets/entry cannot satisfy the target.
- Runtime: a current container ID is inspected through the fixed local Unix Docker socket for ID, image, running state, published ports/network IPs. App port or app DNS must address that inspected container. The build's produced image must equal the running image. A copied attestation alone is insufficient. The image_digest field here means Docker's immutable .Image SHA256 image/config ID; distribution manifest digests are separate.
- Browser: Playwright CLI/test module/core versions; complete installed package/core file closure; actual Node executable/hash/version; browser executable/hash/version/cache revision paired with package metadata. Target requires the reviewed1.63.0 triple.
- Browser witness: actual data-ui, media preference, exact HTML script entries, no unbound executable inline scripts, actual fetched JS/CSS/font/assets hashes including manifest record.assets. Unknown frontend assets and the frozen SPA entry body are rejected even if loaded through a new bootstrap. Script/style/font requests and every script/asset witness must also have the exact bound origin; a matching pathname from another port cannot borrow a genuine local preload.
- Before/after: source/build/runtime/browser/harness state is recomputed; drift fails. Exact argv/config, effective grep/invert, snapshot mode and reported runner version are recorded/checked. Report times later than completion fail.

Live runtime inspection and browser witnessing are prospective code paths. They were not executed in this preparation. The current single-process placement is incompatible with the planned runner/private-app topology; the blocking requirement below must be resolved before named-gate import. Denied access fails closed. Build/runtime receipt adapters and their reviewed placement are not yet supplied. No current target binding exists.

If moved into an authorized S1 worktree, regenerate the absolute inventory paths and package-hash manifest as a reviewed import change, then generate new bindings. Do not reuse scratch bindings or historical receipt labels. A settled React M0 baseline needs its own reviewed current-base binding; this historical frozen diagnostic deliberately remains on bb99e8.

## Blocking core integration: process and network placement

The prototype cannot simply be copied into the planned pinned compose runner. io.mjs:102/156–163 synchronously invokes host Docker CLI/socket inspection, while launch.mjs:19–20 starts Playwright in the same placement. The planned runner has no Docker CLI/socket mount; the app is private with no host-published ports and is reached as http://app:8080 from the compose network (canonical pack/bootstrap/compose.gate.yml:4,11–21,40,65–84; Dockerfile.toolchain:23–29).

This is an unresolved, BLOCKING core integration requirement for named-gate import/target qualification. Prototype named-gate portability is NOT_QUALIFIED. Running the whole prototype on the host does not establish pinned-runner/private-app execution; running it wholly in the runner cannot perform the current inspection.

CORE_REQUEST-draft.md proposes a core-reviewed host-wrapper before/after live-runtime witness, scoped runner adapter and shared nonce/source/build/image/browser provenance, or another compatible reviewed placement. The draft is unassigned and has not been registered in another repository. No bridge is implemented. Socket exposure/mounts, published ports, generic host RPC, wrapper bypass or reduced checks are not authorized solutions.

All execution counts remain unchanged:69 Node checks;48 future browser cases unexecuted. The original29-case preview and its three oracle controls remain provisional; all six source mutants remain unexecuted.

## Checks actually run

69/69 focused Node tests passed, zero failures/skips/todos. They use synthetic receipts, fake child process outcomes, fake runtime/image metadata and public filesystem fixtures. Coverage includes killed/null-status child with stale passing receipt; complete/count-preserving inventory substitutions; profile mixing; changed source/build/image/browser/Node/dependency witnesses; altered copy+manifest; extra/frozen bootstrap scripts; assets-only manifest references; filters matching all cases; timestamp/config/version drift; canonical file containment; and native-shaped synthetic Conexiuni projection/scoring.

Original224-file seal and canonical110-file Git binding pass. Every copied assertion file matches the original byte hash. New source passes Node syntax checks.

No browser matrix was rerun, no future-target browser case was executed, no real Docker/container or app image was probed, no source mutant was compiled, and no app source/build/ADR/content changed. Earlier Node-only failed assertion logs remain preserved.

## Next action

Parent first resolves CORE_REQUEST-draft.md through the reviewed core wrapper/placement, then finishes base/content/ADR coordination and core/bootstrap and explicitly dispatches S1. This prototype cannot yet be imported as a portable named gate. Review/import the resolved adapter and bindings under that authorized worktree. Run the appropriate current React baseline and later target profile on the real pinned runner before claiming qualification. Keep frozen leakage diagnostics outside target acceptance.
