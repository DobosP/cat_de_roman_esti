import {createServer} from "node:http";
import {readFile} from "node:fs/promises";
import {resolve, extname} from "node:path";
import {fileURLToPath} from "node:url";
const root=fileURLToPath(new URL("./frozen/cat_de_roman_esti/web/static/",import.meta.url));
const port=Number(process.env.MOTION_PREVIEW_PORT||8936);
if(!Number.isInteger(port)||port<1024||port>65535)throw Error("invalid preview port");
const types={".js":"text/javascript",".css":"text/css",".woff2":"font/woff2",".html":"text/html",".json":"application/json"};
const server=createServer(async(req,res)=>{
 const path=decodeURIComponent(new URL(req.url,"http://127.0.0.1").pathname);
 if(path==="/__preview_health"){res.writeHead(200,{"Content-Type":"application/json"});res.end('{"provisional":true}');return;}
 if(path.startsWith("/api/")){res.writeHead(501);res.end("API must be intercepted synthetically");return;}
 const target=path.startsWith("/assets/")?resolve(root,"."+path):resolve(root,"index.html");
 if(!target.startsWith(root)){res.writeHead(403);res.end();return;}
 try{const bytes=await readFile(target);res.writeHead(200,{"Content-Type":types[extname(target)]||"application/octet-stream","Cache-Control":"no-store"});res.end(bytes);}
 catch{res.writeHead(404);res.end();}
});
server.listen(port,"127.0.0.1",()=>console.log("PROVISIONAL frozen React preview port="+port));
for(const signal of ["SIGINT","SIGTERM"])process.on(signal,()=>server.close(()=>process.exit(0)));
