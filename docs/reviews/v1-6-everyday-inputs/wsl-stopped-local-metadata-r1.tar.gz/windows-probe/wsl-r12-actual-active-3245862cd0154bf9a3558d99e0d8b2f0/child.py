import json,os,pathlib,signal,subprocess,sys,time
marker=pathlib.Path(sys.argv[1])
grand=subprocess.Popen([sys.executable,"-c","import time; time.sleep(60)"])
def identity(pid):
 f=pathlib.Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
 return {'pid':pid,'pgid':int(f[2]),'sid':int(f[3]),'start_ticks':int(f[19])}
def stopped(signum,frame):
 try:
  grand.terminate()
  grand.wait(timeout=1)
 except ProcessLookupError:
  pass
 finally:
  raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stopped)
signal.signal(signal.SIGINT,stopped)
marker.write_text(json.dumps({'child':identity(os.getpid()),'grandchild':identity(grand.pid)}))
while True: time.sleep(.1)
