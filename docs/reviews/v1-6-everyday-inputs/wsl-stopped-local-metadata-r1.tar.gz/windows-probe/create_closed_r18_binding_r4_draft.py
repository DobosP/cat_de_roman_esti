import hashlib,json,pathlib,re
R=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_worktrees/cat_de_roman_esti/codex__content-v1-6')
S=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-6')
D=R/'docs/reviews/v1-6-everyday-inputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def linux(p):
 parts=p.parts
 assert p.drive=='C:'
 return '/mnt/c/'+p.as_posix()[3:]
parent_path=D/'wsl-r12-actual-active-r18-parent.json'
parent=json.loads(parent_path.read_bytes())
assert parent['exit_code']==0 and parent['elapsed_seconds']<=30 and parent['fixture_sha256']=='TO_BE_BOUND'
nonce=parent['nonce'];assert re.fullmatch('[a-f0-9]{32}',nonce)
directory=S/'probe'/('wsl-r12-actual-active-r18-'+nonce)
manifest_path=directory/'admission.json'
manifest=json.loads(manifest_path.read_bytes())
check_path=directory/'check-result.json';check=json.loads(check_path.read_bytes())
assert check['passed'] and check['work_finished_elapsed_seconds']<=24 and check['elapsed_seconds']<=30
lane=manifest['lane'];assert re.fullmatch('r18-active-[a-f0-9]{16}',lane)
binding={'schema':'v1-6-r12-exact-closed-failed-lane-refusal-binding-r1','lane':lane,'active_fixture_sha256':parent['fixture_sha256'],'original_start_size':752431588,'expected_deadline_utc':manifest['deadline_utc'],'pins':manifest['inputs']}
for key,path in {'manifest':manifest_path,'active_check':check_path,'state':S/'probe'/(lane+'-r4-r2-state.json'),'cumulative_result':D/(lane+'-result.json'),'step0':D/(lane+'-step-0-result.json'),'active_parent':parent_path}.items():
 assert path.is_file() and not path.is_symlink()
 binding[key]={'path':linux(path),'sha256':sha(path)}
output=D/'wsl-r12-failed-lane-refusal-binding-r4.json'
data=(json.dumps(binding,sort_keys=True,indent=2)+'\n').encode()
with output.open('xb') as f:f.write(data)
print(json.dumps({'path':str(output),'sha256':hashlib.sha256(data).hexdigest(),'lane':lane,'original_deadline_utc':manifest['deadline_utc'],'new_admission_or_clock':False}))
