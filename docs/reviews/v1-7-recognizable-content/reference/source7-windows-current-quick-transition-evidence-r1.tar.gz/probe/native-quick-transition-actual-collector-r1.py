import pathlib,json,hashlib,time,stat,os,shutil,ctypes,datetime
S=pathlib.Path(r'C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7');O=S/'source7-current-quick-transition-r1';P=S/'probe'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def put(p,j):
 b=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return hashlib.sha256(b).hexdigest()
spec=json.loads((P/'native-quick-transition-spec-r1.json').read_bytes());raw=(P/'native-quick-transition-common-r2.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==spec['common_sha256']
ns={};exec(compile(raw,str(P/'native-quick-transition-common-r2.py'),'exec'),ns);ns['validate_contract'](spec);ns['full_readset'](spec,'windows',True);ns['check_transition_inputs'](spec,'windows')
state=json.loads((O/'run/state.json').read_bytes());assert state['kind']=='passed' and len(state['completed'])==1 and state['stage_only_target_changed'] and state['stage_modes_preserved']
assert sha(O/'run/state.json')=='8329994bd45a0c26bc75d14ce4cb7e86d17cfaf2878e840ac83408e9e0b6c738'
events=[ns['load_json'](b) for b in (O/'run/quick-transition.telemetry.jsonl').read_bytes().splitlines()]
assert len([x for x in events if x['kind']=='complete'])==1 and not any(x['kind']=='failed' for x in events)
complete=next(x for x in events if x['kind']=='complete');out=next(x for x in events if x['kind']=='quick-output')
assert complete['returncode']==0 and complete['group_absent'] is True and complete['native_peak']==254595072
stdout=(O/'run/quick-transition.stdout.log').read_bytes()
assert ns['json_equal'](ns['load_json'](stdout),{'mode':'write','ok':True,'rail':'quick'})
for name in ['quick-transition.stderr.log','quick-transition.controller.stderr.log']:assert (O/'run'/name).read_bytes()==b''
assert out['output_sha256']==spec['new_target_sha256'] and out['proposal_sha256']==spec['new_target_sha256'] and out['stdout_sha256']==hashlib.sha256(stdout).hexdigest()
put(S/'native-quick-transition-outer-observation-r1.json',{'kind':'root outer-tool-return transcription','session_id':28943,'outer_exit_code':0,'native_summary':{'kind':'PASS','completed':1,'parent_inclusive_peak':413917184,'growth':4430399},'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exact_outer_observation_timestamp_not_durably_recorded':True,'native_raw_evidence_separate':True})
closure={'kind':'root targeted closure tool-return transcription','Windows_queried_utc':'2026-10-09T15:41:02.7202736Z','Windows_recorded_generations':state['windows_generations'],'Windows_present':[],'Windows_matching_owned_argv':[],'Linux_queried_epoch':1791560461.7499216,'Linux_recorded_identities':{'337604':2958844,'337455':2954366},'Linux_present':[],'Linux_owned_group_or_session':[],'Linux_available_bytes':57018695680,'scope':'recorded Windows generations and recorded Linux leader/supervisor/nativePGID/session absent; no wholeOS unsampledprocess inventory claim'}
put(S/'native-quick-transition-owner-closure-r1.json',closure)
I=pathlib.Path(spec['windows_stage']);target=pathlib.Path(spec['windows_target']);after=O/'quick_games_v92.after.json'
with after.open('xb') as f:f.write(target.read_bytes())
assert after.read_bytes()==pathlib.Path(spec['windows_proposal']).read_bytes()
expected=dict(spec['stage_files']);expected[spec['target_relative']]=spec['new_target_sha256']
post={'kind':'exact-I1200-after-isolated-Quick-transition-v1','stage_files':expected,'stage_dirs':spec['stage_dirs'],'windows_file_modes':spec['windows_file_modes'],'windows_dir_modes':spec['windows_dir_modes'],'Linux_file_modes':spec['linux_file_modes'],'Linux_dir_modes':spec['linux_dir_modes'],'root_fresh_full_post_readback_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_Linux_fullpost_verified_by_guard':True,'only_changed_relative':spec['target_relative'],'stage_namespace_count':1200,'stage_directory_count_including_root':224,'before_sha256':spec['old_target_sha256'],'after_sha256':spec['new_target_sha256'],'base_I1200_archive_unchanged':'5d0ae406 archived Source7 candidate; forward reconstruction changes exactlyQuick target to preserved after-image'}
put(S/'native-quick-transition-post-I1200-r1.json',post)
def count(root):
 pending=[root];total=files=dirs=0
 while pending:
  p=pending.pop();a=p.lstat();assert stat.S_ISDIR(a.st_mode) and not stat.S_ISLNK(a.st_mode) and not getattr(a,'st_file_attributes',0)&0x400;dirs+=1
  with os.scandir(p) as es:
   for e in es:
    st=e.stat(follow_symlinks=False);assert not stat.S_ISLNK(st.st_mode) and not getattr(st,'st_file_attributes',0)&0x400
    if stat.S_ISDIR(st.st_mode):pending.append(pathlib.Path(e.path))
    else:assert stat.S_ISREG(st.st_mode);total+=st.st_size;files+=1
  b=p.lstat();assert (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino) and stat.S_ISDIR(b.st_mode) and not getattr(b,'st_file_attributes',0)&0x400
 return dict(bytes=total,files=files,dirs=dirs)
counts={p:count(pathlib.Path(p)) for p in spec['accounting_roots']};total=sum(x['bytes'] for x in counts.values());G=1<<30
class M(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ['total','available','tp','ap','tv','av','extra']]
m=M();m.length=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
assert total-spec['full_R_S_baseline']+(8<<20)<=G and shutil.disk_usage(I).free-(8<<20)>=16*G and m.available>=16*G and time.time()<spec['deadline_epoch']
result={'kind':'actual-isolated-Quick-catalog-transition-v1','passed':True,'native_state_sha256':sha(O/'run/state.json'),'spec_sha256':sha(P/'native-quick-transition-spec-r1.json'),'admission_sha256':sha(S/'native-quick-transition-actual-admission-r1.json'),'dispatch_marker_sha256':sha(P/'native-quick-transition-dispatch-approval-r1.json'),'source_boundary_sha256':sha(S/'quick-transition-source-boundary-r1.json'),'before_target_sha256':sha(O/'quick_games_v92.before.json'),'after_target_sha256':sha(after),'before_bytes':(O/'quick_games_v92.before.json').stat().st_size,'after_bytes':after.stat().st_size,'fullI1200_only_target_changed':True,'all1199_other_bytes_namespace_modes_preserved':True,'post_manifest_sha256':sha(S/'native-quick-transition-post-I1200-r1.json'),'original_started_epoch':spec['started_epoch'],'original_cutoff_epoch':spec['deadline_epoch']-180,'original_deadline_epoch':spec['deadline_epoch'],'finished_epoch':state['finished_epoch'],'parent_inclusive_sampled_peak':413917184,'native_peak':254595072,'native_final_growth':4430399,'native_processes':state['completed'][0],'Windows_generations':state['windows_generations'],'closure_sha256':sha(S/'native-quick-transition-owner-closure-r1.json'),'owner_active':False,'raw_stdout_sha256':hashlib.sha256(stdout).hexdigest(),'raw_stderr_empty':True,'telemetry_events':len(events),'telemetry_sha256':sha(O/'run/quick-transition.telemetry.jsonl'),'current_counts_before_result':counts,'current_growth_before_result':total-spec['full_R_S_baseline'],'metadata_headroom_reserved':8<<20,'disk_free_bytes':shutil.disk_usage(I).free,'Windows_available_bytes':m.available,'Linux_last_available_bytes':57018695680,'Linux_last_available_epoch':1791560461.7499216,'metadata_RSS':'unmeasured','RSS_scope':'sampled PowerShell parent+controller+WSLcarrier+Linuxsupervisor/ownednativegroup; consolehelper/source/reviewer/metadata workers excluded; no continuous/wholeOS claim','source6_live':True,'V1_7_installed':False,'scope':'one isolated scratch Quick catalog update only; previous1c6audit/finals are pretransition history','next':'reviewed current5fileQuickpin/assertionupdate, freshaffectedproducer, freshinstalledQuickaudit/SAMErolesfinals, eligibleauthoritycopies and allSource7/fullversiongates'}
put(S/'native-quick-transition-actual-results-r1.json',result)
print(json.dumps({'result_sha256':sha(S/'native-quick-transition-actual-results-r1.json'),'post_manifest_sha256':sha(S/'native-quick-transition-post-I1200-r1.json'),'telemetry_events':len(events),'current_growth':result['current_growth_before_result'],'owner_active':False,'epoch':time.time()}))
