export type ToastKind = 'info' | 'success' | 'error';
export interface ToastData {
    /** Unique, monotonically increasing id (the stack renders in id order). */
    id: number;
    kind: ToastKind;
    message: string;
}
export interface ToastStackProps {
    toasts: ToastData[];
    /** Called when a toast is clicked; the host owns the list + auto-dismiss timers. */
    onDismiss: (id: number) => void;
}
/**
 * Stacked toast overlay, centered at the top of the viewport. Presentational:
 * the host owns the toast list and dismissal timing; the stack animates entries
 * in and briefly retains removed toasts to animate them out (CSS only).
 */
export declare function ToastStack({ toasts, onDismiss }: ToastStackProps): import("react").JSX.Element;
