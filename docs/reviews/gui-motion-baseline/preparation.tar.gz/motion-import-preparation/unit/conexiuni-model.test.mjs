import test from "node:test";
import assert from "node:assert/strict";
import {newSyntheticSession,publicConexiuni,applySyntheticAction} from "../target/conexiuni-model.mjs";
test("near-win live public state hides solved tiles and solution",()=>{
 const s=newSyntheticSession("synthetic",{nearWin:true});const p=publicConexiuni(s);
 assert.equal(p.tiles.length,4);assert.equal(p.solved_count,3);assert.equal(p.clue_available,false);
 for(const key of ["solution","score","ok","correct","category","clue"])assert.equal(Object.hasOwn(p,key),false);
 const r=applySyntheticAction(s,"guess",{ids:p.tiles.map(t=>t.id)});
 assert.equal(r.won,true);assert.equal(r.tiles.length,16);assert.equal(r.score,1000);assert.equal(r.solution.length,4);
 assert.equal(Object.hasOwn(publicConexiuni(s),"correct"),false);
});
test("synthetic guess solves only its submitted group",()=>{
 const s=newSyntheticSession("synthetic",{mistakes:2});const r=applySyntheticAction(s,"guess",{ids:s.groups[0].tiles.map(t=>t.id)});
 assert.equal(r.won,false);assert.equal(r.solved_count,1);assert.equal(r.tiles.length,12);assert.equal(Object.hasOwn(r,"score"),false);
 for(const group of s.groups.slice(1))applySyntheticAction(s,"guess",{ids:group.tiles.map(t=>t.id)});
 assert.equal(publicConexiuni(s).score,500);
});
test("earned clue state has native counters without response-only fields",()=>{
 const s=newSyntheticSession("synthetic",{mistakes:2});const r=applySyntheticAction(s,"clue");
 assert.equal(r.clues_used,1);assert.equal(r.clue_available,false);assert.equal(r.clues.length,1);assert.ok(r.clue);
 const p=publicConexiuni(s);assert.equal(Object.hasOwn(p,"clue"),false);assert.equal(Object.hasOwn(p,"ok"),false);
 for(const group of s.groups)applySyntheticAction(s,"guess",{ids:group.tiles.map(t=>t.id)});
 assert.equal(publicConexiuni(s).score,400);
});
test("newer zero-mistake round and malformed mutations are bounded",()=>{
 const s=newSyntheticSession("newer");assert.equal(publicConexiuni(s).tiles.length,16);assert.equal(publicConexiuni(s).clue_available,false);
 assert.throws(()=>applySyntheticAction(s,"clue"));
 assert.throws(()=>applySyntheticAction(s,"guess",{ids:["fixture-0","fixture-0","fixture-1","fixture-2"]}));
 assert.equal(publicConexiuni(s).solved_count,0);
});
