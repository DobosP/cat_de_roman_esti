from pathlib import Path
import datetime,hashlib,json,shutil
R=Path('/home/dobo/work/_worktrees/cat_de_roman_esti/codex__content-v1-7');S=Path('/home/dobo/work/_temp/codex__content-v1-7');D=R/'docs/reviews/v1-7-recognizable-content';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.load(open(D/'ordinary-leafa-baseline-method-proposal-r2.json'))
now=datetime.datetime.now(datetime.timezone.utc)
free=shutil.disk_usage(R).free
mem=next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
assert free>=17*2**30 and mem>=16*2**30,(free,mem)
for n,h in p['protected_inputs'].items():assert sha(R/n)==h,n
for n,h in p['scratch_bindings'].items():assert sha(Path(n))==h,n
for x in [R/'go-backend/internal/httpapi/v17_ordinary_leafa_probe_r2_test.go',S/'probe/ordinary-leafa-baseline-r2.test',S/'probe/ordinary-leafa-baseline-r2.json',S/'probe/ordinary-leafa-compile-lifecycle-r2.json']:
 assert not x.exists() and not x.is_symlink(),x
review=D/'ordinary-leafa-baseline-method-review-r2.json'
assert sha(review)=='b7d63da3c94e6d34dfdf9e0cc183426d256d9dcae1de7c7d51a469d8b25aed44'
assert sha(S/'probe/run_owned_full_scratch_lane.py')==p['runner_sha256']
inputs=dict(p['protected_inputs'])
for name in [p['method_path'],p['compile_lifecycle_path'],'docs/reviews/v1-7-recognizable-content/ordinary-leafa-baseline-method-proposal-r2.json','docs/reviews/v1-7-recognizable-content/ordinary-leafa-baseline-method-review-r2.json']:
 inputs[name]=sha(R/name)
scratch=dict(p['scratch_bindings']);scratch[p['compile_lifecycle_scratch']]=p['compile_lifecycle_sha256'];scratch[p['runner_path']]=p['runner_sha256']
limits=dict(p['limits']);limits.pop('campaign_seconds_max')
m={'schema':'v1-7-ordinary-leafa-native-baseline-admission-r1','lane':'v17-ordinary-leafa-native-baseline-r1','checked_at_utc':now.isoformat(),'deadline_utc':(now+datetime.timedelta(seconds=1200)).isoformat(),'fresh_headroom':{'disk_free_bytes':free,'memory_available_bytes':mem},'runner_sha256':p['runner_sha256'],'commands':p['commands_before_admission_template'],'environment':p['environment'],'inputs':inputs,'unchanged':p['protected_inputs'],'scratch_bindings':scratch,'limits':limits,'additional_measure_dirs':[],'measurement_roots':[str(S),str(R)],'max_agents_including_root':3,'actual_execution_workers':1,'method_proposal_sha256':sha(D/'ordinary-leafa-baseline-method-proposal-r2.json'),'method_review_sha256':sha(review),'installation_approval':False,'scope':'Exactly one Source6 ordinary leafă baseline build/run from independently accepted R2. No data/pool/runtime/source7 change, no forced case or wider search. All S/R growth, 180second metadata reserve and immutable original campaign clock.'}
out=D/'ordinary-leafa-native-baseline-admission-r1.json'
with out.open('x') as f:json.dump(m,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
print(out.name,sha(out),m['checked_at_utc'],m['deadline_utc'],free,mem)
