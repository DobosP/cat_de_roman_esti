from pathlib import Path
import ast,copy,hashlib,json,os,pathlib,stat as filemode,tempfile,sys
if sys.flags.optimize:raise RuntimeError("unoptimized controls required")
S=Path(r"C:/Users/Paul Work/personal_repos/_temp/codex__content-v1-7");P=S/"probe";T=json.loads((P/"native-current-rail-modules-template-r5.json").read_text())
nodes=[]
for flavor in ["windows","linux"]:
 tree=ast.parse((P/f"native-current-rail-modules-{flavor}-r5.py").read_text())
 items=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ["unique_json_pairs","population_proof"]];nodes.append(items)
assert [ast.dump(n,include_attributes=False) for n in nodes[0]]==[ast.dump(n,include_attributes=False) for n in nodes[1]]
parent=P/"module-control-fixtures";parent.mkdir(exist_ok=True);checks=0
with tempfile.TemporaryDirectory(prefix="owned-",dir=parent) as td:
 root=Path(td);assert root.resolve().is_relative_to(parent.resolve());base=root/"cache";base.mkdir();consumer=root/"consumer";consumer.mkdir()
 (consumer/"go.mod").write_bytes(b"fixed module\n");(consumer/"go.sum").write_bytes(b"fixed ten rows\n")
 spec={"windows_population_cache":str(base),"linux_population_cache":"/virtual-native-cache","windows_consumer":str(consumer),"download_tuples":T["download_tuples"],"consumer_hashes":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in consumer.iterdir()}}
 rows=[]
 for m in T["download_tuples"]:
  directory=base/(m["path"]+"@"+m["version"]);directory.mkdir(parents=True)
  cache=base/"cache/download"/m["path"]/"@v";cache.mkdir(parents=True)
  (cache/(m["version"]+".info")).write_bytes(json.dumps({"Version":m["version"]}).encode())
  (cache/(m["version"]+".mod")).write_bytes(b"same go.mod\n");(directory/"go.mod").write_bytes(b"same go.mod\n")
  (cache/(m["version"]+".zip")).write_bytes(b"opaque source fixture, not genuine Go ZIP validation")
  (cache/(m["version"]+".ziphash")).write_bytes(m["payload_h1"].encode());(cache/(m["version"]+".lock")).write_bytes(b"");(cache/"list").write_bytes((m["version"]+"\n").encode())
  row={"Path":m["path"],"Version":m["version"],"Sum":m["payload_h1"],"GoModSum":m["go_mod_h1"]}
  for field,p in {"Info":cache/(m["version"]+".info"),"GoMod":cache/(m["version"]+".mod"),"Zip":cache/(m["version"]+".zip"),"Dir":directory}.items():row[field]="/virtual-native-cache/"+p.relative_to(base).as_posix()
  rows.append(row)
 env={"pathlib":pathlib,"json":json,"hashlib":hashlib,"os":os,"filemode":filemode,"spec":spec};exec(compile(ast.Module(body=nodes[0],type_ignores=[]),"current-helper","exec"),env)
 proof=env["population_proof"]
 def check(data,accept):
  global checks
  raw=data if isinstance(data,bytes) else ("\n".join(json.dumps(r) for r in data)+"\n").encode()
  try:result=proof(raw,"windows")
  except (AssertionError,RuntimeError,ValueError,KeyError,TypeError):
   assert not accept;result=None
  else:assert accept
  checks+=1;return result
 first=check(rows,True);assert check(list(reversed(rows)),True)==first
 check(rows[:4],False);check(rows+[rows[0]],False)
 for key,values in {"Error":[False,0,None,[],{},"failed"],"Query":[False,0,None,[],{},"latest"],"Reuse":[0,None,"false",True],"Sum":["h1:wrong"],"GoModSum":["h1:wrong"],"Info":["C:/outside-cache.info"],"Version":["v0.0.0"]}.items():
  for value in values:
   mutated=copy.deepcopy(rows);mutated[0][key]=value;check(mutated,False)
 for key,value in [("Error",""),("Query",""),("Reuse",False)]:
  mutated=copy.deepcopy(rows);mutated[0][key]=value;check(mutated,True)
 check(b'{"Path":"a","Path":"b"}',False);check(("\n".join(json.dumps(r) for r in rows)+" trailing").encode(),False)
 m=T["download_tuples"][0];cache=base/"cache/download"/m["path"]/"@v";directory=base/(m["path"]+"@"+m["version"])
 for p,bad in [(cache/(m["version"]+".lock"),b"not empty"),(cache/"list",b"wrong\n"),(cache/(m["version"]+".ziphash"),b"h1:wrong"),(directory/"go.mod",b"wrong")]:
  old=p.read_bytes();p.write_bytes(bad);check(rows,False);p.write_bytes(old)
 (directory/"fixture.lock").write_bytes(b"valid authenticated source payload fixture");check(rows,True);(directory/"fixture.lock").unlink()
 unexpected=cache/"unexpected.tmp";unexpected.write_bytes(b"x");check(rows,False);unexpected.unlink()
 extra=consumer/"extra";extra.write_bytes(b"x");check(rows,False);extra.unlink()
 assert root.resolve().is_relative_to(parent.resolve())
print(json.dumps({"kind":"PASS","controlled_scenarios":checks,"both_helper_AST_equal":True,"scope":"Synthetic parser/path/schema/namespace controls only; no module ZIP h1 or native download qualification."}))
