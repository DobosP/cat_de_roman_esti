import json,os,pathlib,signal,subprocess,sys,time,hashlib
spec_bytes=pathlib.Path(sys.argv[1]).read_bytes()
expected_spec=sys.argv[2]
if sys.flags.optimize or os.environ.get("PYTHONOPTIMIZE"): raise RuntimeError("optimized Python refused")
if hashlib.sha256(spec_bytes).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")
spec=json.loads(spec_bytes.decode("utf-8"))
index=int(sys.argv[3]); step=spec["steps"][index]; run=pathlib.Path(spec["linux_run"])
mono_deadline=time.monotonic()+spec["deadline_epoch"]-time.time()
if spec["deadline_epoch"]-spec["started_epoch"]!=1200: raise RuntimeError("campaign duration drift")
cancel=run/"cancel"; pgid=None; child=None; initial=None; peak=0; error=None
def emit(v): print(json.dumps(v,separators=(",",":")),flush=True)
def stat(pid):
 try:
  t=pathlib.Path("/proc",str(pid),"stat").read_text(); f=t[t.rfind(")")+2:].split()
  return int(f[2]),int(f[19]),int(f[21])*os.sysconf("SC_PAGE_SIZE"),f[0]
 except (FileNotFoundError,ProcessLookupError): return None
def group():
 rows=[]
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdigit(): continue
  v=stat(p.name)
  if v and (int(p.name)==os.getpid() or v[0]==pgid): rows.append((int(p.name),*v))
 return rows
def memory():
 return int(next(x.split()[1] for x in pathlib.Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")))*1024
stopping=False
def interrupted(signum,frame):
 global stopping
 stopping=True
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
def spec_pin():
 if hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest()!=expected_spec: raise RuntimeError("spec SHA drift")
def cleanup():
 if child is None: return
 leader=stat(child.pid)
 if leader is not None and initial is not None and leader[1]!=initial[1]: raise RuntimeError("owned leader generation changed")
 if any(x[1]==pgid and x[4]!="Z" for x in group()):
  try: os.killpg(pgid,signal.SIGTERM)
  except ProcessLookupError: pass
  end=time.monotonic()+2
  while time.monotonic()<end and any(x[1]==pgid and x[4]!="Z" for x in group()): time.sleep(.05)
  if any(x[1]==pgid and x[4]!="Z" for x in group()):
   try: os.killpg(pgid,signal.SIGKILL)
   except ProcessLookupError: pass
 child.wait(timeout=5)
 if any(x[1]==pgid for x in group()): raise RuntimeError("owned group still present")
try:
 spec_pin()
 assert hashlib.sha256(pathlib.Path("/usr/bin/python3.14").read_bytes()).hexdigest()==spec["python_sha256"]
 assert memory()>=spec["memory_floor"]
 assert time.time()<spec["deadline_epoch"]-195
 for path,digest in spec["linux_protected"].items():
  assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
 executable=pathlib.Path(step["argv"][0]); executable.chmod(executable.stat().st_mode|0o100)
 assert hashlib.sha256(executable.read_bytes()).hexdigest()==spec["rail_sha256"]
 env=os.environ.copy(); env.update({"GOMAXPROCS":"2","GOTOOLCHAIN":"local","GOPROXY":"off","GOSUMDB":"off","TMPDIR":str(run/"tmp")})
 with (run/(step["name"]+".stdout.log")).open("wb") as out,(run/(step["name"]+".stderr.log")).open("wb") as err:
  spec_pin();assert not stopping,"cooperative signal"
  assert memory()>=spec["memory_floor"]
  assert time.monotonic()<mono_deadline-195 and time.time()<spec["deadline_epoch"]-195
  child=subprocess.Popen(step["argv"],cwd=spec["linux_stage"],env=env,stdout=out,stderr=err,start_new_session=True)
  pgid=child.pid; initial=stat(pgid); assert initial is not None
  while True:
   rows=group(); rss=sum(x[3] for x in rows); peak=max(peak,rss)
   emit({"kind":"sample","rss":rss,"peak":peak,"pid":child.pid,"start_ticks":initial[1]})
   if stopping or rss>spec["rss_cap"] or memory()<spec["memory_floor"] or cancel.exists() or (time.time()>=spec["deadline_epoch"]-180 or time.monotonic()>=mono_deadline-180): raise RuntimeError("native RSS/memory/cancel/reserve guard")
   done=os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
   if done is not None: break
   time.sleep(.25)
  assert done.si_code==os.CLD_EXITED and done.si_status==0,("command exited",done.si_code,done.si_status)
 cleanup();spec_pin()
 for path,digest in spec["linux_protected"].items(): assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
 assert hashlib.sha256(pathlib.Path("/usr/bin/python3.14").read_bytes()).hexdigest()==spec["python_sha256"]
 assert not stopping,"cooperative signal before completion"
 emit({"kind":"complete","step":step["name"],"returncode":0,"native_peak":peak,"group_absent":True})
except BaseException as exc:
 error=repr(exc);absent=False
 try: cleanup();absent=True
 except BaseException as cleanup_error: error+=";cleanup="+repr(cleanup_error)
 emit({"kind":"failed","step":step["name"],"error":error,"native_peak":peak,"group_absent":absent})
 sys.exit(1)
