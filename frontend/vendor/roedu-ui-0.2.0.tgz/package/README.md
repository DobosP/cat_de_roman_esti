# @roedu/ui

Shared React design system for the RO-EDU consumer apps — tokens, themeable components,
a11y patterns, and a shared API client. **Common artifacts live here; each app themes
them into its own identity.** Full rationale + roadmap: [`ARCHITECTURE.md`](./ARCHITECTURE.md).

## Quick start (in a consuming app)

```bash
# .npmrc in the app repo:  @roedu:registry=https://npm.pkg.github.com
npm install @roedu/ui
```

```tsx
import { ThemeProvider, Button, Card, Stack } from '@roedu/ui';
import '@roedu/ui/styles.css';

const appTheme = { color: { primary: '#ff5c8a' } }; // the app's bespoke identity

export function App() {
  return (
    <ThemeProvider theme={appTheme}>
      <Card>
        <Stack gap="md">
          <h1>RO-EDU</h1>
          <Button variant="primary">Start</Button>
        </Stack>
      </Card>
    </ThemeProvider>
  );
}
```

Everything under `<ThemeProvider>` picks up the app's theme via CSS variables. See
[`docs/theming.md`](./docs/theming.md) and [`docs/consuming-django-react.md`](./docs/consuming-django-react.md).

## Develop this library

```bash
npm install
npm run typecheck   # tsc --noEmit
npm run build       # -> dist/index.js + dist/roedu-ui.css + dist/index.d.ts
npm run dev         # build --watch
```

## Layout

```
src/
  theme/        ThemeProvider, createTheme, base tokens, types (theming engine)
  styles/       reset.css + tokens.css (base CSS variables)
  components/   Button, Card, Stack, Container, Input (themeable, a11y)
  lib/          apiClient (shared RO-EDU fetch client)
  index.ts      public API
docs/
  theming.md, consuming-django-react.md, app-sessions/  (per-app build prompts)
ARCHITECTURE.md the plan / source of truth
```
