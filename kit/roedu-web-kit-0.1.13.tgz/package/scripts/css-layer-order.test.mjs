import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import roeduCssLayerOrder,{ layerOrderStatement,prependLayerOrder } from './css-layer-order.mjs';

// Pure transformation and plugin-contract fixtures; no release outputs or
// receipt files are created. Distribution qualification uses actual npm bytes.
const statement='@layer reset,tokens,base,components,utilities,app;';
const base=readFileSync(new URL('../../src/css/base.css',import.meta.url));
test('owning base source states the canonical six layers before any rules',()=>{
  assert.equal(layerOrderStatement(base),statement);
});
test('bundled components-first CSS gains order without changing existing bytes',()=>{
  const original=Buffer.from('@layer components{.roedu-btn{font:600 14px/1 sans-serif}}\n@layer reset{button{font:inherit}}');
  const output=prependLayerOrder(original,base);
  assert.equal(output.subarray(0,statement.length+1).toString(),statement+'\n');
  assert.deepEqual(output.subarray(statement.length+1),original);
  assert.deepEqual(prependLayerOrder(output,base),output);
});
test('existing first canonical statement remains byte-identical',()=>{
  const original=Buffer.from(statement+'\n@layer components{.label::before{content:"Țară"}}');
  assert.deepEqual(prependLayerOrder(original,base),original);
  assert.deepEqual(prependLayerOrder(new Uint8Array(original),base),original);
});
test('source formatting is normalized while its layer sequence stays exact',()=>{
  assert.equal(layerOrderStatement('  @layer reset, tokens, base, components, utilities, app;\n'),statement);
});
for(const source of ['', '@layer components{button{color:red}}', '@layer tokens,reset,base,components,utilities,app;',
  '@layer reset,tokens,base,components,utilities;', '@layer reset,tokens,base,components,utilities,app,app;']) {
  test(`invalid canonical source is refused: ${source||'empty'}`,()=>{
    assert.throws(()=>prependLayerOrder('@layer components{}',source),/canonical base/);
  });
}
test('missing or non-byte emitted CSS cannot create a passing empty stylesheet',()=>{
  assert.throws(()=>prependLayerOrder('',base),/nonempty/);
  for(const value of [undefined,null,{},42])assert.throws(()=>prependLayerOrder(value,base),/bytes required/);
});
test('post generateBundle updates only CSS before the inventory write hook',()=>{
  const plugin=roeduCssLayerOrder(),chunk={type:'chunk',code:'export const unchanged=true;'},source='@layer components{button{font-weight:600}}';
  const bundle={'roedu-ui.css':{type:'asset',source},'index.js':chunk};
  assert.equal(plugin.enforce,'post');assert.equal(plugin.generateBundle.order,'post');
  plugin.configResolved({root:fileURLToPath(new URL('../../',import.meta.url))});
  plugin.generateBundle.handler({},bundle);
  assert.deepEqual(bundle['roedu-ui.css'].source,Buffer.from(statement+'\n'+source));
  assert.equal(bundle['index.js'],chunk);assert.equal(chunk.code,'export const unchanged=true;');
});
test('missing configured root or stylesheet asset fails closed',()=>{
  const plugin=roeduCssLayerOrder();
  assert.throws(()=>plugin.generateBundle.handler({},{}),/owning root/);
  plugin.configResolved({root:fileURLToPath(new URL('../../',import.meta.url))});
  for(const bundle of [{},{'roedu-ui.css':{type:'chunk',code:'wrong'}}])assert.throws(()=>plugin.generateBundle.handler({},bundle),/actual roedu-ui.css/);
});
